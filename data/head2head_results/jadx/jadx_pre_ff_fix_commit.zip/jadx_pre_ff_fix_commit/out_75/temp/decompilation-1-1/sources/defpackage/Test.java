package defpackage;

import java.io.PrintStream;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_75/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static double[] dArrFld;
    public static long iMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = 1123347078;
    public static volatile byte byFld = 70;
    public static float fFld = 0.129f;
    public static int iFld = 216;

    static {
        double[] dArr = new double[N];
        dArrFld = dArr;
        FuzzerUtils.init(dArr, 63.108622d);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }

    public static void vMeth1(long j, long j2) {
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(iArr, 172);
        FuzzerUtils.init(fArr, 82.79f);
        long j3 = j2;
        double d = 2.0d;
        int i = 19903;
        int i2 = 0;
        int i3 = -107;
        int i4 = -6;
        while (d < 127.0d) {
            iArr = FuzzerUtils.int1array(N, 6);
            int i5 = (int) d;
            fArr[i5] = fArr[i5] + i;
            byFld = (byte) (byFld + 1);
            int i6 = 1;
            while (i6 < 13) {
                i4 = 1;
                while (i4 < 2) {
                    i3 = -11;
                    i = (int) instanceCount;
                    i4++;
                }
                fFld -= 179;
                i6++;
            }
            float f = fFld;
            long j4 = f;
            i3 += i5;
            fFld = f - i4;
            d += 1.0d;
            i2 = i6;
            j3 = j4;
        }
        vMeth1_check_sum += j3 + j + Double.doubleToLongBits(d) + i + i2 + i3 + i4 + 179 + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public static void vMeth(int i) {
        long j = instanceCount;
        vMeth1(j, j);
        int i2 = 235;
        int i3 = 156;
        int i4 = 5;
        while (331 > i4) {
            int i5 = 1;
            while (true) {
                i5++;
                if (i5 < 14) {
                    i <<= i;
                    i3 = 1;
                }
            }
            i4 += 3;
            i2 = i5;
        }
        vMeth_check_sum += (((((((i + i4) + 187) + i2) + 0) + i3) - 34629) + 9685) - 1;
    }

    public static int iMeth(int i) {
        vMeth(i);
        int i2 = i * i;
        int i3 = 270;
        while (true) {
            i3--;
            if (i3 <= 0) {
                break;
            }
            int i4 = (i2 + (((i3 * i2) + i3) - i3)) >> byFld;
            instanceCount = i4;
            try {
                int i5 = i3 % (-33512);
                iFld = i5;
                iFld = i3 % i5;
                i4 = i3 % (-31781);
            } catch (ArithmeticException e) {
            }
            i2 = i4 + i3;
        }
        long j = instanceCount;
        instanceCount = j >> ((int) j);
        int i6 = i2 - 55;
        int i7 = 6;
        int i8 = 4;
        while (371 > i7) {
            fFld -= (float) instanceCount;
            i7++;
            i8 = 150;
        }
        long j2 = i6 + i3 + i7 + i8 + 150;
        iMeth_check_sum += j2;
        return (int) j2;
    }

    public void mainTest(String[] strArr) {
        int i;
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(iArr, -86);
        FuzzerUtils.init(fArr, 0.386f);
        int i2 = 45957;
        double d = 1.0d;
        do {
            iMeth(iFld);
            int i3 = iFld;
            int i4 = i3 * i3;
            iFld = i4;
            iFld = i4 * i4;
            i = (int) d;
            while (75 > i) {
                float f = fFld;
                fFld = f - f;
                i2 -= (int) 195;
                i++;
            }
            d += 1.0d;
        } while (d < 336.0d);
        int i5 = 368;
        while (i5 > 10) {
            long j = instanceCount << ((int) 195);
            instanceCount = j;
            instanceCount = j + (i5 * i5) + 4;
            i5--;
        }
        iFld = 76022876;
        iArr[(i5 >>> 1) % N] = iArr[r4] - 13637;
        FuzzerUtils.out.println("d i17 i18 = " + Double.doubleToLongBits(d) + "," + i + "," + i2);
        FuzzerUtils.out.println("l2 i19 i20 = 195," + i5 + ",17317");
        FuzzerUtils.out.println("l3 i21 i22 = -4289381791,-40701,-48491");
        FuzzerUtils.out.println("i23 i24 i25 = -227,3,52077");
        FuzzerUtils.out.println("s1 i26 i27 = 28792,5,20666");
        FuzzerUtils.out.println("i28 iArr1 fArr1 = -13," + FuzzerUtils.checkSum(iArr) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)));
        PrintStream printStream = FuzzerUtils.out;
        long j2 = instanceCount;
        byte b = byFld;
        printStream.println("Test.instanceCount Test.byFld Test.fFld = " + j2 + "," + ((int) b) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.iFld Test.dArrFld = " + iFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

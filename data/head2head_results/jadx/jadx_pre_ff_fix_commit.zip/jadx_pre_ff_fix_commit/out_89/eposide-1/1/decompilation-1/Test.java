
import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_89/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static float[] fArrFld;
    public static long iMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = 8091256981805891036L;
    public static short sFld = 28484;
    public static boolean bFld = true;
    public static byte byFld = -28;
    public int iFld = -14479;
    public int[] iArrFld = new int[N];

    static {
        float[] fArr = new float[N];
        fArrFld = fArr;
        FuzzerUtils.init(fArr, 17.494f);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }

    public static void vMeth1(int i, int i2) {
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -3420664041L);
        FuzzerUtils.init(iArr, -8);
        int i3 = (i ^ ((int) instanceCount)) + 4975;
        jArr[(i3 >>> 1) % N] = -38;
        int i4 = i3 >> (-33180);
        instanceCount = 119L;
        int i5 = 97;
        int i6 = 10;
        int i7 = 12;
        int i8 = 12;
        while (i7 < 271) {
            i4 %= 3;
            int i9 = i8;
            int i10 = i6;
            int i11 = 1;
            while (i11 < 6) {
                i4 <<= i4;
                i9 = 1;
                while (i9 < 2) {
                    iArr = FuzzerUtils.int2array(N, -61173);
                    instanceCount = i9;
                    i9++;
                }
                sFld = (short) (sFld + ((short) (i11 * i2)));
                i10 *= (int) instanceCount;
                i11++;
            }
            i7++;
            i5 = i11;
            i6 = i10;
            i8 = i9;
        }
        vMeth1_check_sum += i4 + i2 + i7 + 3 + i5 + i6 + i8 + 12 + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth(int i, int i2, int i3) {
        int i4;
        int i5 = N;
        int[] iArr = new int[N];
        short[] sArr = new short[N];
        FuzzerUtils.init(sArr, (short) 18421);
        int i6 = -1;
        FuzzerUtils.init(iArr, -1);
        int i7 = i3;
        vMeth1(-23, i7);
        int i8 = i2;
        int i9 = 86;
        int i10 = -2;
        int i11 = 65244;
        int i12 = 0;
        while (i12 < i5) {
            short s = sArr[i12];
            iArr[377] = iArr[377] + 118;
            int i13 = i11;
            int i14 = i10;
            int i15 = 1;
            while (i15 < 4) {
                i7 += ((i15 * i15) + i6) - i6;
                bFld = bFld;
                int i16 = i15 % 2;
                if (i16 + 57 != 58) {
                    i4 = i8;
                } else if (i16 != 0) {
                    if (i16 == 1) {
                        i4 = i8;
                        int i17 = i15 - 1;
                        iArr[i17] = iArr[i17] >> i4;
                    } else {
                        long j = instanceCount;
                        i4 = i8;
                        instanceCount = j + (((i15 * j) + i13) - j);
                    }
                } else {
                    int i18 = i8;
                    int i19 = i15 % 6;
                    if (i19 != 0) {
                        if (i19 != 1) {
                            if (i19 == 2) {
                                i13 -= i7;
                                i8 = i18;
                            } else if (i19 == 3) {
                                i13 *= sFld;
                                i8 = i18;
                            } else if (i19 == 4) {
                                i8 = i18 >>> (-35470);
                            } else {
                                if (i19 == 5 && i15 != 0) {
                                    vMeth_check_sum += ((((i + i18) + i7) + i15) - 1) + Double.doubleToLongBits(-2.5814d) + i14 + i13 + 31 + FuzzerUtils.checkSum(sArr) + FuzzerUtils.checkSum(iArr);
                                    return;
                                }
                                i8 = i18;
                            }
                            i15++;
                            i6 = -1;
                        }
                    } else {
                        i14 = 1;
                        while (2 > i14) {
                            i7 *= 31;
                            i14++;
                        }
                    }
                    long j2 = instanceCount;
                    instanceCount = j2 >> ((int) j2);
                    i8 = i18;
                    i15++;
                    i6 = -1;
                }
                i8 = i4;
                i15++;
                i6 = -1;
            }
            i12++;
            i9 = i15;
            i10 = i14;
            i11 = i13;
            i5 = N;
            i6 = -1;
        }
        vMeth_check_sum += ((((i + i8) + i7) + i9) - 1) + Double.doubleToLongBits(-2.5814d) + i10 + i11 + 31 + FuzzerUtils.checkSum(sArr) + FuzzerUtils.checkSum(iArr);
    }

    public int iMeth(int i, double d) {
        int i2 = 4;
        int i3 = -5;
        float f = -2.87f;
        int i4 = 1;
        int i5 = 9;
        while (true) {
            i4++;
            if (i4 < 181) {
                int i6 = this.iFld;
                int i7 = i6 << i6;
                this.iFld = i7;
                vMeth(i7, i4, -108);
                i = 1;
                i2 = 1;
                while (i2 < 9) {
                    i *= 156;
                    this.iArrFld[i2] = this.iFld;
                    i3 = 1;
                    while (i3 < 2) {
                        long j = instanceCount;
                        this.iArrFld[i3 - 1] = (int) j;
                        i |= (int) j;
                        f *= i3;
                        instanceCount = j << ((int) j);
                        i3++;
                    }
                    f += i2 * i2;
                    i2++;
                    i5 = i4;
                }
            } else {
                long doubleToLongBits = ((((((i + Double.doubleToLongBits(d)) + i4) + i2) + i5) + i3) - 2027) + Float.floatToIntBits(f);
                iMeth_check_sum += doubleToLongBits;
                return (int) doubleToLongBits;
            }
        }
    }

    public void mainTest(String[] strArr) {
        int i;
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -205616215L);
        FuzzerUtils.init(iArr, -17);
        float f = -28.762f;
        int i2 = (int) (-28.762f);
        this.iFld = i2;
        long j = jArr[(i2 >>> 1) % N];
        long j2 = instanceCount + 1;
        instanceCount = j2;
        int min = i2 - ((int) Math.min(j, j2));
        this.iFld = min;
        this.iFld = min - ((int) (instanceCount + iMeth(min, -2.69211d)));
        sFld = (short) (sFld >>> (-27197));
        boolean z = bFld;
        int i3 = 1;
        int i4 = -134;
        int i5 = 97;
        int i6 = -8;
        if (z) {
            int i7 = 4;
            while (134 > i7) {
                int i8 = ((i7 % 2) * 5) + 100;
                if (i8 == 102) {
                    this.iFld -= sFld;
                    f *= i7;
                } else if (i8 != 105) {
                    i7++;
                    i3 = 1;
                }
                int i9 = i7 - 1;
                long j3 = instanceCount;
                jArr[i9] = j3;
                int i10 = (int) j3;
                this.iFld = i10;
                int i11 = (((i10 >>> 1) % 6) * 5) + 14;
                if (i11 != 16) {
                    if (i11 != 18) {
                        if (i11 == 28) {
                            this.iFld = (int) f;
                        } else {
                            if (i11 == 37) {
                                float[] fArr = fArrFld;
                                fArr[i7] = fArr[i7] + i10;
                                this.iArrFld[i9] = i10;
                            } else if (i11 == 34) {
                                int i12 = (int) (i10 + (i7 ^ j3));
                                this.iFld = i12;
                                int i13 = i12 + 1562642782;
                                this.iFld = i13;
                                if (!bFld) {
                                    this.iFld = i13 - 81;
                                }
                            } else if (i11 != 35) {
                                i4 = 1562642782 + (i7 | i5);
                            } else {
                                int i14 = 1;
                                while (true) {
                                    i4 = -7;
                                    i14 += i3;
                                    if (i14 >= 193) {
                                        break;
                                    } else {
                                        i6 = 2;
                                    }
                                }
                                i5 = i14;
                            }
                            i4 = 1562642782;
                        }
                    }
                    i4 = 1562642782 + i7;
                } else {
                    f += (float) (-2.69211d);
                    i4 = 1562642782;
                }
                i7++;
                i3 = 1;
            }
            i = i7;
        } else if (z) {
            i4 = (int) (-2.69211d);
            i = 1;
        } else {
            byFld = (byte) (byFld * ((byte) (-81)));
            i = 1;
        }
        FuzzerUtils.out.println("f d2 i21 = " + Float.floatToIntBits(f) + "," + Double.doubleToLongBits(-2.69211d) + "," + i);
        FuzzerUtils.out.println("i22 i23 i24 = " + i4 + ",-81," + i5);
        FuzzerUtils.out.println("i25 lArr iArr2 = " + i6 + "," + FuzzerUtils.checkSum(jArr) + "," + FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.sFld = " + instanceCount + "," + this.iFld + "," + ((int) sFld));
        PrintStream printStream = FuzzerUtils.out;
        boolean z2 = bFld;
        byte b = byFld;
        printStream.println("Test.bFld Test.byFld iArrFld = " + (z2 ? 1 : 0) + "," + ((int) b) + "," + FuzzerUtils.checkSum(this.iArrFld));
        PrintStream printStream2 = FuzzerUtils.out;
        long doubleToLongBits = Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld));
        StringBuilder sb = new StringBuilder();
        sb.append("Test.fArrFld = ");
        sb.append(doubleToLongBits);
        printStream2.println(sb.toString());
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

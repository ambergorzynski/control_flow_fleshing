
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_40/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long iMeth_check_sum;
    public static long lMeth_check_sum;
    public static long vMeth_check_sum;
    public float fFld = 117.493f;
    public volatile long lFld = 2416172527L;
    public static long instanceCount = 4806054886177115960L;
    public static int iFld = -9418;
    public static final int N = 400;
    public static volatile int[] iArrFld = new int[N];

    static {
        FuzzerUtils.init(iArrFld, -1);
        vMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
    }

    public static int iMeth(int i) {
        int i2 = -20696;
        int i3 = 62058;
        int i4 = 8;
        int i5 = 41169;
        float f = 0.39f;
        int i6 = 5;
        while (i6 < 278) {
            i3 = i6;
            while (i3 < 6) {
                f = i;
                i2 -= i6;
                long j = instanceCount;
                iArrFld[i3 - 1] = (int) j;
                instanceCount = j ^ j;
                i |= i2;
                i3++;
                i4 = 1;
            }
            float f2 = f;
            int i7 = i6;
            while (i7 < 6) {
                iFld = 5177;
                f2 -= (float) (-2.96498d);
                i7++;
            }
            i6++;
            int i8 = i7;
            f = f2 + f2;
            i5 = i8;
        }
        long floatToIntBits = (((((((((((i + i6) + i2) + i3) - 225) + Float.floatToIntBits(f)) + i4) + 70) + 1) - 166) + i5) - 76) + Double.doubleToLongBits(-2.96498d);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static long lMeth(byte b) {
        int i;
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr, 2);
        FuzzerUtils.init(jArr, 4L);
        int i2 = -22983;
        int i3 = -8;
        float f = 176.0f;
        while (true) {
            f -= 2.0f;
            if (f > 0.0f) {
                int i4 = iFld;
                int i5 = i4 + 1;
                iFld = i5;
                long j = instanceCount - 1;
                instanceCount = j;
                instanceCount = i4 + (j | j);
                iFld = i5 - 1;
                iFld = i5 * i5;
                int i6 = 1;
                while (true) {
                    i = i6 + 1;
                    if (i < 18) {
                        int i7 = iFld;
                        int i8 = (int) (i7 + (((i * f) + ((float) instanceCount)) - i7));
                        iFld = i8;
                        try {
                            int i9 = i + 1;
                            iArr[(int) f][i9] = i / i8;
                            iFld = iArr[i9][(int) (1.0f + f)] % i8;
                            iFld = i / i;
                        } catch (ArithmeticException e) {
                        }
                        iFld = (int) 57.51107d;
                        i6 = i;
                        i3 = 2;
                    }
                }
                i2 = i;
            } else {
                long floatToIntBits = b + Float.floatToIntBits(f) + i2 + 1 + i3 + Double.doubleToLongBits(57.51107d) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr);
                lMeth_check_sum += floatToIntBits;
                return floatToIntBits;
            }
        }
    }

    public void vMeth(int i, short s, int i2) {
        lMeth((byte) 91);
        int i3 = iFld << i2;
        iFld = i3;
        instanceCount -= i3;
        int i4 = 14;
        int i5 = 33240;
        int i6 = 120;
        int i7 = 1;
        while (true) {
            i7 += 2;
            if (i7 >= 176) {
                vMeth_check_sum += i3 + s + i2 + 91 + 1 + i7 + i4 + i5 + 81 + Double.doubleToLongBits(-2.60086d) + i6 + 61;
                return;
            }
            i4 = 1;
            while (true) {
                i4++;
                if (i4 < 18) {
                    i5 = 1;
                    i6 = 1;
                }
            }
        }
    }

    public void mainTest(String[] strArr) {
        double[][] dArr;
        double[][] dArr2 = (double[][]) Array.newInstance((Class<?>) double.class, N, N);
        FuzzerUtils.init(dArr2, 1.114414d);
        double[] dArr3 = dArr2[88];
        dArr2[6] = dArr3;
        dArr2[2] = dArr3;
        dArr2[88] = dArr3;
        dArr2[88] = dArr3;
        int i = -2319;
        int i2 = -39455;
        int i3 = 12;
        int i4 = -17;
        int i5 = -9;
        int i6 = 51629;
        int i7 = -145;
        short s = -15372;
        int i8 = 281;
        while (true) {
            i8--;
            if (i8 > 0) {
                vMeth(i, s, 30100);
                switch ((i8 % 3) + 16) {
                    case 16:
                    case 17:
                        instanceCount = -12509L;
                        i2 = 3;
                        while (i2 < 89) {
                            int i9 = (int) instanceCount;
                            iFld = i9;
                            instanceCount = i2;
                            i += i9;
                            i2++;
                        }
                    case 18:
                        i3 = 5;
                        while (i3 < 89) {
                            iArrFld[i8 + 1] = i8;
                            int i10 = (i4 - 84) << ((int) instanceCount);
                            iFld = (int) (iFld + (((1 * i3) + i10) - this.lFld));
                            i4 = i10 ^ 1726015176;
                            this.lFld = i3;
                            i3++;
                            dArr2 = dArr2;
                            i5 = 2;
                        }
                        dArr = dArr2;
                        iArrFld = FuzzerUtils.int1array(N, 240);
                        break;
                    default:
                        dArr = dArr2;
                        break;
                }
                i4 -= i8;
                i6 = 4;
                while (i6 < 89) {
                    i6++;
                    i7 = 1;
                }
                s = (short) (s * ((short) i7));
                dArr2 = dArr;
            } else {
                FuzzerUtils.out.println("i i1 s1 = " + i + "," + i8 + "," + ((int) s));
                FuzzerUtils.out.println("i24 i25 i26 = " + i2 + ",-84," + i3);
                FuzzerUtils.out.println("i27 i28 i29 = " + i4 + "," + i5 + "," + i6);
                FuzzerUtils.out.println("i30 i31 i32 = 0," + i7 + ",0");
                FuzzerUtils.out.println("b2 dArr = 1," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr2)));
                FuzzerUtils.out.println("Test.instanceCount Test.iFld fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(this.fFld));
                FuzzerUtils.out.println("lFld Test.iArrFld = " + this.lFld + "," + FuzzerUtils.checkSum(iArrFld));
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

package defpackage;

import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_50/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public int iFld = -112;
    public static long instanceCount = -62448;
    public static long fMeth_check_sum = 0;
    public static long lMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;

    public static void vMeth(double d, float f, short s) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 1);
        long j = instanceCount - 1;
        instanceCount = j;
        instanceCount = j << ((int) j);
        iArr[0] = (int) d;
        int i = -29179;
        int i2 = 1;
        int i3 = 1;
        while (true) {
            i2++;
            if (i2 < 195) {
                long j2 = instanceCount;
                i3 = (i3 + i2) >> ((int) j2);
                long j3 = j2 << 57;
                instanceCount = j3;
                long j4 = 1;
                long j5 = j3 + j4;
                instanceCount = j5;
                instanceCount = j5 + (((j4 * j5) + i3) - j5);
                i = 1;
            } else {
                vMeth_check_sum += Double.doubleToLongBits(d) + Float.floatToIntBits(f) + s + i3 + i2 + i + 51657 + 57 + 1 + FuzzerUtils.checkSum(iArr);
                return;
            }
        }
    }

    public static long lMeth(float f, int i, float f2) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 62300);
        short s = 21071;
        vMeth(-83.1227d, 0.287f, (short) 21071);
        long j = 23;
        while (j < 372) {
            f = -2920.0f;
            s = (short) j;
            j++;
        }
        long floatToIntBits = ((((((((((Float.floatToIntBits(f) + i) + Float.floatToIntBits(f2)) + Double.doubleToLongBits(-83.1227d)) + s) + j) + 32) - 207) + 1) + 57396) - 5) + 8 + 0 + ((byte) (-5)) + FuzzerUtils.checkSum(iArr);
        lMeth_check_sum += floatToIntBits;
        return floatToIntBits;
    }

    public static float fMeth() {
        int i = -10;
        int i2 = 73;
        float f = 2.69f;
        int i3 = 8;
        while (i3 < 183) {
            i += (int) lMeth(62.199f, -14540, 0.102f);
            i2 = 1;
            while (i2 < 9) {
                i &= i;
                long j = instanceCount;
                instanceCount = j - j;
                f = 2.0f;
                i2++;
            }
            i3++;
        }
        int i4 = i - 2;
        short s = (short) ((-18895) * ((short) instanceCount));
        int i5 = 15;
        while (i5 < 306) {
            i4 <<= 217;
            i5++;
        }
        long floatToIntBits = i3 + (i4 / (i3 | 1)) + Float.floatToIntBits(0.102f) + i2 + 45 + Float.floatToIntBits(f) + s + Double.doubleToLongBits(-4.6838636037947546E18d) + i5 + 0;
        fMeth_check_sum += floatToIntBits;
        return (float) floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        float[][] fArr = (float[][]) Array.newInstance((Class<?>) float.class, N, N);
        int i = -13;
        FuzzerUtils.init(iArr, -13);
        FuzzerUtils.init(fArr, 95.215f);
        long j = instanceCount;
        int i2 = ((int) (j * j)) + 61;
        int i3 = 38723;
        int i4 = 233;
        while (true) {
            i4 -= 2;
            if (i4 > 0) {
                int i5 = 1;
                while (true) {
                    i5++;
                    if (i5 < 214) {
                        i2--;
                        instanceCount += i5;
                        i3 = 1;
                    }
                }
                iArr[i4] = -19364;
                i = i5;
            } else {
                FuzzerUtils.out.println("i i1 i2 = " + i2 + "," + i4 + "," + i);
                FuzzerUtils.out.println("i3 i4 f5 = " + i3 + ",214," + Float.floatToIntBits(51.36f));
                FuzzerUtils.out.println("d3 s3 b2 = " + Double.doubleToLongBits(-1.48842d) + ",29283,0");
                FuzzerUtils.out.println("iArr2 fArr = " + FuzzerUtils.checkSum(iArr) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)));
                FuzzerUtils.out.println("Test.instanceCount iFld = " + instanceCount + "," + this.iFld);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
                FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}


import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_82/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static byte[] byArrFld;
    public static float[] fArrFld;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vSmallMeth_check_sum;
    public long[] lArrFld = new long[N];
    public static long instanceCount = -6154815280945900337L;
    public static int iFld = 2;
    public static float fFld = 0.608f;

    static {
        byte[] bArr = new byte[N];
        byArrFld = bArr;
        fArrFld = new float[N];
        FuzzerUtils.init(bArr, (byte) -86);
        FuzzerUtils.init(fArrFld, 0.856f);
        vSmallMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
    }

    public static int iMeth(long j, float f, boolean z) {
        int[] iArr = new int[N];
        double[] dArr = new double[N];
        FuzzerUtils.init(iArr, -173);
        FuzzerUtils.init(dArr, 124.57537d);
        int i = iFld;
        iArr[(i >>> 1) % N] = i;
        int i2 = i * ((int) f);
        iFld = i2;
        iFld = i2 + 96;
        long j2 = j;
        double d = 48.50419d;
        int i3 = 13;
        int i4 = -20002;
        int i5 = 223;
        while (i3 < 250) {
            double d2 = 1.0d;
            while (d2 < 7.0d) {
                i4 += (int) d2;
                d2 += 1.0d;
            }
            long j3 = instanceCount + (((i3 * (-22)) + iFld) - i3);
            instanceCount = j3;
            i4 += (int) j3;
            int i6 = 1;
            while (true) {
                i6++;
                if (i6 < 7) {
                    long j4 = instanceCount;
                    dArr[i6 - 1] = j4;
                    i4 -= 41594;
                    j2 += i4;
                    instanceCount = j4 - 203;
                }
            }
            i3++;
            i5 = i6;
            d = d2;
        }
        long floatToIntBits = (((((((j2 + Float.floatToIntBits(f)) + (z ? 1L : 0L)) + i3) + i4) + Double.doubleToLongBits(d)) + (15165 - i3)) - 22) + i5 + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth(long j) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -4);
        int iMeth = iMeth(instanceCount, fFld, true) * (-11);
        int i = 267;
        while (7 < i) {
            float[] fArr = fArrFld;
            fArr[41] = fArr[41] + iFld;
            i--;
        }
        int i2 = 1;
        while (230 > i2) {
            i2++;
            iArr[i2] = iArr[i2] * ((int) fFld);
        }
        byArrFld[(i2 >>> 1) % N] = (byte) (r6[r7] - 33);
        iArr[(iMeth >>> 1) % N] = (int) fFld;
        int i3 = 241;
        float f = 24.86f;
        int i4 = 1;
        while (true) {
            i4++;
            if (i4 < 137) {
                i3 = 11;
                while (i3 > 1) {
                    float f2 = 1.0f;
                    while (f2 < 2.0f) {
                        byArrFld = byArrFld;
                        int i5 = iFld + ((int) f2);
                        iFld = i5;
                        int i6 = (int) (f2 - 1.0f);
                        iArr[i6] = iArr[i6] * (-43512);
                        fFld += ((i4 * f2) + i5) - 1;
                        f2 += 1.0f;
                    }
                    i3--;
                    f = f2;
                }
            } else {
                iFld += i3;
                vMeth_check_sum += ((((((j + iMeth) + 1) + i) - 51) + i2) - 7) + i4 + i3 + 1 + Float.floatToIntBits(f) + 18 + FuzzerUtils.checkSum(iArr);
                return;
            }
        }
    }

    public static void vSmallMeth(int i, int i2) {
        vMeth(instanceCount);
        vSmallMeth_check_sum += i + i2;
    }

    public void mainTest(String[] strArr) {
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        int[] iArr2 = new int[N];
        FuzzerUtils.init(iArr, 2);
        FuzzerUtils.init(iArr2, -39784);
        long j = instanceCount;
        int[] iArr3 = iArr[43];
        iArr3[43] = iArr3[43] - 1;
        instanceCount = j + (-(174 + r7));
        int i = 87;
        int i2 = -252;
        int i3 = -12;
        int i4 = 10;
        short s = 7359;
        double d = 6.0d;
        while (d < 300.0d) {
            for (int i5 = 0; i5 < 62; i5++) {
                vSmallMeth(i2, i);
            }
            i3 = 1;
            while (86 > i3) {
                i4 += (int) ((i3 * i3) + 2746857203L);
                s = (short) (s + 41);
                i3++;
            }
            int[] iArr4 = iArr[(int) (d - 1.0d)];
            int i6 = (int) d;
            iArr4[i6] = iArr4[i6] & i3;
            i += i2;
            instanceCount = -12L;
            i2 = iFld;
            d += 1.0d;
        }
        iFld += 181;
        for (int i7 = 0; i7 < 400; i7++) {
            int i8 = iArr2[i7];
            i2 = -219;
        }
        int i9 = 4;
        int i10 = -14205;
        int i11 = -44732;
        long j2 = -232269950720414539L;
        while (i9 < 177) {
            j2 = i9;
            while (j2 < 145) {
                iArr[i9][(int) j2] = 9;
                instanceCount = s;
                j2++;
                i10 = 64580;
                i11 = 1;
            }
            i9++;
        }
        FuzzerUtils.out.println("i d i1 = " + i + "," + Double.doubleToLongBits(d) + "," + i2);
        FuzzerUtils.out.println("i17 i18 s = " + i3 + "," + i4 + "," + ((int) s));
        FuzzerUtils.out.println("b2 i20 i21 = 0," + i9 + ",64580");
        FuzzerUtils.out.println("l2 i22 i23 = " + j2 + "," + i10 + "," + i11);
        FuzzerUtils.out.println("i24 iArr iArr3 = 18683," + FuzzerUtils.checkSum(iArr) + "," + FuzzerUtils.checkSum(iArr2));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.byArrFld Test.fArrFld lArrFld = " + FuzzerUtils.checkSum(byArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(this.lArrFld));
        PrintStream printStream = FuzzerUtils.out;
        long j3 = iMeth_check_sum;
        StringBuilder sb = new StringBuilder();
        sb.append("iMeth_check_sum: ");
        sb.append(j3);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

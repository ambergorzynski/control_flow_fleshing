package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_52/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public int[][][] iArrFld = (int[][][]) Array.newInstance((Class<?>) int.class, N, N, N);
    public static long instanceCount = -7105456895305352589L;
    public static volatile boolean bFld = false;
    public static double dFld = -2.99432d;
    public static long vMeth_check_sum = 0;
    public static long dMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;

    public static int iMeth(int i) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 14);
        instanceCount *= 10;
        long j = ((long) 83.35386d) + 3;
        int i2 = 8443;
        int i3 = -5;
        int i4 = -41468;
        int i5 = 16995;
        float f = -2.554f;
        short s = 6460;
        int i6 = 8;
        while (i6 < 369) {
            int i7 = i3;
            int i8 = 1;
            while (i8 < 5) {
                i7 = (int) (i7 + (((i8 * f) + i6) - ((float) j)));
                s = (short) (s >> ((short) instanceCount));
                i8++;
            }
            j = -41448;
            float f2 = f - ((float) instanceCount);
            int i9 = i5;
            int i10 = 1;
            while (i10 < 5) {
                i9 = 1;
                while (i9 < 2) {
                    j *= i6;
                    f2 -= (float) 83.35386d;
                    i9++;
                }
                i10++;
            }
            i6++;
            i2 = i8;
            i3 = i7;
            i4 = i10;
            i5 = i9;
            f = f2;
        }
        long doubleToLongBits = ((((((((((i + j) + Double.doubleToLongBits(83.35386d)) + i6) - 199) + i2) + i3) + Float.floatToIntBits(f)) + s) + i4) - 8) + i5 + 108 + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static double dMeth(int i, int i2) {
        float f;
        int i3;
        short[] sArr = new short[N];
        FuzzerUtils.init(sArr, (short) -6649);
        int i4 = 0;
        int i5 = 9;
        int i6 = -6608;
        if (bFld) {
            int i7 = (i >>> 1) % N;
            f = -0.45700002f;
            sArr[i7] = (short) (sArr[i7] * ((short) (-0.45700002f)));
            i2 -= (int) (Math.max(iMeth(i), i2) + instanceCount);
            i3 = 12;
            while (i3 < 310) {
                i += i;
                int i8 = i4 - ((int) instanceCount);
                i5 = 1;
                while (i5 < 16) {
                    instanceCount = i6;
                    i6 -= 634524287;
                    f = (f * (-1.69478447E18f)) + (i5 * i5) + 152;
                    i2 -= i5;
                    instanceCount = i2;
                    i5++;
                    i8 = i6;
                }
                i4 = i8 - ((int) instanceCount);
                i3 += 3;
            }
        } else {
            f = 0.543f;
            i3 = 34723;
        }
        long floatToIntBits = i + i2 + Float.floatToIntBits(f) + i3 + i4 + i5 + i6 + FuzzerUtils.checkSum(sArr);
        dMeth_check_sum += floatToIntBits;
        return floatToIntBits;
    }

    public static void vMeth(int i, double d, long j) {
        int i2;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -54178);
        int i3 = i;
        double d2 = d;
        int i4 = 2;
        int i5 = -11;
        int i6 = -21556;
        int i7 = -10;
        int i8 = 66;
        float f = 2.622f;
        int i9 = 0;
        int i10 = 0;
        int i11 = 1;
        while (i4 < 139) {
            double d3 = d2;
            double d4 = -22983;
            i9 = dMeth(-22983, i3) != d4 ? 1 : 0;
            int i12 = i5;
            int i13 = i6;
            i10 = 1;
            double d5 = d3;
            while (i10 < 11) {
                i13 = 1;
                while (true) {
                    if (i13 >= 3) {
                        break;
                    }
                    Double.isNaN(d4);
                    d5 += d4;
                    i7 += 253;
                    f = (float) instanceCount;
                    i12 = 103;
                    i13++;
                }
                int i14 = 1;
                for (i2 = 3; i14 < i2; i2 = 3) {
                    i7 >>>= 0;
                    i3 -= i8;
                    i8 += ((i14 * i3) + i10) - i10;
                    int i15 = i14;
                    iArr[i15] = iArr[i14] >> ((int) instanceCount);
                    i14 = i15 + 1;
                }
                i10 += 2;
                i11 = i14;
            }
            i4++;
            double d6 = d5;
            i5 = i12;
            i6 = i13;
            d2 = d6;
        }
        vMeth_check_sum += ((((i3 + Double.doubleToLongBits(d2)) + j) + i4) - 22983) + i9 + i10 + i5 + i6 + i7 + Float.floatToIntBits(f) + i11 + i8 + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        int i3;
        long[] jArr = new long[N];
        double[] dArr = new double[N];
        FuzzerUtils.init(jArr, 1926585113L);
        FuzzerUtils.init(dArr, 105.101899d);
        int i4 = -61530;
        vMeth(-61530, dFld, instanceCount);
        int i5 = -6;
        int i6 = -9;
        int i7 = 8;
        long j = 15;
        int i8 = 2;
        while (true) {
            i = 9;
            if (j >= 386) {
                break;
            }
            i4 *= i4;
            i5 = 4;
            while (68 > i5) {
                instanceCount /= i6 | 1;
                i5++;
                jArr = jArr;
            }
            long[] jArr2 = jArr;
            i6 += (int) j;
            int i9 = (int) (j - 1);
            j++;
            int[] iArr = this.iArrFld[i9][(int) j];
            iArr[i9] = iArr[i9] * 9;
            int i10 = 4;
            while (68 > i10) {
                jArr2[i10] = jArr2[i10] / (i4 | 1);
                i10++;
            }
            i7 = i10;
            jArr = jArr2;
            i8 = 56886;
        }
        long[] jArr3 = jArr;
        int i11 = -11;
        int i12 = 14;
        int i13 = 15218;
        long j2 = -13;
        int i14 = 4;
        short s = 14670;
        while (true) {
            i2 = i13;
            if (i14 >= 174) {
                break;
            }
            int i15 = i12;
            int i16 = i14 + 1;
            int[] iArr2 = this.iArrFld[(i5 >>> 1) % N][i16];
            int i17 = i14 - 1;
            iArr2[i17] = iArr2[i17] - s;
            double[] dArr2 = dArr;
            int i18 = i11 + ((int) ((i14 * i14) - 302364850467512982L)) + ((int) dFld);
            long j3 = instanceCount;
            instanceCount = j3 - j3;
            i13 = i2;
            i12 = i15;
            int i19 = 2;
            while (true) {
                i3 = i18;
                if (i19 < 148) {
                    int i20 = i6;
                    int i21 = i7;
                    long j4 = i19;
                    i12 = i12;
                    while (j4 < 2) {
                        instanceCount = -7L;
                        s = (short) (s + s);
                        long j5 = j;
                        i8 += (int) (j4 * j4);
                        int[] iArr3 = this.iArrFld[i19 - 1][i19];
                        int i22 = (int) j4;
                        iArr3[i22] = iArr3[i22] * 107;
                        i12 >>= -152;
                        j4++;
                        j = j5;
                    }
                    long j6 = j;
                    dArr2[i14] = 13;
                    int i23 = i19 + 1;
                    int[] iArr4 = this.iArrFld[i17][i23];
                    j2 = j4;
                    iArr4[i14] = iArr4[i14] + ((int) instanceCount);
                    instanceCount = -52L;
                    i13 = 1;
                    while (i13 < 2) {
                        int[][][] iArr5 = this.iArrFld;
                        iArr5[i19 - 1][6] = iArr5[i13 - 1][i23];
                        int[] iArr6 = iArr5[41][i16];
                        iArr6[i16] = iArr6[i16] - (-34);
                        jArr3[i19] = instanceCount;
                        i13++;
                    }
                    i19 = i23;
                    i18 = i3;
                    i7 = i21;
                    i6 = i20;
                    j = j6;
                }
            }
            i14 = i16;
            i11 = i3;
            i6 = i6;
            i = i19;
            dArr = dArr2;
        }
        int i24 = i12;
        FuzzerUtils.out.println("i24 l2 i25 = " + i4 + "," + j + "," + i8);
        FuzzerUtils.out.println("i26 i27 i28 = " + i5 + "," + i6 + "," + i7);
        FuzzerUtils.out.println("i29 i30 i31 = " + i11 + "," + i14 + ",-152");
        FuzzerUtils.out.println("s1 i32 i33 = " + ((int) s) + "," + i + ",13");
        FuzzerUtils.out.println("l3 i34 i35 = " + j2 + "," + i24 + "," + i2);
        FuzzerUtils.out.println("i36 i37 by = 155,-13,-34");
        FuzzerUtils.out.println("lArr dArr = " + FuzzerUtils.checkSum(jArr3) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)));
        PrintStream printStream = FuzzerUtils.out;
        long j7 = instanceCount;
        int i25 = bFld ? 1 : 0;
        printStream.println("Test.instanceCount Test.bFld Test.dFld = " + j7 + "," + i25 + "," + Double.doubleToLongBits(dFld));
        PrintStream printStream2 = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum((Object[][]) this.iArrFld);
        StringBuilder sb = new StringBuilder();
        sb.append("iArrFld = ");
        sb.append(checkSum);
        printStream2.println(sb.toString());
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

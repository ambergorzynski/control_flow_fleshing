
import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_85/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static long bMeth_check_sum;
    public static long[] lArrFld;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public static volatile long instanceCount = -59;
    public static volatile double dFld = 96.889d;
    public static float fFld = -2.556f;
    public static byte byFld = 90;
    public static boolean bFld = false;

    static {
        long[] jArr = new long[N];
        lArrFld = jArr;
        FuzzerUtils.init(jArr, 38279L);
        bMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }

    public static void vMeth1() {
        int i;
        int i2;
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, -2.611f);
        FuzzerUtils.init(iArr, -182);
        byte b = (byte) instanceCount;
        int i3 = -36;
        int i4 = -57551;
        int i5 = -205;
        int i6 = -7;
        int i7 = 269;
        int i8 = 8;
        while (i7 > 2) {
            int i9 = i8;
            int i10 = i6;
            int i11 = i5;
            int i12 = 1;
            while (i12 < 6) {
                i10 = 1;
                while (i10 < 2) {
                    i3 += (int) instanceCount;
                    switch ((i12 % 3) + 8) {
                        case 8:
                            int i13 = i10 + 1;
                            fArr[i13] = fArr[i13] - (-59392.0f);
                            break;
                        case 9:
                            i = i10;
                            i2 = 27191;
                            instanceCount = i11;
                            try {
                                i = iArr[i7] / i10;
                                iArr[i10] = (-22612) / i11;
                                i3 = (-37849) % iArr[i10 + 1];
                            } catch (ArithmeticException e) {
                                i3 = i2;
                            }
                            i9 = i;
                            instanceCount += instanceCount;
                            lArrFld[i12 + 1] = i10;
                            i9 *= 4;
                            break;
                        case 10:
                            i = i9;
                            i2 = i3;
                            instanceCount = i11;
                            i = iArr[i7] / i10;
                            iArr[i10] = (-22612) / i11;
                            i3 = (-37849) % iArr[i10 + 1];
                            i9 = i;
                            instanceCount += instanceCount;
                            lArrFld[i12 + 1] = i10;
                            i9 *= 4;
                            break;
                        default:
                            instanceCount += instanceCount;
                            lArrFld[i12 + 1] = i10;
                            i9 *= 4;
                            break;
                    }
                    i10++;
                    i11 = i7;
                }
                i12++;
            }
            i7--;
            i4 = i12;
            i5 = i11;
            i6 = i10;
            i8 = i9;
        }
        vMeth1_check_sum += b + i7 + i3 + i4 + i5 + i6 + i8 + 27191 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth(long j, int i) {
        double d = 1.0d;
        while (369.0d > d) {
            vMeth1();
            long j2 = instanceCount;
            double d2 = fFld;
            Double.isNaN(d2);
            instanceCount = j2 + ((long) (d2 + d));
            d += 1.0d;
        }
        int i2 = -180;
        int i3 = 43449;
        int i4 = 8;
        while (i4 < 198) {
            byFld = (byte) (byFld * ((byte) (-10085)));
            instanceCount += i4 - i4;
            int i5 = i3;
            int i6 = 1;
            while (i6 < 8) {
                i5 = 1;
                while (i5 < 2) {
                    long[] jArr = lArrFld;
                    int i7 = i6 - 1;
                    jArr[i7] = jArr[i7] - i6;
                    i5++;
                }
                instanceCount += ((i6 * i5) - 11) - i6;
                i6++;
            }
            i4++;
            i2 = i6;
            i3 = i5;
        }
        vMeth_check_sum += ((((((i + j) + Double.doubleToLongBits(d)) - 193) + i4) - 11) - 10085) + i2 + 35 + i3 + 15;
    }

    public static boolean bMeth(long j) {
        long[] jArr = lArrFld;
        lArrFld = jArr;
        lArrFld = jArr;
        lArrFld = jArr;
        lArrFld = jArr;
        vMeth(instanceCount, -139);
        bMeth_check_sum += j;
        return j % 2 > 0;
    }

    public void mainTest(String[] strArr) {
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        short[] sArr = new short[N];
        boolean[] zArr = new boolean[N];
        double[] dArr = new double[N];
        FuzzerUtils.init(iArr, 232);
        FuzzerUtils.init(zArr, false);
        FuzzerUtils.init(dArr, 73.98781d);
        FuzzerUtils.init(sArr, (short) -24537);
        byte b = (byte) 37;
        int i = -43;
        int i2 = 14;
        int i3 = -12;
        int i4 = 925568;
        int i5 = 17;
        while (i5 < 374) {
            double d = dFld;
            double d2 = dFld;
            double d3 = iArr[i5][i5] ^ (-1);
            Double.isNaN(d3);
            double max = Math.max((int) (d2 + d3), iArr[i5][i5 - 1]);
            Double.isNaN(max);
            dFld = d - max;
            instanceCount += i5;
            i = i5;
            while (i < 71) {
                int i6 = i + 1;
                zArr[i6] = bMeth(-5162315414646549387L) || bFld;
                instanceCount >>= (int) instanceCount;
                int i7 = i5 + 1;
                double d4 = dArr[i7];
                double d5 = i;
                Double.isNaN(d5);
                dArr[i7] = d4 - d5;
                dFld -= -49.0d;
                float f = i4;
                i4 = (int) (f + (((i * fFld) + f) - 136));
                i = i6;
                iArr = iArr;
                i2 = 1;
            }
            i3 += 7;
            i5++;
            iArr = iArr;
        }
        FuzzerUtils.out.println("i by i1 = " + i4 + "," + ((int) b) + "," + i5);
        FuzzerUtils.out.println("i2 i3 i4 = 136," + i + ",6");
        FuzzerUtils.out.println("i19 i20 i21 = " + i2 + ",11,6336");
        FuzzerUtils.out.println("i22 i23 i24 = -25707,2," + i3);
        FuzzerUtils.out.println("s2 i25 i26 = 8925,57690,24");
        FuzzerUtils.out.println("iArr bArr dArr = " + FuzzerUtils.checkSum(iArr) + "," + FuzzerUtils.checkSum(zArr) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)));
        PrintStream printStream = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(sArr);
        StringBuilder sb = new StringBuilder();
        sb.append("sArr = ");
        sb.append(checkSum);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.fFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(fFld));
        PrintStream printStream2 = FuzzerUtils.out;
        byte b2 = byFld;
        boolean z = bFld;
        printStream2.println("Test.byFld Test.bFld Test.lArrFld = " + ((int) b2) + "," + (z ? 1 : 0) + "," + FuzzerUtils.checkSum(lArrFld));
        PrintStream printStream3 = FuzzerUtils.out;
        long j = vMeth1_check_sum;
        StringBuilder sb2 = new StringBuilder();
        sb2.append("vMeth1_check_sum: ");
        sb2.append(j);
        printStream3.println(sb2.toString());
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_3/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long iMeth_check_sum;
    public static long lMeth_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = -2296936133024613144L;
    public static int iFld = 13869;
    public static long lFld = -4003616719L;
    public static final int N = 400;
    public static volatile int[] iArrFld = new int[N];
    public static long[] lArrFld = new long[N];

    static {
        FuzzerUtils.init(iArrFld, -13);
        FuzzerUtils.init(lArrFld, 1307677492188439752L);
        vMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
    }

    public static int iMeth(int i, int i2) {
        float[][][] fArr = (float[][][]) Array.newInstance((Class<?>) float.class, N, N, N);
        FuzzerUtils.init((Object[][]) fArr, (Object) Float.valueOf(-49.804f));
        int i3 = ((i2 + i2) >>> 1) % N;
        fArr[i3][i3] = fArr[i3][i3];
        double d = i2;
        Double.isNaN(d);
        double d2 = d + 0.107158d;
        int i4 = 8712;
        float f = 0.604f;
        int i5 = 378;
        while (i5 > 18) {
            lArrFld[i5 - 1] = f;
            i4 = 1;
            while (i4 < 13) {
                long j = instanceCount;
                long j2 = j + (i4 * j);
                instanceCount = j2;
                i2 -= (int) j2;
                long j3 = j2 % 175;
                instanceCount = j3;
                d2 -= 1.2599999904632568d;
                iFld += i4 * i4;
                f += 25.698f;
                lFld = j3;
                i4++;
            }
            i5 -= 3;
        }
        long doubleToLongBits = (((((((r0 + i2) + Double.doubleToLongBits(d2)) + i5) + 174) + Float.floatToIntBits(f)) + i4) - 165) + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][]) fArr));
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static long lMeth(long j) {
        int i = 232;
        long j2 = 4;
        while (j2 < 206) {
            j--;
            i = (int) ((i - j) + iMeth(iFld, i - 1));
            int i2 = iFld;
            iFld = i2 + i2;
            j2++;
        }
        for (int i3 : iArrFld) {
            iFld &= 50476;
        }
        instanceCount = 8L;
        iFld -= i;
        long j3 = j + j2 + i;
        lMeth_check_sum += j3;
        return j3;
    }

    public static void vMeth(float f, int i) {
        int[] iArr = iArrFld;
        int i2 = (i >>> 1) % N;
        iArr[i2] = iArr[i2] * ((int) (68 - (Math.min(instanceCount, 2205506403L) - lMeth(-6L))));
        vMeth_check_sum += Float.floatToIntBits(f) + i;
    }

    public void mainTest(String[] strArr) {
        int i;
        int[] iArr = new int[N];
        short[] sArr = new short[N];
        FuzzerUtils.init(iArr, -7);
        FuzzerUtils.init(sArr, (short) -8941);
        int i2 = 3;
        float f = -1.785f;
        double d = 0.2671d;
        int i3 = 365;
        int i4 = 16107;
        int i5 = -39769;
        int i6 = 1;
        while (true) {
            i = 7;
            if (i3 <= 19) {
                break;
            }
            int[] iArr2 = iArr;
            long j = i3;
            int i7 = instanceCount <= j ? 1 : 0;
            i6 = i7 & (((((float) instanceCount) > f ? 1 : (((float) instanceCount) == f ? 0 : -1)) != 0 ? 1 : 0) != (i7 ^ 1) ? 1 : 0);
            if (i6 != 0) {
                vMeth(f, i5);
            } else {
                int i8 = 1;
                while (i8 < 73) {
                    iArrFld[i3 + 1] = 7;
                    long j2 = lFld;
                    lArrFld[i8] = i2 >> ((int) j2);
                    i2 = (int) instanceCount;
                    lFld = j2 * j;
                    int[] iArr3 = iArrFld;
                    i8++;
                    iArr3[i8] = iArr3[i8] - iFld;
                    double d2 = i3;
                    Double.isNaN(d2);
                    d *= d2;
                    lFld += 2;
                    iArrFld = iArrFld;
                    i5 = i5;
                }
                int i9 = i5;
                long j3 = instanceCount;
                instanceCount = j3;
                float f2 = (float) j3;
                try {
                    int i10 = i3 - 1;
                    i5 = 4055 / iArrFld[i10];
                    try {
                        iArr2[i10] = 2496 / i3;
                        iFld = i8 % i2;
                    } catch (ArithmeticException e) {
                    }
                } catch (ArithmeticException e2) {
                    i5 = i9;
                }
                i4 = i8;
                f = f2;
            }
            i3--;
            iArr = iArr2;
        }
        int[] iArr4 = iArr;
        int i11 = i3 - ((int) f);
        double d3 = i3;
        Double.isNaN(d3);
        double d4 = d * d3;
        long j4 = 226;
        int i12 = -51;
        int i13 = i5;
        int i14 = -6;
        int i15 = -183;
        while (7 < j4) {
            i12 = 115;
            while (i12 > i) {
                int i16 = (int) ((j4 % 2) + 36);
                if (i16 == 36) {
                    sArr = FuzzerUtils.short1array(N, (short) -16247);
                    lFld = -93;
                    i11 = ((int) (i11 + (((i12 * f) - 53) - iFld))) + (((1 * i12) + i4) - 2);
                    i14 = 2;
                    i15 = 2;
                } else if (i16 == 37) {
                    i13 -= (int) f;
                }
                i12--;
                i = 7;
            }
            j4--;
            i = 7;
        }
        FuzzerUtils.out.println("i i1 b = " + i3 + "," + i13 + "," + i6);
        FuzzerUtils.out.println("f i11 i12 = " + Float.floatToIntBits(f) + "," + i4 + "," + i11);
        FuzzerUtils.out.println("d1 l2 i13 = " + Double.doubleToLongBits(d4) + "," + j4 + ",-53");
        FuzzerUtils.out.println("i14 i15 i16 = " + i12 + ",-61," + i14);
        FuzzerUtils.out.println("i17 by iArr = " + i15 + ",-93," + FuzzerUtils.checkSum(iArr4));
        PrintStream printStream = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(sArr);
        StringBuilder sb = new StringBuilder();
        sb.append("sArr = ");
        sb.append(checkSum);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.lFld = " + instanceCount + "," + iFld + "," + lFld);
        FuzzerUtils.out.println("Test.iArrFld Test.lArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

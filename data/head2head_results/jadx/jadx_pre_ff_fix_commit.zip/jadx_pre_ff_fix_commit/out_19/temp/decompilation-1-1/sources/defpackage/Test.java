package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_19/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static long dMeth_check_sum;
    public static int[] iArrFld;
    public static long iMeth_check_sum;
    public static long lMeth_check_sum;
    public static long instanceCount = 7013341965226609775L;
    public static int iFld1 = 44528;
    public static short sFld = -28773;
    public static double dFld = -2.101387d;
    public int iFld = -3;
    public boolean bFld = true;
    public float fFld = 2.191f;
    public float[] fArrFld = new float[N];
    public volatile double[] dArrFld = new double[N];

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, -22063);
        iMeth_check_sum = 0L;
        dMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
    }

    public static long lMeth(int i, short s) {
        long j = s + i + i;
        lMeth_check_sum += j;
        return j;
    }

    public static double dMeth(int i, int i2) {
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(iArr, 8);
        FuzzerUtils.init(zArr, true);
        int i3 = i;
        int i4 = i2;
        int i5 = -5;
        int i6 = -38623;
        int i7 = -54;
        short s = -9593;
        float f = 1.674f;
        int i8 = 295;
        int i9 = 13;
        while (i8 > 13) {
            i5 = 6;
            int i10 = i4;
            int i11 = i3;
            int i12 = i10;
            while (i5 > 1) {
                int[] iArr2 = iArrFld;
                iArr2[i8] = iArr2[i8] - iFld1;
                int i13 = i5 - 1;
                int i14 = iArr[i13][i8];
                instanceCount *= lMeth(i6, s);
                try {
                    i6 = iFld1 % (-912903211);
                    i11 /= -136;
                    i9 = i6 % i14;
                } catch (ArithmeticException e) {
                }
                s = (short) (s - ((short) (-1.122462d)));
                i11 *= 1842;
                i9 <<= i5;
                instanceCount = i7;
                zArr[i13] = true;
                i5--;
                f = i6;
                i12 = i14;
            }
            instanceCount -= -8;
            i7 -= 38976;
            i8--;
            int i15 = i11;
            i4 = i12;
            i3 = i15;
        }
        long floatToIntBits = i3 + i4 + i8 + i9 + i5 + i6 + s + i7 + Float.floatToIntBits(f) + 1 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(zArr);
        dMeth_check_sum += floatToIntBits;
        return floatToIntBits;
    }

    public static int iMeth(int i) {
        int[][][] iArr = (int[][][]) Array.newInstance((Class<?>) int.class, N, N, N);
        long[] jArr = new long[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, 1.568f);
        FuzzerUtils.init(jArr, 4L);
        FuzzerUtils.init((Object[][]) iArr, (Object) (-4));
        long j = instanceCount + 1;
        instanceCount = j;
        int i2 = (i >>> 1) % N;
        float f = fArr[i2];
        fArr[i2] = 1.0f + f;
        int i3 = (int) (((float) ((i + 42) * j)) * f);
        int[] iArr2 = iArrFld;
        int i4 = iArr2[43];
        double d = jArr[(i3 >>> 1) % N] + (j * (-226));
        double dMeth = dMeth(i3, iFld1) - (-4.309000015258789d);
        Double.isNaN(d);
        iArr2[43] = i4 - ((int) (d * dMeth));
        for (int i5 = 0; i5 < 400; i5++) {
            float f2 = fArr[i5];
            i3 = sFld;
        }
        iArrFld[(i3 >>> 1) % N] = (int) instanceCount;
        long j2 = 7;
        int i6 = 1;
        int i7 = 1;
        while (true) {
            i6++;
            if (i6 < 164) {
                j2 = 1;
                while (j2 < 10) {
                    int i8 = iFld1;
                    instanceCount += ((j2 * j2) + j2) - i8;
                    j2++;
                    i7 <<= i8;
                }
                long j3 = instanceCount;
                instanceCount = j3 + j3;
                int i9 = iFld1 << i7;
                iFld1 = i9;
                iArrFld[i6 + 1] = i9;
                i7 += i6 - i7;
            } else {
                long doubleToLongBits = i3 + i6 + j2 + i7 + 0 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum((Object[][]) iArr);
                iMeth_check_sum += doubleToLongBits;
                return (int) doubleToLongBits;
            }
        }
    }

    public void mainTest(String[] strArr) {
        short[] sArr = new short[N];
        FuzzerUtils.init(sArr, (short) -21901);
        int i = this.iFld;
        this.iFld = i - 1;
        this.iFld = i;
        instanceCount += Math.min(iMeth(iFld1), this.iFld);
        int i2 = 1;
        int i3 = -235;
        int i4 = -159;
        int i5 = 51309;
        int i6 = -6;
        byte b = -62;
        int i7 = 1;
        int i8 = 1;
        while (i7 < 161) {
            i4 = 157;
            while (i4 > 9) {
                long j = instanceCount;
                instanceCount = j - j;
                i8 = 1;
                while (true) {
                    i8 += i2;
                    if (i8 < 3) {
                        int i9 = this.iFld;
                        int i10 = i9 >> i9;
                        this.iFld = i10;
                        double d = dFld;
                        long j2 = instanceCount;
                        int i11 = i3;
                        double d2 = j2;
                        Double.isNaN(d2);
                        dFld = d + d2;
                        if (this.bFld) {
                            this.iFld = (int) (i10 + (((i10 * i8) + j2) - i4));
                            float[] fArr = this.fArrFld;
                            int i12 = i4 + 1;
                            fArr[i12] = fArr[i12] + sFld;
                        }
                        double[] dArr = this.dArrFld;
                        int i13 = i7 - 1;
                        double d3 = dArr[i13];
                        double d4 = i8;
                        Double.isNaN(d4);
                        dArr[i13] = d3 + d4;
                        int i14 = iFld1 % (i7 | 1);
                        iFld1 = i14;
                        long j3 = i4;
                        instanceCount = j3;
                        long j4 = j3 * i8;
                        instanceCount = j4;
                        long j5 = j4 + i14;
                        instanceCount = j5;
                        switch (((i7 % 3) * 5) + 103) {
                            case 110:
                                b = (byte) (b + ((byte) i8));
                                i3 = i11;
                                i2 = 1;
                                break;
                            case 111:
                                instanceCount = j5 + (i8 * i8) + 231;
                                int i15 = i8 + 1;
                                sArr[i15] = (short) (sArr[i15] ^ (-14132));
                                i3 = i11;
                                i2 = 1;
                                break;
                            case 112:
                                if (this.bFld) {
                                    int i16 = i8 % 1;
                                    instanceCount = j5 * i7;
                                    this.fFld = i14;
                                } else {
                                    switch (((i14 >>> 1) % 4) + 46) {
                                        case 46:
                                            i3 = (i11 + b) << i4;
                                            int i17 = this.iFld;
                                            instanceCount = j5 + (((i8 * i17) + i17) - i4);
                                            i5 = i14;
                                            i2 = 1;
                                            break;
                                        case 47:
                                            iFld1 = i14 * i6;
                                            dFld -= 1.1319999694824219d;
                                            i6 -= i14;
                                            i5 = i14;
                                            i3 = i11;
                                            i2 = 1;
                                            break;
                                        case 48:
                                            dFld -= 1.1319999694824219d;
                                            i6 -= i14;
                                            i5 = i14;
                                            i3 = i11;
                                            i2 = 1;
                                            break;
                                        case 49:
                                            this.iFld += i7;
                                            break;
                                        default:
                                            this.iFld -= i8;
                                            break;
                                    }
                                }
                                i5 = i14;
                                i3 = i11;
                                i2 = 1;
                                break;
                            default:
                                int i152 = i8 + 1;
                                sArr[i152] = (short) (sArr[i152] ^ (-14132));
                                i3 = i11;
                                i2 = 1;
                                break;
                        }
                    }
                }
                i4 -= 2;
                i2 = 1;
            }
            i7++;
            i2 = 1;
        }
        FuzzerUtils.out.println("i12 i13 i14 = " + i7 + "," + i3 + "," + i4);
        FuzzerUtils.out.println("i15 i16 by = " + i5 + "," + i8 + "," + ((int) b));
        FuzzerUtils.out.println("i17 sArr = " + i6 + "," + FuzzerUtils.checkSum(sArr));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.iFld1 = " + instanceCount + "," + this.iFld + "," + iFld1);
        PrintStream printStream = FuzzerUtils.out;
        short s = sFld;
        printStream.println("Test.sFld Test.dFld bFld = " + ((int) s) + "," + Double.doubleToLongBits(dFld) + "," + (this.bFld ? 1 : 0));
        FuzzerUtils.out.println("fFld Test.iArrFld fArrFld = " + Float.floatToIntBits(this.fFld) + "," + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
        PrintStream printStream2 = FuzzerUtils.out;
        long doubleToLongBits = Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld));
        StringBuilder sb = new StringBuilder();
        sb.append("dArrFld = ");
        sb.append(doubleToLongBits);
        printStream2.println(sb.toString());
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_68/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long iMeth_check_sum;
    public static long lMeth_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = -191;
    public static int iFld = 31912;
    public static volatile boolean bFld = false;
    public static double dFld = 2.26244d;
    public static final int N = 400;
    public static long[] lArrFld = new long[N];
    public static volatile double[][] dArrFld = (double[][]) Array.newInstance((Class<?>) double.class, N, N);

    static {
        FuzzerUtils.init(lArrFld, 8L);
        FuzzerUtils.init(dArrFld, 75.46002d);
        lMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }

    public static void vMeth(long j, boolean z) {
        instanceCount >>= iFld;
        vMeth_check_sum += j + (z ? 1L : 0L);
    }

    public static int iMeth() {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 224);
        vMeth(-1012790185L, bFld);
        int i = iFld;
        int i2 = i >> i;
        iFld = i2;
        iFld = i2;
        int i3 = (i2 >>> 1) % N;
        iArr[i3] = iArr[i3] << i2;
        int i4 = -7;
        int i5 = -42;
        int i6 = -3;
        int i7 = -5;
        int i8 = 180;
        float f = 2.953f;
        if (bFld) {
            i4 = 3;
            while (i4 < 135) {
                switch ((i4 % 10) + 120) {
                    case 120:
                        i6 = 1;
                        do {
                            i7 = i6;
                            while (1 > i7) {
                                iFld += i6;
                                int i9 = i6 - 1;
                                double[] dArr = dArrFld[i9];
                                double d = dArr[i9];
                                double d2 = i8;
                                Double.isNaN(d2);
                                dArr[i9] = d - d2;
                                bFld = false;
                                f -= f;
                                i8 += i7;
                                iFld += i5;
                                i7++;
                            }
                            i6++;
                        } while (i6 < 12);
                    case 121:
                        i5 = (int) f;
                        break;
                    case 122:
                        iFld = (int) f;
                        break;
                    case 123:
                        int i10 = i4 - 1;
                        double[] dArr2 = dArrFld[i10];
                        double d3 = dArr2[i10];
                        double d4 = instanceCount;
                        Double.isNaN(d4);
                        dArr2[i10] = d3 * d4;
                        break;
                    case 124:
                        lArrFld[i4 + 1] = i5;
                        break;
                    case 125:
                    case 126:
                        f = 1.63f;
                        break;
                    case 127:
                        dArrFld[i4 + 1] = dArrFld[i4 - 1];
                    case 128:
                        dFld = 16910.0d;
                    case 129:
                        i8 = -52;
                        break;
                }
                i4++;
            }
        } else if (bFld) {
            i8 = 180 + ((int) instanceCount);
        }
        long floatToIntBits = i4 + i5 + i6 + i7 + i8 + Float.floatToIntBits(f) + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static long lMeth(int i, boolean z, int i2) {
        bFld = ((long) (iMeth() + i2)) != instanceCount;
        int i3 = i2 + 40;
        int i4 = -10;
        float f = 91.404f;
        long j = 1;
        int i5 = 1;
        while (true) {
            i5++;
            if (i5 < 124) {
                f /= i3 | 1;
                i3 += i5;
                long[] jArr = lArrFld;
                int i6 = i5 - 1;
                jArr[i6] = jArr[i6] * 105;
                instanceCount *= iFld;
                j = 1;
                while (true) {
                    j++;
                    if (j >= 13) {
                        break;
                    }
                    instanceCount = i;
                }
                instanceCount = i5;
                i4 = 1;
                while (i4 < 13) {
                    iFld *= (int) dFld;
                    i3 += 6;
                    i4++;
                }
                dFld = 105;
                instanceCount *= -6201389689115867959L;
            } else {
                long floatToIntBits = (((((((i + (z ? 1 : 0)) + i3) + i5) + Float.floatToIntBits(f)) + 105) + j) + i4) - 6;
                lMeth_check_sum += floatToIntBits;
                return floatToIntBits;
            }
        }
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        boolean[][] zArr = (boolean[][]) Array.newInstance((Class<?>) boolean.class, N, N);
        FuzzerUtils.init(zArr, false);
        FuzzerUtils.init(iArr, -13);
        int i = iFld;
        zArr[(i >>> 1) % N][(i >>> 1) % N] = bFld;
        float f = 94.57f;
        double d = -92.119186d;
        for (long j : lArrFld) {
            d -= 1.0d;
            int i2 = iFld;
            iFld = i2 - 1;
            double d2 = i2 + f + i2;
            Double.isNaN(d2);
            f -= (float) (d2 + d);
        }
        lMeth(56, bFld, iFld);
        int i3 = 12;
        int i4 = -2921;
        while (i3 < 340) {
            i4 = (int) instanceCount;
            i3++;
        }
        FuzzerUtils.out.println("f d i10 = " + Float.floatToIntBits(f) + "," + Double.doubleToLongBits(d) + "," + i3);
        FuzzerUtils.out.println("i11 s i12 = -25239,9804,-2");
        FuzzerUtils.out.println("i13 i14 i15 = -4,-132,64958");
        FuzzerUtils.out.println("i16 by1 i17 = -125,94," + i4);
        FuzzerUtils.out.println("bArr iArr1 = " + FuzzerUtils.checkSum(zArr) + "," + FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.bFld = " + instanceCount + "," + iFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.dFld Test.lArrFld Test.dArrFld = " + Double.doubleToLongBits(dFld) + "," + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        PrintStream printStream = FuzzerUtils.out;
        long j2 = vMeth_check_sum;
        StringBuilder sb = new StringBuilder();
        sb.append("vMeth_check_sum: ");
        sb.append(j2);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

package defpackage;

import java.io.PrintStream;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_22/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long iMeth1_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = -133;
    public static double dFld = 49.83847d;
    public static boolean bFld = false;
    public static float fFld = 9.36f;
    public static int iFld = -64;
    public static long lFld = 3433240200L;
    public static int iFld1 = -28662;
    public static final int N = 400;
    public static volatile int[] iArrFld = new int[N];
    public int iFld2 = 51275;
    public float[] fArrFld = new float[N];

    static {
        FuzzerUtils.init(iArrFld, 54441);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
    }

    public static int iMeth1(double d) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 58883L);
        int i = -149;
        int i2 = 11;
        int i3 = 29364;
        int i4 = 13;
        int i5 = -52351;
        int i6 = 7;
        boolean z = true;
        while (i6 < 245) {
            i2 = 7;
            while (i2 > 1) {
                z = bFld;
                i3 = (int) dFld;
                i4 = i6;
                while (i4 < 2) {
                    long j = instanceCount;
                    instanceCount = j + i4 + j;
                    int[] iArr = iArrFld;
                    int i7 = (i2 >>> 1) % N;
                    iArr[i7] = iArr[i7] + 10;
                    instanceCount = i6;
                    fFld += i6;
                    bFld = true;
                    i4++;
                }
                i += i2 - 125;
                i5 -= (int) dFld;
                i2--;
            }
            i6++;
        }
        long doubleToLongBits = Double.doubleToLongBits(d) + i6 + i + i2 + i3 + (z ? 1L : 0L) + i4 + i5 + 125 + FuzzerUtils.checkSum(jArr);
        iMeth1_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static int iMeth(int i, long j, float f) {
        float max = Math.max(-93, iMeth1(dFld));
        int i2 = -106;
        int i3 = -2;
        int i4 = 17998;
        int i5 = 5;
        int i6 = 1;
        while (true) {
            i6++;
            if (i6 < 195) {
                i2 = 1;
                while (i2 < 8) {
                    int i7 = i3 + ((int) max);
                    i4 = 1;
                    while (i4 < 2) {
                        int[] iArr = iArrFld;
                        iArr[i4] = iArr[i4] - i4;
                        i4++;
                    }
                    i3 = i7 + (((i2 * i6) + i7) - i4);
                    long j2 = instanceCount + (i2 - i2);
                    instanceCount = j2;
                    i5 = ((int) j2) + (i5 >> i5);
                    i2++;
                }
                i5 = ((int) (i5 + (((i6 * max) + i3) - max))) % (-88);
                i = i2;
            } else {
                long floatToIntBits = i + j + Float.floatToIntBits(max) + i6 + i2 + i3 + i4 + i5;
                iMeth_check_sum += floatToIntBits;
                return (int) floatToIntBits;
            }
        }
    }

    public void vMeth() {
        dFld *= -34098.0d;
        iMeth(iFld, instanceCount, fFld);
        int[] iArr = iArrFld;
        int i = iFld;
        int i2 = (i >>> 1) % N;
        iArr[i2] = i & iArr[i2];
        int i3 = -201;
        int i4 = -96;
        int i5 = 58;
        int i6 = 9;
        while (i6 < 218) {
            instanceCount = instanceCount;
            int i7 = i6 + 1;
            this.fArrFld[i7] = i6;
            int[] iArr2 = iArrFld;
            iArr2[i6] = iArr2[i6] * i6;
            lFld = i6;
            int i8 = i5;
            int i9 = 1;
            while (i9 < 8) {
                i8 = 1;
                while (i8 < 2) {
                    i3 <<= -5;
                    if ((((i9 >>> 1) % 1) * 5) + 80 == 81) {
                        lFld += i8 + 5;
                        iFld >>= i9;
                        i3 = i6;
                    }
                    i8++;
                }
                i9++;
            }
            i4 = i9;
            i6 = i7;
            i5 = i8;
        }
        vMeth_check_sum += ((((i6 + i3) + i4) - 5) + i5) - 17527;
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        int i3;
        byte[] bArr = new byte[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 38009L);
        FuzzerUtils.init(bArr, (byte) -92);
        int i4 = 13;
        int i5 = 13;
        int i6 = 12;
        int i7 = -10;
        int i8 = 110;
        int i9 = 136;
        int i10 = -124;
        int i11 = 41822;
        short s = -28317;
        int i12 = 1;
        while (167 > i12) {
            int i13 = i6;
            int i14 = i5;
            int i15 = i4;
            int i16 = 289;
            while (true) {
                i = i16 - 1;
                if (i <= 0) {
                    break;
                }
                int i17 = i12 | (-76);
                int i18 = 1;
                while (true) {
                    if (i18 >= 2) {
                        break;
                    }
                    vMeth();
                    jArr[i18] = i17;
                    i18++;
                    s = s;
                    i11 = i11;
                }
                int i19 = i11;
                int i20 = i12 - 1;
                jArr[i20] = jArr[i20] << iFld;
                s = s;
                i9 = i;
                for (i3 = 2; i9 < i3; i3 = 2) {
                    i17 = (int) instanceCount;
                    i8 += (i9 * i9) - 50730;
                    short s2 = (short) (s + ((short) (((i9 * i17) + i17) - i14)));
                    i14 += i8;
                    double d = dFld;
                    double d2 = fFld;
                    Double.isNaN(d2);
                    dFld = d - d2;
                    i9++;
                    s = s2;
                    i18 = i18;
                }
                int i21 = i18;
                float f = fFld;
                int i22 = iFld;
                float f2 = f + (((i * (-106)) + i8) - i22);
                fFld = f2;
                i14 -= (int) f2;
                iFld = i22 + i;
                int[] iArr = iArrFld;
                int i23 = i - 1;
                iArr[i23] = iArr[i23] + iFld1;
                i13 = i17;
                i16 = i;
                i11 = i19;
                i15 = i21;
            }
            int i24 = 4;
            while (i24 < 210) {
                try {
                    i11 = iFld1 / i14;
                    iFld = (-20360) % iArrFld[i24 + 1];
                    i2 = iFld1 % 366847954;
                } catch (ArithmeticException e) {
                    i2 = i11;
                }
                i11 = i2 - this.iFld2;
                int i25 = iFld;
                int i26 = i15;
                double d3 = dFld;
                iFld = i25 - ((int) d3);
                long j = lFld + ((r0 + i24) - i8);
                lFld = j;
                this.iFld2 = (int) instanceCount;
                lFld = j + ((long) d3);
                bArr[i12 + 1] = (byte) 61;
                s = (short) (s + ((short) (i24 * i24)));
                int i27 = i12 - 1;
                jArr[i27] = jArr[i27] * i12;
                i24++;
                i15 = i26;
                i14 = i14;
                i13 = i13;
                i8 = i8;
            }
            int i28 = i13;
            dFld = i9;
            i12 += 3;
            i4 = i15;
            i7 = i;
            i5 = i14;
            i6 = i28;
            i10 = i24;
        }
        FuzzerUtils.out.println("i i1 i2 = " + i12 + "," + i6 + "," + i7);
        FuzzerUtils.out.println("i3 i4 i23 = " + i4 + "," + i8 + "," + i9);
        FuzzerUtils.out.println("i24 s by1 = " + i5 + "," + ((int) s) + ",-106");
        PrintStream printStream = FuzzerUtils.out;
        printStream.println("i25 i26 i27 = " + i10 + ",61," + i11);
        FuzzerUtils.out.println("lArr1 byArr = " + FuzzerUtils.checkSum(jArr) + "," + FuzzerUtils.checkSum(bArr));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.bFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.fFld Test.iFld Test.lFld = " + Float.floatToIntBits(fFld) + "," + iFld + "," + lFld);
        FuzzerUtils.out.println("Test.iFld1 iFld2 Test.iArrFld = " + iFld1 + "," + this.iFld2 + "," + FuzzerUtils.checkSum(iArrFld));
        PrintStream printStream2 = FuzzerUtils.out;
        long doubleToLongBits = Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld));
        StringBuilder sb = new StringBuilder();
        sb.append("fArrFld = ");
        sb.append(doubleToLongBits);
        printStream2.println(sb.toString());
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}


import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_36/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long iMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public int iFld = 62254;
    public static long instanceCount = 5585222879345510373L;
    public static float fFld = -107.854f;
    public static double dFld = 2.118922d;
    public static boolean bFld = true;
    public static int iFld1 = 6;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static long[] lArrFld = new long[N];
    public static byte[][] byArrFld = (byte[][]) Array.newInstance((Class<?>) byte.class, N, N);

    static {
        FuzzerUtils.init(iArrFld, -14);
        FuzzerUtils.init(lArrFld, -14L);
        FuzzerUtils.init(byArrFld, (byte) 22);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }

    public static void vMeth1(int i, long j, long j2) {
        long j3 = i;
        int i2 = 11;
        int i3 = -27729;
        int i4 = -9;
        int i5 = -208;
        int i6 = 1;
        while (true) {
            i6++;
            if (i6 >= 312) {
                vMeth1_check_sum += i + j + j3 + 1 + i6 + Float.floatToIntBits(1.425f) + i2 + i3 + i4 + i5;
                return;
            }
            j3 += i6;
            int i7 = ((i6 % 2) * 5) + 100;
            if (i7 == 102) {
                i2 = i6;
                while (i2 < 5) {
                    i4 = 1;
                    while (i4 > i2) {
                        i3 = (int) j;
                        i = -4;
                        i4--;
                    }
                    instanceCount = i4;
                    i5 = -6;
                    i2 += 2;
                }
            } else if (i7 != 103) {
                i3 += 27;
            }
        }
    }

    public static void vMeth(long j, int i) {
        long[][][] jArr = (long[][][]) Array.newInstance((Class<?>) long.class, N, N, N);
        FuzzerUtils.init((Object[][]) jArr, (Object) 0L);
        int i2 = i + ((int) j);
        long j2 = instanceCount;
        int[] iArr = iArrFld;
        int i3 = (i2 >>> 1) % N;
        int i4 = iArr[i3] - 1;
        iArr[i3] = i4;
        long j3 = j2 << (i2 - ((i2 - i2) - i4));
        instanceCount = j3;
        vMeth1(i2, j, j3);
        float f = fFld;
        fFld = f + (433 - f);
        long[] jArr2 = jArr[13][2];
        jArr2[12] = jArr2[12] * (-8);
        long j4 = 12;
        vMeth_check_sum += j + (i2 * 6) + 1 + j4 + 2 + j4 + FuzzerUtils.checkSum((Object[][]) jArr);
    }

    public static int iMeth() {
        int i;
        int i2 = 53413;
        int i3 = 7;
        while (i3 < 283) {
            vMeth(instanceCount, i3);
            double d = dFld;
            double d2 = i3;
            Double.isNaN(d2);
            dFld = d - d2;
            i2 = (i2 & (-44829)) + ((int) instanceCount);
            i3++;
        }
        int i4 = 6;
        while (i4 < 311) {
            long[] jArr = lArrFld;
            int i5 = i4 - 1;
            jArr[i5] = jArr[i5] / (instanceCount | 1);
            byte[] bArr = byArrFld[i4];
            i4++;
            bArr[i4] = (byte) i3;
        }
        int i6 = i2 << 91;
        int i7 = 22;
        int i8 = 54865;
        while (i7 < 352) {
            i8 = 1;
            do {
                fFld *= i3;
                int i9 = i8 - 1;
                byArrFld[i9][i9] = -90;
                i = i7 + 1;
                iArrFld[i] = (int) instanceCount;
                i6 += i8 + i3;
                i8 += 3;
            } while (i8 < 5);
            i7 = i;
        }
        long j = (((i3 + i6) + i4) - 11) + 91 + i7 + 21151 + i8;
        iMeth_check_sum += j;
        return (int) j;
    }

    public void mainTest(String[] strArr) {
        boolean[] zArr;
        int i;
        int i2;
        int i3;
        long j;
        int i4;
        int i5;
        Test test;
        int i6;
        int i7;
        long j2;
        Test test2;
        boolean[] zArr2;
        long j3;
        Test test3 = this;
        boolean[] zArr3 = new boolean[N];
        boolean z = false;
        FuzzerUtils.init(zArr3, false);
        int i8 = test3.iFld;
        int i9 = -66;
        int i10 = -22836;
        int i11 = -206;
        int i12 = -125;
        long j4 = 46427;
        long j5 = -834965808;
        switch (((i8 >>> 1) % 3) + 107) {
            case 107:
                zArr = zArr3;
                instanceCount = iMeth();
                i5 = 14;
                j = -834965808;
                i3 = 111;
                i = -167;
                i4 = 95;
                i2 = 12;
                break;
            case 108:
                test3.iFld = i8 + i8;
                int i13 = 4;
                while (i13 < 158) {
                    i9 += i13;
                    i13++;
                }
                int i14 = 111;
                i = 4;
                i2 = 12;
                int i15 = 95;
                while (i < 267) {
                    switch ((i % 8) + 92) {
                        case 92:
                            int[] iArr = iArrFld;
                            int i16 = i - 1;
                            iArr[i16] = iArr[i16] * 228;
                            int i17 = 6;
                            long j6 = 4018892783215375499L;
                            while (i17 < 191) {
                                int i18 = i14 + i17;
                                j5 = 1;
                                while (2 > j5) {
                                    i18 = 5063;
                                    zArr3[i17] = bFld;
                                    j5++;
                                }
                                i12 = 1;
                                int i19 = i13;
                                long j7 = j6;
                                int i20 = 1;
                                while (true) {
                                    int i21 = 2;
                                    if (i20 < 2) {
                                        j7 <<= i17;
                                        try {
                                            test3.iFld = 7617 / i;
                                            i2 = iArrFld[i20] % 51266;
                                            i2 = i20 % i18;
                                        } catch (ArithmeticException e) {
                                        }
                                        i20++;
                                    } else {
                                        int i22 = i18 << ((int) instanceCount);
                                        i9 = i9;
                                        while (i12 < i21) {
                                            zArr3[i] = z;
                                            int i23 = i;
                                            long j8 = instanceCount;
                                            i11 -= (int) j8;
                                            instanceCount = j8 + (i12 * i12) + 3;
                                            int i24 = ((i17 % 4) * 5) + 86;
                                            if (i24 == 95) {
                                                test2 = this;
                                                int[] iArr2 = iArrFld;
                                                int i25 = i12 - 1;
                                                iArr2[i25] = iArr2[i25] & i2;
                                            } else if (i24 == 104) {
                                                test2 = this;
                                                int[] iArr3 = iArrFld;
                                                int i26 = i12 + 1;
                                                iArr3[i26] = iArr3[i26] * i17;
                                                i9 |= (int) j7;
                                                test2.iFld = 2947;
                                                i22 = i23;
                                            } else if (i24 == 99) {
                                                test2 = this;
                                                test2.iFld = 1096595504;
                                                i9 <<= 2;
                                            } else if (i24 != 100) {
                                                test2 = this;
                                            } else {
                                                i22 |= (int) j7;
                                                test2 = this;
                                            }
                                            i12++;
                                            test3 = test2;
                                            i = i23;
                                            i21 = 2;
                                            z = false;
                                        }
                                        i17++;
                                        test3 = test3;
                                        i14 = i22;
                                        j6 = j7;
                                        i10 = i20;
                                        i13 = i19;
                                        z = false;
                                    }
                                }
                            }
                            test = test3;
                            i6 = i;
                            i7 = i13;
                            i15 = i17;
                            j2 = j6;
                            int[] iArr4 = iArrFld;
                            int i27 = i6 + 1;
                            zArr2 = zArr3;
                            iArr4[i27] = iArr4[i27] + ((int) dFld);
                            j4 = j2;
                            break;
                        case 93:
                            test = test3;
                            i6 = i;
                            i7 = i13;
                            j2 = 4018892783215375499L;
                            int[] iArr42 = iArrFld;
                            int i272 = i6 + 1;
                            zArr2 = zArr3;
                            iArr42[i272] = iArr42[i272] + ((int) dFld);
                            j4 = j2;
                            break;
                        case 94:
                            dFld *= -2.0d;
                            test = test3;
                            i6 = i;
                            i7 = i13;
                            j4 = 4018892783215375499L;
                            zArr2 = zArr3;
                            break;
                        case 95:
                            i14 *= i12;
                        case 96:
                            fFld += i14;
                            test = test3;
                            i6 = i;
                            i7 = i13;
                            j4 = 4018892783215375499L;
                            zArr2 = zArr3;
                            break;
                        case 97:
                            j3 = -4018892783215345879L;
                            test = test3;
                            i6 = i;
                            i7 = i13;
                            j4 = j3;
                            i9 = -141;
                            zArr2 = zArr3;
                            break;
                        case 98:
                            j3 = 4018892783215375499L;
                            test = test3;
                            i6 = i;
                            i7 = i13;
                            j4 = j3;
                            i9 = -141;
                            zArr2 = zArr3;
                            break;
                        case 99:
                            test = test3;
                            i6 = i;
                            i7 = i13;
                            i9 = i2 + ((i * i) - 4936);
                            zArr2 = zArr3;
                            i2 = i9;
                            j4 = 4018892783215375499L;
                            break;
                        default:
                            test = test3;
                            i6 = i;
                            i7 = i13;
                            zArr2 = zArr3;
                            i9 = i2;
                            i2 = i9;
                            j4 = 4018892783215375499L;
                            break;
                    }
                    i = i6 + 2;
                    test3 = test;
                    zArr3 = zArr2;
                    i13 = i7;
                    z = false;
                }
                int i28 = i13;
                zArr = zArr3;
                i3 = i14;
                j = j5;
                i4 = i15;
                i5 = i28;
                break;
            case 109:
                lArrFld[15] = r0[15] - 206;
                zArr = zArr3;
                i5 = 14;
                j = -834965808;
                i3 = 111;
                i = -167;
                i4 = 95;
                i2 = 12;
                break;
            default:
                zArr = zArr3;
                iFld1 |= 6429;
                i5 = 14;
                j = -834965808;
                i3 = 111;
                i = -167;
                i4 = 95;
                i2 = 12;
                break;
        }
        FuzzerUtils.out.println("i18 i19 i20 = " + i5 + "," + i9 + "," + i);
        FuzzerUtils.out.println("i21 l3 i22 = 228," + j4 + "," + i4);
        FuzzerUtils.out.println("i23 l4 i24 = " + i3 + "," + j + "," + i2);
        FuzzerUtils.out.println("i25 i26 i27 = " + i10 + "," + i11 + "," + i12);
        FuzzerUtils.out.println("i28 bArr = -141," + FuzzerUtils.checkSum(zArr));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.fFld = " + instanceCount + "," + this.iFld + "," + Float.floatToIntBits(fFld));
        PrintStream printStream = FuzzerUtils.out;
        long doubleToLongBits = Double.doubleToLongBits(dFld);
        boolean z2 = bFld;
        printStream.println("Test.dFld Test.bFld Test.iFld1 = " + doubleToLongBits + "," + (z2 ? 1 : 0) + "," + iFld1);
        FuzzerUtils.out.println("Test.iArrFld Test.lArrFld Test.byArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(byArrFld));
        PrintStream printStream2 = FuzzerUtils.out;
        long j9 = vMeth1_check_sum;
        StringBuilder sb = new StringBuilder();
        sb.append("vMeth1_check_sum: ");
        sb.append(j9);
        printStream2.println(sb.toString());
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}


import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_65/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public static long iMeth_check_sum;
    public static long lMeth_check_sum;
    public static long vMeth_check_sum;
    public long lFld = -177;
    public static long instanceCount = -833413353;
    public static int iFld = 13;
    public static int iFld1 = -7;
    public static boolean bFld = true;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, -9);
        lMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static int iMeth(int i, long j) {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 2L);
        FuzzerUtils.init(iArr, -250);
        long j2 = j;
        double d = -1.26119d;
        int i2 = 6;
        int i3 = -6423;
        int i4 = 17;
        short s = -2982;
        double d2 = 0.121151d;
        int i5 = -66;
        float f = 1.653f;
        while (348 > i2) {
            int i6 = 5;
            while (true) {
                i6--;
                if (i6 > 0) {
                    jArr[i2] = jArr[i2] >> (-6);
                    int[] iArr2 = iArr;
                    long j3 = i6;
                    long j4 = j2 + j3;
                    int i7 = ((i2 % 8) * 5) + 50;
                    if (i7 == 55) {
                        i5 -= (int) instanceCount;
                    } else if (i7 == 57) {
                        d = i3;
                    } else if (i7 == 75) {
                        i3 += i6 * i6;
                    } else if (i7 != 86) {
                        if (i7 == 87) {
                            iFld = (int) (iFld + (f | j3));
                            f += i6;
                            d2 = 2.0d;
                        } else {
                            switch (i7) {
                                case 71:
                                    int i8 = i2 - 1;
                                    jArr[i8] = jArr[i8] - (-45);
                                    break;
                                case 73:
                                    int i9 = i2 - 1;
                                    iArr2[i9] = iArr2[i9] | i5;
                                    break;
                            }
                        }
                        int i10 = (i6 >>> 1) % N;
                        jArr[i10] = jArr[i10] + j3;
                    } else {
                        s = (short) (s * 6);
                    }
                    iArr = iArr2;
                    j2 = j4;
                }
            }
            i2++;
            i4 = i6;
        }
        long floatToIntBits = ((((((((((i + j2) + i2) + i3) + i4) + Float.floatToIntBits(f)) + Double.doubleToLongBits(d2)) + i5) + Double.doubleToLongBits(d)) + s) - 45) + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth(byte b, float f, long j) {
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, -20.934f);
        int iMeth = ((-5) - ((int) (((float) j) + 37.307f))) | ((int) (iMeth(r3, -8527375566115542874L) + f));
        int i = (int) 0.0f;
        fArr[i] = fArr[i] - 2.92f;
        vMeth_check_sum += ((((((((((Float.floatToIntBits(iMeth * f) + b) + j) + iMeth) + Double.doubleToLongBits(iMeth)) - 8527375566115542874L) + Float.floatToIntBits(1.0f)) - 8305) + 3996) - 2) - 54175) + 14 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public static long lMeth(int i, long j, float f) {
        boolean[][] zArr = (boolean[][]) Array.newInstance((Class<?>) boolean.class, N, N);
        FuzzerUtils.init(zArr, false);
        vMeth((byte) -94, f, 1196943289L);
        int i2 = iFld & i;
        iFld = i2;
        long j2 = i2;
        int i3 = -46;
        double d = 10.0d;
        while (d < 228.0d) {
            i3 = 1;
            while (i3 < 7) {
                i3++;
            }
            d += 1.0d;
        }
        long floatToIntBits = ((((((((((i + j2) + Float.floatToIntBits(f)) - 94) + Double.doubleToLongBits(d)) - 40925) + i3) + 62922) + 1) + 185) - 4) + 14104 + FuzzerUtils.checkSum(zArr);
        lMeth_check_sum += floatToIntBits;
        return floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        long[][] jArr;
        float f;
        double d;
        int i;
        int i2;
        int i3 = 2;
        long[][] jArr2 = (long[][]) Array.newInstance((Class<?>) long.class, N, N);
        FuzzerUtils.init(jArr2, 470742557182377984L);
        long j = instanceCount;
        double lMeth = ((-233) - (-Math.max(j, j))) - (lMeth(iFld, 1L, 0.607f) + instanceCount);
        Double.isNaN(lMeth);
        double d2 = 0.13591d - lMeth;
        boolean z = bFld;
        int i4 = -8;
        int i5 = 48465;
        int i6 = 193;
        int i7 = 53;
        int i8 = 55;
        if (z) {
            double d3 = 7.0d;
            while (156.0d > d3) {
                instanceCount <<= iFld;
                instanceCount = -8;
                d3 += 1.0d;
            }
            int i9 = 1;
            int i10 = 1;
            i = -9;
            i2 = 29739;
            while (true) {
                int i11 = i10 + i9;
                if (i11 >= 292) {
                    jArr = jArr2;
                    i5 = i11;
                    d = d3;
                    f = 0.607f;
                } else {
                    i = 86;
                    while (i > i3) {
                        i2 = (int) (i2 + i + instanceCount);
                        i4 *= i4;
                        i -= 2;
                    }
                    long[][] jArr3 = jArr2;
                    i4 = (int) (i4 + (((i11 * 16284) + instanceCount) - i2));
                    i6 = 5;
                    while (i6 < 86) {
                        int i12 = iFld1;
                        long j2 = i12;
                        instanceCount = j2;
                        i2 += i6;
                        switch ((i6 % 10) + 24) {
                            case 24:
                                int i13 = iFld;
                                switch (((i13 >>> 1) % 8) + 82) {
                                    case 82:
                                        i8 = 2;
                                    case 83:
                                        this.lFld = iFld1;
                                        break;
                                    case 84:
                                        iFld1 = (int) (i12 + i6 + this.lFld);
                                        break;
                                    case 85:
                                        iFld = i13 * i2;
                                        break;
                                    case 86:
                                        i2 += i2;
                                        break;
                                    case 87:
                                        i2 = -25653;
                                        break;
                                    case 88:
                                        int[] iArr = iArrFld;
                                        int i14 = i6 - 1;
                                        iArr[i14] = iArr[i14] * i;
                                        break;
                                    case 89:
                                        boolean z2 = bFld;
                                        break;
                                    default:
                                        i2 += i6 * i6;
                                        break;
                                }
                            case 25:
                                jArr3[i11][i11 - 1] = this.lFld;
                                break;
                            case 26:
                                double d4 = j2;
                                Double.isNaN(d4);
                                d2 *= d4;
                            case 27:
                                i2 = iFld;
                                break;
                            case 28:
                                this.lFld *= i4;
                                break;
                            case 29:
                            case 30:
                                i4 += 13;
                                break;
                            case 31:
                                iArrFld[i6] = (int) this.lFld;
                                break;
                            case 32:
                                i7 += i6 * i7;
                                break;
                            case 33:
                                iFld1 = (int) j2;
                                break;
                            default:
                                i4 *= (int) d2;
                                break;
                        }
                        i6++;
                    }
                    i10 = i11;
                    jArr2 = jArr3;
                    i3 = 2;
                    i9 = 1;
                }
            }
        } else {
            jArr = jArr2;
            if (z) {
                double d5 = -150;
                Double.isNaN(d5);
                d2 += d5;
                f = 0.607f;
                d = 0.113864d;
                i = -9;
                i2 = 29739;
            } else {
                f = iFld + 0.607f;
                d = 0.113864d;
                i = -9;
                i2 = 29739;
            }
        }
        FuzzerUtils.out.println("d f4 d5 = " + Double.doubleToLongBits(d2) + "," + Float.floatToIntBits(f) + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("i18 i19 i20 = " + i4 + "," + i5 + "," + i);
        FuzzerUtils.out.println("i21 s3 i22 = " + i2 + ",16284," + i6);
        FuzzerUtils.out.println("i23 i24 i25 = " + i7 + "," + i8 + ",-150");
        PrintStream printStream = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(jArr);
        StringBuilder sb = new StringBuilder();
        sb.append("lArr1 = ");
        sb.append(checkSum);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.iFld1 = " + instanceCount + "," + iFld + "," + iFld1);
        PrintStream printStream2 = FuzzerUtils.out;
        long j3 = this.lFld;
        boolean z3 = bFld;
        printStream2.println("lFld Test.bFld Test.iArrFld = " + j3 + "," + (z3 ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld));
        PrintStream printStream3 = FuzzerUtils.out;
        long j4 = iMeth_check_sum;
        StringBuilder sb2 = new StringBuilder();
        sb2.append("iMeth_check_sum: ");
        sb2.append(j4);
        printStream3.println(sb2.toString());
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

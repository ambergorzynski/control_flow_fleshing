
import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_20/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static boolean[] bArrFld;
    public static double[] dArrFld;
    public static long lMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public double dFld = -1.93431d;
    public static long instanceCount = 13;
    public static int iFld = 4;
    public static float fFld = 31.93f;

    static {
        boolean[] zArr = new boolean[N];
        bArrFld = zArr;
        dArrFld = new double[N];
        FuzzerUtils.init(zArr, false);
        FuzzerUtils.init(dArrFld, 0.27282d);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        lMeth_check_sum = 0L;
    }

    public static long lMeth(int i) {
        int[] iArr = new int[N];
        int[][] iArr2 = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 7L);
        FuzzerUtils.init(iArr, -8);
        FuzzerUtils.init(iArr2, 24364);
        int i2 = -20;
        int i3 = -14;
        int i4 = 144;
        while (true) {
            i4--;
            if (i4 <= 0) {
                break;
            }
            i2 = 1;
            while (i2 < 11) {
                i3 >>= i;
                i2++;
            }
            iFld += i3;
        }
        fFld = iFld;
        iFld = i;
        jArr[(i3 >>> 1) % N] = instanceCount;
        iArr[(i2 >>> 1) % N] = iArr[r8] - 12;
        int i5 = 6;
        int i6 = 1;
        while (true) {
            i6++;
            if (i6 < 230) {
                i5 = 1;
                while (i5 < 7) {
                    i5++;
                    iArr[i5] = iArr[i5] * (-126);
                    instanceCount = iFld;
                    iFld = i2;
                    int i7 = i6 + 1;
                    iArr[i7] = iArr[i7] & i4;
                    iArr2 = FuzzerUtils.int2array(N, -228);
                }
            } else {
                long checkSum = ((((((i + i4) + i2) + i3) + i6) + i5) - 187) + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(iArr2);
                lMeth_check_sum += checkSum;
                return checkSum;
            }
        }
    }

    public static void vMeth1(int i, int i2, int i3) {
        int[] iArr = new int[N];
        short[] sArr = new short[N];
        FuzzerUtils.init(sArr, (short) 26463);
        FuzzerUtils.init(iArr, -12);
        boolean[] zArr = bArrFld;
        long j = instanceCount - 1;
        instanceCount = j;
        if (j != i3 - 240) {
        }
        zArr[2] = true;
        vMeth1_check_sum += (((((((((((i + i2) + i3) + 1) + 5489) + 1) - 19083) - 12) - 88) - 29908) + Double.doubleToLongBits(76.96424d)) - 61) + FuzzerUtils.checkSum(sArr) + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth() {
        int i;
        int i2 = -10;
        double d = -2.110635d;
        int i3 = 1;
        long j = 1;
        do {
            int i4 = iFld;
            iFld = i4 + ((int) (i4 ^ j));
            fFld -= -2.38888f;
            i = (int) j;
            while (i < 10) {
                double d2 = 1.0d + d;
                i2++;
                double d3 = i2;
                Double.isNaN(d3);
                double d4 = d * (-27.0d) * d3;
                int i5 = iFld;
                i3 = d4 != ((double) (i5 << (i5 * i5))) ? 1 : 0;
                i++;
                d = d2;
            }
            vMeth1(i, -8, i2);
            j++;
        } while (j < 164);
        if (i3 != 0) {
            instanceCount -= i2;
            i2 *= 79;
        }
        int i6 = 16;
        while (i6 < 269) {
            iFld = i6;
            i6 += 3;
        }
        double d5 = instanceCount;
        int i7 = 35558 >> iFld;
        fFld += 50;
        vMeth_check_sum += j + i + i2 + i3 + Double.doubleToLongBits(d5) + i6 + i7 + 50;
    }

    public void mainTest(String[] strArr) {
        int[][][] iArr = (int[][][]) Array.newInstance((Class<?>) int.class, N, N, N);
        byte[] bArr = new byte[N];
        FuzzerUtils.init((Object[][]) iArr, (Object) (-6));
        FuzzerUtils.init(bArr, (byte) 105);
        vMeth();
        int i = iFld;
        iFld = i * i;
        int i2 = 273;
        while (i2 > 14) {
            int i3 = i2 - 1;
            try {
                int i4 = i2 + 1;
                iArr[i3][i2][i4] = (-1094208255) / i2;
                iFld = (-161) / i2;
                iArr[i4][i4][i2] = (-228) / i2;
            } catch (ArithmeticException e) {
            }
            instanceCount = i2;
            iArr[i3][i2 + 1] = FuzzerUtils.int1array(N, 9);
            i2--;
        }
        fFld -= -41976.0f;
        iFld *= i2;
        int i5 = -10;
        int i6 = -10;
        int i7 = 3;
        int i8 = 64098;
        int i9 = -161;
        int i10 = 24674;
        int i11 = 4;
        int i12 = -5;
        int i13 = 55652;
        int i14 = 20795;
        int i15 = 6;
        while (true) {
            int[][][] iArr2 = iArr;
            if (i7 < 154) {
                iFld -= i7;
                i9 *= i9;
                int i16 = 2;
                int i17 = i15;
                int i18 = i14;
                int i19 = i13;
                int i20 = i12;
                int i21 = i11;
                int i22 = 2;
                while (i22 < 166) {
                    i20 = i22;
                    while (i20 < i16) {
                        i21 *= i21;
                        int i23 = i22;
                        i8 += (int) ((i20 * i20) - 250463933);
                        bArr[i23 + 1] = (byte) fFld;
                        i20++;
                        i22 = i23;
                        i16 = 2;
                    }
                    int i24 = i22;
                    fFld = i24;
                    int i25 = 1;
                    while (2 > i25) {
                        long j = 15;
                        instanceCount = j;
                        i5 = (int) j;
                        i25 += 2;
                    }
                    int i26 = i25;
                    int i27 = i21;
                    iFld *= (int) instanceCount;
                    this.dFld = i27;
                    int i28 = 1;
                    while (i28 < 2) {
                        instanceCount >>= i28;
                        i17 |= iFld;
                        float f = fFld;
                        fFld = f + f;
                        i28++;
                        i18 = 11388;
                    }
                    i21 = i27;
                    i22 = i24 + 1;
                    i16 = 2;
                    i19 = i28;
                    i6 = i26;
                }
                i10 = i22;
                i7++;
                iArr = iArr2;
                i11 = i21;
                i12 = i20;
                i13 = i19;
                i14 = i18;
                i15 = i17;
            } else {
                FuzzerUtils.out.println("i21 i22 i23 = " + i2 + "," + i9 + "," + i7);
                FuzzerUtils.out.println("i24 i25 i26 = " + i8 + "," + i10 + "," + i11);
                FuzzerUtils.out.println("i27 i28 i29 = " + i12 + "," + i5 + "," + i6);
                FuzzerUtils.out.println("i30 s i31 = 15,11388," + i13);
                FuzzerUtils.out.println("i32 b2 i33 = " + i14 + ",0," + i15);
                FuzzerUtils.out.println("iArr3 byArr = " + FuzzerUtils.checkSum((Object[][]) iArr2) + "," + FuzzerUtils.checkSum(bArr));
                FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(fFld));
                FuzzerUtils.out.println("dFld Test.bArrFld Test.dArrFld = " + Double.doubleToLongBits(this.dFld) + "," + FuzzerUtils.checkSum(bArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
                PrintStream printStream = FuzzerUtils.out;
                long j2 = lMeth_check_sum;
                StringBuilder sb = new StringBuilder();
                sb.append("lMeth_check_sum: ");
                sb.append(j2);
                printStream.println(sb.toString());
                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

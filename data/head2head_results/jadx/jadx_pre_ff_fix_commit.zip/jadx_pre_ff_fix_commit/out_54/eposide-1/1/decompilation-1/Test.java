
import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_54/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long iMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public byte[] byArrFld = new byte[N];
    public static long instanceCount = -4165452013L;
    public static short sFld = 31609;
    public static double dFld = 2.13063d;
    public static final int N = 400;
    public static float[] fArrFld = new float[N];
    public static volatile int[][] iArrFld = (int[][]) Array.newInstance((Class<?>) int.class, N, N);

    static {
        FuzzerUtils.init(fArrFld, 0.609f);
        FuzzerUtils.init(iArrFld, -21773);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }

    public static void vMeth1(int i) {
        int i2;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -38168);
        int i3 = (int) (-22.53f);
        int i4 = i - i3;
        int i5 = -38892;
        int i6 = 5;
        int i7 = -214;
        double d = -2.126621d;
        int i8 = 1;
        do {
            instanceCount = ((float) instanceCount) + (((i8 * i8) - 22.53f) - i8);
            i2 = 1;
            while (i2 < 8) {
                i4 += i2 * i2;
                i6 = i2;
                while (i6 < 2) {
                    i4 += i6 ^ i2;
                    i5 |= i6;
                    i7 = (i7 << 61) - i6;
                    double d2 = i7;
                    Double.isNaN(d2);
                    d += d2;
                    i6++;
                }
                iArr[i8 - 1] = i3;
                i2++;
            }
            i8++;
        } while (i8 < 214);
        vMeth1_check_sum += i4 + Float.floatToIntBits(-22.53f) + i8 + i2 + i5 + i6 + i7 + Double.doubleToLongBits(d) + 0 + FuzzerUtils.checkSum(iArr);
    }

    public static int iMeth(int i) {
        int i2;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 4752);
        float f = -59.547f;
        float f2 = 0.231f;
        int i3 = 11;
        int i4 = 13;
        int i5 = 5;
        float f3 = 391.0f;
        while (f3 > 19.0f) {
            int i6 = 9;
            while (true) {
                i2 = i6 - 1;
                if (i2 <= 0) {
                    break;
                }
                vMeth1(-4);
                i = (int) f3;
                i6 = i2;
            }
            int i7 = i + ((int) instanceCount);
            int i8 = 1;
            do {
                long j = i8;
                long j2 = instanceCount;
                f += (float) (((j * j2) + j2) - j);
                f2 = 1.0f;
                i8++;
            } while (i8 < 9);
            f3 -= 2.0f;
            i5 = i8;
            i3 = i2;
            i4 = i3;
            i = i7;
        }
        long floatToIntBits = i + Float.floatToIntBits(f3) + i3 + i4 + i5 + Float.floatToIntBits(f) + Float.floatToIntBits(f2) + 195 + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth() {
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, 0.94074d);
        iMeth(4);
        dArr[42] = dArr[42] * 11.0d;
        instanceCount -= 155;
        vMeth_check_sum += ((((((4 + Float.floatToIntBits(157.0f)) + 155) + 3) + 98) - 172) - 27565) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
    }

    public void mainTest(String[] strArr) {
        short[] sArr = new short[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(sArr, (short) 20895);
        FuzzerUtils.init(jArr, -2519876697L);
        vMeth();
        int i = 7257;
        int i2 = -36040;
        int i3 = -14;
        int i4 = 0;
        int i5 = 18;
        while (i5 < 303) {
            long j = i5;
            long j2 = instanceCount + j;
            instanceCount = j2;
            i4 = (int) (-1.726f);
            sArr[i5 + 1] = (short) j2;
            long j3 = i * ((int) (-1.726f));
            i = (int) (j3 + (((j2 * j) + j) - j3));
            i2 = 1;
            while (true) {
                i2++;
                if (i2 < 88) {
                    i3 = 2;
                    jArr[i5] = jArr[i5] + ((long) dFld);
                }
            }
            double d = dFld;
            double d2 = i2;
            Double.isNaN(d2);
            dFld = d * d2;
            byte[] bArr = this.byArrFld;
            int i6 = i5 + 1;
            bArr[i6] = (byte) (bArr[i6] + ((byte) instanceCount));
            i5++;
        }
        long j4 = i4;
        instanceCount *= j4;
        instanceCount = j4;
        int i7 = 9;
        while (i7 < 276) {
            jArr[i7] = jArr[i7] - (-1.726f);
            i = -1;
            i4 <<= (int) instanceCount;
            i7++;
        }
        FuzzerUtils.out.println("i16 i17 i18 = " + i4 + "," + i5 + "," + i);
        FuzzerUtils.out.println("f5 i19 i20 = " + Float.floatToIntBits(-1.726f) + "," + i2 + "," + i3);
        FuzzerUtils.out.println("b2 i21 i22 = 1," + i7 + ",-7");
        FuzzerUtils.out.println("sArr lArr = " + FuzzerUtils.checkSum(sArr) + "," + FuzzerUtils.checkSum(jArr));
        PrintStream printStream = FuzzerUtils.out;
        long j5 = instanceCount;
        short s = sFld;
        printStream.println("Test.instanceCount Test.sFld Test.dFld = " + j5 + "," + ((int) s) + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.fArrFld Test.iArrFld byArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(this.byArrFld));
        PrintStream printStream2 = FuzzerUtils.out;
        long j6 = vMeth1_check_sum;
        StringBuilder sb = new StringBuilder();
        sb.append("vMeth1_check_sum: ");
        sb.append(j6);
        printStream2.println(sb.toString());
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

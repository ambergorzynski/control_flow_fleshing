package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_0/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static long fMeth_check_sum;
    public static int[] iArrFld1;
    public static long lMeth_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = -2864363349718374362L;
    public static byte byFld = -46;
    public static float fFld = 0.427f;
    public static int iFld = -13;
    public static volatile double dFld = -93.14442d;
    public static short sFld = -16082;
    public int iFld1 = 4;
    public int[][][] iArrFld = (int[][][]) Array.newInstance((Class<?>) int.class, N, N, N);
    public volatile double[] dArrFld = new double[N];

    static {
        int[] iArr = new int[N];
        iArrFld1 = iArr;
        FuzzerUtils.init(iArr, -5);
        fMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
    }

    public static long lMeth(int i, long j, int i2) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -934915742991891276L);
        long j2 = 1;
        long j3 = j;
        long j4 = 1;
        short s = -25069;
        int i3 = 209;
        int i4 = 14;
        int i5 = 165;
        while (true) {
            j4 += j2;
            if (j4 < 237) {
                long j5 = i;
                j3 += ((j4 * j5) + j5) - j5;
                s = (short) (s + ((short) instanceCount));
                int i6 = 1;
                while (true) {
                    i6++;
                    if (i6 < 7) {
                        jArr[i6] = jArr[i6] + j3;
                        j3 = ((j3 - 1) + (fFld ^ i6)) << (-5568);
                        int[] iArr = iArrFld1;
                        int i7 = i6 - 1;
                        iArr[i7] = iArr[i7] + 3;
                        i5 *= (int) j3;
                        i4 = 1;
                    }
                }
                fFld += (float) j4;
                i3 = i6;
                j2 = 1;
            } else {
                long checkSum = i + j3 + i2 + j4 + 0 + s + i3 + i4 + i5 + FuzzerUtils.checkSum(jArr);
                lMeth_check_sum += checkSum;
                return checkSum;
            }
        }
    }

    public static void vMeth() {
        int[] iArr = new int[N];
        short[][][] sArr = (short[][][]) Array.newInstance((Class<?>) short.class, N, N, N);
        FuzzerUtils.init(iArr, -94);
        FuzzerUtils.init((Object[][]) sArr, (Object) (short) -9076);
        int i = iArr[44] + 1;
        iArr[44] = i;
        iArr[44] = i;
        double d = 0.14547d;
        int i2 = 24;
        int i3 = 53688;
        int i4 = -10;
        int i5 = 244;
        int i6 = -12;
        int i7 = 27184;
        while (i2 < 397) {
            i5 = 1;
            while (i5 < 5) {
                long j = instanceCount;
                i3 -= (int) lMeth(-11, j, i2);
                instanceCount = j + i3 + 2;
                i4 += ((i5 * i5) + i3) - i4;
                d = iFld;
                fFld *= -6;
                i5++;
            }
            iFld *= -6;
            int i8 = 1;
            while (i8 < 5) {
                i8++;
                i7 = 2;
            }
            int i9 = i8;
            i3 = i2;
            i2++;
            i6 = i9;
        }
        vMeth_check_sum += ((((i3 + i2) + i4) + i5) - 6) + Double.doubleToLongBits(d) + i6 + 142 + i7 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum((Object[][]) sArr);
    }

    public static float fMeth(int i, int i2, float f) {
        long[] jArr = new long[N];
        byte[] bArr = new byte[N];
        FuzzerUtils.init(jArr, -1831778103L);
        FuzzerUtils.init(bArr, (byte) -11);
        int i3 = 119;
        int i4 = -4;
        int i5 = 126;
        int i6 = 8;
        while (194 > i6) {
            long j = jArr[i6];
            jArr[i6] = 1 + j;
            byFld = (byte) j;
            vMeth();
            float f2 = fFld;
            long j2 = (byFld * i6) + i3;
            long j3 = instanceCount;
            fFld = f2 + ((float) (j2 - j3));
            bArr[i6] = (byte) i2;
            i3 = (int) f;
            i2 = (int) j3;
            int i7 = ((i6 % 3) * 5) + 32;
            if (i7 == 41) {
                instanceCount = 63L;
            } else {
                if (i7 != 42) {
                    if (i7 == 47) {
                        i4 = 1;
                        while (i4 < 9) {
                            i5 = (i5 - i3) << i6;
                            i2 *= 538092779;
                            iFld += i4;
                            i4++;
                        }
                    }
                }
                iFld += (int) dFld;
            }
            i6++;
        }
        long floatToIntBits = i + i2 + Float.floatToIntBits(f) + i6 + i3 + i4 + i5 + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(bArr);
        fMeth_check_sum += floatToIntBits;
        return (float) floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        float f;
        float[] fArr = new float[N];
        boolean[] zArr = new boolean[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -1081556649L);
        FuzzerUtils.init(fArr, 0.258f);
        FuzzerUtils.init(zArr, false);
        float f2 = 15.0f;
        int i = 26944;
        int i2 = -6184;
        int i3 = 15129;
        int i4 = -12324;
        int i5 = 11397;
        while (f2 < 253.0f) {
            int i6 = (int) f2;
            float f3 = f2 + 1.0f;
            int i7 = (int) f3;
            i <<= Math.abs((int) (this.iArrFld[i6][i7][i7] * fMeth(-9, iFld, fFld)));
            jArr[i6] = jArr[i6] - f2;
            int i8 = 1;
            while (true) {
                int[] iArr = iArrFld1;
                i2 = i8 + 1;
                int i9 = iFld;
                iArr[i2] = i9;
                iFld = i9 + (sFld | i8);
                double[] dArr = this.dArrFld;
                double d = dArr[i7];
                int i10 = i3;
                int i11 = i4;
                double d2 = iFld;
                Double.isNaN(d2);
                dArr[i7] = d - d2;
                jArr[i6] = jArr[i6] >> i;
                int[] iArr2 = iArrFld1;
                iArr2[i2] = iArr2[i2] - byFld;
                try {
                    int i12 = 144 / iArr2[i6];
                    iFld = i12;
                    iFld = i12 % i12;
                    i4 = (-157) % i;
                } catch (ArithmeticException e) {
                    i4 = i11;
                }
                int i13 = i8 - 1;
                f = f3;
                int i14 = i7;
                jArr[i13] = jArr[i13] - iFld;
                i5 = 2;
                try {
                    i3 = iArrFld1[i6] / 702747640;
                    try {
                        i = this.iArrFld[i13][i8][i2] / 38744;
                        this.iFld1 = i8 / i;
                    } catch (ArithmeticException e2) {
                    }
                } catch (ArithmeticException e3) {
                    i3 = i10;
                }
                float f4 = fFld + i4;
                fFld = f4;
                fFld = f4 + i8 + byFld;
                if (i2 >= 106) {
                    break;
                }
                i8 = i2;
                f3 = f;
                i7 = i14;
            }
            f2 = f;
        }
        FuzzerUtils.out.println("f i i20 = " + Float.floatToIntBits(f2) + "," + i + "," + i2);
        FuzzerUtils.out.println("i21 i22 b1 = -85," + i3 + ",1");
        FuzzerUtils.out.println("i23 i24 i25 = 144," + i4 + "," + i5);
        FuzzerUtils.out.println("lArr2 fArr bArr = " + FuzzerUtils.checkSum(jArr) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + "," + FuzzerUtils.checkSum(zArr));
        PrintStream printStream = FuzzerUtils.out;
        long j = instanceCount;
        byte b = byFld;
        printStream.println("Test.instanceCount Test.byFld Test.fFld = " + j + "," + ((int) b) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.iFld Test.dFld Test.sFld = " + iFld + "," + Double.doubleToLongBits(dFld) + "," + ((int) sFld));
        FuzzerUtils.out.println("iFld1 iArrFld Test.iArrFld1 = " + this.iFld1 + "," + FuzzerUtils.checkSum((Object[][]) this.iArrFld) + "," + FuzzerUtils.checkSum(iArrFld1));
        PrintStream printStream2 = FuzzerUtils.out;
        long doubleToLongBits = Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld));
        StringBuilder sb = new StringBuilder();
        sb.append("dArrFld = ");
        sb.append(doubleToLongBits);
        printStream2.println(sb.toString());
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}


import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_12/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long dMeth_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vSmallMeth_check_sum;
    public static volatile long instanceCount = -8;
    public static float fFld = 0.673f;
    public static short sFld = 14997;
    public static final int N = 400;
    public static volatile int[] iArrFld = new int[N];

    static {
        FuzzerUtils.init(iArrFld, -13);
        vSmallMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        dMeth_check_sum = 0L;
    }

    public static void vSmallMeth() {
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, 81.137f);
        fArr[343] = 73;
        vSmallMeth_check_sum += (-135) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public static double dMeth(int i) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 80);
        int i2 = 71;
        int i3 = 251;
        int i4 = 95;
        int i5 = 8;
        int i6 = -140;
        int i7 = 206;
        int i8 = 1;
        while (i7 > 7) {
            i3 = 1;
            while (i3 < 16) {
                i5 = 1;
                while (i5 < 2) {
                    int i9 = i4 >> 34;
                    try {
                        i = i2 / 2119186547;
                        i9 = i7 % 109;
                        i8 = (-38964) / i9;
                    } catch (ArithmeticException e) {
                    }
                    fFld += ((i5 * i3) + i9) - 22346;
                    instanceCount |= instanceCount;
                    try {
                        i2 = 55235 / i9;
                        i8 = (-191) / iArr[i5];
                        i = i3 % i9;
                    } catch (ArithmeticException e2) {
                    }
                    i4 = i9 + i5;
                    instanceCount = i2;
                    i5++;
                }
                int i10 = i3;
                while (i10 < 2) {
                    iArr[i3 - 1] = i3;
                    i10++;
                }
                i3++;
                i6 = i10;
            }
            i7 -= 2;
        }
        long checkSum = ((((((((((i + i7) + i2) + i3) + i4) + i5) + i8) + 0) + 22346) + i6) - 6) + FuzzerUtils.checkSum(iArr);
        dMeth_check_sum += checkSum;
        return checkSum;
    }

    public static int iMeth(int i, int i2, int i3) {
        int i4 = -30452;
        int i5 = 157;
        int i6 = -6;
        double d = 0.43876d;
        int i7 = 12;
        while (i7 < 234) {
            dMeth(-190);
            instanceCount = instanceCount;
            i4 = 1;
            while (i4 < 7) {
                instanceCount = 8;
                i -= i2;
                double d2 = i3;
                Double.isNaN(d2);
                d *= d2;
                instanceCount = fFld;
                i4++;
            }
            int i8 = i7 + 1;
            iArrFld[i8] = 8;
            i2 *= (int) fFld;
            int i9 = i7;
            while (i9 < 7) {
                i5 /= -173;
                iArrFld[i7] = -1145699105;
                i9++;
            }
            i6 = i9;
            i7 = i8;
        }
        long doubleToLongBits = (((((((((i + i2) + i3) + i7) + 8) + i4) + i5) + Double.doubleToLongBits(d)) + i6) - 173) + 1;
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static void vMeth(long j, int i) {
        byte[] bArr = new byte[N];
        long[][] jArr = (long[][]) Array.newInstance((Class<?>) long.class, N, N);
        FuzzerUtils.init(bArr, (byte) -113);
        FuzzerUtils.init(jArr, -3006684251L);
        double iMeth = iMeth(i, i, -36517) - i;
        double d = 41.48848d;
        Double.isNaN(iMeth);
        int i2 = i - ((int) (iMeth - 41.48848d));
        int i3 = 22765;
        int i4 = -3;
        int i5 = 1;
        while (true) {
            i5++;
            if (i5 < 212) {
                i3 = 1;
                while (8 > i3) {
                    i2 = i5 - ((int) d);
                    short s = sFld;
                    double d2 = s;
                    Double.isNaN(d2);
                    d *= d2;
                    int i6 = i5 - 1;
                    bArr[i6] = (byte) i2;
                    sFld = (short) (s - ((short) i5));
                    int i7 = ((i5 % 2) * 5) + 126;
                    if (i7 == 131) {
                        int i8 = (int) d;
                        long[] jArr2 = jArr[i5];
                        jArr2[i6] = jArr2[i6] * i2;
                        iArrFld[i5] = i8;
                        i4 = i8;
                        d = i3;
                    } else {
                        i4 = i7 != 133 ? i2 : ((int) fFld) + i2;
                    }
                    i3++;
                }
            } else {
                vMeth_check_sum += j + i2 + Double.doubleToLongBits(d) + i5 + i3 + i4 + FuzzerUtils.checkSum(bArr) + FuzzerUtils.checkSum(jArr);
                return;
            }
        }
    }

    public void mainTest(String[] strArr) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 154L);
        short s = (short) (((short) 7) * 1230);
        for (int i = 0; i < 940; i++) {
            vSmallMeth();
        }
        vMeth(instanceCount, 7);
        iArrFld[3] = 7;
        int i2 = 8;
        short s2 = s;
        double d = 1.59892d;
        int i3 = 8;
        int i4 = -5;
        int i5 = 11;
        int i6 = 0;
        int i7 = 1;
        byte b = 1;
        while (298 > i3) {
            int i8 = i3 + 1;
            jArr[i8] = jArr[i8] << i6;
            int i9 = 5;
            while (i9 < 87) {
                int i10 = i6;
                double d2 = d;
                int i11 = i4;
                short s3 = s2;
                int i12 = 1;
                while (i12 < 2) {
                    instanceCount = i12;
                    fFld = -179.0f;
                    b = (byte) (b + ((byte) d2));
                    switch (((i3 >>> 1) % 9) + 29) {
                        case 29:
                            int[] iArr = iArrFld;
                            int i13 = i9 + 1;
                            iArr[i13] = iArr[i13] << i9;
                            break;
                        case 30:
                        case 31:
                            i7 -= (int) instanceCount;
                            i10 = i12;
                            break;
                        case 32:
                            instanceCount = instanceCount;
                            int i14 = (int) fFld;
                            try {
                                int i15 = i12 - 1;
                                iArrFld[i15] = iArrFld[i15] % 210;
                                i14 = 150 / i11;
                                iArrFld[i12 + 1] = (-176) / i14;
                                i10 = i14;
                                break;
                            } catch (ArithmeticException e) {
                                i10 = i14;
                                break;
                            }
                        case 33:
                            instanceCount += i12 | i3;
                            iArrFld[i3 - 1] = sFld;
                            s3 = (short) (s3 + ((short) ((i12 * i12) - 161)));
                            break;
                        case 34:
                            instanceCount += b;
                        case 35:
                            i11 -= 98;
                            break;
                        case 36:
                            i10 = i11;
                            break;
                        case 37:
                            i7 -= i12;
                        default:
                            d2 = i9;
                            break;
                    }
                    i12++;
                }
                i9++;
                i6 = i10;
                i2 = i12;
                s2 = s3;
                i4 = i11;
                d = d2;
            }
            i3 = i8;
            i5 = i9;
        }
        FuzzerUtils.out.println("s i i24 = " + ((int) s2) + "," + i6 + "," + i3);
        FuzzerUtils.out.println("i25 i26 i27 = " + i4 + "," + i5 + "," + i7);
        FuzzerUtils.out.println("i28 i29 b3 = " + i2 + ",10,0");
        FuzzerUtils.out.println("by1 d3 lArr1 = " + ((int) b) + "," + Double.doubleToLongBits(d) + "," + FuzzerUtils.checkSum(jArr));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.sFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + ((int) sFld));
        PrintStream printStream = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(iArrFld);
        StringBuilder sb = new StringBuilder();
        sb.append("Test.iArrFld = ");
        sb.append(checkSum);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
        FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

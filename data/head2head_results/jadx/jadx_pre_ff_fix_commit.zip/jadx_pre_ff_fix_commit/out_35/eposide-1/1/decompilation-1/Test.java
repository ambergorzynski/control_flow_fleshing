
import java.io.PrintStream;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_35/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long iMeth1_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = 7702945110749427338L;
    public static final int N = 400;
    public static volatile int[] iArrFld = new int[N];
    public int iFld1 = -165;
    public short sFld = -7848;
    public long[] lArrFld = new long[N];

    static {
        FuzzerUtils.init(iArrFld, -14);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
    }

    public static int iMeth1(int i, int i2) {
        long j = i + i + i2;
        iMeth1_check_sum += j;
        return (int) j;
    }

    public static void vMeth() {
        int i = -1;
        int i2 = -1725;
        int i3 = 246;
        float f = 0.915f;
        double d = 1.59913d;
        int i4 = 13;
        int i5 = 1;
        while (256 > i4) {
            float f2 = i2 - 1;
            i2 *= (int) (f2 - ((f * f2) + iMeth1(248, r3)));
            switch ((i4 % 3) + 81) {
                case 81:
                    i5 = 0;
                    break;
                case 82:
                    f += i2;
                    d *= -1.0d;
                    long j = instanceCount;
                    instanceCount = j + (((i4 * i2) + j) - (-3673));
                case 83:
                default:
                    int[] iArr = iArrFld;
                    int i6 = i4 - 1;
                    iArr[i6] = iArr[i6] ^ i4;
                    break;
            }
            i3 = 1;
            while (i3 < 7) {
                double d2 = i2;
                Double.isNaN(d2);
                d += d2;
                try {
                    i2 = i3 % (-42005);
                    int i7 = i2 % i4;
                    i = i2 / iArrFld[i4 - 1];
                } catch (ArithmeticException e) {
                }
                i3++;
            }
            i4++;
        }
        vMeth_check_sum += (((((i4 + i2) + Float.floatToIntBits(f)) + i5) + Double.doubleToLongBits(d)) - 3673) + i3 + i;
    }

    public static int iMeth(int i, float f, int i2) {
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, -63.803f);
        vMeth();
        iArrFld = iArrFld;
        int i3 = -17788;
        short s = -15531;
        int i4 = 1;
        int i5 = 1;
        do {
            int i6 = ((i2 >>> 1) % 2) + 97;
            if (i6 == 97) {
                i *= i;
                int i7 = (i4 % 2) + 114;
                if (i7 == 114) {
                    fArr[i4] = i2;
                    i5 = 1;
                    while (i5 < 10) {
                        i2 += i5;
                        int[] iArr = iArrFld;
                        iArr[i5] = iArr[i5] ^ i2;
                        i3 = (int) f;
                        s = (short) (s + ((short) (i5 | i4)));
                        i5++;
                    }
                    int[] iArr2 = iArrFld;
                    int i8 = i4 - 1;
                    iArr2[i8] = iArr2[i8] + i2;
                } else {
                    if (i7 == 115) {
                        i3 = (int) f;
                    }
                    i2 -= i3;
                }
            } else if (i6 == 98) {
                i3 = i;
            } else {
                int[] iArr3 = iArrFld;
                iArr3[i4] = iArr3[i4] * (-239);
            }
            i4++;
        } while (i4 < 151);
        long floatToIntBits = i + Float.floatToIntBits(f) + i2 + i4 + i5 + i3 + s + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        int i;
        iArrFld[(this.iFld1 >>> 1) % N] = (int) ((iMeth(r2, -23.662f, r2) * instanceCount) - 70);
        int i2 = -5347;
        int i3 = 1;
        while (true) {
            i3++;
            if (i3 >= 255) {
                break;
            }
            int i4 = this.iFld1 % 1;
            this.iFld1 = i4;
            this.iFld1 = i4 * ((int) instanceCount);
            int i5 = 1;
            while (true) {
                int[] iArr = iArrFld;
                iArr[i3] = iArr[i3] & 87;
                i = i5 + 1;
                if (i >= 99) {
                    try {
                        break;
                    } catch (ArithmeticException e) {
                    }
                } else {
                    i5 = i;
                }
            }
            this.iFld1 = i3 / i;
            this.iFld1 = i3 / (-97);
            this.iFld1 = i / i3;
            i2 = i;
        }
        instanceCount -= this.iFld1;
        int i6 = 1;
        do {
            i6++;
        } while (i6 < 272);
        FuzzerUtils.out.println("f2 i11 i12 = " + Float.floatToIntBits(-23.662f) + "," + i3 + "," + i2);
        FuzzerUtils.out.println("by1 i13 i14 = 87," + i6 + ",15");
        FuzzerUtils.out.println("i15 l i16 = 12,43575,32886");
        FuzzerUtils.out.println("b1 l1 i17 = 1,-8989284726440727520,8938");
        PrintStream printStream = FuzzerUtils.out;
        StringBuilder sb = new StringBuilder();
        sb.append("i18 = ");
        sb.append(-44372);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount iFld1 sFld = " + instanceCount + "," + this.iFld1 + "," + ((int) this.sFld));
        FuzzerUtils.out.println("Test.iArrFld lArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(this.lArrFld));
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

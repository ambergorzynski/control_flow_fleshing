
import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_34/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long iMeth1_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = 2096967976490354578L;
    public static float fFld = -86.392f;
    public static byte byFld = -109;
    public static final int N = 400;
    public static volatile long[] lArrFld = new long[N];
    public static float[] fArrFld = new float[N];
    public int iFld = 7;
    public int[][] iArrFld = (int[][]) Array.newInstance((Class<?>) int.class, N, N);

    static {
        FuzzerUtils.init(lArrFld, -6L);
        FuzzerUtils.init(fArrFld, 0.274f);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
    }

    public int iMeth1(float f) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -1);
        int i = -9;
        int i2 = 96;
        short s = 26004;
        double d = 17.4084d;
        int i3 = 358;
        while (true) {
            i3--;
            if (i3 <= 0) {
                break;
            }
            s = (short) (s + ((short) fFld));
            this.iFld <<= i3;
            instanceCount += (i3 * i3) - 11708;
            i = 1;
            while (i < 5) {
                d = -58236.0d;
                i2 *= (int) f;
                long[] jArr = lArrFld;
                int i4 = i - 1;
                jArr[i4] = jArr[i4] << i2;
                this.iFld >>>= i2;
                i++;
            }
        }
        fFld = f;
        int[] iArr2 = this.iArrFld[(i2 >>> 1) % N];
        int i5 = (i >>> 1) % N;
        iArr2[i5] = iArr2[i5] * i3;
        int i6 = -11560;
        for (int i7 = 0; i7 < 400; i7++) {
            int i8 = iArr[i7];
            i6 = 4;
            while (true) {
                i6--;
                if (i6 > 0) {
                    instanceCount = byFld;
                }
            }
        }
        this.iFld += 44295;
        long floatToIntBits = Float.floatToIntBits(f) + i3 + s + i + i2 + Double.doubleToLongBits(d) + i6 + FuzzerUtils.checkSum(iArr);
        iMeth1_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public int iMeth(int i, boolean z) {
        long j = instanceCount + (i * (-202));
        int[] iArr = this.iArrFld[(i >>> 1) % N];
        int i2 = iArr[45] + 1;
        iArr[45] = i2;
        int i3 = j == ((long) i2) ? 0 : 1;
        int i4 = 3;
        int i5 = 8445;
        int i6 = 14;
        double d = 85.30178d;
        while (i4 < 363) {
            i6 = 5;
            while (true) {
                i6--;
                if (i6 > 0) {
                    double iMeth1 = iMeth1(-12.242f) << (-1834406545);
                    Double.isNaN(iMeth1);
                    i |= (int) (1.80901d + iMeth1);
                    int[][] iArr2 = this.iArrFld;
                    int i7 = i4 + 1;
                    iArr2[i6 + 1] = iArr2[i7];
                    d = i6;
                    while (d < 1.0d) {
                        instanceCount -= 29034;
                        int[][] iArr3 = this.iArrFld;
                        iArr3[(int) (d - 1.0d)] = iArr3[i7];
                        int i8 = this.iFld;
                        fFld = i8;
                        iArr3[i6 - 1][i7] = i6;
                        i5 = (i5 + 64) << 6;
                        i = 206;
                        this.iFld = i8 + 81;
                        d += 3.0d;
                    }
                }
            }
            i4++;
        }
        long doubleToLongBits = ((((((i + i3) + i4) + i5) + i6) + Double.doubleToLongBits(d)) - 64) + 29034;
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public void vMeth() {
        int i;
        int i2;
        int[][][] iArr = (int[][][]) Array.newInstance((Class<?>) int.class, N, N, N);
        short[][][] sArr = (short[][][]) Array.newInstance((Class<?>) short.class, N, N, N);
        FuzzerUtils.init((Object[][]) iArr, (Object) 138);
        FuzzerUtils.init((Object[][]) sArr, (Object) (short) -6811);
        int i3 = -254;
        int i4 = 4;
        int i5 = -62766;
        double d = 72.2678d;
        float f = 0.526f;
        int i6 = 8;
        while (173 > i6) {
            long j = instanceCount;
            float f2 = fFld;
            int i7 = i6 + 1;
            int[] iArr2 = iArr[i6][i7];
            int i8 = i6 - 1;
            iArr2[i8] = iArr2[i8] - (-17219);
            instanceCount = j - ((f2 - (-r11)) + ((i3 / (i3 | 1)) + (13363 - i6)));
            long[] jArr = lArrFld;
            int i9 = i3 - 1;
            jArr[i8] = jArr[i8] + (i6 - r13);
            int i10 = 1;
            while (true) {
                switch ((i6 % 6) + 77) {
                    case 77:
                        i = i7;
                        long[] jArr2 = lArrFld;
                        int i11 = i10 + 1;
                        long j2 = jArr2[i11];
                        short[] sArr2 = sArr[i10][i];
                        short s = (short) (sArr2[i8] + 1);
                        sArr2[i8] = s;
                        int[] iArr3 = iArr[i10][i6];
                        int i12 = i10 - 1;
                        int i13 = iArr3[i12] + 1;
                        iArr3[i12] = i13;
                        jArr2[i11] = j2 >> (s + i13);
                        i2 = i9;
                        iMeth(i2, false);
                        double d2 = -17219;
                        Double.isNaN(d2);
                        d /= d2;
                        break;
                    case 78:
                        i = i7;
                        int i14 = this.iFld;
                        this.iFld = i14 - i14;
                        this.iFld = 25834;
                        this.iFld = (int) fFld;
                        i2 = i9;
                        break;
                    case 79:
                        f = 1.0f;
                    case 80:
                        int i15 = i10 - 1;
                        int[] iArr4 = iArr[i15][i10 + 1];
                        iArr4[i15] = iArr4[i15] >>> i9;
                    case 81:
                        i = i7;
                        this.iFld = (int) (this.iFld + i10 + instanceCount);
                        i5 <<= i9;
                        i2 = i9;
                        this.iFld += 13;
                        break;
                    case 82:
                        i = i7;
                        i5 <<= i9;
                        i2 = i9;
                        this.iFld += 13;
                        break;
                    default:
                        i = i7;
                        i2 = i9;
                        this.iFld += 13;
                        break;
                }
                i10++;
                if (i10 >= 10) {
                    break;
                }
                i9 = i2;
                i7 = i;
            }
            i4 = i10;
            i3 = i2;
            i6 = i;
        }
        vMeth_check_sum += ((i6 + i3) - 17219) + i4 + 0 + Double.doubleToLongBits(d) + Float.floatToIntBits(f) + i5 + FuzzerUtils.checkSum((Object[][]) iArr) + FuzzerUtils.checkSum((Object[][]) sArr);
    }

    public void mainTest(String[] strArr) {
        double[] dArr;
        int[] iArr = new int[N];
        double[] dArr2 = new double[N];
        FuzzerUtils.init(dArr2, -57.11637d);
        FuzzerUtils.init(iArr, 113);
        int i = 118;
        int i2 = 19;
        while (i2 < 388) {
            i += (i2 * i2) - 12;
            i2 += 3;
        }
        int i3 = i - 1;
        instanceCount -= i;
        vMeth();
        long[] jArr = lArrFld;
        int i4 = (i2 >>> 1) % N;
        jArr[i4] = jArr[i4] + 20203;
        int i5 = 378;
        int i6 = 7;
        int i7 = -22430;
        int i8 = 97;
        int i9 = -39676;
        int i10 = -11;
        int i11 = 6;
        while (true) {
            int i12 = 2;
            if (i5 > 2) {
                i6 = 8;
                while (i6 < 133) {
                    long j = instanceCount;
                    int[] iArr2 = iArr;
                    long j2 = j + i6 + j;
                    instanceCount = j2;
                    i3 += (int) ((i6 * i6) + 1.33f);
                    int[] iArr3 = this.iArrFld[i6 - 1];
                    iArr3[i5] = iArr3[i5] - this.iFld;
                    instanceCount = j2;
                    float[] fArr = fArrFld;
                    int i13 = i6 + 1;
                    fArr[i13] = fArr[i13] + i12;
                    int i14 = i5 + 1;
                    dArr2[i14] = dArr2[i14] + 40706.0d;
                    int i15 = (i5 % 2) + 112;
                    if (i15 != 112) {
                        if (i15 == 113) {
                            i3 |= (int) j2;
                        }
                        i7 += i6;
                    } else {
                        i9 = 1;
                        while (i12 > i9) {
                            switch ((i5 % 5) + 20) {
                                case 20:
                                    dArr = dArr2;
                                    fArrFld[i6] = r2[i6] - 12.0f;
                                    long j3 = instanceCount;
                                    instanceCount = j3 ^ j3;
                                    i7 += this.iFld + i9;
                                    break;
                                case 21:
                                    dArr = dArr2;
                                    instanceCount += i10;
                                    i10 += 137;
                                    break;
                                case 22:
                                    dArr = dArr2;
                                    i10 += 137;
                                    break;
                                case 23:
                                    this.iFld = (int) instanceCount;
                                    dArr = dArr2;
                                    break;
                                case 24:
                                    iArr2[i13] = i12;
                                    dArr = dArr2;
                                    break;
                                default:
                                    dArr = dArr2;
                                    int[] iArr4 = this.iArrFld[i14];
                                    int i16 = (this.iFld >>> 1) % N;
                                    iArr4[i16] = iArr4[i16] + i3;
                                    break;
                            }
                            i9++;
                            dArr2 = dArr;
                            i12 = 2;
                        }
                    }
                    dArr2 = dArr2;
                    i6 = i13;
                    iArr = iArr2;
                    i8 = 2;
                    i11 = 2;
                    i12 = 2;
                }
                i5 -= 2;
            } else {
                FuzzerUtils.out.println("i i1 i16 = " + i2 + "," + i3 + "," + i5);
                FuzzerUtils.out.println("i17 i18 i19 = -137," + i6 + ",5");
                FuzzerUtils.out.println("i20 i21 i22 = " + i11 + "," + i7 + ",6");
                FuzzerUtils.out.println("i23 i24 i25 = " + i8 + "," + i9 + "," + i10);
                FuzzerUtils.out.println("dArr iArr2 = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr2)) + "," + FuzzerUtils.checkSum(iArr));
                FuzzerUtils.out.println("Test.instanceCount Test.fFld iFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + this.iFld);
                PrintStream printStream = FuzzerUtils.out;
                byte b = byFld;
                printStream.println("Test.byFld Test.lArrFld iArrFld = " + ((int) b) + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
                PrintStream printStream2 = FuzzerUtils.out;
                long doubleToLongBits = Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld));
                StringBuilder sb = new StringBuilder();
                sb.append("Test.fArrFld = ");
                sb.append(doubleToLongBits);
                printStream2.println(sb.toString());
                FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

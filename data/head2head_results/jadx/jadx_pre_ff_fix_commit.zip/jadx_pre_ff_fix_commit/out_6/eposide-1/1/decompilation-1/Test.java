
import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_6/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public int[][] iArrFld = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
    public static long instanceCount = 3;
    public static boolean bFld = true;
    public static int iFld = -13;
    public static volatile byte byFld = 44;
    public static float fFld = 1.982f;
    public static volatile double dFld = 67.128121d;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long vMeth2_check_sum = 0;

    public static void vMeth2(short s, float f) {
        int[][][] iArr = (int[][][]) Array.newInstance((Class<?>) int.class, N, N, N);
        float[] fArr = new float[N];
        double[] dArr = new double[N];
        FuzzerUtils.init((Object[][]) iArr, (Object) 46595);
        FuzzerUtils.init(fArr, -100.246f);
        FuzzerUtils.init(dArr, 0.6493d);
        instanceCount <<= -5;
        vMeth2_check_sum += ((((s + Float.floatToIntBits(f)) - 5) - 18) - 14) + 1 + FuzzerUtils.checkSum((Object[][]) iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
    }

    public static void vMeth1(int i) {
        float[] fArr = new float[N];
        int[] iArr = new int[N];
        FuzzerUtils.init(fArr, 8.778f);
        FuzzerUtils.init(iArr, -219);
        vMeth2((short) 28492, -1.948f);
        int i2 = 64561;
        int i3 = -14;
        int i4 = 10;
        double d = 1.9954d;
        double d2 = -2.5635d;
        float f = 22.0f;
        while (f < 385.0f) {
            int i5 = (int) (f - 1.0f);
            float f2 = fArr[i5];
            long j = instanceCount;
            fArr[i5] = f2 + ((float) j);
            f += 1.0f;
            int i6 = (int) f;
            iArr[i6] = 28492;
            instanceCount = j / (-54693);
            int i7 = 1;
            while (i7 < 5) {
                i7++;
            }
            iArr[i6] = iArr[i6] | i7;
            d -= 8.0d;
            i2 -= i;
            bFld = bFld;
            double d3 = 1.0d;
            while (5.0d > d3) {
                i4 += 28492;
                d = instanceCount;
                d3 += 1.0d;
            }
            i3 = i7;
            d2 = d3;
        }
        vMeth1_check_sum += i + 28492 + Float.floatToIntBits(f) + i2 + i3 + i4 + Double.doubleToLongBits(d) + Double.doubleToLongBits(d2) + 11 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth(long j) {
        int[] iArr = new int[N];
        double[] dArr = new double[N];
        FuzzerUtils.init(iArr, 13);
        FuzzerUtils.init(dArr, -1.70413d);
        vMeth1(iFld);
        int i = -172;
        int i2 = -243;
        int i3 = -24004;
        float f = -2.35f;
        int i4 = 202;
        while (i4 > 1) {
            int i5 = i4 - 1;
            iArr[i5] = iArr[i5] - byFld;
            int i6 = ((i4 % 7) * 5) + 84;
            if (i6 != 86) {
                if (i6 != 98) {
                    if (i6 == 111) {
                        if (bFld) {
                            i = (int) (i + (fFld ^ i4));
                            iArr[i4 + 1] = byFld;
                            iFld = (int) 83.409f;
                            double d = dFld;
                            double d2 = i | 1;
                            Double.isNaN(d2);
                            dFld = d % d2;
                        }
                        float f2 = 1.0f;
                        while (true) {
                            f2 += 1.0f;
                            if (f2 >= 8.0f) {
                                break;
                            }
                            iFld += (int) (f2 * f2);
                            i2 = 1;
                        }
                        f = f2;
                    } else if (i6 != 102) {
                        if (i6 != 103) {
                            if (i6 == 106) {
                                double d3 = dArr[i4];
                                double d4 = iFld;
                                Double.isNaN(d4);
                                dArr[i4] = d3 - d4;
                            } else if (i6 == 107) {
                                iFld += (int) j;
                            }
                        }
                        i3 = (int) f;
                    }
                    i4--;
                } else {
                    iFld += i;
                }
            }
            i3 = -4;
            i4--;
        }
        vMeth_check_sum += j + i4 + i + Float.floatToIntBits(f) + i2 + i3 + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
    }

    public void mainTest(String[] strArr) {
        int i;
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 13L);
        vMeth(instanceCount);
        iFld -= (int) instanceCount;
        int i2 = 14;
        int i3 = 18652;
        int i4 = -190;
        int i5 = -34693;
        int i6 = 63776;
        int i7 = -2948;
        int i8 = 38201;
        short s = 23722;
        double d = 114.10959d;
        int i9 = 8;
        int i10 = 1;
        while (i9 < 139) {
            instanceCount = i2;
            i3 = 2;
            while (true) {
                if (i3 >= 191) {
                    break;
                }
                byFld = (byte) (byFld + ((byte) i3));
                int i11 = i3 * i3;
                instanceCount = ((float) instanceCount) + ((i11 + fFld) - iFld);
                byFld = (byte) (byFld ^ 76);
                instanceCount >>= i2;
                s = (short) (s + ((short) (i11 - 11)));
                i5 = i9;
                while (i5 < 2) {
                    i4 = (int) instanceCount;
                    fFld -= -3.06481792E9f;
                    instanceCount = i4;
                    double d2 = dFld;
                    double d3 = instanceCount;
                    Double.isNaN(d3);
                    dFld = d2 - d3;
                    instanceCount = i10;
                    s = (short) (s + s);
                    i5++;
                    i7 = i7;
                }
                i3++;
            }
            i6 = 8;
            for (i = 191; i6 < i; i = 191) {
                i7 = 1;
                while (i7 < 2) {
                    int i12 = i9 + 1;
                    jArr[i12] = jArr[i12] - 2273;
                    i10 >>= 25125;
                    i7++;
                }
                this.iArrFld = this.iArrFld;
                i2 -= iFld;
                instanceCount = i2;
                if (!bFld) {
                    d = 1.0d;
                    while (d < 2.0d) {
                        iFld += (int) d;
                        d += 1.0d;
                        i2 = i10;
                        i8 = i2;
                    }
                    fFld += i6 * i6;
                }
                i6++;
            }
            i9++;
        }
        FuzzerUtils.out.println("i12 i13 i14 = " + i9 + "," + i2 + "," + i3);
        FuzzerUtils.out.println("i15 s2 i16 = " + i4 + "," + ((int) s) + "," + i5);
        FuzzerUtils.out.println("i17 i18 i19 = " + i10 + "," + i6 + ",148");
        FuzzerUtils.out.println("i20 i21 d2 = " + i7 + "," + i8 + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("i22 lArr = -99," + FuzzerUtils.checkSum(jArr));
        PrintStream printStream = FuzzerUtils.out;
        long j = instanceCount;
        int i13 = bFld ? 1 : 0;
        printStream.println("Test.instanceCount Test.bFld Test.iFld = " + j + "," + i13 + "," + iFld);
        PrintStream printStream2 = FuzzerUtils.out;
        byte b = byFld;
        printStream2.println("Test.byFld Test.fFld Test.dFld = " + ((int) b) + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(dFld));
        PrintStream printStream3 = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(this.iArrFld);
        StringBuilder sb = new StringBuilder();
        sb.append("iArrFld = ");
        sb.append(checkSum);
        printStream3.println(sb.toString());
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}


import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_45/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public static long iMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public long lFld = -4226959853L;
    public static long instanceCount = -1886613931;
    public static boolean bFld = true;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 0);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }

    public static void vMeth1(long j) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 14L);
        int[] iArr = iArrFld;
        iArr[41] = iArr[41] - ((int) 2.36561d);
        int i = -171;
        float f = 33.339f;
        int i2 = 1;
        do {
            f += (float) (i2 - instanceCount);
            i2++;
        } while (i2 < 7);
        int i3 = 1;
        while (7 > i3) {
            int[] iArr2 = iArrFld;
            iArr2[0] = iArr2[0] << 1;
            i -= i2;
            i3++;
        }
        vMeth1_check_sum += (((((((((((2 + j) + Double.doubleToLongBits(2.36561d)) + 1) + i2) + Float.floatToIntBits(f - i)) + i3) + i) - 207) + 60910) - 119) - 6444) + FuzzerUtils.checkSum(jArr);
    }

    public static void vMeth(int i) {
        int[] iArr = iArrFld;
        int length = iArr.length;
        float f = 68.927f;
        float f2 = 2.403f;
        int i2 = 23001;
        byte b = 104;
        short s = 29849;
        int i3 = 0;
        while (i3 < length) {
            int i4 = iArr[i3];
            short s2 = s;
            byte b2 = b;
            int i5 = i2;
            float f3 = f2;
            float f4 = 1.0f;
            while (4.0f > f4) {
                i5 = 1;
                while (i5 < 2) {
                    if (i != 0) {
                        vMeth_check_sum += i + Float.floatToIntBits(f4) + 34559 + i5 + 11 + b2 + s2 + Float.floatToIntBits(f3);
                        return;
                    }
                    b2 = (byte) (b2 + ((byte) (((i5 * 34559) + 34559) - 34559)));
                    long j = instanceCount;
                    instanceCount = j + (((i5 * i) + i) - j);
                    vMeth1(41404L);
                    s2 = (short) (s2 + ((short) (i5 + 34559)));
                    iArrFld[(int) (f4 - 1.0f)] = i5;
                    instanceCount *= b2;
                    i5++;
                }
                instanceCount = i5;
                f3 -= 9.0f;
                i |= i5;
                f4 += 1.0f;
            }
            i3++;
            f = f4;
            f2 = f3;
            i2 = i5;
            b = b2;
            s = s2;
        }
        vMeth_check_sum += i + Float.floatToIntBits(f) + 34559 + i2 + 11 + b + s + Float.floatToIntBits(f2);
    }

    public static int iMeth(int i) {
        int[][][] iArr = (int[][][]) Array.newInstance((Class<?>) int.class, N, N, N);
        FuzzerUtils.init((Object[][]) iArr, (Object) (-14));
        vMeth(i);
        int i2 = i - i;
        int i3 = 5;
        long j = -13;
        short s = -32206;
        int i4 = 11;
        while (i4 < 236) {
            s = (short) (s + ((short) (((i4 * 54451) + 1) - r12)));
            instanceCount = instanceCount * 54451;
            i2 += (int) 0.75468d;
            iArrFld[i4] = 49775;
            i4++;
            j = 1;
            i3 = 2;
        }
        long checkSum = i2 + i4 + 54451 + j + 36983 + i3 + s + FuzzerUtils.checkSum((Object[][]) iArr);
        iMeth_check_sum += checkSum;
        return (int) checkSum;
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        int i3;
        int[][][] iArr = (int[][][]) Array.newInstance((Class<?>) int.class, N, N, N);
        FuzzerUtils.init((Object[][]) iArr, (Object) (-1));
        int i4 = 1;
        int i5 = -153;
        int i6 = 8;
        int i7 = 9;
        int i8 = 43794;
        int i9 = -32829;
        int i10 = -3;
        int i11 = -210;
        int i12 = 207;
        int i13 = -7;
        short s = 1240;
        float f = 0.135f;
        int i14 = 1;
        while (true) {
            i14 += i4;
            if (i14 >= 228) {
                FuzzerUtils.out.println("i i1 i2 = " + i14 + "," + i5 + "," + i6);
                FuzzerUtils.out.println("i3 s i21 = " + i7 + "," + ((int) s) + "," + i8);
                FuzzerUtils.out.println("i22 i23 i24 = " + i9 + "," + i10 + "," + i11);
                FuzzerUtils.out.println("i25 i26 f3 = " + i12 + "," + i13 + "," + Float.floatToIntBits(f));
                PrintStream printStream = FuzzerUtils.out;
                long checkSum = FuzzerUtils.checkSum((Object[][]) iArr);
                StringBuilder sb = new StringBuilder();
                sb.append("iArr1 = ");
                sb.append(checkSum);
                printStream.println(sb.toString());
                FuzzerUtils.out.println("Test.instanceCount lFld Test.bFld = " + instanceCount + "," + this.lFld + "," + (bFld ? 1 : 0));
                PrintStream printStream2 = FuzzerUtils.out;
                long checkSum2 = FuzzerUtils.checkSum(iArrFld);
                StringBuilder sb2 = new StringBuilder();
                sb2.append("Test.iArrFld = ");
                sb2.append(checkSum2);
                printStream2.println(sb2.toString());
                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                return;
            }
            i5 = 110;
            while (5 < i5) {
                int i15 = 1;
                while (true) {
                    i15 += i4;
                    if (i15 >= 3) {
                        break;
                    }
                    i6 += i15 * i15;
                    short s2 = (short) (s + 1);
                    float abs = Math.abs(-1.388f) / (s | 1);
                    int i16 = i8;
                    int i17 = i9;
                    long j = instanceCount;
                    instanceCount = j + 1;
                    if (abs + ((float) j) == ((float) (iMeth(i15) + instanceCount))) {
                        iArrFld[i15] = 40718;
                    }
                    s = s2;
                    i8 = i16;
                    i9 = i17;
                    i4 = 1;
                }
                int i18 = i8;
                int i19 = i9;
                int i20 = ((i14 % 5) * 5) + 104;
                if (i20 != 106) {
                    if (i20 == 108) {
                        i = i15;
                        i3 = i19;
                    } else if (i20 == 120) {
                        instanceCount = i5;
                        boolean z = bFld;
                        if (z) {
                            long j2 = this.lFld;
                            this.lFld = j2 >> ((int) j2);
                            i6 -= 120;
                            int i21 = i5;
                            while (i21 < 3) {
                                long j3 = this.lFld;
                                this.lFld = j3 + i21 + j3;
                                i21++;
                                i15 = i15;
                                i6 = i6;
                            }
                            i = i15;
                            i3 = i19;
                            i10 = i21;
                        } else {
                            i = i15;
                            if (z) {
                                i3 = i5;
                            } else {
                                int i22 = 1;
                                while (i22 < 3) {
                                    bFld = bFld;
                                    i13 = -14545;
                                    i11 &= 13;
                                    f = -49761.0f;
                                    i22++;
                                }
                                i12 = i22;
                                i3 = i19;
                            }
                        }
                    } else if (i20 == 125) {
                        int i23 = i19;
                        i2 = 3;
                        while (i2 > i14) {
                            instanceCount = i23;
                            s = (short) (s >> (-38));
                            instanceCount = i2;
                            i2--;
                            i23 = i14;
                        }
                        i9 = i23 >>> i15;
                        i = i15;
                        int i24 = i6 / (i6 | 1);
                        i6 = 25312;
                        i18 = i2;
                        i5 -= 2;
                        i7 = i;
                        i8 = i18;
                        i4 = 1;
                    } else if (i20 != 128) {
                        i = i15;
                        i9 = i19;
                        i5 -= 2;
                        i7 = i;
                        i8 = i18;
                        i4 = 1;
                    }
                    i9 = i3 + (i5 * i5);
                    i5 -= 2;
                    i7 = i;
                    i8 = i18;
                    i4 = 1;
                }
                i = i15;
                i2 = i18;
                i9 = i19;
                int i242 = i6 / (i6 | 1);
                i6 = 25312;
                i18 = i2;
                i5 -= 2;
                i7 = i;
                i8 = i18;
                i4 = 1;
            }
            i8 = i8;
            i4 = 1;
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}


import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_25/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;
    public static long vMeth_check_sum;
    public double dFld = -114.66431d;
    public int iFld1 = 5;
    public static long instanceCount = -13253;
    public static int iFld = -2585;
    public static volatile short sFld = 25230;
    public static volatile byte byFld = 58;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static int[][] iArrFld1 = (int[][]) Array.newInstance((Class<?>) int.class, N, N);

    static {
        FuzzerUtils.init(iArrFld, -8);
        FuzzerUtils.init(iArrFld1, -240);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }

    public static void vMeth2() {
        int i;
        float[] fArr = new float[N];
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 5);
        FuzzerUtils.init(fArr, 27.519f);
        iArr[(iFld >>> 1) % N] = (int) instanceCount;
        instanceCount = 101L;
        sFld = (short) (sFld + sFld);
        float f = -109.736f;
        float f2 = 1.0f;
        do {
            i = 14;
            while (i > 1) {
                iFld = (int) (-2.125023d);
                f = (f - ((float) instanceCount)) + 39893.0f;
                i--;
            }
            instanceCount += f2 | iFld;
            f2 += 3.0f;
        } while (f2 < 331.0f);
        int i2 = (i >>> 1) % N;
        int i3 = (int) f2;
        iArr[i2] = i3;
        iArr[i2] = iArr[i2] + 45694;
        iFld = -197;
        iArr[349] = iArr[349] * i3;
        fArr[i2] = fArr[i2] - ((float) (-2.125023d));
        vMeth2_check_sum += ((Float.floatToIntBits(f2) + i) - 197) + Double.doubleToLongBits(-2.125023d) + Float.floatToIntBits(f) + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public static void vMeth1(int i) {
        vMeth2();
        long j = instanceCount >> sFld;
        instanceCount = j;
        float f = -3.932f;
        instanceCount = j - (-3.932f);
        int i2 = 10;
        int i3 = 14;
        int i4 = -72;
        int i5 = 98;
        int i6 = -11;
        double d = 103.101107d;
        int i7 = 6;
        while (245 > i7) {
            double d2 = d;
            int i8 = i6;
            int i9 = i5;
            int i10 = i4;
            float f2 = f;
            int i11 = 1;
            while (i11 < 7) {
                f2 += i11;
                i9 = i7;
                while (2 > i9) {
                    instanceCount -= f2;
                    i9++;
                }
                int i12 = (int) instanceCount;
                i8 = 1;
                while (i8 < 2) {
                    long j2 = byFld;
                    instanceCount = j2;
                    long j3 = j2 + i8;
                    instanceCount = j3;
                    instanceCount = j3 + f2;
                    d2 -= -34488.0d;
                    i2 += i8 * i8;
                    i8++;
                }
                i11++;
                i10 = i12;
            }
            i7++;
            i3 = i11;
            f = f2;
            i4 = i10;
            i5 = i9;
            i6 = i8;
            d = d2;
        }
        vMeth1_check_sum += (((((((((i + Float.floatToIntBits(f)) + i7) + i2) + i3) + i4) + i5) - 21) + i6) - 75) + Double.doubleToLongBits(d);
    }

    public static void vMeth(int i) {
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, -77.110192d);
        vMeth1(iFld);
        int i2 = (int) instanceCount;
        int i3 = (i2 >>> 1) % N;
        double d = dArr[i3];
        double d2 = iFld;
        Double.isNaN(d2);
        dArr[i3] = d - d2;
        int i4 = 60373;
        int i5 = 3;
        while (i5 < 301) {
            i4 += i5;
            i2 -= i4;
            i5++;
        }
        iFld |= -24529;
        int i6 = 15;
        while (270 > i6) {
            i6++;
        }
        int[] iArr = iArrFld;
        int length = iArr.length;
        int i7 = 0;
        int i8 = -169;
        int i9 = -9;
        while (i7 < length) {
            int i10 = iArr[i7];
            int i11 = 1;
            while (i11 < 4) {
                int[] iArr2 = iArrFld;
                i11++;
                iArr2[i11] = iArr2[i11] - ((int) instanceCount);
                iFld = i9;
                iArrFld1 = iArrFld1;
                i9 -= i10;
            }
            i7++;
            i8 = i11;
        }
        vMeth_check_sum += ((((i2 + i5) + i4) + i6) - 62637) + i8 + i9 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
    }

    public void mainTest(String[] strArr) {
        int i = iFld >> 168;
        iFld = i;
        vMeth(i);
        int i2 = 7;
        while (i2 < 312) {
            iFld += i2 * i2;
            i2++;
        }
        int i3 = 14;
        int i4 = 2;
        long j = 1087475071600411524L;
        double d = -10.111871d;
        int i5 = 14;
        int i6 = -96;
        int i7 = 29756;
        int i8 = 52224;
        float f = -2.394f;
        int i9 = 2;
        while (i9 < 289) {
            j = 4;
            while (88 > j) {
                i5 = i9;
                while (i5 < i4) {
                    iFld = (int) j;
                    i6 -= 6414;
                    int[] iArr = iArrFld;
                    iArr[i5] = iArr[i5] + 251;
                    i7 *= sFld;
                    int i10 = i3;
                    instanceCount += i5 | j;
                    int i11 = (int) ((j % 2) + 66);
                    if (i11 == 66) {
                        i6 -= 4;
                        i7 -= (int) f;
                        i3 = 168;
                    } else if (i11 != 67) {
                        i3 = i10;
                    } else {
                        i7 = (int) this.dFld;
                        i3 = i10;
                    }
                    i5++;
                }
                int i12 = i3;
                d = 0.0d;
                f = (f - i12) + ((float) ((j * j) - 13));
                int i13 = 1;
                while (i13 < i4) {
                    iArrFld1[i13 - 1][i9 - 1] = (int) 0.0d;
                    double d2 = this.dFld;
                    double d3 = f;
                    Double.isNaN(d3);
                    double d4 = d2 - d3;
                    this.dFld = d4;
                    instanceCount >>= iFld;
                    Double.isNaN(d3);
                    this.dFld = d4 - d3;
                    i13++;
                    i7 = i7;
                    i4 = 2;
                    i6 = -230;
                }
                j++;
                i3 = i12;
                i4 = 2;
                i8 = i13;
            }
            i9++;
            i4 = 2;
        }
        FuzzerUtils.out.println("i i20 i21 = 168," + i2 + "," + i3);
        FuzzerUtils.out.println("i22 i23 l = " + i9 + ",4," + j);
        FuzzerUtils.out.println("i24 i25 i26 = " + i6 + "," + i5 + "," + i7);
        FuzzerUtils.out.println("f4 b d2 = " + Float.floatToIntBits(f) + ",1," + Double.doubleToLongBits(d));
        PrintStream printStream = FuzzerUtils.out;
        StringBuilder sb = new StringBuilder();
        sb.append("i27 i28 = ");
        sb.append(i8);
        sb.append(",");
        sb.append(-140);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.sFld = " + instanceCount + "," + iFld + "," + ((int) sFld));
        PrintStream printStream2 = FuzzerUtils.out;
        byte b = byFld;
        printStream2.println("Test.byFld dFld iFld1 = " + ((int) b) + "," + Double.doubleToLongBits(this.dFld) + "," + this.iFld1);
        FuzzerUtils.out.println("Test.iArrFld Test.iArrFld1 = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(iArrFld1));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}


import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_5/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public int iFld = 3;
    public long[] lArrFld = new long[N];
    public static long instanceCount = -72;
    public static byte byFld = -47;
    public static boolean bFld = true;
    public static double dFld = 1.51139d;
    public static float fFld = 0.338f;
    public static volatile short sFld = -16313;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long iMeth_check_sum = 0;

    public static int iMeth() {
        int i = 3;
        int[][][] iArr = (int[][][]) Array.newInstance((Class<?>) int.class, N, N, N);
        FuzzerUtils.init((Object[][]) iArr, (Object) 63069);
        int i2 = -9;
        int i3 = 52;
        int i4 = -4;
        long j = 1984157282;
        float f = -72.144f;
        int i5 = 9;
        while (191 > i5) {
            j = 9;
            while (j > 1) {
                int[] iArr2 = iArr[(int) j][(int) (j - 1)];
                int i6 = i5 + 1;
                iArr2[i6] = iArr2[i6] + i5;
                i3 = 1;
                while (i3 < 5) {
                    i2 -= i3;
                    i4 = -64035858;
                    boolean z = bFld;
                    if (z) {
                        int i7 = (int) (i + (i3 - f));
                        f += byFld;
                        int[] iArr3 = iArr[i5 - 1][i6];
                        int i8 = i3 + 1;
                        iArr3[i8] = iArr3[i8] + i2;
                        i = i7 + i3;
                    } else if (z) {
                        i2 += i3;
                        instanceCount += i3 * i3;
                        i4 = (i3 - i3) - 64035858;
                        i = i2;
                    }
                    i3++;
                }
                j -= 3;
            }
            i5++;
        }
        long floatToIntBits = i5 + i2 + j + i + i3 + i4 + Float.floatToIntBits(f) + FuzzerUtils.checkSum((Object[][]) iArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth1(int i) {
        long[] jArr = new long[N];
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 40156);
        FuzzerUtils.init(jArr, 43597L);
        long j = instanceCount;
        int i2 = (i >>> 1) % N;
        int i3 = iArr[i2] - 1;
        iArr[i2] = i3;
        int max = i + ((int) ((((-6) + j) * i3) - (Math.max(j, j) * (i - i))));
        int iMeth = (((iMeth() >>> 1) % 10) * 5) + 111;
        long j2 = 7732065335955848916L;
        short s = -16795;
        if (iMeth == 114 || iMeth == 121) {
            max >>= max;
        } else if (iMeth == 123) {
            j2 = 1;
            do {
                int i4 = (int) (((j2 % 3) * 5) + 60);
                if (i4 == 65) {
                    short s2 = (short) (s + ((short) j2));
                    long j3 = instanceCount;
                    double d = dFld;
                    instanceCount = j3 - ((long) d);
                    if (bFld) {
                        s = s2;
                    } else {
                        max += (int) d;
                        s = s2;
                    }
                } else {
                    if (i4 == 68 || i4 == 74) {
                        float f = (float) j2;
                        max += (int) (((f * 0.702f) + max) - f);
                        bFld = true;
                    }
                    if (bFld) {
                        int i5 = (int) j2;
                        iArr[i5] = iArr[i5] - max;
                    } else {
                        instanceCount += s;
                        short s3 = (short) max;
                        max = -29015;
                        s = s3;
                    }
                }
                j2++;
            } while (j2 < 351);
        } else if (iMeth == 145) {
            instanceCount <<= 35294;
        } else if (iMeth == 152) {
            iArr[(max >>> 1) % N] = max;
        } else {
            if (iMeth != 160) {
                if (iMeth == 134) {
                    s = (short) ((-16795) - ((short) max));
                } else if (iMeth == 135) {
                    max -= 2009277388;
                } else if (iMeth != 142) {
                    if (iMeth == 143) {
                        jArr[(max >>> 1) % N] = jArr[r4] - 16795;
                    } else {
                        max += max;
                    }
                }
            }
            max *= 1264072781;
        }
        vMeth1_check_sum += max + j2 + s + Float.floatToIntBits(0.702f) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr);
    }

    public static void vMeth(int i) {
        int i2;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -12127);
        int i3 = 62313;
        int i4 = -14;
        int i5 = 0;
        while (i5 < 400) {
            vMeth1(iArr[i5]);
            long j = i;
            instanceCount = j;
            if (bFld) {
                i2 = i;
            } else {
                instanceCount = j >>> (-71);
                i2 = (i - 8) - ((int) fFld);
            }
            int i6 = 1;
            do {
                i6++;
            } while (i6 < 4);
            i5++;
            i3 = i6;
            i = i2;
            i4 = 1;
        }
        vMeth_check_sum += i + i3 + i4 + 12 + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -181);
        this.iFld = this.iFld;
        int i = -118;
        float f = 55.404f;
        int i2 = 8;
        while (i2 < 135) {
            f = 6.0f;
            while (197.0f > f) {
                instanceCount <<= i - iArr[(int) f];
                vMeth(i2);
                f += 1.0f;
                i--;
            }
            i2++;
        }
        int i3 = 0 >> ((int) instanceCount);
        int i4 = this.iFld;
        fFld *= i3;
        int i5 = 4;
        int i6 = 13;
        int i7 = -6911;
        while (129 > i5) {
            i3 = (int) (i3 + (i5 | instanceCount));
            int i8 = 1;
            while (true) {
                i8++;
                if (i8 < 201) {
                    this.iFld = 168;
                    i4 = -14;
                    i7 = 2;
                }
            }
            i5++;
            i6 = i8;
        }
        FuzzerUtils.out.println("i i1 f = " + i2 + "," + i4 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i2 i15 i16 = " + i3 + "," + i5 + ",168");
        FuzzerUtils.out.println("i17 i18 i19 = " + i6 + "," + i7 + ",-11");
        PrintStream printStream = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(iArr);
        StringBuilder sb = new StringBuilder();
        sb.append("iArr = ");
        sb.append(checkSum);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount iFld Test.byFld = " + instanceCount + "," + this.iFld + "," + ((int) byFld));
        PrintStream printStream2 = FuzzerUtils.out;
        boolean z = bFld;
        printStream2.println("Test.bFld Test.dFld Test.fFld = " + (z ? 1 : 0) + "," + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(fFld));
        PrintStream printStream3 = FuzzerUtils.out;
        short s = sFld;
        printStream3.println("Test.sFld lArrFld = " + ((int) s) + "," + FuzzerUtils.checkSum(this.lArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_33/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long bMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public static volatile long instanceCount = -248;
    public static boolean bFld = false;
    public static double dFld = 52.91308d;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static double[][] dArrFld = (double[][]) Array.newInstance((Class<?>) double.class, N, N);
    public int iFld = 14;
    public byte byFld = 33;
    public float fFld = 2.696f;

    static {
        FuzzerUtils.init(iArrFld, -77);
        FuzzerUtils.init(dArrFld, -1.6862d);
        bMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }

    public static void vMeth1(int i, int i2) {
        int i3 = 185;
        int i4 = 64559;
        int i5 = -9;
        int i6 = 28487;
        double d = 3.0d;
        while (194.0d > d) {
            i += (int) (d * d);
            int i7 = i6;
            int i8 = i5;
            int i9 = i4;
            int i10 = 1;
            while (i10 < 8) {
                int i11 = 1;
                while (2 > i11) {
                    try {
                        i = i9 % (-762226749);
                        iArrFld[i11 - 1] = 132 / i11;
                        i9 = -13;
                    } catch (ArithmeticException e) {
                    }
                    instanceCount <<= -4;
                    i11++;
                }
                instanceCount += 0.65f;
                i10++;
                i8 = i11;
                i7 = 2;
            }
            d += 1.0d;
            i3 = i10;
            i4 = i9;
            i5 = i8;
            i6 = i7;
            i2 = -4;
        }
        vMeth1_check_sum += ((((((((i + i2) + Double.doubleToLongBits(d)) + 192) - 4) + i3) + i4) + i5) - 13) + i6;
    }

    public static void vMeth() {
        long j = instanceCount;
        int[] iArr = iArrFld;
        int i = iArr[25];
        iArr[25] = i - 1;
        instanceCount = j - i;
        vMeth1(50, -96);
        int i2 = -190;
        int i3 = -142;
        int i4 = 7218;
        int i5 = -42753;
        double d = 120.1274d;
        int i6 = 1;
        while (true) {
            i6 += 2;
            if (i6 >= 197 || bFld) {
                break;
            }
            d -= d;
            i2 = 1;
            while (i2 < 16) {
                i3 = i6;
                while (i3 < 2) {
                    instanceCount = i4;
                    i5 += i3 * i3;
                    i3++;
                }
                int[] iArr2 = iArrFld;
                iArr2[i6] = iArr2[i6] - i2;
                double[] dArr = dArrFld[i6];
                double d2 = dArr[i2];
                double d3 = 6;
                Double.isNaN(d3);
                dArr[i2] = d2 + d3;
                i4 = i2;
                i2++;
            }
        }
        vMeth_check_sum += 65 + i6 + Double.doubleToLongBits(d) + i2 + 6 + i3 + i4 + i5;
    }

    public static boolean bMeth(boolean z, byte b) {
        int i = -11;
        double d = -57.123535d;
        int i2 = 20;
        while (i2 < 344) {
            long j = i2 * i2;
            instanceCount += j;
            vMeth();
            if (z) {
                instanceCount += j;
                if (i2 != 0) {
                    return ((int) ((((((long) ((((z ? 1 : 0) + b) + i2) + i)) + Double.doubleToLongBits(d)) + ((long) 5330)) + ((long) (-8))) + ((long) (-32435)))) % 2 > 0;
                }
                i += i2 - i;
                double d2 = 5330;
                Double.isNaN(d2);
                d -= d2;
            } else if (bFld) {
                int[] iArr = iArrFld;
                int i3 = i2 + 1;
                iArr[i3] = iArr[i3] * 4580;
            }
            instanceCount += r4 + 12;
            i2++;
        }
        long doubleToLongBits = (((((((z ? 1 : 0) + b) + i2) + i) + Double.doubleToLongBits(d)) + 5330) - 8) - 32435;
        bMeth_check_sum += doubleToLongBits;
        return doubleToLongBits % 2 > 0;
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        this.iFld = this.iFld;
        bFld = bMeth(bFld, this.byFld);
        int i3 = -173;
        int i4 = -31;
        int i5 = -163;
        int i6 = 14;
        int i7 = -12;
        long j = 0;
        int i8 = 6;
        while (i8 < 130) {
            i3 = 84;
            i4 = 8;
            while (i4 < 202) {
                i6 = i5;
                long j2 = 1;
                while (j2 < 2) {
                    int i9 = ((i4 % 2) * 5) + 104;
                    if (i9 == 107 || i9 == 111) {
                        int i10 = i7 >>> (-62115);
                        int[] iArr = iArrFld;
                        iArr[i4] = iArr[i4] << i10;
                        i6 += i8;
                        i7 = i10;
                    }
                    iArrFld[i8] = 146;
                    this.fFld -= (float) instanceCount;
                    j2++;
                }
                i4++;
                i5 = i6;
                j = j2;
            }
            i6 = (i6 * ((int) dFld)) >> (-61);
            i8++;
        }
        instanceCount >>= i3;
        this.fFld -= i6;
        this.iFld = i7;
        int i11 = i5;
        int i12 = 16;
        int i13 = -11;
        int i14 = i3;
        while (i12 < 321) {
            try {
                i13 = 99 % i8;
                i11 = iArrFld[i12 - 1] / (-37528);
                i14 %= 90;
            } catch (ArithmeticException e) {
            }
            int[] iArr2 = iArrFld;
            int i15 = i12 - 1;
            iArr2[i15] = iArr2[i15] - i12;
            i12 += 2;
        }
        int[] iArr3 = iArrFld;
        iArr3[(i13 >>> 1) % N] = i6;
        int i16 = (((i4 >>> 1) % 8) * 5) + 46;
        double d = 0.17361d;
        if (i16 == 52) {
            i13 |= (int) instanceCount;
            i = -19223;
            i2 = -3;
        } else if (i16 == 57) {
            i7 -= i11;
            i = -19223;
            i2 = -3;
        } else if (i16 == 71) {
            int i17 = 1;
            do {
                this.fFld += i11;
                i17++;
            } while (i17 < 272);
            i7 <<= i4;
            d = 1.0d;
            while (d < 148.0d) {
                this.fFld = -106.0f;
                this.iFld += 159;
                d += 1.0d;
            }
            i = i17;
            i2 = -3;
        } else {
            if (i16 == 73) {
                instanceCount *= this.byFld;
            } else if (i16 == 76) {
                iArr3[(i7 >>> 1) % N] = this.iFld;
            } else if (i16 == 85) {
                i7 *= 2;
                i = -19223;
                i2 = -3;
            } else if (i16 == 81) {
                this.byFld = (byte) i13;
            } else if (i16 == 82) {
                i2 = (-3) - i4;
                i = -19223;
            }
            i = -19223;
            i2 = -3;
        }
        FuzzerUtils.out.println("i19 i20 i21 = " + i8 + "," + i14 + "," + i4);
        FuzzerUtils.out.println("i22 i23 l = " + i11 + "," + i6 + "," + j);
        FuzzerUtils.out.println("i24 i25 i26 = " + i7 + "," + i12 + "," + i13);
        FuzzerUtils.out.println("i27 d3 i28 = " + i + "," + Double.doubleToLongBits(d) + "," + i2);
        FuzzerUtils.out.println("Test.instanceCount iFld Test.bFld = " + instanceCount + "," + this.iFld + "," + (bFld ? 1 : 0));
        PrintStream printStream = FuzzerUtils.out;
        byte b = this.byFld;
        printStream.println("byFld fFld Test.dFld = " + ((int) b) + "," + Float.floatToIntBits(this.fFld) + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.iArrFld Test.dArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

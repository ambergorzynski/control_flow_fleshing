
import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_21/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static long byMeth_check_sum;
    public static int[] iArrFld;
    public static long iMeth_check_sum;
    public static long[] lArrFld;
    public static long vMeth_check_sum;
    public short sFld = 19414;
    public static long instanceCount = 11;
    public static double dFld = 109.111344d;
    public static float fFld = 2.184f;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        lArrFld = new long[N];
        FuzzerUtils.init(iArr, 7359);
        FuzzerUtils.init(lArrFld, -1116910489L);
        byMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
    }

    public static int iMeth(int i, int i2) {
        int i3;
        int i4 = N;
        int[] iArr = new int[N];
        long[][] jArr = (long[][]) Array.newInstance((Class<?>) long.class, N, N);
        double[] dArr = new double[N];
        FuzzerUtils.init(iArr, -214);
        FuzzerUtils.init(jArr, 12469L);
        FuzzerUtils.init(dArr, 9.94702d);
        int i5 = 1;
        int i6 = i;
        int i7 = 1;
        while (true) {
            try {
                iArr[i7] = 28910 / i2;
                iArr[i7 - 1] = i7 % 1912;
                i6 = (-1570563024) % i2;
            } catch (ArithmeticException e) {
            }
            iArr[i7 - 1] = (int) 94.675f;
            long[] jArr2 = jArr[i7];
            int i8 = (i7 >>> 1) % i4;
            jArr2[i8] = jArr2[i8] >>> 23596;
            i7++;
            if (i7 >= 158) {
                break;
            }
            i4 = N;
            i5 = 1;
        }
        int i9 = i2 - i7;
        int i10 = 31341;
        int i11 = -116;
        int i12 = 7386;
        if (((i7 >>> 1) % i5) + 69 != 69) {
            i3 = i6;
        } else {
            int i13 = 0;
            while (i13 < i4) {
                int i14 = iArr[i13];
                i10 = 4;
                while (i5 < i10) {
                    long j = instanceCount;
                    i9 *= (int) j;
                    double d = dArr[2];
                    double d2 = (int) j;
                    Double.isNaN(d2);
                    dArr[2] = d * d2;
                    instanceCount = j - ((long) dFld);
                    i11 *= i10;
                    i10--;
                    i5 = 1;
                    i12 = 2;
                    i6 = i6;
                }
                i13++;
                i4 = N;
                i5 = 1;
            }
            i3 = i6;
        }
        long floatToIntBits = i3 + i9 + i7 + Float.floatToIntBits(94.675f) + i10 + i11 + i12 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth(int i, int i2, long j) {
        int i3;
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, 0.263f);
        FuzzerUtils.init(iArr, 12197);
        iMeth(i2, i2);
        int i4 = i2 * i2;
        instanceCount = fFld;
        long j2 = j;
        int i5 = -35573;
        int i6 = 5;
        while (i6 < 184) {
            int i7 = 1;
            do {
                int i8 = (i4 >>> 1) % N;
                fArr[i8] = fArr[i8] * 114.0f;
                i7++;
            } while (i7 < 9);
            i6++;
            i5 = i7;
            iArr = FuzzerUtils.int2array(N, -87);
            j2 = 44;
        }
        int[] iArr2 = iArr[30];
        int i9 = (i >>> 1) % N;
        iArr2[i9] = iArr2[i9] - (-6870);
        instanceCount += i6;
        int i10 = (int) j2;
        int i11 = 6;
        int i12 = 12060;
        int i13 = -5;
        while (i11 < 187) {
            int i14 = i12;
            int i15 = i10;
            int i16 = i4;
            int i17 = 1;
            while (true) {
                i3 = i17 + 1;
                if (i3 < 9) {
                    try {
                        iArr[i11 + 1][i3 - 1] = (-40010) % i6;
                        i16 = i5 / i5;
                        i14 = i3 / 4590;
                    } catch (ArithmeticException e) {
                    }
                    i15 *= i11;
                    i17 = i3;
                }
            }
            i11++;
            i4 = i16;
            i10 = i15;
            i12 = i14;
            i13 = i3;
        }
        vMeth_check_sum += ((((((((i10 + i4) + j2) + r9) + i12) + i5) - 6870) + i11) - 42) + i13 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(iArr);
    }

    public static byte byMeth(int i, int i2, int i3) {
        int abs = i3 >> ((int) ((-13) - ((i3 * 3) * Math.abs(i2))));
        vMeth(i2, 1, 241L);
        int i4 = 10;
        int i5 = -191;
        int i6 = -13;
        int i7 = 0;
        while (i4 < 255) {
            switch ((i4 % 10) + 75) {
                case 75:
                    instanceCount = 44L;
                    int i8 = 7;
                    while (i8 > 1) {
                        iArrFld[i4] = (int) dFld;
                        i += i8 - 5;
                        long j = instanceCount;
                        instanceCount = j + j;
                        lArrFld = FuzzerUtils.long1array(N, -3644002736018853046L);
                        long j2 = i8;
                        instanceCount = j2;
                        i6 >>= (int) j2;
                        i7 = 2;
                        i8--;
                    }
                    i5 = i8;
                    abs = -5;
                    continue;
                case 76:
                    i6 += i4;
                    continue;
                case 77:
                    i <<= i5;
                    break;
                case 79:
                case 80:
                    try {
                        int i9 = i4 / 48;
                        int i10 = i6 / iArrFld[i4 + 1];
                        abs = i % iArrFld[i4];
                        continue;
                    } catch (ArithmeticException e) {
                        break;
                    }
                case 81:
                    i += (int) instanceCount;
                    continue;
                case 82:
                    i += (int) instanceCount;
                    continue;
                case 83:
                    long j3 = instanceCount;
                    instanceCount = j3 - j3;
                    continue;
                case 84:
                    instanceCount <<= i;
                    continue;
            }
            double d = dFld;
            double d2 = i4;
            Double.isNaN(d2);
            dFld = d + d2;
            i4++;
        }
        long j4 = ((((i + i2) + abs) + i4) - 5) + i5 + i6 + i7 + 1;
        byMeth_check_sum += j4;
        return (byte) j4;
    }

    public void mainTest(String[] strArr) {
        int i;
        double d;
        int i2 = 7;
        double d2 = 1.123119d;
        int i3 = 7;
        while (true) {
            i = -60145;
            if (i3 >= 397) {
                break;
            }
            instanceCount += byMeth(i3, -60145, 14);
            double d3 = 1.0d;
            while (d3 < 65.0d) {
                d3 += 1.0d;
            }
            i3++;
            d2 = d3;
        }
        byte b = (byte) ((-84) / ((byte) (1 | r6)));
        int i4 = -42790;
        instanceCount = instanceCount;
        int i5 = 8;
        int i6 = 123;
        int i7 = 23090;
        int i8 = -4;
        int i9 = 224;
        long j = -2980827217L;
        while (i5 < 229) {
            switch ((i5 % 8) + 36) {
                case 36:
                    i4 += i5;
                case 37:
                    i7 = 114;
                    while (4 < i7) {
                        int i10 = ((i7 % 2) * 5) + 63;
                        if (i10 == 69) {
                            d = d2;
                            fFld += (float) (((2 * i3) + j) - i7);
                            i6 = i4;
                        } else if (i10 == 70) {
                            int[] iArr = iArrFld;
                            iArr[3] = iArr[3] + i2;
                            d = d2;
                            i9 = 0;
                            i7--;
                            d2 = d;
                            i2 = 7;
                        } else {
                            d = d2;
                        }
                        int i11 = (int) fFld;
                        lArrFld[3] = 200;
                        instanceCount += ((2 * i7) + i6) - i11;
                        i = i11;
                        i8 = i5;
                        i9 = 0;
                        i7--;
                        d2 = d;
                        i2 = 7;
                    }
                    break;
                case 38:
                case 39:
                    i4 -= i8;
                    break;
                case 41:
                    i6 *= 6;
                case 42:
                    j -= instanceCount;
                    break;
                case 43:
                    i4 &= i;
                    break;
            }
            i5++;
            d2 = d2;
            i2 = 7;
        }
        FuzzerUtils.out.println("i i1 d = " + i3 + "," + i + "," + Double.doubleToLongBits(d2));
        FuzzerUtils.out.println("i25 by b1 = " + i4 + "," + ((int) b) + ",1");
        FuzzerUtils.out.println("i26 i27 i28 = " + i5 + "," + i6 + "," + i7);
        FuzzerUtils.out.println("i29 i30 l1 = " + i8 + "," + i9 + "," + j);
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.fFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(fFld));
        PrintStream printStream = FuzzerUtils.out;
        short s = this.sFld;
        printStream.println("sFld Test.iArrFld Test.lArrFld = " + ((int) s) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        PrintStream printStream2 = FuzzerUtils.out;
        long j2 = iMeth_check_sum;
        StringBuilder sb = new StringBuilder();
        sb.append("iMeth_check_sum: ");
        sb.append(j2);
        printStream2.println(sb.toString());
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("byMeth_check_sum: " + byMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

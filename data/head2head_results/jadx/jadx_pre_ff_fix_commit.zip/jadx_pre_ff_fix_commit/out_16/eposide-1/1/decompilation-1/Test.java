
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_16/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public boolean bFld = true;
    public long[] lArrFld = new long[N];
    public static long instanceCount = 3;
    public static float fFld = -109.268f;
    public static volatile int iFld = 26579;
    public static byte byFld = 21;
    public static long vMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;

    public static void vMeth1() {
        int[] iArr = new int[N];
        byte[] bArr = new byte[N];
        FuzzerUtils.init(bArr, (byte) -77);
        FuzzerUtils.init(iArr, -55642);
        int i = 159;
        double d = 18.0d;
        int i2 = 5;
        while (d < 315.0d) {
            i2 = (int) d;
            while (i2 < 6) {
                int i3 = (int) (d - 1.0d);
                bArr[i3] = (byte) (bArr[i3] * (-52));
                i2++;
            }
            d += 1.0d;
            i = -126;
        }
        int i4 = 1;
        int i5 = 226;
        int i6 = 63138;
        int i7 = -155;
        int i8 = -13;
        int i9 = 1;
        while (true) {
            i9 += i4;
            if (i9 < 336) {
                i6 = 1;
                while (i6 < 5) {
                    i7 += (int) fFld;
                    i += i7;
                    i5 = -1003069736;
                    long j = instanceCount;
                    instanceCount = j + j;
                    i6++;
                }
                i8 = 5;
                while (i8 > i9) {
                    int i10 = i8 + 1;
                    iArr[i10] = iArr[i10] / ((int) (instanceCount | 1));
                    i ^= i2;
                    i8--;
                    i5 = i5;
                }
                i4 = 1;
            } else {
                vMeth1_check_sum += ((((Double.doubleToLongBits(d) + i) + i2) + i5) - 126) + i9 + i6 + i7 + i8 + 47 + 1 + FuzzerUtils.checkSum(bArr) + FuzzerUtils.checkSum(iArr);
                return;
            }
        }
    }

    public static int iMeth(int i, float f) {
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 3306712452L);
        FuzzerUtils.init(iArr, -14589);
        int i2 = i - 1;
        jArr[330] = i;
        vMeth1();
        byte b = (byte) i2;
        instanceCount = i2;
        iFld ^= iFld;
        int i3 = i2 + i2;
        int[] iArr2 = iArr[(i3 >>> 1) % N];
        int i4 = (iFld >>> 1) % N;
        iArr2[i4] = iArr2[i4] << b;
        int i5 = 62383;
        int i6 = 12;
        while (i6 < 358) {
            i3 += iFld;
            iArr[i6][i6 - 1] = i6;
            int i7 = (i6 % 2) + 108;
            if (i7 == 108) {
                i5 ^= -179712700;
                instanceCount = instanceCount;
            } else if (i7 != 109) {
                i5 += i5;
                i6++;
            }
            i3 = iFld;
            i6++;
        }
        long floatToIntBits = i3 + Float.floatToIntBits(f) + b + i6 + i5 + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth(int i) {
        iMeth(-6, -85.115f);
        vMeth_check_sum += i;
    }

    /* JADX WARN: Removed duplicated region for block: B:45:0x0136 A[LOOP:3: B:32:0x0095->B:45:0x0136, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0131 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void mainTest(java.lang.String[] r23) {
        /*
            Method dump skipped, instructions count: 666
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.Test.mainTest(java.lang.String[]):void");
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}


import java.io.PrintStream;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_2/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 7;
    public static short sFld = -25338;
    public static long vMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;

    public static void vMeth1() {
        int i;
        int[] iArr = new int[N];
        int[] iArr2 = new int[N];
        FuzzerUtils.init(iArr, 218);
        FuzzerUtils.init(iArr2, 7);
        int i2 = ((int) instanceCount) * 2;
        int i3 = 0;
        int i4 = 15;
        while (i4 < 245) {
            try {
                i2 /= -1495179385;
                iArr[i4 + 1] = 9 / i4;
                i = iArr2[i4] / 53150;
            } catch (ArithmeticException e) {
                i = i2;
            }
            i2 = i * i4;
            i3 = (-475873698) * i4;
            instanceCount = i2;
            iArr[i4 - 1] = 4988;
            i4++;
        }
        int i5 = (i4 >>> 1) % N;
        iArr[i5] = iArr[i5] + 3;
        vMeth1_check_sum += ((1 + (i2 - 4988)) - 61) + i4 + i3 + 4988 + Float.floatToIntBits(0.332f / (i3 | 1)) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(iArr2);
    }

    public static int iMeth(int i, double d, long j) {
        long j2 = i - 1;
        int i2 = (int) (j2 - (((-3) + j) - j2));
        vMeth1();
        float f = 0.184f;
        int i3 = 1;
        while (true) {
            i3++;
            if (i3 >= 266) {
                break;
            }
            f = (f + f) * i2;
        }
        sFld = (short) i3;
        int i4 = (int) j;
        int i5 = i4 + i4;
        int i6 = 6;
        int i7 = 29325;
        int i8 = 16198;
        int i9 = -3;
        while (i6 < 202) {
            i8 = 1;
            while (i8 < 8) {
                i7 >>= i8;
                i9 = 2;
                i8++;
            }
            i6++;
        }
        long doubleToLongBits = i5 + Double.doubleToLongBits(d) + j + i3 + Float.floatToIntBits(f) + i6 + i7 + i8 + 3 + i9;
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static void vMeth() {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 151);
        int i = iArr[41] - 1;
        iArr[41] = i;
        long j = instanceCount - 1;
        instanceCount = j;
        int iMeth = ((-14) - i) + ((int) ((27291 * 35.768f) + ((float) j) + iMeth(r2, 98.84318d, j)));
        int i2 = -1740;
        int i3 = -55568;
        int i4 = -7;
        float f = -8.221f;
        int i5 = 10;
        while (i5 < 212) {
            i2 = (int) instanceCount;
            i3 = i5;
            while (i3 < 8) {
                f = i2;
                i3 += 2;
                i4 = 1;
            }
            iArr[i5] = iArr[i5] - 37367;
            instanceCount += i5;
            i5++;
        }
        iArr[(i2 >>> 1) % N] = i2;
        vMeth_check_sum += ((((((iMeth + 27291) + Double.doubleToLongBits(98.84318d)) + i5) + i2) + i3) - 211) + Float.floatToIntBits(f) + i4 + 0 + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 0);
        vMeth();
        int i = 10;
        int i2 = 2;
        while (i < 175) {
            i2 += i2;
            i++;
        }
        long j = instanceCount - i2;
        instanceCount = j;
        int i3 = (i2 * ((int) j)) >> sFld;
        int i4 = 5;
        int i5 = 167;
        int i6 = -35040;
        int i7 = 6;
        double d = 0.74122d;
        int i8 = 10;
        while (i8 < 244) {
            instanceCount = i3;
            i5 = 107;
            while (i5 > i8) {
                d = -194.0d;
                i4 = 12;
                i5--;
                i6 = 2;
                i7 = 1;
            }
            i8++;
        }
        FuzzerUtils.out.println("i18 i19 b1 = " + i + "," + i3 + ",1");
        FuzzerUtils.out.println("d2 i20 i21 = " + Double.doubleToLongBits(d) + "," + i8 + "," + i4);
        FuzzerUtils.out.println("i22 i23 i24 = " + i5 + ",10," + i6);
        FuzzerUtils.out.println("f3 i25 i26 = " + Float.floatToIntBits(-113.901f) + "," + i7 + ",-71");
        PrintStream printStream = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(iArr);
        StringBuilder sb = new StringBuilder();
        sb.append("iArr3 = ");
        sb.append(checkSum);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount Test.sFld = " + instanceCount + "," + ((int) sFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

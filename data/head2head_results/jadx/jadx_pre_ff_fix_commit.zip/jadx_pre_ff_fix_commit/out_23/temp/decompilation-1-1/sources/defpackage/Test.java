package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_23/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static long bMeth_check_sum;
    public static int[] iArrFld;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public static volatile long instanceCount = 65350;
    public static volatile int iFld1 = 7293;
    public static float fFld = 2.342f;
    public static volatile byte byFld = 27;
    public int iFld = -2;
    public double dFld = 11.47497d;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 63558);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        bMeth_check_sum = 0L;
    }

    /* JADX WARN: Type inference failed for: r4v18, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r4v28 */
    /* JADX WARN: Type inference failed for: r4v30 */
    public boolean bMeth(float f, int i) {
        int[][][] iArr = (int[][][]) Array.newInstance((Class<?>) int.class, N, N, N);
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -8L);
        FuzzerUtils.init((Object[][]) iArr, (Object) 139);
        iFld1 -= (int) instanceCount;
        boolean z = false;
        for (int i2 = 0; i2 < 400; i2++) {
            long j = jArr[i2];
            this.iFld <<= -13;
        }
        int i3 = 7;
        float f2 = f;
        int i4 = i;
        int i5 = -1;
        int i6 = -12;
        int i7 = -8;
        int i8 = 7;
        while (true) {
            int i9 = 1;
            if (i8 < 253) {
                i5 = 1;
                boolean z2 = z;
                while (i5 < i3) {
                    int i10 = 2;
                    int i11 = i4;
                    float f3 = f2;
                    int i12 = i6;
                    int i13 = i11;
                    ?? r4 = z2;
                    while (i10 > i9) {
                        try {
                            i13 = r4 % i13;
                            int i14 = i5 - 1;
                            iArr[i8][i8 - 1][i5 + 1] = (-48358) / iArr[i14][i14][i8];
                        } catch (ArithmeticException e) {
                        }
                        int i15 = this.iFld - ((int) instanceCount);
                        this.iFld = i15;
                        if (i13 == 0) {
                            this.iFld = i15 + (i10 * i10);
                            int i16 = (int) (((long) r4) + (i10 - instanceCount));
                            this.iFld -= (int) (-2.65185d);
                            f3 = (f3 - f3) + (i10 - iFld1);
                            i12 = i16 + i5;
                            i10--;
                            r4 = 0;
                            i9 = 1;
                        } else {
                            if (((int) ((((((((((Float.floatToIntBits(f3) + i13) + i8) + r4) + i5) - 60210) + i10) - 48358) + Double.doubleToLongBits(-2.65185d)) + FuzzerUtils.checkSum(jArr)) + FuzzerUtils.checkSum((Object[][]) iArr))) % 2 > 0) {
                                return true;
                            }
                            return r4;
                        }
                    }
                    i5++;
                    i7 = i10;
                    z2 = false;
                    i3 = 7;
                    i9 = 1;
                    int i17 = i13;
                    i6 = i12;
                    f2 = f3;
                    i4 = i17;
                }
                i8++;
                z = false;
                i3 = 7;
            } else {
                long floatToIntBits = (((((((Float.floatToIntBits(f2) + i4) + i8) + i6) + i5) - 60210) + i7) - 48358) + Double.doubleToLongBits(-2.65185d) + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum((Object[][]) iArr);
                bMeth_check_sum += floatToIntBits;
                return floatToIntBits % 2 > 0;
            }
        }
    }

    public void vMeth1() {
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        FuzzerUtils.init(iArr, -72);
        int i = -56587;
        int i2 = 15;
        int i3 = 1;
        while (i2 < 375) {
            instanceCount = 73.444f;
            this.iFld += ((iFld1 * i2) + iFld1) - this.iFld;
            i3 = (i3 == 0 || !bMeth(-73.444f, -168)) ? 0 : 1;
            fFld -= -73.444f;
            int i4 = this.iFld;
            iArr[i2][i2 - 1] = i4;
            iFld1 = (int) (iFld1 + (((i2 * (-73.444f)) + iFld1) - (-73.444f)));
            i2++;
            i = i4;
        }
        int i5 = 142;
        int i6 = -181;
        while (i5 > 7) {
            i6 = 12;
            while (i6 > i5) {
                long j = -14;
                instanceCount += j;
                if (i3 != 0) {
                    break;
                }
                i = (int) (i + (((i6 * (-18049)) + instanceCount) - j));
                fFld *= -10.0f;
                iFld1 *= this.iFld;
                i6--;
            }
            i5--;
        }
        vMeth1_check_sum += (((((((i2 + i) + i3) + i5) - 14) + i6) - 14) - 18049) + FuzzerUtils.checkSum(iArr);
    }

    public void vMeth() {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -4);
        vMeth1();
        int i = 69;
        int i2 = 7;
        while (i2 < 260) {
            i = 1;
            while (i < 6) {
                iFld1 %= (int) (fFld | 1);
                i++;
            }
            i2++;
        }
        vMeth_check_sum += ((((((i2 - 14) + i) - 27203) + 0) + 8) - 220) + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        long[] jArr = new long[N];
        double[] dArr = new double[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(jArr, -1890164814L);
        FuzzerUtils.init(dArr, 2.44146d);
        FuzzerUtils.init(fArr, -2.686f);
        int i = this.iFld;
        int i2 = i - 1;
        this.iFld = i2;
        this.iFld = i * (i2 + 48 + (i2 * iFld1));
        int i3 = 43256;
        int i4 = -3;
        int i5 = 3609;
        int i6 = 16302;
        long j = -2619759133L;
        int i7 = 14;
        while (i7 < 338) {
            int i8 = i7 + 1;
            long j2 = jArr[i8] + 1;
            jArr[i8] = j2;
            double d = j2;
            double d2 = dArr[i7] - 1.0d;
            dArr[i7] = d2;
            double d3 = i7 - iFld1;
            Double.isNaN(d3);
            Double.isNaN(d);
            int i9 = i3 - ((int) (d - (d2 - d3)));
            long j3 = j;
            int i10 = i5;
            int i11 = 2;
            while (78 > i11) {
                j3 = 1;
                while (j3 < 2) {
                    vMeth();
                    i9 += (int) j3;
                    fFld -= (float) j3;
                    j3++;
                }
                i10 -= (int) instanceCount;
                i11++;
            }
            iArrFld[i7] = this.iFld;
            fArr[i8] = (float) this.dFld;
            int i12 = i9;
            instanceCount += i10;
            iFld1 *= iFld1;
            int[] iArr = iArrFld;
            int i13 = i7 - 1;
            iArr[i13] = iArr[i13] + i6;
            i6 = iFld1;
            i3 = i12;
            i4 = i11;
            i5 = i10;
            j = j3;
            i7 = i8;
        }
        instanceCount = j;
        int i14 = 11;
        int i15 = 189;
        int i16 = -178;
        int i17 = 203;
        while (i14 < 322) {
            i16 = 81;
            while (i16 > i14) {
                int[] iArr2 = iArrFld;
                double[] dArr2 = dArr;
                iArr2[i16] = iArr2[i16] + ((int) fFld);
                this.iFld = i15;
                instanceCount -= 25;
                i5 += this.iFld;
                byFld = (byte) (byFld - ((byte) i7));
                float f = fFld + ((float) (1 + instanceCount));
                fFld = f;
                i15 >>>= 2;
                fFld = f + (i16 * i16);
                int i18 = i14 + 1;
                fArr[i18] = fArr[i18] + iFld1;
                iArrFld = iArrFld;
                fFld += i16;
                i16--;
                dArr = dArr2;
                i17 = 2;
            }
            i14++;
        }
        double[] dArr3 = dArr;
        FuzzerUtils.out.println("i i1 i2 = " + i7 + "," + i3 + "," + i4);
        FuzzerUtils.out.println("i3 l i4 = " + i5 + "," + j + "," + i6);
        FuzzerUtils.out.println("i24 i25 i26 = " + i14 + "," + i15 + "," + i16);
        FuzzerUtils.out.println("i27 i28 lArr = 28224," + i17 + "," + FuzzerUtils.checkSum(jArr));
        FuzzerUtils.out.println("dArr fArr = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr3)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.iFld1 = " + instanceCount + "," + this.iFld + "," + iFld1);
        FuzzerUtils.out.println("Test.fFld dFld Test.byFld = " + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(this.dFld) + "," + ((int) byFld));
        PrintStream printStream = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(iArrFld);
        StringBuilder sb = new StringBuilder();
        sb.append("Test.iArrFld = ");
        sb.append(checkSum);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

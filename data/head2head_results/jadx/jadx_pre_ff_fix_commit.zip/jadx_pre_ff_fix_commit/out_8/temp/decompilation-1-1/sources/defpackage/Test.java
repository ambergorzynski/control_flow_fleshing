package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_8/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static double[] dArrFld;
    public static float[] fArrFld;
    public static int[] iArrFld;
    public static long iMeth1_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = -3639986684759510532L;
    public static boolean bFld = false;
    public static volatile double dFld = -2.4342d;
    public static volatile byte byFld = -62;
    public static short sFld = 9354;

    static {
        float[] fArr = new float[N];
        fArrFld = fArr;
        dArrFld = new double[N];
        iArrFld = new int[N];
        FuzzerUtils.init(fArr, -2.872f);
        FuzzerUtils.init(dArrFld, 0.79412d);
        FuzzerUtils.init(iArrFld, 49699);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth1_check_sum = 0L;
    }

    public void vMeth(int i, short s) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 9860);
        vMeth_check_sum += (Integer.reverseBytes(i) * iArr[(i >>> 1) % N]) + s + FuzzerUtils.checkSum(iArr);
    }

    public static int iMeth1(int i, double d, short s) {
        int[] iArr = new int[N];
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, -23.30395d);
        FuzzerUtils.init(iArr, 3);
        int i2 = 32513;
        int i3 = -6;
        int i4 = -1;
        int i5 = i;
        long j = -12;
        int i6 = 17;
        int i7 = -168;
        while (i6 < 390) {
            i3 = 1;
            while (i3 < 5) {
                i4 %= i4 | 1;
                j = 2;
                while (j > 1) {
                    dArr[i6] = i6;
                    j--;
                }
                if (((i3 % 1) * 5) + 101 == 105) {
                    boolean z = bFld;
                    i2 = -13;
                    i4 = 14469;
                } else {
                    int i8 = i3 - 1;
                    iArr[i8] = iArr[i8] | i3;
                    i5 += i4;
                }
                byFld = (byte) j;
                i7 = 2;
                instanceCount += 4;
                i3++;
            }
            i6++;
        }
        long doubleToLongBits = ((((((((i5 + Double.doubleToLongBits(d)) + s) + i6) + i2) + i3) + i4) + j) - 13) + i7 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + FuzzerUtils.checkSum(iArr);
        iMeth1_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static void vMeth1(float f) {
        int i;
        int[] iArr = new int[N];
        long[][][] jArr = (long[][][]) Array.newInstance((Class<?>) long.class, N, N, N);
        FuzzerUtils.init((Object[][]) jArr, (Object) 7441971514106604820L);
        FuzzerUtils.init(iArr, 2126);
        int i2 = 1477;
        byte b = -117;
        int i3 = 253;
        while (true) {
            i = 2;
            if (2 >= i3) {
                break;
            }
            double d = dFld;
            dFld = 1.0d + d;
            int i4 = i2 + ((int) d);
            long j = instanceCount - 1;
            instanceCount = j;
            i2 = i4 + ((int) (j * b)) + iMeth1(i3, dFld, (short) -31049);
            i3 -= 3;
            b = (byte) (b - 1);
        }
        int i5 = (i3 >>> 1) % N;
        long[][] jArr2 = jArr[i5];
        int i6 = (i2 >>> 1) % N;
        long[] jArr3 = jArr2[i6];
        jArr3[i5] = jArr3[i5] + i2;
        double[] dArr = dArrFld;
        double d2 = dArr[i6];
        double d3 = i3;
        Double.isNaN(d3);
        dArr[i6] = d2 * d3;
        float f2 = 1.0f;
        int i7 = i2;
        int i8 = -5;
        int i9 = 36;
        int i10 = 206;
        float f3 = 1.0f;
        int i11 = 40;
        float f4 = f;
        while (f3 < 382.0f) {
            if (((int) ((f3 % f2) + 40.0f)) == 40) {
                switch ((int) ((f3 % 9.0f) + 38.0f)) {
                    case 38:
                    case 39:
                        int i12 = 1;
                        while (i12 < 12) {
                            iArr[i12] = 79290671;
                            i7 += ((i12 * i3) + i7) - (-82);
                            int i13 = 1;
                            while (i13 < i && !bFld) {
                                i13++;
                            }
                            double d4 = dFld;
                            double d5 = i7;
                            Double.isNaN(d5);
                            dFld = d4 - d5;
                            i12++;
                            i10 = i13;
                        }
                        i9 = i12;
                        continue;
                    case 40:
                        f4 = -82;
                        continue;
                    case 41:
                        i7 += (int) f3;
                        continue;
                    case 42:
                        if (bFld) {
                            break;
                        }
                        break;
                    case 43:
                        break;
                    case 44:
                        boolean z = bFld;
                        continue;
                    case 45:
                        boolean z2 = bFld;
                        continue;
                    default:
                        i8 = (int) instanceCount;
                        continue;
                }
                i11 = (int) instanceCount;
            } else {
                int i14 = (int) f3;
                iArr[i14] = iArr[i14] * i7;
            }
            f3 += 3.0f;
            f2 = 1.0f;
            i = 2;
        }
        vMeth1_check_sum += ((((((((Float.floatToIntBits(f4) + i3) + i7) + b) - 31049) + Float.floatToIntBits(f3)) + i8) + i9) - 82) + i10 + i11 + FuzzerUtils.checkSum((Object[][]) jArr) + FuzzerUtils.checkSum(iArr);
    }

    public static int iMeth() {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 0L);
        FuzzerUtils.init(iArr, -145);
        int i = -10;
        int i2 = 106;
        int i3 = -11;
        double d = 1.1346d;
        int i4 = 14;
        while (i4 < 272) {
            long j = i;
            long j2 = i4;
            int i5 = ((int) (j + (((instanceCount * j2) + j2) - j))) + i4;
            long j3 = jArr[i4] - 1;
            jArr[i4] = j3;
            i = i5 + (-i5) + (((int) j3) ^ i5);
            if (!bFld) {
                int i6 = i + ((int) fArrFld[(i >>> 1) % N]);
                i2 = 1;
                while (i2 < 12) {
                    double d2 = -23648;
                    Double.isNaN(d2);
                    d += d2;
                    i2++;
                }
                vMeth1(116.715f);
                i3 *= (int) instanceCount;
                i = i6 + i3;
                boolean z = bFld;
                if (!z) {
                    bFld = z;
                }
            }
            i4 += 2;
        }
        long doubleToLongBits = (((i4 + i) + i2) - 23648) + Double.doubleToLongBits(d) + Float.floatToIntBits(116.715f) + 7 + i3 + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        int i;
        float f;
        int i2;
        vMeth(iMeth(), sFld);
        boolean z = bFld;
        bFld = z;
        int i3 = 11;
        int i4 = -45708;
        int i5 = -2815;
        int i6 = -4572;
        long j = 2796139709L;
        float f2 = 2.67f;
        if (z) {
            i = 2;
            float f3 = -11.932f;
            i2 = 0;
            while (i < 180) {
                int i7 = 141;
                while (true) {
                    i7--;
                    if (i7 <= 0) {
                        break;
                    }
                    long j2 = i;
                    instanceCount = j2;
                    i3 = (int) j2;
                    j = (long) dFld;
                    f3 = 0.0f;
                    i2 = 1;
                }
                int i8 = 1;
                while (true) {
                    i8++;
                    if (i8 < 141) {
                        f2 = 1.0f;
                        float[] fArr = fArrFld;
                        fArr[i] = fArr[i] * (-244);
                        fArr[i] = fArr[i] - (-21730.0f);
                        i6 = 1;
                    }
                }
                i++;
                i4 = i7;
                i5 = i8;
            }
            f = f3;
        } else {
            i = -167;
            f = 0.0f;
            i2 = 0;
        }
        FuzzerUtils.out.println("i20 i21 i22 = " + i + "," + i3 + "," + i4);
        FuzzerUtils.out.println("l2 f3 i23 = " + j + "," + Float.floatToIntBits(f) + "," + i2);
        FuzzerUtils.out.println("i24 i25 f4 = 7," + i5 + "," + Float.floatToIntBits(f2));
        FuzzerUtils.out.println("i26 i27 i28 = -244," + i6 + ",3");
        PrintStream printStream = FuzzerUtils.out;
        long j3 = instanceCount;
        int i9 = bFld ? 1 : 0;
        printStream.println("Test.instanceCount Test.bFld Test.dFld = " + j3 + "," + i9 + "," + Double.doubleToLongBits(dFld));
        PrintStream printStream2 = FuzzerUtils.out;
        byte b = byFld;
        short s = sFld;
        printStream2.println("Test.byFld Test.sFld Test.fArrFld = " + ((int) b) + "," + ((int) s) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("Test.dArrFld Test.iArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

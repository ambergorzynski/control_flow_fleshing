package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_73/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 167;
    public static float fFld = 40.638f;
    public static byte byFld = 43;
    public static boolean bFld = false;
    public static long vMeth_check_sum = 0;
    public static long sMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public double dFld = 8.83933d;
    public int iFld = 44292;
    public int iFld1 = 1;
    public double[] dArrFld = new double[N];

    public static void vMeth1(double d) {
        int i;
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -6806402445794829225L);
        FuzzerUtils.init(iArr, -5);
        int i2 = 161;
        int i3 = 9;
        int i4 = -10;
        int i5 = 1;
        do {
            i = 1;
            while (5 > i) {
                jArr[i5] = jArr[i5] - 4889710303079700949L;
                i3 = 2;
                while (i3 > 1) {
                    i4 <<= i4;
                    float f = fFld + (i3 * i3);
                    fFld = f;
                    int i6 = i2 - 52039;
                    long j = instanceCount + i3;
                    instanceCount = j;
                    switch (((i5 >>> 1) % 3) + 110) {
                        case 110:
                            i2 = 12;
                            int i7 = i3 - 1;
                            iArr[i7] = iArr[i7] >> 12;
                            break;
                        case 111:
                            long j2 = j + i6;
                            instanceCount = j2;
                            instanceCount = j2 + (i3 | i);
                            fFld = f + (((i3 * (-2299)) + f) - (-2299));
                        case 112:
                            i2 = i;
                            break;
                        default:
                            i2 = (int) j;
                            break;
                    }
                    i3--;
                }
                i++;
            }
            i5++;
        } while (i5 < 306);
        vMeth1_check_sum += (((((((Double.doubleToLongBits(d) + i5) + i) + i2) + i3) + i4) + 0) - 2299) + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr);
    }

    public static short sMeth() {
        byte[] bArr = new byte[N];
        FuzzerUtils.init(bArr, (byte) 44);
        double d = 59673;
        vMeth1(d);
        bArr[236] = (byte) (bArr[236] >> ((byte) instanceCount));
        int i = 4;
        int i2 = 39;
        int i3 = -236;
        int i4 = 14;
        while (i4 < 238) {
            fFld += (float) d;
            if (bFld) {
                byFld = (byte) (byFld + ((byte) i));
                int i5 = 1;
                while (7 > i5) {
                    byFld = (byte) (byFld + ((byte) i));
                    i -= i;
                    i5++;
                    i3 = 1;
                }
                i2 = i5;
            }
            i4++;
        }
        long doubleToLongBits = Double.doubleToLongBits(d) + 0 + i4 + i + i2 + i3 + FuzzerUtils.checkSum(bArr);
        sMeth_check_sum += doubleToLongBits;
        return (short) doubleToLongBits;
    }

    public void vMeth(int i) {
        int[][][] iArr = (int[][][]) Array.newInstance((Class<?>) int.class, N, N, N);
        FuzzerUtils.init((Object[][]) iArr, (Object) (-146));
        int[][] iArr2 = iArr[33];
        int i2 = (i >>> 1) % N;
        int[] iArr3 = iArr2[i2];
        iArr3[i2] = iArr3[i2] * 1;
        double d = this.dFld;
        int i3 = i + 1;
        double d2 = i3;
        Double.isNaN(d2);
        this.dFld = d - d2;
        long sMeth = instanceCount + sMeth() + 97.845f;
        instanceCount = sMeth;
        int i4 = i3 | ((int) sMeth);
        int i5 = 5;
        int i6 = -13;
        int i7 = -128;
        int i8 = -71;
        int i9 = 42880;
        int i10 = 5;
        while (i10 < 306) {
            i7 = 1;
            while (i7 < i5 && !bFld) {
                i6 += (int) instanceCount;
                fFld += i7 * i7;
                i9 = 1;
                while (2 > i9) {
                    int i11 = this.iFld;
                    this.iFld = i11 + i11;
                    instanceCount = -12L;
                    i8 -= i7;
                    float f = fFld;
                    long j = ((float) (-12)) + (((i9 * i4) + i7) - f);
                    instanceCount = j;
                    i4 = (int) (i4 + i9 + j);
                    fFld = f + 159.0f;
                    i9++;
                    i6 = i6;
                }
                i7++;
                i5 = 5;
            }
            i10++;
            i5 = 5;
        }
        vMeth_check_sum += i4 + i10 + i6 + i7 + i8 + i9 + 42 + FuzzerUtils.checkSum((Object[][]) iArr);
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(jArr, 0L);
        FuzzerUtils.init(fArr, 1.334f);
        FuzzerUtils.init(iArr, -38462);
        vMeth(5);
        int i = -10;
        int i2 = -10;
        int i3 = 36;
        int i4 = -59;
        int i5 = 11;
        while (i5 < 231) {
            this.dArrFld[i5] = this.iFld;
            this.iFld = 2104919056;
            jArr[i5 + 1] = 2104919056;
            i3 = 2;
            while (i3 < 343) {
                i += i3;
                double d = this.dFld;
                long j = instanceCount;
                double d2 = j;
                Double.isNaN(d2);
                this.dFld = d + d2;
                instanceCount = j << byFld;
                i3++;
            }
            int i6 = i5;
            while (343 > i6) {
                instanceCount = 14;
                i6++;
                i2 = 1;
                i = 206;
            }
            i5 += 3;
            i4 = i6;
        }
        FuzzerUtils.out.println("i17 i18 i19 = " + i5 + "," + i + "," + i3);
        FuzzerUtils.out.println("i20 i21 i22 = 14," + i4 + ",206");
        FuzzerUtils.out.println("i23 i24 d2 = " + i2 + ",-54743," + Double.doubleToLongBits(-1.4597d));
        FuzzerUtils.out.println("s1 lArr1 fArr = 28474," + FuzzerUtils.checkSum(jArr) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)));
        PrintStream printStream = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(iArr);
        StringBuilder sb = new StringBuilder();
        sb.append("iArr2 = ");
        sb.append(checkSum);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount dFld Test.fFld = " + instanceCount + "," + Double.doubleToLongBits(this.dFld) + "," + Float.floatToIntBits(fFld));
        PrintStream printStream2 = FuzzerUtils.out;
        byte b = byFld;
        boolean z = bFld;
        printStream2.println("Test.byFld Test.bFld iFld = " + ((int) b) + "," + (z ? 1 : 0) + "," + this.iFld);
        FuzzerUtils.out.println("iFld1 dArrFld = " + this.iFld1 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("sMeth_check_sum: " + sMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

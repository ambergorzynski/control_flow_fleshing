
import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_30/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long iMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public int iFld = -6;
    public short sFld = -20811;
    public static volatile long instanceCount = -7945161477086214461L;
    public static double dFld = 1.23809d;
    public static final int N = 400;
    public static volatile double[] dArrFld = new double[N];
    public static long[] lArrFld = new long[N];

    static {
        FuzzerUtils.init(dArrFld, 0.83052d);
        FuzzerUtils.init(lArrFld, 1746855379901599385L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
    }

    /* JADX WARN: Type inference failed for: r4v0 */
    /* JADX WARN: Type inference failed for: r4v14 */
    public static int iMeth(int i, int i2, int i3) {
        int i4;
        int[] iArr = new int[N];
        boolean[] zArr = new boolean[N];
        short[] sArr = new short[N];
        boolean z = 1;
        FuzzerUtils.init(zArr, true);
        FuzzerUtils.init(iArr, 3);
        FuzzerUtils.init(sArr, (short) -5388);
        int i5 = i2;
        int i6 = i3;
        double d = 7.0d;
        int i7 = -236;
        int i8 = -31139;
        float f = -65.226f;
        short s = -9949;
        while (d < 191.0d) {
            double d2 = dFld;
            double d3 = -109;
            Double.isNaN(d3);
            dFld = d2 + d3;
            i7 /= -31529;
            int i9 = i6;
            short s2 = s;
            int i10 = i5;
            float f2 = f + ((float) d);
            int i11 = 9;
            while (i11 > z) {
                zArr[(int) d] = z;
                i9 += (int) f2;
                int i12 = (int) (1.0d + d);
                iArr[i12] = iArr[i12] + 12;
                float f3 = -64;
                i10 += i11 * i;
                s2 = (short) (s2 - ((short) i7));
                sArr[i11 - 1] = (short) (sArr[r0] - 13848);
                f2 = (f2 * f3) + f3;
                i11--;
            }
            int i13 = (int) d;
            try {
                iArr[i13] = (-1176967986) % i9;
                i7 = 9002 % iArr[i13];
                i4 = i10;
                try {
                    i7 = i9 % iArr[(int) (d - 1.0d)];
                } catch (ArithmeticException e) {
                }
            } catch (ArithmeticException e2) {
                i4 = i10;
            }
            d += 1.0d;
            i5 = i4;
            i6 = i9;
            i8 = i11;
            f = f2;
            s = s2;
            z = 1;
        }
        long doubleToLongBits = (((((((((i + i5) + i6) + Double.doubleToLongBits(d)) + i7) - 109) + Float.floatToIntBits(f)) + 1) + i8) - 64) + s + FuzzerUtils.checkSum(zArr) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(sArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static void vMeth1(int i) {
        int[][][] iArr = (int[][][]) Array.newInstance((Class<?>) int.class, N, N, N);
        FuzzerUtils.init((Object[][]) iArr, (Object) (-1977));
        int i2 = 0;
        int i3 = 10;
        int i4 = 57633;
        int i5 = 72;
        float f = 0.46f;
        short s = 16450;
        int i6 = i;
        int i7 = 7;
        while (i7 < 380) {
            instanceCount += ((i7 * i6) + i3) - instanceCount;
            int i8 = 5;
            short s2 = s;
            float iMeth = (iMeth(i6, i6, i6) + i2) - 2.02893005E9f;
            int i9 = i6;
            while (i8 > i7) {
                int i10 = i8 - 1;
                try {
                    int i11 = i7 + 1;
                    iArr[i10][i11][i7] = iArr[i11][i10][i7] / (-2007784377);
                    i9 = i7 / (-61856);
                    i3 = iArr[i10][i8 + 1][i11] % i8;
                } catch (ArithmeticException e) {
                }
                instanceCount -= 9;
                instanceCount += iMeth;
                iMeth = 193;
                i5 = 2;
                s2 = (short) (s2 + ((short) (i8 * i8)));
                i8 -= 2;
            }
            i7++;
            i6 = i9;
            i4 = i8;
            f = iMeth;
            s = s2;
            i2 = -59904;
        }
        vMeth1_check_sum += i6 + i7 + i2 + Float.floatToIntBits(f) + i3 + i4 + 193 + i5 + s + FuzzerUtils.checkSum((Object[][]) iArr);
    }

    public void vMeth(float f, int i, float f2) {
        int[] iArr = new int[N];
        short[] sArr = new short[N];
        int i2 = 6;
        FuzzerUtils.init(iArr, 6);
        FuzzerUtils.init(sArr, (short) -31520);
        vMeth1(i);
        while (i2 < 173) {
            f2 -= 9.0f;
            iArr[i2] = iArr[i2] - ((int) f);
            double[] dArr = dArrFld;
            double d = dArr[i2];
            double d2 = i;
            Double.isNaN(d2);
            dArr[i2] = d * d2;
            i2++;
        }
        int i3 = 7;
        int i4 = 13;
        int i5 = 12444;
        int i6 = 208;
        byte b = 115;
        while (i3 < 215) {
            b = (byte) i3;
            i4 = 14;
            i5 = 1;
            while (i5 < 8) {
                i6 = 4;
                i5++;
            }
            i3++;
        }
        vMeth_check_sum += (((((((((((Float.floatToIntBits(f) + i) + Float.floatToIntBits(f2)) + i2) + i4) + i3) + 52600) + b) + i5) - 4) + i6) - 8653) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(sArr);
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 7);
        instanceCount *= -64559;
        int i = iArr[168] - 1;
        iArr[168] = i;
        int i2 = (i - 64559) & (-64559);
        float f = 127.649f;
        vMeth(127.649f, 28592, 127.649f);
        int i3 = i2 - 1;
        int i4 = 3;
        while (i4 < 300) {
            i3 += i4;
            i4++;
        }
        long[] jArr = lArrFld;
        long j = jArr[38];
        int i5 = this.iFld;
        jArr[38] = j + i5;
        this.iFld = i5 - i5;
        double d = dFld;
        double d2 = i4 | 1;
        Double.isNaN(d2);
        dFld = d / d2;
        iArr[64] = 136;
        int i6 = 12;
        while (i6 < 334) {
            double d3 = dFld;
            f = (float) d3;
            double d4 = 33843;
            Double.isNaN(d4);
            dFld = d3 * d4;
            i6++;
        }
        FuzzerUtils.out.println("i f4 i22 = " + i3 + "," + Float.floatToIntBits(f) + "," + i4);
        FuzzerUtils.out.println("i23 i24 i25 = 5,-3,136");
        FuzzerUtils.out.println("i26 i27 i28 = 33843,-136,128");
        FuzzerUtils.out.println("b2 i29 i30 = 0," + i6 + ",12");
        PrintStream printStream = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(iArr);
        StringBuilder sb = new StringBuilder();
        sb.append("iArr = ");
        sb.append(checkSum);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount Test.dFld iFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + this.iFld);
        PrintStream printStream2 = FuzzerUtils.out;
        short s = this.sFld;
        printStream2.println("sFld Test.dArrFld Test.lArrFld = " + ((int) s) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + FuzzerUtils.checkSum(lArrFld));
        PrintStream printStream3 = FuzzerUtils.out;
        long j2 = iMeth_check_sum;
        StringBuilder sb2 = new StringBuilder();
        sb2.append("iMeth_check_sum: ");
        sb2.append(j2);
        printStream3.println(sb2.toString());
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}


import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_88/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static long bMeth_check_sum;
    public static int[] iArrFld;
    public static long iMeth_check_sum;
    public static long[] lArrFld;
    public static long vMeth_check_sum;
    public static long vSmallMeth_check_sum;
    public byte byFld = -45;
    public double dFld = 0.70946d;
    public static long instanceCount = -177;
    public static int iFld = -63755;
    public static float fFld = -64.261f;
    public static volatile short sFld = -4165;
    public static int iFld1 = 51;
    public static boolean bFld = true;
    public static boolean bFld1 = false;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        lArrFld = new long[N];
        FuzzerUtils.init(iArr, 0);
        FuzzerUtils.init(lArrFld, -9L);
        vSmallMeth_check_sum = 0L;
        bMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }

    public static void vSmallMeth(short s, long j) {
        iFld = iFld + 1;
        vSmallMeth_check_sum += s + j + Float.floatToIntBits(r0);
    }

    public static void vMeth(int i, int i2, int i3) {
        int i4 = 3;
        double[][][] dArr = (double[][][]) Array.newInstance((Class<?>) double.class, N, N, N);
        FuzzerUtils.init((Object[][]) dArr, (Object) Double.valueOf(-1.41995d));
        int i5 = 48964;
        float f = 2.627f;
        try {
            instanceCount = -19639L;
            while (352 > i4) {
                i2 = sFld;
                float f2 = 1.0f;
                while (true) {
                    f2 += 1.0f;
                    if (f2 < 5.0f) {
                        long j = i;
                        instanceCount = j;
                        i3 += (int) 55.28662d;
                        dArr[i4][(int) (f2 - 1.0f)][i4] = j;
                        iFld += i4;
                        i5 = (i5 - i2) + ((int) (i4 * f2));
                    }
                }
                int[] iArr = iArrFld;
                iArr[i4] = iArr[i4] + i2;
                iFld = (int) instanceCount;
                i4++;
                f = f2;
            }
        } catch (UserDefinedExceptionTest e) {
            while (352 > i4) {
                i2 = sFld;
                float f3 = 1.0f;
                while (true) {
                    f3 += 1.0f;
                    if (f3 < 5.0f) {
                        long j2 = i;
                        instanceCount = j2;
                        i3 += (int) 55.28662d;
                        dArr[i4][(int) (f3 - 1.0f)][i4] = j2;
                        iFld += i4;
                        i5 = (i5 - i2) + ((int) (i4 * f3));
                    }
                }
                int[] iArr2 = iArrFld;
                iArr2[i4] = iArr2[i4] + i2;
                iFld = (int) instanceCount;
                i4++;
                f = f3;
            }
        } catch (Throwable th) {
            while (352 > i4) {
                short s = sFld;
                float f4 = 1.0f;
                while (true) {
                    f4 += 1.0f;
                    if (f4 < 5.0f) {
                        long j3 = i;
                        instanceCount = j3;
                        dArr[i4][(int) (f4 - 1.0f)][i4] = j3;
                        iFld += i4;
                    }
                }
                int[] iArr3 = iArrFld;
                iArr3[i4] = iArr3[i4] + s;
                iFld = (int) instanceCount;
                i4++;
            }
            throw th;
        }
        vMeth_check_sum += i + i2 + i3 + i4 + i5 + Float.floatToIntBits(f) + Double.doubleToLongBits(55.28662d) + 0 + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][]) dArr));
    }

    public static int iMeth(int i, int i2, int i3) {
        int i4 = 42;
        double d = 86.15206d;
        int i5 = 11;
        while (i5 < 332) {
            d = i5;
            while (d < 5.0d) {
                long j = (21956 - instanceCount) - (21956 + i3);
                int abs = Math.abs(41393);
                iFld = iFld - 1;
                instanceCount = j * abs * r8;
                d += 1.0d;
            }
            vMeth(21956, 12, iFld1);
            if ((i5 % 1) + 36 == 36) {
                i4 >>= iFld;
                i3 = (int) instanceCount;
            }
            i3 *= 5;
            long j2 = instanceCount;
            int i6 = iFld1;
            long j3 = j2 + i6;
            instanceCount = j3;
            iFld1 = i6 << i2;
            if (!bFld) {
                iArrFld[i5] = (int) j3;
            }
            i5++;
        }
        fFld *= (float) instanceCount;
        long doubleToLongBits = i + i2 + i3 + i5 + 21956 + Double.doubleToLongBits(d) + i4 + 10 + Double.doubleToLongBits(2.31837d - d);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v1 */
    /* JADX WARN: Type inference failed for: r2v2, types: [int] */
    /* JADX WARN: Type inference failed for: r2v28 */
    /* JADX WARN: Type inference failed for: r2v29 */
    /* JADX WARN: Type inference failed for: r2v31 */
    public static boolean bMeth(boolean z, int i, int i2) {
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(zArr, true);
        ?? r2 = z;
        int i3 = i;
        int i4 = i2;
        int i5 = 43;
        int i6 = 1;
        while (true) {
            i6++;
            if (i6 >= 374) {
                break;
            }
            int i7 = iArrFld[i6];
            zArr[i6 - 1] = false;
            i4 += (i6 * i6) - 20063;
            i5 = 1;
            while (i5 < 5) {
                iFld += (i5 * i5) + 0;
                i5++;
            }
            int[] iArr = iArrFld;
            int i8 = iArr[i6];
            float f = fFld;
            fFld = 1.0f + f;
            iArr[i6] = i8 * ((int) f);
            long j = (i4 - i7) * ((-17292) - (instanceCount << 36));
            short s = (short) (sFld + 1);
            sFld = s;
            int i9 = (int) (j + s);
            int i10 = iFld;
            double d = i9;
            Double.isNaN(d);
            i3 = i9 - ((int) ((-1.77023d) - d));
            iFld = i10 * (-i3);
            if (bFld1) {
                double d2 = -71;
                Double.isNaN(d2);
                double d3 = fFld - i5;
                Double.isNaN(d3);
                int i11 = (int) (62.43000030517578d - (((-1.77023d) - d2) + d3));
                iFld = i11;
                int i12 = i11 + ((int) (-1.77023d));
                iFld = i12;
                double d4 = i12;
                double d5 = i4;
                Double.isNaN(d5);
                double d6 = (-1.77023d) - d5;
                double iMeth = iMeth(-13, i12, i6);
                Double.isNaN(iMeth);
                Double.isNaN(d4);
                instanceCount = (long) (d4 * d6 * iMeth);
                i3 += 57696;
                r2 = 1;
            } else {
                fFld = i3;
                r2 = 1;
            }
        }
        long doubleToLongBits = (((((((r2 + i3) + i4) + i6) + i5) + 36) + Double.doubleToLongBits(-1.77023d)) - 71) + FuzzerUtils.checkSum(zArr);
        bMeth_check_sum += doubleToLongBits;
        return doubleToLongBits % 2 > 0;
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        int i3;
        int[] iArr;
        float f;
        double d;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9 = N;
        int[] iArr2 = new int[N];
        double[] dArr = new double[N];
        short[] sArr = new short[N];
        FuzzerUtils.init(sArr, (short) 11445);
        FuzzerUtils.init(iArr2, 7);
        FuzzerUtils.init(dArr, -112.127712d);
        for (int i10 = 0; i10 < 865; i10++) {
            int i11 = iFld;
            short s = sArr[(i11 >>> 1) % N];
            int i12 = (i11 >>> 1) % N;
            iArr2[i12] = iArr2[i12] - 1;
            vSmallMeth(s, (-r8) - (-33661));
        }
        int i13 = -1;
        int i14 = 40700;
        int i15 = 87;
        if (bMeth(true, iFld1, iFld)) {
            f = this.byFld;
            i2 = 182;
            i5 = -53280;
            iArr = iArr2;
            d = -57.44107d;
            i = 0;
            i4 = -13;
            i7 = -6;
            i6 = -9;
        } else {
            instanceCount += iFld;
            double d2 = -57.44107d;
            i = 0;
            i2 = 249;
            while (true) {
                i3 = 5;
                if (5 >= i2) {
                    break;
                }
                i = 3;
                while (i < 103) {
                    d2 = i;
                    while (d2 < 2.0d) {
                        int[] iArr3 = iArrFld;
                        int i16 = (int) (d2 - 1.0d);
                        int i17 = iArr3[i16];
                        long j = instanceCount;
                        iArr3[i16] = i17 - ((int) j);
                        iArr3[i2] = iArr3[i2] + iFld;
                        iFld1 -= (int) j;
                        d2 += 1.0d;
                        i13 = i2;
                        i14 -= 11693;
                        i15 = 723315989;
                    }
                    i++;
                }
                iFld = (int) instanceCount;
                i2--;
            }
            int i18 = 5;
            int i19 = -13;
            int i20 = -9;
            int i21 = -6;
            while (i18 < 188) {
                int i22 = i21;
                i19 = 5;
                while (i19 < 137) {
                    if ((i18 % 1) * 5 != i3) {
                        i8 = i18;
                    } else {
                        i8 = i18;
                        fFld += (float) (((i19 * i19) + sFld) - instanceCount);
                        lArrFld = FuzzerUtils.long1array(i9, 0L);
                    }
                    i22 = 1;
                    while (i22 < 3) {
                        fFld += (float) d2;
                        int i23 = iFld1;
                        i20 += i23;
                        i13 += i22;
                        this.dFld -= d2;
                        i14 -= i23;
                        bFld1 = bFld;
                        i22++;
                        iArr2 = iArr2;
                    }
                    instanceCount = i2;
                    i19 += 2;
                    iArr2 = iArr2;
                    i18 = i8;
                    i9 = N;
                    i3 = 5;
                }
                fFld = i22;
                i21 = i22;
                i3 = 5;
                dArr = FuzzerUtils.double1array(N, 0.127794d);
                i9 = N;
                i18++;
                iArr2 = iArr2;
            }
            int i24 = i18;
            iArr = iArr2;
            f = -80.537f;
            d = d2;
            i4 = i19;
            i5 = i24;
            i6 = i20;
            i7 = i21;
        }
        FuzzerUtils.out.println("f1 i17 i18 = " + Float.floatToIntBits(f) + "," + i2 + "," + i14);
        FuzzerUtils.out.println("i19 i20 d4 = " + i + "," + i15 + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("i21 i22 i23 = " + i13 + "," + i5 + ",3");
        FuzzerUtils.out.println("i24 i25 i26 = " + i4 + ",2," + i7);
        FuzzerUtils.out.println("i27 sArr iArr = " + i6 + "," + FuzzerUtils.checkSum(sArr) + "," + FuzzerUtils.checkSum(iArr));
        PrintStream printStream = FuzzerUtils.out;
        long doubleToLongBits = Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
        StringBuilder sb = new StringBuilder();
        sb.append("dArr1 = ");
        sb.append(doubleToLongBits);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount Test.iFld byFld = " + instanceCount + "," + iFld + "," + ((int) this.byFld));
        PrintStream printStream2 = FuzzerUtils.out;
        int floatToIntBits = Float.floatToIntBits(fFld);
        short s2 = sFld;
        printStream2.println("Test.fFld Test.sFld Test.iFld1 = " + floatToIntBits + "," + ((int) s2) + "," + iFld1);
        PrintStream printStream3 = FuzzerUtils.out;
        boolean z = bFld;
        boolean z2 = bFld1;
        printStream3.println("Test.bFld Test.bFld1 dFld = " + (z ? 1 : 0) + "," + (z2 ? 1 : 0) + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("Test.iArrFld Test.lArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

package defpackage;

/* compiled from: Test.java */
/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_88/eposide-1/1/original-1/Test.dex */
class UserDefinedExceptionTest extends RuntimeException {
    public int field;

    UserDefinedExceptionTest() {
    }
}

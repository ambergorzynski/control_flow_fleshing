package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_55/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long iMeth_check_sum;
    public static long lMeth_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = 3;
    public static volatile float fFld = -1.805f;
    public static short sFld = 22185;
    public static byte byFld = -15;
    public static final int N = 400;
    public static int[][] iArrFld = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
    public static long[][] lArrFld = (long[][]) Array.newInstance((Class<?>) long.class, N, N);

    static {
        FuzzerUtils.init(iArrFld, 63);
        FuzzerUtils.init(lArrFld, -420064933L);
        vMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
    }

    public static int iMeth(int i, boolean z) {
        double[] dArr = new double[N];
        short[] sArr = new short[N];
        FuzzerUtils.init(sArr, (short) -6196);
        FuzzerUtils.init(dArr, 1.35667d);
        int i2 = (int) instanceCount;
        long j = i2;
        instanceCount = j;
        int i3 = (i2 >>> 1) % N;
        sArr[i3] = (short) 53.7468d;
        sArr[i3] = (short) (sArr[i3] >> ((short) j));
        int i4 = 10;
        int i5 = 0;
        int i6 = 8;
        int i7 = -60;
        long j2 = 5;
        while (261 > j2) {
            int i8 = 1;
            int i9 = 1;
            while (6 > i9) {
                fFld *= i9;
                i9++;
            }
            do {
                lArrFld[i8][(int) j2] = instanceCount;
                fFld += (float) (i8 ^ i9);
                i8 += 2;
            } while (i8 < 6);
            sFld = (short) 8533;
            j2++;
            i7 = 2;
            i6 = i8;
            i5 = i9;
            i4 = 8533;
            i2 = -62;
        }
        long doubleToLongBits = (((((((((i2 + (z ? 1 : 0)) + Double.doubleToLongBits(53.7468d)) + j2) + i4) + i5) - 11) + i6) + i7) - 62) + FuzzerUtils.checkSum(sArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public long lMeth(byte b, long j, int i) {
        boolean[] zArr = new boolean[N];
        double[][][] dArr = (double[][][]) Array.newInstance((Class<?>) double.class, N, N, N);
        FuzzerUtils.init(zArr, true);
        FuzzerUtils.init((Object[][]) dArr, (Object) Double.valueOf(-2.17656d));
        long j2 = j;
        int i2 = i >>> 60763;
        double d = -101.125158d;
        int i3 = -42164;
        int i4 = -6;
        int i5 = -9845;
        int i6 = -22;
        int i7 = 2;
        while (i7 < 378) {
            if (!zArr[i7 - 1]) {
                i4 = 1;
                while (true) {
                    i4++;
                    if (i4 >= 4) {
                        break;
                    }
                    dArr[i7 + 1][i4 + 1][i4] = i3;
                    i3 = (i3 + 1) - ((int) fFld);
                    j2 = (iMeth(i3, true) + i2) * i2;
                    i5 = i4;
                    while (i5 < 1) {
                        fFld += i2;
                        i5++;
                    }
                    i6 += i4 * i5;
                }
                try {
                    i2 = i4 / (-50838);
                    int i8 = i3 % 49;
                    int i9 = (-36572) % i7;
                } catch (ArithmeticException e) {
                }
                d += 83.0d;
                sFld = (short) (sFld / ((short) (instanceCount | 1)));
                i3 = i2;
                i2 = i6;
            }
            i7++;
        }
        long doubleToLongBits = b + j2 + i2 + i7 + i3 + i4 + 1 + i5 + i6 + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(zArr) + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][]) dArr));
        lMeth_check_sum += doubleToLongBits;
        return doubleToLongBits;
    }

    public void vMeth(long j, long j2, long j3) {
        double[][] dArr;
        long j4;
        long j5;
        int i;
        long j6 = j;
        double[][] dArr2 = (double[][]) Array.newInstance((Class<?>) double.class, N, N);
        FuzzerUtils.init(dArr2, 0.121567d);
        double[] dArr3 = dArr2[205];
        double d = dArr3[205];
        int[] iArr = iArrFld[205];
        int i2 = iArr[205];
        iArr[205] = i2 + 1;
        double d2 = i2;
        Double.isNaN(d2);
        dArr3[205] = d * d2;
        long j7 = j3;
        long j8 = 10;
        int i3 = 22010;
        int i4 = -55;
        int i5 = -157;
        int i6 = 19025;
        int i7 = 14482;
        int i8 = -21584;
        while (true) {
            if (j8 < 209) {
                int i9 = i8;
                int i10 = i7;
                int i11 = i6;
                int i12 = 8;
                for (int i13 = 1; i13 < i12; i13 = 1) {
                    long j9 = j7;
                    int i14 = i11 << ((int) (i12 * j6));
                    i3 = (int) (j2 - i14);
                    i11 = i14;
                    i10 = 1;
                    long j10 = j9;
                    while (i10 < 3) {
                        switch ((i12 % 8) + 101) {
                            case 101:
                                dArr = dArr2;
                                j4 = j6;
                                int i15 = i3;
                                int i16 = (int) (i4 + i10 + j4);
                                int[] iArr2 = iArrFld[i12 + 1];
                                int i17 = i10 - 1;
                                iArr2[i17] = iArr2[i17] >> (-i9);
                                fFld = fFld + 1.0f;
                                j5 = j10;
                                lArrFld[i12][i12 - 1] = i9 - r15;
                                i3 = i15;
                                i4 = i16;
                                i9++;
                                break;
                            case 102:
                                j10 *= i10 >> ((int) ((i10 + j6) - iArrFld[i12 - 1][(int) j8]));
                                instanceCount *= -220;
                            case 103:
                                double d3 = iArrFld[(int) j8][(int) (j8 - 1)];
                                Double.isNaN(d3);
                                i4 -= i12;
                                dArr = dArr2;
                                j4 = j;
                                i3 = Math.min((int) (0.99168d + d3), (int) (i4 * lMeth(byFld, j4, 8)));
                                byFld = (byte) (byFld >> ((byte) j4));
                                j5 = j10;
                                break;
                            case 104:
                            case 105:
                                sFld = (short) (sFld * ((short) i9));
                                i11 += i11;
                                dArr = dArr2;
                                j5 = j10;
                                j4 = j6;
                                break;
                            case 106:
                            case 107:
                                dArr = dArr2;
                                j5 = j10;
                                i = i3;
                                j4 = j6;
                                i3 = i;
                                break;
                            case 108:
                                int[] iArr3 = iArrFld[i12 + 1];
                                iArr3[i12] = iArr3[i12] * i12;
                                dArr = dArr2;
                                j5 = j10;
                                i = i3;
                                j4 = j6;
                                fFld += i10;
                                i3 = i;
                                break;
                            default:
                                dArr = dArr2;
                                j5 = j10;
                                i = i3;
                                j4 = j6;
                                fFld += i10;
                                i3 = i;
                                break;
                        }
                        i10++;
                        j6 = j4;
                        dArr2 = dArr;
                        j10 = j5;
                    }
                    i12 -= 2;
                    dArr2 = dArr2;
                    j7 = j10;
                }
                j8++;
                i5 = i12;
                i6 = i11;
                i7 = i10;
                i8 = i9;
                dArr2 = dArr2;
                j7 = j7;
            } else {
                vMeth_check_sum += j6 + j2 + j7 + i3 + j8 + i4 + i5 + i6 + i7 + i8 + Double.doubleToLongBits(0.99168d) + 1 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr2));
                return;
            }
        }
    }

    public void mainTest(String[] strArr) {
        int i;
        long j;
        int i2;
        int i3;
        byte[] bArr = new byte[N];
        FuzzerUtils.init(bArr, (byte) -58);
        long j2 = instanceCount;
        vMeth(j2, j2, j2);
        bArr[34] = (byte) (bArr[34] + ((byte) 68));
        int i4 = 44246 + ((int) (-1452115045211642065L));
        double d = i4;
        int i5 = 2;
        int i6 = 50979;
        int i7 = -74;
        int i8 = 232;
        try {
            int i9 = i4 >>> 1;
            iArrFld[i9 % N] = iArrFld[i9 % N];
            i6 = 1;
            while (i6 < 337) {
                int[] iArr = iArrFld[i6];
                int i10 = i6 - 1;
                iArr[i10] = iArr[i10] - i4;
                fFld += ((i6 * i6) + i4) - i7;
                fFld = i6;
                int i11 = (((i6 >>> 1) % i5) * 5) + 14;
                if (i11 != 16) {
                    if (i11 == 24) {
                        bArr[i6] = (byte) i6;
                    } else {
                        i4 += byFld;
                        i7 = ((int) (i7 + (((i6 * i7) + instanceCount) - i4))) + i4;
                    }
                }
                instanceCount -= i6;
                i6++;
                i5 = 2;
            }
            fFld += (float) instanceCount;
            i = 7764;
            j = -1452115045211642065L;
            i2 = 8285;
            i3 = 11;
        } catch (NullPointerException e) {
            i = 7;
            j = -1452115045211642065L;
            i2 = 8285;
            i3 = 11;
            while (i < 378) {
                i2 = 3;
                while (i2 < 68) {
                    fFld = i4;
                    long[] jArr = lArrFld[i + 1];
                    int i12 = i2 + 1;
                    jArr[i12] = jArr[i12] >> (-10);
                    fFld = i7;
                    i3 -= 53595;
                    i7 += 1 + i7;
                    j++;
                    iArrFld[i2][i - 1] = r4[r5] - 252;
                    i2 = i12;
                    i8 = 2;
                }
                i++;
            }
        }
        FuzzerUtils.out.println("i18 d3 l6 = " + i4 + "," + Double.doubleToLongBits(d) + "," + j);
        FuzzerUtils.out.println("i19 i20 i21 = " + i6 + "," + i7 + "," + i);
        FuzzerUtils.out.println("i22 i23 i24 = -10," + i2 + "," + i3);
        FuzzerUtils.out.println("i25 byArr = " + i8 + "," + FuzzerUtils.checkSum(bArr));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.sFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + ((int) sFld));
        PrintStream printStream = FuzzerUtils.out;
        byte b = byFld;
        printStream.println("Test.byFld Test.iArrFld Test.lArrFld = " + ((int) b) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        PrintStream printStream2 = FuzzerUtils.out;
        long j3 = iMeth_check_sum;
        StringBuilder sb = new StringBuilder();
        sb.append("iMeth_check_sum: ");
        sb.append(j3);
        printStream2.println(sb.toString());
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

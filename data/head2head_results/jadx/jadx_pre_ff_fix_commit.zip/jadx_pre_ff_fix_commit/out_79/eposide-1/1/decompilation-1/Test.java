
import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_79/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static float[] fArrFld;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vSmallMeth_check_sum;
    public static long instanceCount = -6;
    public static double dFld = -1.130926d;
    public static volatile byte byFld = 34;

    static {
        float[] fArr = new float[N];
        fArrFld = fArr;
        FuzzerUtils.init(fArr, -51.967f);
        vSmallMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
    }

    public static int iMeth(int i, int i2) {
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        byte[] bArr = new byte[N];
        long[] jArr = new long[N];
        double[] dArr = new double[N];
        FuzzerUtils.init(bArr, (byte) -90);
        FuzzerUtils.init(jArr, 58027L);
        FuzzerUtils.init(iArr, 23057);
        FuzzerUtils.init(fArr, -125.416f);
        FuzzerUtils.init(dArr, 106.41434d);
        int i3 = i;
        int i4 = i2;
        int i5 = -6816;
        int i6 = 243;
        int i7 = 322;
        while (true) {
            int i8 = 1;
            float f = -2.91f;
            if (i7 > 3) {
                long j = instanceCount;
                instanceCount = j + j;
                int i9 = i7 - 1;
                bArr[i9] = (byte) (bArr[i9] - ((byte) i4));
                int i10 = i4;
                int i11 = 1;
                int i12 = i3;
                while (true) {
                    jArr[i9] = f;
                    try {
                        i12 = i7 % 35025;
                        i10 = 48;
                        i12 = iArr[i7 + 1] / (-60);
                    } catch (ArithmeticException e) {
                    }
                    instanceCount += i8 ^ i7;
                    i11++;
                    if (i11 >= 15) {
                        break;
                    }
                    i8 = 1;
                    f = -2.91f;
                }
                i7 -= 3;
                i3 = i12;
                i4 = i10;
                i5 = i11;
                i6 = -1;
            } else {
                long floatToIntBits = ((((((((i3 + i4) + i7) + 37195) + i5) + Float.floatToIntBits(-2.91f)) + i6) + 1) - 7) + FuzzerUtils.checkSum(bArr) + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
                iMeth_check_sum += floatToIntBits;
                return (int) floatToIntBits;
            }
        }
    }

    public static void vMeth(int i, int i2) {
        float[] fArr = new float[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -44467L);
        FuzzerUtils.init(fArr, -8.247f);
        float iMeth = iMeth(i, i) + i2;
        int i3 = -2;
        for (int i4 = 0; i4 < 400; i4++) {
            long j = jArr[i4];
            i -= i2;
            i3 = 4;
        }
        vMeth_check_sum += (((((((i + i2) + Float.floatToIntBits(iMeth)) + i3) - 59496) + 1) - 39046) - 29864) + FuzzerUtils.checkSum(jArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public static void vSmallMeth(int i) {
        int[][][] iArr = (int[][][]) Array.newInstance((Class<?>) int.class, N, N, N);
        FuzzerUtils.init((Object[][]) iArr, (Object) 34872);
        int i2 = (i >>> 1) % N;
        int[] iArr2 = iArr[i2][i2];
        iArr2[i2] = iArr2[i2] + 1;
        dFld = (r3 + Math.min(i, i)) * (-15635);
        vMeth(i, -14);
        vSmallMeth_check_sum += (i - 15635) + FuzzerUtils.checkSum((Object[][]) iArr);
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -2309178621L);
        FuzzerUtils.init(iArr, -2);
        for (int i = 0; i < 361; i++) {
            vSmallMeth(-106);
        }
        int i2 = 366;
        int i3 = -189;
        int i4 = -83;
        int i5 = -26657;
        int i6 = 9;
        int i7 = 0;
        while (i2 > 5) {
            i7 = 10;
            while (209 > i7) {
                fArrFld[i7 - 1] = i4;
                i5 = 1;
                while (3 > i5) {
                    dFld -= 28111.0d;
                    i4 |= i5;
                    i6 = (int) 1.49f;
                    i3 = i5 + 14;
                    i5 += 2;
                }
                i7 += 2;
            }
            i2 -= 3;
        }
        FuzzerUtils.out.println("i13 i14 i15 = 0," + i2 + "," + i3);
        FuzzerUtils.out.println("i16 i17 i18 = " + i7 + "," + i4 + "," + i5);
        FuzzerUtils.out.println("i19 i20 f2 = " + i6 + ",-3," + Float.floatToIntBits(1.49f));
        FuzzerUtils.out.println("b2 lArr2 iArr2 = 1," + FuzzerUtils.checkSum(jArr) + "," + FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.byFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + ((int) byFld));
        PrintStream printStream = FuzzerUtils.out;
        long doubleToLongBits = Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld));
        StringBuilder sb = new StringBuilder();
        sb.append("Test.fArrFld = ");
        sb.append(doubleToLongBits);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}


import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_46/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long iMeth1_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public boolean bFld = true;
    public double[] dArrFld = new double[N];
    public static long instanceCount = -5282731952868115069L;
    public static float fFld = -35.322f;
    public static long lFld = 1339813621;
    public static short sFld = 10181;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static volatile short[] sArrFld = new short[N];
    public static volatile byte[] byArrFld = new byte[N];

    static {
        FuzzerUtils.init(iArrFld, 55128);
        FuzzerUtils.init(sArrFld, (short) 29345);
        FuzzerUtils.init(byArrFld, (byte) -10);
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
        vMeth_check_sum = 0L;
    }

    public static void vMeth(long j, long j2, double d) {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        float[][] fArr = (float[][]) Array.newInstance((Class<?>) float.class, N, N);
        FuzzerUtils.init(jArr, -5938807188903259100L);
        FuzzerUtils.init(fArr, 0.604f);
        FuzzerUtils.init(iArr, -124);
        instanceCount += fFld;
        long j3 = j;
        double d2 = d;
        int i = 1;
        int i2 = 6;
        while (i < 387) {
            long j4 = i;
            int i3 = i + 1;
            jArr[i3] = 127;
            fArr[i3][i] = (float) j2;
            int i4 = i * i;
            d2 += 34554.0d;
            j3 = j3 + j4 + i4 + j4;
            i2 = (i2 - 152) + i + i4;
            jArr = jArr;
            i = i3;
            iArr = iArr;
        }
        long[] jArr2 = jArr;
        float[] fArr2 = fArr[(i2 >>> 1) % N];
        int i5 = (i >>> 1) % N;
        fArr2[i5] = fArr2[i5] * i2;
        vMeth_check_sum += j3 + j2 + Double.doubleToLongBits(d2) + i + (i2 >> i2) + FuzzerUtils.checkSum(jArr2) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(iArr);
    }

    public static int iMeth1() {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -2L);
        long j = instanceCount;
        vMeth(j, j, -127.85523d);
        iArrFld = iArrFld;
        int i = 35;
        int i2 = -4;
        int i3 = -59085;
        int i4 = 132;
        int i5 = -60836;
        int i6 = 6;
        while (i6 < 224) {
            int i7 = i5;
            int i8 = i4;
            int i9 = i3;
            int i10 = 1;
            while (7 > i10) {
                i9 = (int) instanceCount;
                i8 = 1;
                while (i8 < 2) {
                    float f = fFld;
                    float f2 = 9;
                    i7 = (int) (i7 + (((i8 * f) + f2) - f2));
                    i9 = ((int) f) + i10;
                    i8++;
                }
                long j2 = lFld << (-2);
                lFld = j2;
                jArr[i6] = jArr[i6] - j2;
                i7 += i10 * i10;
                i10++;
            }
            int i11 = i9 * (-2);
            i += i6 * i6;
            i6++;
            i4 = i8;
            i5 = i7;
            int i12 = i10;
            i3 = i11;
            i2 = i12;
        }
        long doubleToLongBits = Double.doubleToLongBits(-127.85523d) + i6 + i + i2 + i3 + i4 + i5 + 9 + FuzzerUtils.checkSum(jArr);
        iMeth1_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public int iMeth(int i, long j, double d) {
        short[] sArr;
        int i2;
        instanceCount <<= iMeth1();
        int i3 = i;
        long j2 = j;
        int i4 = 176;
        int i5 = -146;
        int i6 = -173;
        int i7 = 64611;
        byte b = 92;
        int i8 = 174;
        while (true) {
            int i9 = 1;
            if (i8 <= 1) {
                break;
            }
            int i10 = 1;
            while (true) {
                float f = fFld;
                fFld = f - f;
                i2 = i10 + 1;
                if (i2 >= 9) {
                    break;
                }
                i10 = i2;
            }
            lFld *= -1;
            int i11 = i8 + 1;
            this.dArrFld[i11] = i5;
            try {
                i3 /= iArrFld[i8 - 1];
                iArrFld[i8] = (-56) / i8;
                i5 = (-916338267) % iArrFld[i11];
            } catch (ArithmeticException e) {
            }
            while (i9 < 9) {
                j2 -= (long) d;
                i7 -= i5;
                i9++;
            }
            b = (byte) (b - ((byte) i3));
            i8--;
            i4 = i2;
            i6 = i9;
        }
        short[] sArr2 = sArrFld;
        int length = sArr2.length;
        int i12 = 0;
        int i13 = -67;
        while (i12 < length) {
            short s = sArr2[i12];
            i13 = 1;
            while (true) {
                sArr = sArr2;
                if (i13 < 4) {
                    fFld -= i7;
                    instanceCount = i8;
                    i13++;
                    sArr2 = sArr;
                }
            }
            i12++;
            sArr2 = sArr;
        }
        long doubleToLongBits = i3 + j2 + Double.doubleToLongBits(d) + i8 + i5 + i4 + i6 + i7 + b + i13 + 198;
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        long[] jArr = new long[N];
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(jArr, 4682269006106612412L);
        FuzzerUtils.init(zArr, false);
        jArr[199] = iMeth(-38097, instanceCount, -2.93149d);
        int i3 = -38097;
        int i4 = 25773;
        int i5 = -145;
        int i6 = -50966;
        int i7 = -49034;
        int i8 = 49193;
        int i9 = 46206;
        int i10 = -64721;
        int i11 = 14;
        int i12 = 0;
        while (i11 < 229) {
            i4++;
            i5 = 7;
            while (true) {
                i = 117;
                if (i5 >= 117) {
                    break;
                }
                i6 = i3 << i11;
                i7 = 2;
                for (int i13 = 1; i7 > i13; i13 = 1) {
                    boolean z = this.bFld;
                    this.bFld = z;
                    fFld -= i4;
                    lFld -= 32;
                    zArr[i5 - 1] = z;
                    sFld = (short) (sFld << 43);
                    i7--;
                    i10 = i10;
                }
                fFld += (float) instanceCount;
                byArrFld = byArrFld;
                instanceCount -= sFld;
                i5++;
                i3 = i6;
                i10 = i10;
            }
            int i14 = 3;
            int i15 = i6 >> i5;
            int i16 = i3;
            while (true) {
                i2 = i15;
                if (i14 < i) {
                    lFld |= 28080;
                    i9 <<= (int) instanceCount;
                    int i17 = i2 - i2;
                    try {
                        i16 = ((-49864) % i17) % (-32168);
                        i8 = i14 / i7;
                    } catch (ArithmeticException e) {
                    }
                    sFld = (short) i11;
                    int[] iArr = iArrFld;
                    int i18 = i11 + 1;
                    iArr[i18] = iArr[i18] + ((int) fFld);
                    int i19 = 1;
                    while (2 > i19) {
                        short[] sArr = sArrFld;
                        int i20 = i11 - 1;
                        sArr[i20] = (short) (sArr[i20] * ((short) lFld));
                        i19++;
                        i8 = -9;
                        i9 = 0;
                    }
                    i14++;
                    i = 117;
                    i15 = i17;
                    i10 = i19;
                }
            }
            i11++;
            i12 = i14;
            int i21 = i16;
            i6 = i2;
            i3 = i21;
        }
        FuzzerUtils.out.println("i d3 i18 = " + i3 + "," + Double.doubleToLongBits(-2.93149d) + "," + i11);
        FuzzerUtils.out.println("i19 i20 i21 = " + i4 + "," + i5 + "," + i6);
        FuzzerUtils.out.println("i22 i23 by3 = " + i7 + "," + i8 + ",32");
        FuzzerUtils.out.println("i24 i25 i26 = " + i12 + "," + i9 + "," + i10);
        FuzzerUtils.out.println("i27 lArr bArr = 9," + FuzzerUtils.checkSum(jArr) + "," + FuzzerUtils.checkSum(zArr));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.lFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + lFld);
        PrintStream printStream = FuzzerUtils.out;
        boolean z2 = this.bFld;
        short s = sFld;
        printStream.println("bFld Test.sFld Test.iArrFld = " + (z2 ? 1 : 0) + "," + ((int) s) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("dArrFld Test.sArrFld Test.byArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld)) + "," + FuzzerUtils.checkSum(sArrFld) + "," + FuzzerUtils.checkSum(byArrFld));
        PrintStream printStream2 = FuzzerUtils.out;
        long j = vMeth_check_sum;
        StringBuilder sb = new StringBuilder();
        sb.append("vMeth_check_sum: ");
        sb.append(j);
        printStream2.println(sb.toString());
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

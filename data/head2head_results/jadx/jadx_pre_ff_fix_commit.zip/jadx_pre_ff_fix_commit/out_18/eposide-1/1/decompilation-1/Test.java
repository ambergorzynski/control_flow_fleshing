
import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_18/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static float[] fArrFld;
    public static long iMeth1_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static volatile long instanceCount = 160;
    public static int iFld = 198;

    static {
        float[] fArr = new float[N];
        fArrFld = fArr;
        FuzzerUtils.init(fArr, -1.185f);
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
        vMeth_check_sum = 0L;
    }

    public static void vMeth() {
        int[] iArr = new int[N];
        byte[] bArr = new byte[N];
        long[][][] jArr = (long[][][]) Array.newInstance((Class<?>) long.class, N, N, N);
        FuzzerUtils.init(iArr, 159);
        FuzzerUtils.init(bArr, (byte) 53);
        FuzzerUtils.init((Object[][]) jArr, (Object) (-8019742773354537068L));
        iArr[121] = 57043;
        bArr[168] = (byte) (bArr[168] >> ((byte) 19466));
        int i = 4;
        float f = -2.351f;
        int i2 = 6;
        while (i2 < 244) {
            float f2 = 1.0f;
            do {
                f2 += 1.0f;
            } while (f2 < 7.0f);
            i2++;
            f = f2;
            i = 1;
        }
        vMeth_check_sum += (((-1756929) + i2) - 11746) + Float.floatToIntBits(f) + i + 5 + 0 + Double.doubleToLongBits(32.58854d) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(bArr) + FuzzerUtils.checkSum((Object[][]) jArr);
    }

    public static int iMeth1(int i) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 94);
        vMeth();
        int i2 = -20;
        int i3 = -22;
        long j = 5;
        float f = -13.0f;
        int i4 = 6;
        while (i4 < 179) {
            long j2 = 1;
            while (j2 < 18) {
                f = i4 - 5.75163f;
                instanceCount -= j2;
                iArr[i4] = i;
                int i5 = i4 + 1;
                iArr[i5] = iArr[i5] + 0;
                i3 += (int) (i * j2);
                iArr[(int) j2] = -25995;
                j2++;
                i2 = i3;
            }
            i3 <<= i4;
            i4 += 2;
            j = j2;
        }
        long floatToIntBits = i + Float.floatToIntBits(f) + i4 + i2 + j + i3 + FuzzerUtils.checkSum(iArr);
        iMeth1_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static int iMeth(int i) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -1);
        float f = iArr[(i >>> 1) % N];
        long j = instanceCount - 1;
        instanceCount = j;
        int i2 = i * ((int) (f + (-86.234f) + ((float) j)));
        int i3 = 4;
        while (i3 < 308) {
            i2 >>= iArr[i3];
            i3++;
        }
        iArr[327] = iArr[327] + ((int) (-87.234f));
        Math.abs(iArr[(i2 >>> 1) % N]);
        int i4 = 9;
        int i5 = 14;
        while (i4 < 155) {
            i5 >>= (iMeth1(60558) - i3) * i2;
            i4++;
        }
        long floatToIntBits = i2 + Float.floatToIntBits(-87.234f) + i3 + 60558 + i4 + 60558 + i5 + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        int[][] iArr2 = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        double[] dArr = new double[N];
        FuzzerUtils.init(iArr, 8);
        int i = 5;
        FuzzerUtils.init(iArr2, 5);
        FuzzerUtils.init(dArr, -2.62166d);
        int i2 = 1;
        float f = 0.244f;
        int i3 = (int) 0.244f;
        iArr[1] = iArr[1] + i3;
        int i4 = 0;
        for (int i5 = N; i4 < i5; i5 = N) {
            int i6 = iArr[i4];
            instanceCount >>= Math.min(53195, -14);
            iArr[2] = iArr[2] + ((int) instanceCount);
            iMeth(i6);
            i4++;
        }
        short s = 23895;
        while (140 > i) {
            s = (short) (s + ((short) i3));
            i++;
        }
        int i7 = 11;
        int i8 = 59670;
        int i9 = -62487;
        int i10 = 1;
        int i11 = 0;
        while (true) {
            i10 += i2;
            if (i10 >= 348) {
                break;
            }
            int i12 = i11 - 4;
            i9 = i10;
            while (72 > i9) {
                float[] fArr = fArrFld;
                fArr[i9] = fArr[i9] - ((float) instanceCount);
                i7 -= i12;
                i8 *= (int) instanceCount;
                i9++;
            }
            i11 = i12 + (i10 * i10) + 9;
            f = i7;
            i2 = 1;
        }
        int i13 = 7194;
        instanceCount <<= 7194;
        int i14 = 1;
        while (i14 < 295) {
            int i15 = iFld - s;
            iFld = i15;
            i13 -= i15;
            iArr[i14] = iArr[i14] >>> i11;
            instanceCount += i14;
            i14++;
            double d = dArr[i14];
            int i16 = i9;
            double d2 = i13;
            Double.isNaN(d2);
            dArr[i14] = d + d2;
            i = i;
            i10 = i10;
            i9 = i16;
        }
        int i17 = i;
        FuzzerUtils.out.println("f i1 s = " + Float.floatToIntBits(f) + "," + i11 + "," + ((int) s));
        FuzzerUtils.out.println("i18 i19 i20 = " + i7 + "," + i17 + "," + i8);
        FuzzerUtils.out.println("b1 i21 i22 = 0," + i10 + "," + i9);
        FuzzerUtils.out.println("i23 i24 i25 = " + i13 + "," + i14 + ",8");
        FuzzerUtils.out.println("iArr iArr4 dArr = " + FuzzerUtils.checkSum(iArr) + "," + FuzzerUtils.checkSum(iArr2) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.fArrFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        PrintStream printStream = FuzzerUtils.out;
        long j = vMeth_check_sum;
        StringBuilder sb = new StringBuilder();
        sb.append("vMeth_check_sum: ");
        sb.append(j);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

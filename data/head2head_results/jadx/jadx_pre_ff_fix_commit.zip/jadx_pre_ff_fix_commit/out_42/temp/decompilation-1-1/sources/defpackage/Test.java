package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_42/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;
    public static long vMeth_check_sum;
    public volatile long[][] lArrFld = (long[][]) Array.newInstance((Class<?>) long.class, N, N);
    public static long instanceCount = 9;
    public static volatile byte byFld = -94;
    public static float fFld = -109.974f;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static short[][] sArrFld = (short[][]) Array.newInstance((Class<?>) short.class, N, N);

    static {
        FuzzerUtils.init(iArrFld, 226);
        FuzzerUtils.init(sArrFld, (short) -10630);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }

    public static void vMeth2(long j) {
        int i = 14;
        int i2 = 14;
        int i3 = 8;
        int i4 = 44304;
        short s = -3397;
        while (287 > i) {
            i2 = 1;
            do {
                s = (short) (s - 10);
                byFld = (byte) (byFld + ((byte) i));
                i3 = (int) 0.101776d;
                i4 = 2;
                i2++;
            } while (i2 < 6);
            i++;
        }
        vMeth2_check_sum += j + i + i3 + i2 + s + i4 + Double.doubleToLongBits(0.101776d);
    }

    public static void vMeth1() {
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        float[] fArr = new float[N];
        FuzzerUtils.init(iArr, -13);
        FuzzerUtils.init(fArr, 75.508f);
        long j = instanceCount;
        int[] iArr2 = iArr[45];
        iArr2[45] = iArr2[45] + 1;
        long j2 = j % (r6 | 1);
        instanceCount = j2;
        vMeth2(j2);
        double d = -5;
        Double.isNaN(d);
        double d2 = 0.941d - d;
        int i = 228;
        while (i > 7) {
            i--;
        }
        vMeth1_check_sum += ((((((-5) + Double.doubleToLongBits(d2)) + i) - 9) + 5) - 106) + 1 + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public void vMeth(int i, float f) {
        int[] iArr = new int[N];
        long[][][] jArr = (long[][][]) Array.newInstance((Class<?>) long.class, N, N, N);
        FuzzerUtils.init((Object[][]) jArr, (Object) 3L);
        FuzzerUtils.init(iArr, 13);
        int i2 = i;
        float f2 = f;
        double d = 27.54717d;
        int i3 = 24;
        int i4 = -151;
        int i5 = 18551;
        int i6 = -31176;
        int i7 = 200;
        int i8 = 16;
        while (i8 < 297) {
            float reverseBytes = f2 - ((float) Long.reverseBytes(jArr[i8][i8][i8]));
            vMeth1();
            switch ((i8 % 5) + 97) {
                case 97:
                case 98:
                    i4 = 1;
                    while (true) {
                        i6 = 6;
                        if (i4 >= 6) {
                            while (i6 > 1) {
                                instanceCount = i3;
                                i5 = (i5 + i6) - ((int) reverseBytes);
                                int i9 = i6 - 1;
                                long[] jArr2 = jArr[i9][i9];
                                jArr2[i6] = jArr2[i6] >> i5;
                                i6--;
                            }
                            break;
                        } else {
                            i4++;
                            iArr[i4] = iArr[i4] - i3;
                            i2 *= (int) fFld;
                            reverseBytes = (float) d;
                            i3 = i8;
                            i5 = i3;
                        }
                    }
                case 99:
                    try {
                        i5 = iArr[i8 - 1] / i2;
                        i2 = 251 % i5;
                        iArr[i8 + 1] = i3 / (-42);
                    } catch (ArithmeticException e) {
                    }
                case 100:
                    i7 <<= i7;
                case 101:
                    d = i8;
                    break;
            }
            f2 = reverseBytes;
            i8++;
        }
        vMeth_check_sum += i2 + Float.floatToIntBits(f2) + i8 + i3 + i4 + i5 + Double.doubleToLongBits(d) + i6 + i7 + 0 + FuzzerUtils.checkSum((Object[][]) jArr) + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int i = 243;
        int i2 = -169;
        int i3 = -34047;
        int i4 = -144;
        float f = 1.656f;
        long j = -250;
        int i5 = 8;
        while (324 > i5) {
            float f2 = i;
            long j2 = i5;
            long j3 = instanceCount;
            int i6 = (int) (((int) (f2 + (((i5 * f) + f2) - f2))) + (((j2 * j3) + j3) - 26526));
            byFld = (byte) (byFld + ((byte) i5));
            int i7 = i6 + (((i5 * i5) + i6) - i6);
            float f3 = f;
            int i8 = 2;
            while (i8 < 80) {
                long j4 = instanceCount;
                f3 += (float) ((-j4) + Long.reverseBytes(j4) + 31);
                long j5 = instanceCount;
                i7 += (int) ((j2 + j5) * ((j5 + j2) - i8));
                i8++;
            }
            int i9 = i7;
            vMeth(i5, fFld);
            fFld -= i8;
            j = 4;
            while (j < 80) {
                i3 = 1;
                while (2 > i3) {
                    i4 -= (int) (-46.76134d);
                    i3++;
                }
                j++;
            }
            i5++;
            i2 = i8;
            f = f3;
            i = i9;
        }
        FuzzerUtils.out.println("i i1 f = " + i5 + "," + i + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("s i2 i3 = 26526," + i2 + ",-1");
        FuzzerUtils.out.println("l1 i20 i21 = " + j + ",14," + i3);
        FuzzerUtils.out.println("i22 i23 d3 = -20998," + i4 + "," + Double.doubleToLongBits(-46.76134d));
        PrintStream printStream = FuzzerUtils.out;
        StringBuilder sb = new StringBuilder();
        sb.append("i24 = ");
        sb.append(7);
        printStream.println(sb.toString());
        PrintStream printStream2 = FuzzerUtils.out;
        long j6 = instanceCount;
        byte b = byFld;
        printStream2.println("Test.instanceCount Test.byFld Test.fFld = " + j6 + "," + ((int) b) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.iArrFld Test.sArrFld lArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(sArrFld) + "," + FuzzerUtils.checkSum(this.lArrFld));
        PrintStream printStream3 = FuzzerUtils.out;
        long j7 = vMeth2_check_sum;
        StringBuilder sb2 = new StringBuilder();
        sb2.append("vMeth2_check_sum: ");
        sb2.append(j7);
        printStream3.println(sb2.toString());
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

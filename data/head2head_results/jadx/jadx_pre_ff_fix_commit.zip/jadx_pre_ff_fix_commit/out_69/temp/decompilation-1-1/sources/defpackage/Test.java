package defpackage;

import java.io.PrintStream;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_69/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static long[] lArrFld;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = -12;
    public static short sFld = 18099;
    public float fFld = -1.808f;
    public double dFld = 67.8746d;

    static {
        long[] jArr = new long[N];
        lArrFld = jArr;
        FuzzerUtils.init(jArr, 3477296346L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }

    public static void vMeth2() {
        int[] iArr = new int[N];
        double[] dArr = new double[N];
        short[] sArr = new short[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, 0.177f);
        FuzzerUtils.init(sArr, (short) 26452);
        FuzzerUtils.init(dArr, 60.53056d);
        FuzzerUtils.init(iArr, -249);
        int i = 1;
        int i2 = -56323;
        int i3 = 208;
        double d = 18.4885d;
        int i4 = 1;
        while (true) {
            i4 += i;
            if (i4 < 328) {
                int i5 = ((i4 % 7) * 5) + 4;
                if (i5 == 5) {
                    int i6 = i4 + 1;
                    double d2 = dArr[i6];
                    double d3 = i4;
                    Double.isNaN(d3);
                    dArr[i6] = d2 + d3;
                    i2 = i2;
                    int i7 = 1;
                    while (5 > i7) {
                        instanceCount -= -1;
                        i2 = ((int) ((i7 * i7) - 198)) + 16573;
                        iArr[i6] = -2;
                        i7++;
                    }
                    i3 = i7;
                } else if (i5 == 8) {
                    d = i4;
                } else {
                    if (i5 != 20) {
                        if (i5 == 28) {
                            instanceCount = i3;
                        } else if (i5 == 34) {
                            i2 += (int) instanceCount;
                        } else if (i5 == 35) {
                            long j = instanceCount;
                            i2 *= (int) j;
                            fArr[i4 + 1] = i4;
                            instanceCount = j - ((long) d);
                        }
                    }
                    int i8 = i4 + 1;
                    iArr[i8] = iArr[i8] ^ i3;
                }
                i = 1;
            } else {
                vMeth2_check_sum += ((((i4 + i2) + Double.doubleToLongBits(d)) + i3) - 2) + 16573 + 0 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(sArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + FuzzerUtils.checkSum(iArr);
                return;
            }
        }
    }

    public static void vMeth1(short s, int i, float f) {
        short s2;
        int i2;
        int i3;
        long[] jArr = new long[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(jArr, 2063L);
        FuzzerUtils.init(fArr, -29.482f);
        vMeth2();
        int i4 = 4;
        int i5 = -11;
        int i6 = 15620;
        byte b = 71;
        while (i4 < 331) {
            long j = instanceCount;
            byte b2 = (byte) j;
            i *= i;
            switch ((i4 % 4) + 102) {
                case 102:
                case 103:
                    jArr[i4] = i5;
                    continue;
                case 104:
                    jArr[i4] = jArr[i4] - 31595;
                    s2 = (short) j;
                    i2 = i + 1;
                    i3 = -31595;
                    break;
                case 105:
                    s2 = s;
                    i2 = i;
                    i3 = i5;
                    break;
                default:
                    i5 -= s;
                    continue;
            }
            int i7 = 1;
            do {
                int i8 = i7 - 1;
                fArr[i8] = fArr[i8] + 6.0f;
                f -= i4;
                instanceCount += i3;
                i7++;
            } while (i7 < 5);
            i6 = i7;
            s = s2;
            i = i2;
            i5 = i3;
            i4++;
            b = b2;
        }
        vMeth1_check_sum += s + i + Float.floatToIntBits(f) + i4 + i5 + b + i6 + 1 + FuzzerUtils.checkSum(jArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public static void vMeth(int i) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -164);
        int i2 = 10;
        int i3 = 10;
        int i4 = 14;
        int i5 = -25;
        int i6 = -219;
        int i7 = 1;
        while (i7 < 227) {
            vMeth1(sFld, i, 0.717f);
            i4 = 1;
            while (i4 < 7) {
                instanceCount = -117;
                iArr[i4] = iArr[i4] - ((int) 0.717f);
                i4++;
            }
            i *= 25702;
            i2 <<= i4;
            int i8 = i6;
            int i9 = i5;
            int i10 = i7;
            while (i10 < 7) {
                i9 = (int) (i9 + i10 + instanceCount);
                i2 &= -117;
                long[] jArr = lArrFld;
                int i11 = i7 + 1;
                jArr[i11] = jArr[i11] + 90;
                i8 = 0;
                i10++;
            }
            i7++;
            i3 = i10;
            i5 = i9;
            i6 = i8;
        }
        vMeth_check_sum += ((((((((((i + i7) + i2) + Float.floatToIntBits(0.717f)) + i4) - 117) + i3) + 90) + i5) + i6) - 11) + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int[] iArr;
        Test test = this;
        int i = N;
        int[] iArr2 = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -171L);
        FuzzerUtils.init(iArr2, 10);
        for (int i2 = 0; i2 < 400; i2++) {
            long j = jArr[i2];
        }
        int i3 = -59417;
        int i4 = -63;
        int i5 = -9484;
        int i6 = -62;
        double d = -1.5766d;
        byte b = -51;
        int i7 = -110;
        int i8 = 0;
        while (i8 < i) {
            long j2 = jArr[i8];
            vMeth(i7);
            int i9 = i7 * i7;
            sFld = (short) i9;
            d = 3.0d;
            int i10 = i3;
            int i11 = i9;
            int i12 = i4;
            int i13 = i10;
            while (63.0d > d) {
                try {
                    i11 = i13 / i11;
                    i13 = ((-10) / i11) % i11;
                } catch (ArithmeticException e) {
                }
                int i14 = i5;
                int i15 = i13;
                int i16 = i11;
                int i17 = 1;
                while (i17 < 2) {
                    i15++;
                    test.fFld *= i15;
                    i16 += i17;
                    switch ((i17 % 3) + 32) {
                        case 32:
                            iArr = iArr2;
                            i16 -= i15;
                            break;
                        case 33:
                        case 34:
                            double d2 = test.dFld;
                            iArr = iArr2;
                            double d3 = i14;
                            Double.isNaN(d3);
                            test.dFld = d2 - d3;
                            i14 += 14;
                            i15 = i17;
                            break;
                        default:
                            iArr = iArr2;
                            break;
                    }
                    i17++;
                    iArr2 = iArr;
                }
                int[] iArr3 = iArr2;
                instanceCount += (long) d;
                int i18 = 1;
                while (i18 < 2) {
                    float f = this.fFld * ((float) this.dFld);
                    this.fFld = f;
                    iArr3[i18 + 1] = iArr3[r2] - 8;
                    this.fFld = f * i15;
                    this.fFld = -196;
                    b = (byte) (b + ((byte) ((i18 * i18) - 135)));
                    i14 += i18;
                    i18 += 2;
                    i16 = -196;
                }
                test = this;
                d += 1.0d;
                i12 = i17;
                i11 = i16;
                i13 = i15;
                i5 = i14;
                i6 = i18;
                iArr2 = iArr3;
            }
            i8++;
            i = N;
            int i19 = i13;
            i4 = i12;
            i7 = i11;
            i3 = i19;
        }
        int[] iArr4 = iArr2;
        FuzzerUtils.out.println("i d1 i18 = " + i7 + "," + Double.doubleToLongBits(d) + "," + i3);
        FuzzerUtils.out.println("i19 i20 i21 = " + i4 + "," + i5 + "," + i6);
        FuzzerUtils.out.println("i22 i23 by2 = 13922,-196," + ((int) b));
        FuzzerUtils.out.println("lArr iArr2 = " + FuzzerUtils.checkSum(jArr) + "," + FuzzerUtils.checkSum(iArr4));
        PrintStream printStream = FuzzerUtils.out;
        long j3 = instanceCount;
        short s = sFld;
        printStream.println("Test.instanceCount Test.sFld fFld = " + j3 + "," + ((int) s) + "," + Float.floatToIntBits(test.fFld));
        FuzzerUtils.out.println("dFld Test.lArrFld = " + Double.doubleToLongBits(test.dFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}


import java.io.PrintStream;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_17/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static double[] dArrFld;
    public static long iMeth_check_sum;
    public static long[] lArrFld;
    public static long lMeth_check_sum;
    public static long vMeth_check_sum;
    public static volatile long instanceCount = 79;
    public static int iFld = 124;
    public static double dFld = -115.6292d;
    public static short sFld1 = 29388;
    public static boolean bFld = false;
    public static volatile int iFld2 = -145;
    public short sFld = 15369;
    public int iFld1 = 9;
    public double dFld1 = -115.5534d;
    public byte byFld = -124;
    public int[] iArrFld = new int[N];
    public float[] fArrFld = new float[N];

    static {
        long[] jArr = new long[N];
        lArrFld = jArr;
        dArrFld = new double[N];
        FuzzerUtils.init(jArr, -5779320234873997146L);
        FuzzerUtils.init(dArrFld, 58.88823d);
        lMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }

    public void vMeth(int i, long j, int i2) {
        int i3 = -39;
        int i4 = -3;
        int i5 = 10;
        while (i5 < 194) {
            instanceCount = iFld;
            i3 *= i2;
            j += i3;
            instanceCount += i5;
            int i6 = iFld + ((int) instanceCount);
            iFld = i6;
            this.iFld1 <<= i6;
            i4 = 1;
            while (9 > i4) {
                i2 *= 25;
                i4++;
            }
            instanceCount *= -2.528f;
            float[] fArr = this.fArrFld;
            int i7 = i5 + 1;
            fArr[i7] = fArr[i7] - iFld;
            long[] jArr = lArrFld;
            jArr[i5] = jArr[i5] - (-2.528f);
            i5++;
        }
        vMeth_check_sum += i + j + i2 + i5 + i3 + i4 + 0 + Float.floatToIntBits(-2.528f);
    }

    public int iMeth(long j) {
        int i = this.iFld1;
        int i2 = iFld;
        int i3 = i2 + ((int) (i2 - 0.837f));
        iFld = i3;
        long j2 = instanceCount + 1;
        instanceCount = j2;
        this.iFld1 = i >>> ((int) (i3 + j2));
        int i4 = 655;
        int i5 = 164;
        int i6 = -35942;
        double d = 12.58768d;
        int i7 = 378;
        while (i7 > 4) {
            d = 9.0d;
            while (d > 1.0d) {
                int[] iArr = this.iArrFld;
                int i8 = (int) (1.0d + d);
                int i9 = iArr[i8];
                short max = (short) Math.max(iFld, 50);
                this.sFld = max;
                iArr[i8] = i9 - (i4 - max);
                d -= 3.0d;
            }
            i5 = 9;
            while (i5 > 1) {
                instanceCount = this.byFld;
                int i10 = iFld + ((int) 0.837f);
                iFld = i10;
                switch (((((int) (i10 + instanceCount)) >>> 1) % 4) + 40) {
                    case 40:
                        vMeth(i4, -54719L, 198);
                        i4 *= i4;
                        break;
                    case 41:
                    case 42:
                        int i11 = i4 + i5;
                        try {
                            i11 = 50 % this.iArrFld[i7];
                            iFld = -25;
                            iFld = i7 % (-762048616);
                        } catch (ArithmeticException e) {
                        }
                        i4 = i11;
                        i6 = i7;
                        while (i6 < 2) {
                            int[] iArr2 = this.iArrFld;
                            iArr2[i6] = iArr2[i6] >> (-144);
                            sFld1 = (short) (-147);
                            i6++;
                        }
                        break;
                    case 43:
                        this.sFld = (short) (this.sFld + 54);
                        break;
                    default:
                        i4 -= i6;
                        break;
                }
                i5--;
            }
            i7 -= 2;
        }
        long floatToIntBits = (((((((j + Float.floatToIntBits(0.837f)) + i7) + 50) + Double.doubleToLongBits(d)) + i4) + i5) - 147) + i6 + 207;
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public long lMeth(byte b, int i, int i2) {
        int i3;
        int i4;
        int i5 = i2;
        int i6 = i + 1;
        float f = i5 - (this.iArrFld[(i6 >>> 1) % N] * i);
        short s = 1;
        int i7 = -234;
        int i8 = -49083;
        int i9 = 1;
        while (true) {
            long j = i6;
            int i10 = (int) (j * (i5 - (instanceCount + j)));
            iFld = i10;
            int i11 = i10 + i9;
            iFld = i11;
            iFld = i11 * (-i9);
            int[] iArr = this.iArrFld;
            int i12 = i9 + 1;
            iArr[i12] = iArr[i12] * i9;
            int i13 = 1;
            while (i13 < 6) {
                short s2 = (short) (this.sFld - s);
                this.sFld = s2;
                if (s2 >= iMeth(instanceCount)) {
                    i7 = i13;
                    while (i7 < 2) {
                        int[] iArr2 = this.iArrFld;
                        int i14 = iArr2[i9];
                        short s3 = (short) (this.sFld + s);
                        this.sFld = s3;
                        double d = s3 + this.iFld1 + i9;
                        double d2 = i13 - instanceCount;
                        int i15 = i13;
                        int i16 = i12;
                        double d3 = f;
                        Double.isNaN(d3);
                        Double.isNaN(d2);
                        Double.isNaN(d);
                        iArr2[i9] = i14 >> ((int) (d * (d2 - (d3 + 0.52325d))));
                        this.iFld1 += 729;
                        iFld = i8;
                        i5 -= Math.max(Math.min(-3, i5), (int) (instanceCount + b)) * i9;
                        this.iArrFld[i16] = (int) dFld;
                        i7++;
                        i8++;
                        i12 = i16;
                        i13 = i15;
                        s = 1;
                    }
                    i3 = i13;
                    i4 = i12;
                } else {
                    i3 = i13;
                    i4 = i12;
                    boolean z = bFld;
                    if (z) {
                        long j2 = instanceCount;
                        double d4 = this.dFld1;
                        double d5 = this.sFld;
                        Double.isNaN(d5);
                        instanceCount = j2 | ((long) (d4 * d5));
                    } else if (z) {
                        int[] iArr3 = this.iArrFld;
                        this.iArrFld = iArr3;
                        this.iArrFld = iArr3;
                    }
                }
                i13 = i3 + 1;
                i12 = i4;
                s = 1;
            }
            int i17 = i13;
            i9 = i12;
            if (i9 < 260) {
                s = 1;
            } else {
                long floatToIntBits = b + i6 + i5 + Float.floatToIntBits(f) + i9 + i17 + 193 + i7 + i8;
                lMeth_check_sum += floatToIntBits;
                return floatToIntBits;
            }
        }
    }

    public void mainTest(String[] strArr) {
        long[] jArr = lArrFld;
        int i = iFld;
        int i2 = (i >>> 1) % N;
        long j = jArr[i2];
        long lMeth = lMeth((byte) -18, -15656, i);
        int i3 = this.iFld1;
        jArr[i2] = j * ((lMeth - i3) - i3);
        int i4 = 1260029097 | i3;
        this.iFld1 = i4;
        this.iFld1 = i4 | i4;
        instanceCount -= -28519;
        iFld = -2;
        this.dFld1 = 145.0d;
        int i5 = 46854;
        int i6 = 8;
        int i7 = -64309;
        int i8 = 34340;
        int i9 = -37568;
        int i10 = -6844;
        float f = -50.389f;
        int i11 = 248;
        while (i11 > 7) {
            boolean z = bFld;
            if (z) {
                i6 = 3;
                while (104 > i6) {
                    this.iFld1 *= (int) dFld;
                    i7 *= i5;
                    i6++;
                }
                int i12 = i11;
                while (104 > i12) {
                    iFld2 += i12;
                    try {
                        i5 = this.iArrFld[(i12 >>> 1) % N] % (-26660);
                        int i13 = (-1347803591) % this.iArrFld[i12];
                        int i14 = this.iArrFld[i11 - 1] % 43404;
                    } catch (ArithmeticException e) {
                    }
                    instanceCount ^= -10457;
                    byte b = (byte) (this.byFld * ((byte) this.iFld1));
                    this.byFld = b;
                    int i15 = ((i12 % 2) * 5) + 57;
                    if (i15 == 62) {
                        this.byFld = (byte) (b - ((byte) (-2)));
                    } else if (i15 != 67) {
                        f += (((float) (i12 * instanceCount)) + f) - i6;
                    } else {
                        i10 = 1;
                    }
                    i12++;
                    i7 = 2;
                    i9 = 2;
                }
                i8 = i12;
            } else if (z) {
                dArrFld[i11 + 1] = -53033.0d;
            } else if (z) {
            }
            i11--;
        }
        FuzzerUtils.out.println("i20 i21 i22 = " + i11 + "," + i5 + "," + i6);
        FuzzerUtils.out.println("i23 i24 i25 = " + i7 + "," + i8 + ",-9200");
        FuzzerUtils.out.println("i26 f3 i27 = " + i9 + "," + Float.floatToIntBits(f) + "," + i10);
        PrintStream printStream = FuzzerUtils.out;
        StringBuilder sb = new StringBuilder();
        sb.append("i28 = ");
        sb.append(-2);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount Test.iFld sFld = " + instanceCount + "," + iFld + "," + ((int) this.sFld));
        FuzzerUtils.out.println("iFld1 Test.dFld dFld1 = " + this.iFld1 + "," + Double.doubleToLongBits(dFld) + "," + Double.doubleToLongBits(this.dFld1));
        FuzzerUtils.out.println("byFld Test.sFld1 Test.bFld = " + ((int) this.byFld) + "," + ((int) sFld1) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.iFld2 Test.lArrFld iArrFld = " + iFld2 + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("fArrFld Test.dArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_53/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long iMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = 1064;
    public static boolean bFld = true;
    public static final int N = 400;
    public static long[][] lArrFld = (long[][]) Array.newInstance((Class<?>) long.class, N, N);
    public static volatile float[] fArrFld = new float[N];

    static {
        FuzzerUtils.init(lArrFld, -1851775457685635771L);
        FuzzerUtils.init(fArrFld, 0.497f);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
    }

    public static int iMeth(int i, long j, int i2) {
        FuzzerUtils.init(new int[N], -10);
        int[] int1array = FuzzerUtils.int1array(N, 49);
        int1array[379] = int1array[379] * ((int) instanceCount);
        int i3 = -141;
        int i4 = 26741;
        float f = 0.84f;
        int i5 = 279;
        while (i5 > 17) {
            i3 = i5;
            while (6 > i3) {
                i4 = 1;
                f = 1.0f;
                i3 += 2;
            }
            i5--;
            i2 = i;
        }
        long floatToIntBits = ((((((((i + j) + i2) + i5) + 13) + i3) + 249) + i4) - 65089) + Float.floatToIntBits(f) + 4 + FuzzerUtils.checkSum(int1array);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth1(int i, int i2, int i3) {
        int i4;
        int i5;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 235);
        iMeth(i3, instanceCount, i);
        iArr[(i2 >>> 1) % N] = (int) instanceCount;
        int i6 = i - i2;
        int i7 = -6;
        float f = -75.714f;
        int i8 = 352;
        int i9 = 1;
        while (true) {
            i8--;
            if (i8 > 0) {
                int i10 = 5;
                do {
                    i4 = (int) f;
                    iArr[i10 - 1] = i10;
                    instanceCount >>= i8;
                    i5 = 1;
                    while (true) {
                        i5++;
                        if (i5 >= 3) {
                            break;
                        }
                        int i11 = ((i4 >>> 1) % 2) + 37;
                        if (i11 == 37) {
                            i6 *= (int) instanceCount;
                            f += 1.0f;
                            i2 += i5 * i5;
                        } else if (i11 == 38) {
                            f -= i10;
                            i4 += ((i5 * i8) + i10) - i5;
                        } else {
                            f = -4.0f;
                        }
                    }
                    i10 -= 3;
                } while (i10 > 0);
                i9 = i10;
                i3 = i4;
                i7 = i5;
            } else {
                vMeth1_check_sum += i6 + i2 + i3 + i8 + i9 + Float.floatToIntBits(f) + i7 + FuzzerUtils.checkSum(iArr);
                return;
            }
        }
    }

    public static void vMeth(short s, int i) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -189);
        int i2 = -185;
        int i3 = i ^ (-185);
        int i4 = (int) ((((i3 * (-14723)) - 4) << i3) + 0.41f);
        int i5 = -23;
        byte b = -56;
        double d = 0.71928d;
        float f = -0.59000003f;
        int i6 = 9;
        int i7 = 12;
        while (i6 < 232) {
            int i8 = i6 + 1;
            long j = instanceCount;
            iArr[i8] = (i4 * i2) + i5 + Math.abs((int) (j + j));
            long j2 = instanceCount;
            long[][] jArr = lArrFld;
            int i9 = i6 - 1;
            long[] jArr2 = jArr[i9];
            b = (byte) (b + 1);
            long j3 = b + jArr2[i8];
            jArr2[i8] = j3;
            long[] jArr3 = jArr[i6];
            int i10 = iArr[i6] * ((int) f);
            iArr[i6] = i10;
            long j4 = i10;
            jArr3[i9] = j4;
            instanceCount = j2 + Math.min(j3, j4);
            d = i6;
            i5 = i5;
            while (14.0d > d) {
                f -= i2;
                i2 >>= (int) (((20169 - (instanceCount - i2)) * i5) - i6);
                d += 2.0d;
                i7 = 1;
                i5--;
            }
            i6 += 2;
        }
        vMeth_check_sum += ((((((((((s + i4) + i2) + Float.floatToIntBits(f)) + i6) + i5) + b) + Double.doubleToLongBits(d)) + 12) + i7) - 168) + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 12469);
        long j = instanceCount;
        instanceCount = j + j;
        vMeth((short) -12727, -13);
        instanceCount = -3L;
        int i = 5;
        int i2 = 211;
        float f = 107.422f;
        int i3 = 5;
        int i4 = -1;
        while (i3 < 121) {
            long j2 = i3;
            instanceCount = j2;
            long j3 = j2 + (i4 * i3);
            instanceCount = j3;
            long j4 = j3 + ((long) (-1.70118d));
            instanceCount = j4;
            int i5 = i3 % 1;
            i4 = 1425281854;
            f += ((i3 * i2) + f) - f;
            iArr[i3] = iArr[i3] - ((int) j4);
            i2 = (i2 + ((int) (-1.70118d))) & (-52380);
            i3++;
        }
        double d = -12727;
        Double.isNaN(d);
        double d2 = (-1.70118d) - d;
        int i6 = 11;
        int i7 = -215;
        int i8 = 119;
        int i9 = 6;
        while (i6 < 215) {
            int i10 = i;
            instanceCount += (long) d2;
            iArr[i6] = i2;
            i = i10;
            i7 = 123;
            while (i7 > 2) {
                i8 += i7 * i7;
                i9 = 1;
                while (i9 < 2) {
                    iArr = FuzzerUtils.int1array(N, -109);
                    long j5 = instanceCount << (-100);
                    instanceCount = j5;
                    instanceCount = j5 >> i6;
                    i2 += i9;
                    i = 43722;
                    iArr[i7] = iArr[i7] + 158;
                    i9++;
                    i8 = i3;
                }
                i7--;
            }
            i6++;
            i4 = i10;
        }
        FuzzerUtils.out.println("s1 i22 i23 = -12727," + i4 + "," + i3);
        FuzzerUtils.out.println("i24 d1 f3 = " + i2 + "," + Double.doubleToLongBits(d2) + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i25 i26 i27 = " + i6 + "," + i + "," + i7);
        FuzzerUtils.out.println("i28 i29 i30 = " + i8 + "," + i9 + ",-1");
        FuzzerUtils.out.println("by1 iArr3 = -100," + FuzzerUtils.checkSum(iArr));
        PrintStream printStream = FuzzerUtils.out;
        long j6 = instanceCount;
        int i11 = bFld ? 1 : 0;
        printStream.println("Test.instanceCount Test.bFld Test.lArrFld = " + j6 + "," + i11 + "," + FuzzerUtils.checkSum(lArrFld));
        PrintStream printStream2 = FuzzerUtils.out;
        long doubleToLongBits = Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld));
        StringBuilder sb = new StringBuilder();
        sb.append("Test.fArrFld = ");
        sb.append(doubleToLongBits);
        printStream2.println(sb.toString());
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

package defpackage;

import java.io.PrintStream;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_29/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static long dMeth_check_sum;
    public static int[] iArrFld;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = -86;
    public static volatile double dFld = 2.6143d;
    public static byte byFld = -7;
    public float fFld = -52.179f;
    public boolean[] bArrFld = new boolean[N];

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 50);
        dMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }

    public static void vMeth(int i, int i2) {
        float f;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -57356);
        float f2 = 137.0f;
        while (f2 > 2.0f) {
            f2 -= 1.0f;
        }
        long j = 208;
        int i3 = -37801;
        int i4 = 49755;
        int i5 = 42798;
        do {
            iArr[(int) j] = 22;
            i -= (int) dFld;
            f = 8.0f;
            while (f > 1.0f) {
                int i6 = i4;
                i5 = 1;
                while (i5 < 2) {
                    i = -2;
                    iArr = FuzzerUtils.int1array(N, 8492);
                    i6 = (i6 * ((int) f2)) >> i4;
                    i5++;
                }
                f -= 1.0f;
                int i7 = i4;
                i4 = i6;
                i3 = i7;
            }
            j--;
        } while (j > 0);
        vMeth_check_sum += ((((((((i + 11) + Float.floatToIntBits(f2)) + i3) + j) + Float.floatToIntBits(f)) + i4) + i5) - 20495) + FuzzerUtils.checkSum(iArr);
    }

    public int iMeth(int i, int i2, int i3) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -28);
        vMeth(i3, i3);
        short s = (short) (((short) i3) * 7427);
        int i4 = 0;
        int i5 = -37114;
        int i6 = 1;
        while (i6 < 197) {
            i4 = 1;
            do {
                i >>>= i3;
                dFld = 173.0d;
                instanceCount = 26758L;
                i4++;
            } while (i4 < 8);
            i6++;
            i5 = 1;
        }
        long checkSum = (((((i + i2) + i3) + s) + i6) - 250) + i4 + i5 + 167 + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += checkSum;
        return (int) checkSum;
    }

    public double dMeth(int i, byte b) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 7835966092896054966L);
        int i2 = 14880;
        int i3 = -189;
        int i4 = -39468;
        int i5 = -36928;
        int i6 = 1;
        while (true) {
            i6++;
            if (i6 >= 175) {
                long checkSum = i + b + i6 + i2 + i3 + i4 + i5 + 1 + FuzzerUtils.checkSum(jArr);
                dMeth_check_sum += checkSum;
                return checkSum;
            }
            int iMeth = i >> iMeth(200, i6, i);
            long j = instanceCount;
            instanceCount = j & j;
            i = iMeth >>> iMeth;
            i2 = i6;
            while (i2 < 9) {
                iArrFld[i6 + 1] = -50269;
                i = (i + i6) >>> i2;
                i5 = (int) dFld;
                i2++;
                i3 = i6;
                i4 = 1;
            }
        }
    }

    public void mainTest(String[] strArr) {
        long j;
        float[] fArr;
        int i;
        int i2;
        int[] iArr = new int[N];
        double[] dArr = new double[N];
        float[] fArr2 = new float[N];
        FuzzerUtils.init(iArr, -10);
        FuzzerUtils.init(dArr, -1.9122d);
        FuzzerUtils.init(fArr2, 1.672f);
        int[] int1array = FuzzerUtils.int1array(N, -8);
        int abs = ((-1) - Math.abs(Math.max(-140, 4))) * (-141);
        int i3 = abs + 1;
        double d = abs;
        Double.isNaN(d);
        double d2 = (-16.33351d) - d;
        dMeth(i3, byFld);
        int i4 = i3 + i3;
        dArr[(i4 >>> 1) % N] = 108.83915d;
        int i5 = i4;
        long j2 = 3547325499L;
        int i6 = 30888;
        int i7 = 102;
        int i8 = 11;
        int i9 = -4;
        int i10 = 14;
        int i11 = 17;
        while (true) {
            int i12 = i10;
            boolean z = false;
            if (i11 < 354) {
                try {
                    i6 = int1array[i11 - 1] % (i6 % i11);
                    i5 = iArrFld[i11 + 1] % 117;
                } catch (ArithmeticException e) {
                }
                int[] iArr2 = iArrFld;
                int i13 = iArr2[i11];
                int[] iArr3 = int1array;
                double[] dArr2 = dArr;
                long j3 = instanceCount;
                iArr2[i11] = i13 & ((int) j3);
                i6 *= (int) j3;
                long j4 = 2;
                int i14 = i12;
                while (j4 < 75) {
                    int i15 = i5 - i7;
                    i7 -= 47264;
                    try {
                        i6 = i7 / 2103681232;
                        i15 = i11 / i7;
                        i6 = iArrFld[i11 + 1] % iArrFld[i11];
                    } catch (ArithmeticException e2) {
                    }
                    this.bArrFld[i11] = z;
                    this.fFld = this.fFld;
                    i5 = (int) (i15 + (j4 * j4) + 248);
                    i8 = 1;
                    while (i8 < 2) {
                        i9 += 57;
                        long j5 = j4;
                        switch ((int) ((j4 % 9) + 37)) {
                            case 37:
                                j = j5;
                                fArr = fArr2;
                                long j6 = ((float) instanceCount) + (((i8 * this.fFld) + ((float) j)) - byFld);
                                instanceCount = j6;
                                i = i6;
                                i2 = i7;
                                instanceCount = j6 - ((long) dFld);
                                break;
                            case 38:
                                j = j5;
                                i5 += i6;
                                i9 = (int) this.fFld;
                                fArr = fArr2;
                                i = i6;
                                i2 = i7;
                                break;
                            case 39:
                                j = j5;
                                fArr = fArr2;
                                i = i6;
                                i2 = i7;
                                break;
                            case 40:
                                j = j5;
                                i5 = -14;
                                fArr = fArr2;
                                i = i6;
                                i2 = i7;
                                break;
                            case 41:
                            case 42:
                                j = j5;
                                i5 = (int) j;
                                fArr = fArr2;
                                i = i6;
                                i2 = i7;
                                break;
                            case 43:
                                fArr = fArr2;
                                i = i6;
                                i2 = i7;
                                j = j5;
                                i14 = -249;
                                break;
                            case 44:
                                float f = this.fFld;
                                this.fFld = f * f;
                                fArr = fArr2;
                                i = i6;
                                i2 = i7;
                                j = j5;
                                break;
                            case 45:
                                instanceCount = -2101959090L;
                                fArr = fArr2;
                                i = i6;
                                i2 = i7;
                                j = j5;
                                fArr[i8] = (float) dFld;
                                break;
                            default:
                                fArr = fArr2;
                                i = i6;
                                i2 = i7;
                                j = j5;
                                fArr[i8] = (float) dFld;
                                break;
                        }
                        i8++;
                        i7 = i2;
                        i6 = i;
                        j4 = j;
                        fArr2 = fArr;
                    }
                    j4 = 1 + j4;
                    fArr2 = fArr2;
                    z = false;
                }
                i11++;
                j2 = j4;
                dArr = dArr2;
                fArr2 = fArr2;
                i10 = i14;
                int1array = iArr3;
            } else {
                int[] iArr4 = int1array;
                float[] fArr3 = fArr2;
                FuzzerUtils.out.println("i d i21 = " + i5 + "," + Double.doubleToLongBits(d2) + "," + i11);
                FuzzerUtils.out.println("i22 b1 l1 = " + i6 + ",0," + j2);
                FuzzerUtils.out.println("i23 i24 i25 = " + i7 + "," + i8 + "," + i9);
                FuzzerUtils.out.println("i26 iArr dArr = " + i12 + "," + FuzzerUtils.checkSum(iArr4) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)));
                PrintStream printStream = FuzzerUtils.out;
                long doubleToLongBits = Double.doubleToLongBits(FuzzerUtils.checkSum(fArr3));
                StringBuilder sb = new StringBuilder();
                sb.append("fArr = ");
                sb.append(doubleToLongBits);
                printStream.println(sb.toString());
                FuzzerUtils.out.println("Test.instanceCount Test.dFld fFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(this.fFld));
                PrintStream printStream2 = FuzzerUtils.out;
                byte b = byFld;
                printStream2.println("Test.byFld Test.iArrFld bArrFld = " + ((int) b) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(this.bArrFld));
                PrintStream printStream3 = FuzzerUtils.out;
                long j7 = vMeth_check_sum;
                StringBuilder sb2 = new StringBuilder();
                sb2.append("vMeth_check_sum: ");
                sb2.append(j7);
                printStream3.println(sb2.toString());
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

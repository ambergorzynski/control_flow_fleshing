
import java.io.PrintStream;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_27/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static long fMeth_check_sum;
    public static int[] iArrFld;
    public static long vMeth_check_sum;
    public static long vSmallMeth_check_sum;
    public static long instanceCount = -15253;
    public static float fFld = -119.292f;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, -184);
        vSmallMeth_check_sum = 0L;
        fMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }

    public static void vMeth() {
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, -113.179f);
        int i = -222;
        int i2 = 3973;
        short s = 7729;
        float f = -1.253f;
        int i3 = 3;
        while (214 > i3) {
            long j = instanceCount << 42505;
            instanceCount = j;
            i = i3 + 6;
            int i4 = ((i3 % 9) * 5) + 46;
            if (i4 != 48) {
                if (i4 == 56) {
                    iArrFld[i3] = 60555;
                } else {
                    if (i4 == 67) {
                        i2 += i3 + i2;
                    } else {
                        if (i4 != 69) {
                            if (i4 != 78) {
                                if (i4 != 84) {
                                    if (i4 != 88) {
                                        if (i4 == 53) {
                                            instanceCount = j + i3;
                                        } else if (i4 == 54) {
                                            int i5 = i - ((int) 1.15395d);
                                            vMeth_check_sum += i3 + (i5 / (i5 | 1)) + 1 + Double.doubleToLongBits(1.15395d) + s + i2 + Float.floatToIntBits(f) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
                                            return;
                                        }
                                    }
                                }
                            }
                            i2 = i3;
                        } else {
                            i2 = (int) j;
                        }
                        int[] iArr = iArrFld;
                        int i6 = i3 - 1;
                        iArr[i6] = iArr[i6] >> ((int) instanceCount);
                    }
                    f += (float) (((i3 * instanceCount) + i) - i2);
                }
                i3++;
            }
            s = (short) i3;
            i3++;
        }
        vMeth_check_sum += ((i3 + i) - 3) + Double.doubleToLongBits(1.15395d) + s + i2 + Float.floatToIntBits(f) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public static float fMeth(int i, long j) {
        long j2;
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 4670220663119571140L);
        int i2 = -1;
        int i3 = -8;
        int i4 = -38;
        int i5 = -186;
        int i6 = 9;
        while (338 > i6) {
            vMeth();
            int i7 = 1;
            int i8 = i;
            int i9 = 1;
            do {
                i += i9 + i6;
                i8 += i;
                j2 = i6;
                i9 += 2;
            } while (i9 < 5);
            i >>= (int) instanceCount;
            while (i7 < 5) {
                i5 += i7;
                i7++;
            }
            i5 += i6 * i6;
            i6++;
            i4 = i7;
            i2 = i8;
            i3 = i9;
            j = j2;
        }
        int i10 = 205;
        while (i10 > 11) {
            int i11 = i10 + 1;
            jArr[i11] = jArr[i11] + j;
            i10--;
        }
        long checkSum = i + j + i6 + i2 + i3 + i4 + i5 + i10 + 5413 + FuzzerUtils.checkSum(jArr);
        fMeth_check_sum += checkSum;
        return (float) checkSum;
    }

    public static void vSmallMeth(double d, int i) {
        instanceCount = instanceCount * (fMeth(68, r0) - i);
        vSmallMeth_check_sum += Double.doubleToLongBits(d) + i;
    }

    public void mainTest(String[] strArr) {
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, 1.74877d);
        for (int i = 0; i < 563; i++) {
            vSmallMeth(-2.42223d, -13);
        }
        int i2 = 9;
        int i3 = -11;
        int i4 = -126;
        int i5 = 33135;
        while (i2 < 170) {
            i3 = (int) instanceCount;
            int i6 = 1;
            while (true) {
                i6++;
                if (i6 < 156) {
                    instanceCount >>= 116;
                    fFld = 254;
                    i3 = 254;
                    i5 = 1;
                }
            }
            i2++;
            i4 = i6;
        }
        FuzzerUtils.out.println("d2 i13 i14 = " + Double.doubleToLongBits(-2.42223d) + "," + i2 + "," + i3);
        FuzzerUtils.out.println("i16 i17 i18 = " + i4 + ",-98," + i5);
        FuzzerUtils.out.println("i19 by dArr = -9,-58," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.iArrFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + FuzzerUtils.checkSum(iArrFld));
        PrintStream printStream = FuzzerUtils.out;
        long j = vMeth_check_sum;
        StringBuilder sb = new StringBuilder();
        sb.append("vMeth_check_sum: ");
        sb.append(j);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

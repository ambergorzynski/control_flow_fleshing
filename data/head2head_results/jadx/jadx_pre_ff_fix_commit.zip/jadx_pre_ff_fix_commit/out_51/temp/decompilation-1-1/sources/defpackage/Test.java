package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_51/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static float[] fArrFld;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public static long vSmallMeth_check_sum;
    public static long instanceCount = -699333489;
    public static short sFld = 17154;
    public static long lFld = 9;

    static {
        float[] fArr = new float[N];
        fArrFld = fArr;
        FuzzerUtils.init(fArr, 0.953f);
        vSmallMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x0047, code lost:
    
        r4 = r4 + 1;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static void vMeth1(int r10, int r11, long r12) {
        /*
            float[] r0 = defpackage.Test.fArrFld
            int r1 = r0.length
            r2 = -14643(0xffffffffffffc6cd, float:NaN)
            r3 = 65287(0xff07, float:9.1487E-41)
            r4 = 0
        Lc:
            r5 = 4626219263903401781(0x4033a1e8e6080735, double:19.63246)
            r7 = 1
            if (r4 >= r1) goto L4a
            r10 = r0[r4]
            r8 = -120(0xffffffffffffff88, double:NaN)
            long r12 = r12 - r8
            r10 = r11
            r2 = 1
        L1e:
            int r2 = r2 + r7
            r8 = 4
            if (r2 >= r8) goto L47
            r8 = r2 | r11
            int r10 = r10 + r8
            if (r11 == 0) goto L3b
            long r0 = defpackage.Test.vMeth1_check_sum
            int r10 = r10 + r11
            long r10 = (long) r10
            long r10 = r10 + r12
            long r12 = (long) r7
            long r10 = r10 + r12
            long r12 = (long) r2
            long r10 = r10 + r12
            long r12 = java.lang.Double.doubleToLongBits(r5)
            long r10 = r10 + r12
            long r12 = (long) r3
            long r10 = r10 + r12
            long r0 = r0 + r10
            defpackage.Test.vMeth1_check_sum = r0
            return
        L3b:
            long r8 = defpackage.Test.instanceCount
            int r3 = (int) r8
            long r8 = r8 >> r3
            defpackage.Test.instanceCount = r8
            int r3 = (int) r5
            int r11 = r11 + r3
            r3 = 2
            goto L1e
        L47:
            int r4 = r4 + 1
            goto Lc
        L4a:
            long r0 = defpackage.Test.vMeth1_check_sum
            int r10 = r10 + r11
            long r10 = (long) r10
            long r10 = r10 + r12
            long r12 = (long) r7
            long r10 = r10 + r12
            long r12 = (long) r2
            long r10 = r10 + r12
            long r12 = java.lang.Double.doubleToLongBits(r5)
            long r10 = r10 + r12
            long r12 = (long) r3
            long r10 = r10 + r12
            long r0 = r0 + r10
            defpackage.Test.vMeth1_check_sum = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.Test.vMeth1(int, int, long):void");
    }

    public static void vMeth(double d) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 207208703L);
        int i = 3;
        int i2 = 47757;
        int i3 = 38;
        int i4 = -26223;
        int i5 = -4725;
        int i6 = 6;
        int i7 = 1;
        while (i6 < 332) {
            i7 = 1;
            while (i7 < 5) {
                i += ((i7 * 2) - 6) - i7;
                i7++;
            }
            vMeth1(i7, i7, instanceCount);
            int i8 = i5;
            int i9 = i4;
            int i10 = i3;
            int i11 = 1;
            while (i11 < 5) {
                i = (i >>> 32) % 1;
                i9 = 1;
                while (i9 < 2) {
                    long j = instanceCount + i11;
                    instanceCount = j;
                    long j2 = j + i9;
                    instanceCount = j2;
                    i = (i + ((i9 * i9) - 40201)) ^ ((int) j2);
                    i9++;
                }
                i8 -= i8;
                i11++;
                i10 = 2;
            }
            i6++;
            i2 = i11;
            i3 = i10;
            i4 = i9;
            i5 = i8;
        }
        vMeth_check_sum += (((((((Double.doubleToLongBits(d) + i6) + 2) + i7) + i) - 6) + i2) - 9) + i3 + i4 + i5 + FuzzerUtils.checkSum(jArr);
    }

    public static void vSmallMeth(int i) {
        vMeth(97.77378d);
        vSmallMeth_check_sum += (i - ((int) instanceCount)) + Double.doubleToLongBits(97.77378d);
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        int i3;
        long[] jArr;
        long[] jArr2;
        int[][][] iArr = (int[][][]) Array.newInstance((Class<?>) int.class, N, N, N);
        long[] jArr3 = new long[N];
        long[] jArr4 = new long[N];
        FuzzerUtils.init((Object[][]) iArr, (Object) (-245));
        FuzzerUtils.init(jArr3, -637209366L);
        FuzzerUtils.init(jArr4, -12L);
        int i4 = 0;
        for (int i5 = 0; i5 < 376; i5++) {
            vSmallMeth(182);
        }
        int[] iArr2 = iArr[0][0];
        iArr2[0] = iArr2[0] ^ 0;
        int i6 = 9;
        int i7 = -1;
        int i8 = 6170;
        int i9 = 47629;
        int i10 = -9;
        int i11 = 48817;
        int i12 = 11420;
        int i13 = -151;
        int i14 = -15479;
        float f = 91.427f;
        double d = 32.40625d;
        while (i6 < 194) {
            int i15 = i8;
            i8 = 1;
            while (true) {
                i = i13;
                i2 = i14;
                long j = instanceCount;
                jArr3[i8] = j;
                jArr3[i8] = jArr3[i8] - i15;
                long j2 = i8;
                f = (f + ((float) (((j2 * j) + j2) - i4))) - (-5.6199442E18f);
                int[] iArr3 = iArr[i6 - 1][i6];
                i3 = i8 + 1;
                jArr = jArr4;
                jArr2 = jArr3;
                iArr3[i3] = iArr3[i3] + ((int) lFld);
                i10 -= (int) j;
                if (i3 >= 136) {
                    break;
                }
                i14 = i2;
                jArr4 = jArr;
                jArr3 = jArr2;
                i13 = i;
                i15 = i8;
                i8 = i3;
            }
            i14 = i2;
            jArr3 = jArr2;
            i13 = i;
            i11 = 136;
            while (i11 > 2) {
                double d2 = 1.0d;
                while (d2 < 2.0d) {
                    long j3 = lFld;
                    long j4 = instanceCount;
                    lFld = j3 << ((int) j4);
                    i12 = (int) j4;
                    i13 >>>= i8;
                    int i16 = i8;
                    double d3 = i3;
                    Double.isNaN(d3);
                    double d4 = i10;
                    Double.isNaN(d4);
                    double d5 = (d3 * d2) + d4;
                    double d6 = i13;
                    Double.isNaN(d6);
                    instanceCount = j4 + ((long) (d5 - d6));
                    d2 += 1.0d;
                    jArr3 = jArr;
                    i8 = i16;
                    i3 = i3;
                }
                int i17 = i3;
                int i18 = i8;
                jArr3[i11] = jArr3[i11] / (f | 1);
                if ((i6 % 1) + 38 == 38) {
                    i14 = 1;
                    while (i14 < 2) {
                        i4 = i13 & 11;
                        i12 *= (int) instanceCount;
                        i14++;
                    }
                }
                i4--;
                i11--;
                d = d2;
                i8 = i18;
                i3 = i17;
            }
            i6++;
            jArr4 = jArr;
            i7 = i3;
            i9 = 1;
        }
        long[] jArr5 = jArr4;
        long[] jArr6 = jArr3;
        FuzzerUtils.out.println("i14 i15 i16 = " + i4 + "," + i6 + "," + i8);
        FuzzerUtils.out.println("i17 f1 i18 = " + i7 + "," + Float.floatToIntBits(f) + "," + i9);
        FuzzerUtils.out.println("i19 i20 i21 = " + i10 + "," + i11 + "," + i12);
        FuzzerUtils.out.println("d3 i22 i23 = " + Double.doubleToLongBits(d) + "," + i13 + "," + i14);
        FuzzerUtils.out.println("i24 iArr lArr1 = 8," + FuzzerUtils.checkSum((Object[][]) iArr) + "," + FuzzerUtils.checkSum(jArr6));
        PrintStream printStream = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(jArr5);
        StringBuilder sb = new StringBuilder();
        sb.append("lArr2 = ");
        sb.append(checkSum);
        printStream.println(sb.toString());
        PrintStream printStream2 = FuzzerUtils.out;
        long j5 = instanceCount;
        short s = sFld;
        printStream2.println("Test.instanceCount Test.sFld Test.lFld = " + j5 + "," + ((int) s) + "," + lFld);
        PrintStream printStream3 = FuzzerUtils.out;
        long doubleToLongBits = Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld));
        StringBuilder sb2 = new StringBuilder();
        sb2.append("Test.fArrFld = ");
        sb2.append(doubleToLongBits);
        printStream3.println(sb2.toString());
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_61/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 2807943533L;
    public static float fFld = 2.245f;
    public static double dFld = 57.67855d;
    public static short sFld = 22787;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long vMeth2_check_sum = 0;
    public byte byFld = 83;
    public boolean[][][] bArrFld = (boolean[][][]) Array.newInstance((Class<?>) boolean.class, N, N, N);
    public int[] iArrFld = new int[N];

    public static void vMeth2(int i) {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(jArr, 4088018907L);
        FuzzerUtils.init(fArr, -79.881f);
        FuzzerUtils.init(iArr, -31152);
        int i2 = 1;
        for (int i3 = 0; i3 < 400; i3++) {
            long j = jArr[i3];
            fArr[183] = fArr[183] - (-31937.0f);
            iArr[43] = iArr[43] * (-42930);
            i = -85860;
            iArr[318] = iArr[318] * 29657;
            long j2 = instanceCount;
            instanceCount = j2 ^ j2;
            i2 = 1;
            while (i2 < 4) {
                instanceCount = 194L;
                i2++;
                i = -68;
            }
        }
        vMeth2_check_sum += (((i + 1) + i2) - 68) + FuzzerUtils.checkSum(jArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth1(int i, long j, int i2) {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr, 14260);
        FuzzerUtils.init(jArr, -774510122840822359L);
        vMeth2(-8909);
        int i3 = i * i;
        int i4 = -4;
        int i5 = 56217;
        float f = -2.191f;
        long j2 = -21651;
        int i6 = 6;
        while (i6 < 220) {
            long j3 = instanceCount;
            j += j3;
            instanceCount = j3 << i;
            f = i6;
            while (8.0f > f) {
                j2 = i4;
                i5 *= i4;
                f += 1.0f;
            }
            i4 <<= -55;
            i6++;
        }
        vMeth1_check_sum += (((((i + j) + i3) + i6) + i4) - 29719) + 0 + Float.floatToIntBits(f) + i5 + j2 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr);
    }

    public static void vMeth(int i, float f, byte b) {
        int[][][] iArr = (int[][][]) Array.newInstance((Class<?>) int.class, N, N, N);
        FuzzerUtils.init((Object[][]) iArr, (Object) 32262);
        vMeth1(i, instanceCount, i);
        int i2 = -116;
        int i3 = 179;
        int i4 = -24298;
        int i5 = -13240;
        int i6 = 152;
        int i7 = 5;
        short s = -10665;
        int i8 = 15;
        while (i8 < 358) {
            i2 *= (int) instanceCount;
            short s2 = s;
            int i9 = i7;
            int i10 = i6;
            int i11 = i5;
            int i12 = i4;
            int i13 = 1;
            while (i13 < 14) {
                s2 = (short) (s2 - ((short) i));
                int i14 = 2;
                while (i14 > 1) {
                    i12 *= b;
                    instanceCount -= (long) dFld;
                    i14--;
                }
                double d = dFld;
                double d2 = i13;
                Double.isNaN(d2);
                dFld = d + d2;
                i10 += i14;
                int i15 = i13 + 1;
                iArr[i15][i13][i13 - 1] = b;
                int i16 = i8;
                for (int i17 = 2; i16 < i17; i17 = 2) {
                    instanceCount *= i13;
                    i10 += (int) f;
                    i16++;
                }
                i11 = i14;
                i13 = i15;
                i9 = i16;
            }
            i8 += 3;
            i3 = i13;
            i4 = i12;
            i5 = i11;
            i6 = i10;
            i7 = i9;
            s = s2;
        }
        vMeth_check_sum += i + Float.floatToIntBits(f) + b + i8 + i2 + i3 + i4 + s + i5 + i6 + i7 + 21629 + FuzzerUtils.checkSum((Object[][]) iArr);
    }

    public void mainTest(String[] strArr) {
        vMeth(-9, fFld, this.byFld);
        int i = 32514;
        int i2 = 1;
        while (true) {
            i2++;
            if (i2 < 233) {
                fFld += i2;
                this.bArrFld[i2][i2][i2] = true;
                i = i2;
                while (i < 108) {
                    int[] iArr = this.iArrFld;
                    iArr[5] = iArr[5] - ((int) instanceCount);
                    i++;
                }
            } else {
                int i3 = (int) instanceCount;
                long j = i2 & 176;
                FuzzerUtils.out.println("i18 i19 b2 = " + i3 + "," + i2 + ",1");
                FuzzerUtils.out.println("i20 i21 l3 = " + i + "," + ((int) j) + "," + j);
                FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.dFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(dFld));
                PrintStream printStream = FuzzerUtils.out;
                byte b = this.byFld;
                short s = sFld;
                printStream.println("byFld Test.sFld bArrFld = " + ((int) b) + "," + ((int) s) + "," + FuzzerUtils.checkSum((Object[][]) this.bArrFld));
                PrintStream printStream2 = FuzzerUtils.out;
                long checkSum = FuzzerUtils.checkSum(this.iArrFld);
                StringBuilder sb = new StringBuilder();
                sb.append("iArrFld = ");
                sb.append(checkSum);
                printStream2.println(sb.toString());
                FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

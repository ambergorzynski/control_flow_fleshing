
import java.io.PrintStream;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_59/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -4598101244947970670L;
    public static double dFld = 2.117003d;
    public static int iFld = 4;
    public static long vMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public int iFld1 = -32582;
    public short sFld = 10016;
    public float[] fArrFld = new float[N];

    public static void vMeth1(int i, int i2) {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        double[] dArr = new double[N];
        FuzzerUtils.init(iArr, 114);
        FuzzerUtils.init(jArr, -8668846350062243565L);
        FuzzerUtils.init(dArr, 16.12102d);
        float f = i * 48.104f;
        int i3 = 13;
        while (i3 < 269) {
            iArr[i3] = iArr[i3] * (-130);
            iArr[i3] = 25490;
            dArr[i3 - 1] = -130;
            i3++;
        }
        vMeth1_check_sum += ((((((((i + i2) + Float.floatToIntBits(f)) + i3) - 130) + 6) + 138) + 32034) - 225) + 68 + 11 + 1 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
    }

    public static int iMeth(byte b, double d, double d2) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 118);
        double d3 = d2;
        int i = 26;
        int i2 = -31197;
        int i3 = 7;
        int i4 = 55645;
        float f = 94.1f;
        int i5 = 9;
        while (i5 < 148) {
            i = 1;
            while (true) {
                i3 = 11;
                if (11 <= i) {
                    break;
                }
                d3 = ((i * 11) + ((instanceCount - 25041) * (-45623))) - 1780;
                i++;
            }
            while (i3 > 1) {
                i4 |= i5;
                vMeth1(i4, 31);
                f *= i;
                iArr[i3] = iArr[i3] - ((int) instanceCount);
                int i6 = i3;
                i3--;
                i2 = i6;
            }
            f *= -64.0f;
            i5++;
        }
        long doubleToLongBits = b + Double.doubleToLongBits(d) + Double.doubleToLongBits(d3) + i5 + 25041 + i + i2 + i3 + i4 + Float.floatToIntBits(f) + 1 + 242 + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static void vMeth(long j) {
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, 1.90288d);
        int i = iFld;
        float f = (-20.454f) - i;
        iFld = i + 1;
        byte b = -8;
        instanceCount = i + iMeth((byte) -8, 1.123075d, 1.123075d) + j;
        iFld = -3632;
        dArr[((-3632) >>> 1) % N] = f;
        long j2 = -3632;
        int i2 = 13;
        int i3 = -19776;
        int i4 = 59577;
        short s = -26798;
        int i5 = 11;
        while (i5 < 257) {
            iFld = (int) j2;
            i3 = 1;
            while (true) {
                i3++;
                if (i3 < 7) {
                    i2 = (int) instanceCount;
                    i4 = i3;
                    while (i4 < 1) {
                        long j3 = instanceCount;
                        f -= (float) j3;
                        b = (byte) i3;
                        s = (short) j3;
                        i4 += 3;
                    }
                }
            }
            i5++;
        }
        vMeth_check_sum += ((((((((j2 + Float.floatToIntBits(f)) + b) + Double.doubleToLongBits(1.123075d)) + i5) + i2) + i3) + i4) - 45748) + s + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
    }

    public void mainTest(String[] strArr) {
        int i;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -10);
        int i2 = 12;
        int i3 = -63168;
        int i4 = 62212;
        int i5 = -35442;
        int i6 = -7376;
        byte b = -124;
        float f = -2.63f;
        int i7 = 1;
        while (true) {
            int i8 = i7 + 1;
            iArr[i8] = iArr[i8] - Math.abs(-78);
            int i9 = 6;
            while (i9 < 112) {
                i3 = i7;
                while (true) {
                    if (i3 >= 2) {
                        break;
                    }
                    double d = dFld + 1.0d;
                    dFld = d;
                    double d2 = iArr[i7];
                    Double.isNaN(d2);
                    int i10 = (int) ((-d) * d2);
                    i4 -= i10;
                    iArr[i8] = iArr[i8] + 193;
                    b = (byte) (((byte) (iArr[i3] - ((((float) ((r3 * (-2)) + (-(13 - (-(i7 >> i9)))))) + 99.754f) + b))) | b);
                    vMeth(-12L);
                    int i11 = i9 - 1;
                    iArr[i11] = iArr[i11] + iFld;
                    i3++;
                    i2 = i10;
                }
                int i12 = 1;
                for (i = 2; i12 < i; i = 2) {
                    int i13 = iFld;
                    double d3 = dFld;
                    iFld = i13 - ((int) d3);
                    double d4 = d3 - d3;
                    dFld = d4;
                    int i14 = i2 + i3;
                    instanceCount = i14;
                    iArr[i12] = iArr[i12] + 2354;
                    instanceCount = f;
                    f -= -113;
                    double d5 = -113;
                    Double.isNaN(d5);
                    dFld = d4 - d5;
                    i12++;
                    i2 = i14;
                }
                long j = instanceCount;
                instanceCount = j + ((i9 * i9) - 3);
                f = f * ((float) j) * 18172.0f;
                i6 = i7;
                while (2 > i6) {
                    f += (float) (this.iFld1 ^ i6);
                    iArr[i7] = 158;
                    this.fArrFld = this.fArrFld;
                    this.sFld = (short) (this.sFld * ((short) i4));
                    i6++;
                    i2 = i2;
                }
                i9++;
                i5 = i12;
            }
            if (i8 >= 224) {
                FuzzerUtils.out.println("i i1 i2 = " + i8 + "," + i9 + "," + i2);
                FuzzerUtils.out.println("i3 i4 by = " + i3 + "," + i4 + "," + ((int) b));
                FuzzerUtils.out.println("i28 i29 f4 = " + i5 + ",-113," + Float.floatToIntBits(f));
                FuzzerUtils.out.println("i30 i31 iArr = " + i6 + ",-10," + FuzzerUtils.checkSum(iArr));
                FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.iFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + iFld);
                PrintStream printStream = FuzzerUtils.out;
                int i15 = this.iFld1;
                short s = this.sFld;
                printStream.println("iFld1 sFld fArrFld = " + i15 + "," + ((int) s) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
                PrintStream printStream2 = FuzzerUtils.out;
                long j2 = vMeth1_check_sum;
                StringBuilder sb = new StringBuilder();
                sb.append("vMeth1_check_sum: ");
                sb.append(j2);
                printStream2.println(sb.toString());
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                return;
            }
            i7 = i8;
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

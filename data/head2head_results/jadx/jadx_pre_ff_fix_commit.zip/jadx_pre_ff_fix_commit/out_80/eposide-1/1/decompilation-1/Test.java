
import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_80/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long iMeth_check_sum;
    public static long lMeth_check_sum;
    public static long vMeth_check_sum;
    public float[] fArrFld = new float[N];
    public static long instanceCount = 215246253;
    public static int iFld = -1798;
    public static volatile float fFld = 0.329f;
    public static volatile byte byFld = -16;
    public static final int N = 400;
    public static volatile long[] lArrFld = new long[N];

    static {
        FuzzerUtils.init(lArrFld, 7688652982565888386L);
        iMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }

    public static void vMeth(long j) {
        int i;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 156);
        iFld = 140;
        float f = -1.836f;
        iFld = 140 * ((int) (-1.836f));
        int i2 = -13;
        int i3 = 33266;
        byte b = -86;
        long j2 = j;
        int i4 = 1;
        do {
            i = 1;
            while (7 > i) {
                iFld >>>= 47414;
                i2 = 1;
                while (i2 < 2) {
                    int i5 = i2 * i2;
                    i3 += i5;
                    int i6 = iFld + ((int) (i5 - 19));
                    iFld = i6;
                    b = (byte) instanceCount;
                    j2 += ((i2 * 47414) + i) - i3;
                    iArr[i] = iArr[i] + i2;
                    i2++;
                    iArr[i2] = i6;
                }
                i++;
            }
            i4++;
        } while (i4 < 234);
        int i7 = 8;
        while (i7 < 142) {
            f += (float) 7.2901d;
            i7++;
        }
        vMeth_check_sum += j2 + Float.floatToIntBits(f) + i4 + i + 47414 + i2 + i3 + b + i7 + 70 + Double.doubleToLongBits(7.2901d) + 0 + FuzzerUtils.checkSum(iArr);
    }

    public static long lMeth() {
        int[] iArr = new int[N];
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, 73.48672d);
        FuzzerUtils.init(iArr, 14);
        iFld = 127;
        vMeth(instanceCount);
        int i = 15;
        int i2 = -158;
        int i3 = 3;
        float f = -2.108f;
        float f2 = 49.431f;
        byte b = -62;
        int i4 = 1;
        do {
            switch ((i4 % 10) + 125) {
                case 125:
                    i = 1;
                    while (i < 7) {
                        i++;
                    }
                    int i5 = i4 - 1;
                    double d = dArr[i5];
                    double d2 = iFld;
                    Double.isNaN(d2);
                    dArr[i5] = d * d2;
                case 126:
                    i2 = -11;
                    float f3 = 1.0f;
                    while (f3 < 7.0f) {
                        i2 *= i4;
                        long j = instanceCount + i2;
                        instanceCount = j;
                        instanceCount = j + (f3 * f3);
                        i3 >>= i2;
                        f3 += 1.0f;
                    }
                    f = f3;
                    break;
                case 127:
                    long[] jArr = lArrFld;
                    jArr[i4] = jArr[i4] >> ((int) instanceCount);
                    break;
                case 128:
                    iFld = iFld;
                    break;
                case 129:
                    f2 += i4 * f;
                    break;
                case 130:
                    iArr[i4] = iArr[i4] - 57001;
                    break;
                case 131:
                    i3 <<= i3;
                case 132:
                    long j2 = i4;
                    i3 = (int) (i3 + (((instanceCount * j2) + j2) - j2));
                    break;
                case 133:
                    iArr[i4] = iArr[i4] >> i4;
                    break;
                case 134:
                    b = (byte) (b + ((byte) i4));
                    break;
            }
            i4++;
        } while (i4 < 218);
        long floatToIntBits = i4 + i + i2 + Float.floatToIntBits(f) + i3 + 1 + Float.floatToIntBits(f2) + b + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + FuzzerUtils.checkSum(iArr);
        lMeth_check_sum += floatToIntBits;
        return floatToIntBits;
    }

    public static int iMeth() {
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        FuzzerUtils.init(iArr, 0);
        int i = 61;
        double d = 338.0d;
        while (12.0d < d) {
            i += (int) d;
            d -= 1.0d;
        }
        long doubleToLongBits = (((((Double.doubleToLongBits(d) + i) + Double.doubleToLongBits(75.39982d)) - 3518364542L) + 25274) - 13) + 20 + 0 + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 24502);
        FuzzerUtils.out.println("i i1 d = -21367,213," + Double.doubleToLongBits(20.82036d));
        FuzzerUtils.out.println("i16 i17 i18 = 5,-226,48824");
        FuzzerUtils.out.println("i19 s1 iArr = 1,23154," + FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(fFld));
        PrintStream printStream = FuzzerUtils.out;
        byte b = byFld;
        printStream.println("Test.byFld fArrFld Test.lArrFld = " + ((int) b) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)) + "," + FuzzerUtils.checkSum(lArrFld));
        PrintStream printStream2 = FuzzerUtils.out;
        long j = vMeth_check_sum;
        StringBuilder sb = new StringBuilder();
        sb.append("vMeth_check_sum: ");
        sb.append(j);
        printStream2.println(sb.toString());
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

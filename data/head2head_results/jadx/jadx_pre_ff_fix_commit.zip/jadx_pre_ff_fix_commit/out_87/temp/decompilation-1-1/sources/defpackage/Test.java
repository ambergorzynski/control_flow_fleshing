package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_87/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long fMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vSmallMeth_check_sum;
    public byte byFld = 115;
    public float fFld = 2.987f;
    public static long instanceCount = -15120;
    public static short sFld = -1060;
    public static volatile int iFld = 3;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static long[][] lArrFld = (long[][]) Array.newInstance((Class<?>) long.class, N, N);
    public static short[] sArrFld = new short[N];

    static {
        FuzzerUtils.init(iArrFld, -55);
        FuzzerUtils.init(lArrFld, -2313753511L);
        FuzzerUtils.init(sArrFld, (short) 32292);
        vSmallMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        fMeth_check_sum = 0L;
    }

    public static float fMeth(int i, double d, float f) {
        int i2;
        int i3;
        int i4 = -8;
        double d2 = 1.0d;
        do {
            i2 = 1;
            do {
                i2++;
            } while (i2 < 5);
            i3 = 1;
            while (true) {
                i3++;
                if (i3 >= 5) {
                    break;
                }
                int[] iArr = iArrFld;
                int i5 = i3 - 1;
                iArr[i5] = iArr[i5] - ((int) instanceCount);
                int i6 = (int) d2;
                iArr[i6] = iArr[i6] - 35;
                instanceCount = i4;
                int i7 = (int) (d2 - 1.0d);
                iArr[i7] = iArr[i7] - i6;
                i4 += i3 ^ i;
            }
            d2 += 1.0d;
        } while (d2 < 351.0d);
        long doubleToLongBits = ((((((i + Double.doubleToLongBits(d)) + Float.floatToIntBits(f)) + Double.doubleToLongBits(d2)) + i2) + 1) - 129) + i4 + i3;
        fMeth_check_sum += doubleToLongBits;
        return (float) doubleToLongBits;
    }

    public static void vMeth() {
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, 1.44215d);
        double d = dArr[345];
        int i = 60691;
        double min = Math.min(63108, (int) 206.421f) + 60691;
        Double.isNaN(min);
        dArr[345] = d + min;
        int i2 = 76;
        int i3 = -22;
        int i4 = 10;
        while (i4 < 184) {
            short s = sFld;
            int i5 = i4 + 1;
            long[] jArr = lArrFld[i5];
            int i6 = i4 - 1;
            long j = jArr[i6] - 1;
            jArr[i6] = j;
            sFld = (short) (s - ((short) j));
            instanceCount += i4 * i4;
            i2 = i4;
            while (i2 < 9) {
                int[] iArr = iArrFld;
                int i7 = i2 + 1;
                iArr[i7] = iArr[i7] - ((int) fMeth(58852, -1.121454d, 40.579f));
                i += i2 | 4;
                if (1 > i4) {
                    i = (i - 25) * (-169);
                    instanceCount >>>= sFld;
                }
                i2 = i7;
                i3 = 1;
            }
            i4 = i5;
        }
        vMeth_check_sum += ((((((((i + Float.floatToIntBits(40.579f)) + i4) + 58852) + i2) + 4) + Double.doubleToLongBits(-1.121454d)) + i3) - 25) + 1 + 67 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
    }

    public static void vSmallMeth(short s, int i, int i2) {
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, -1.728f);
        vMeth();
        long j = instanceCount;
        instanceCount = j + j;
        vSmallMeth_check_sum += s + i + i2 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public void mainTest(String[] strArr) {
        int i = 17482;
        int i2 = 7;
        int i3 = 63353;
        int i4 = 4;
        int i5 = -11;
        int i6 = 105;
        int i7 = 182;
        while (i2 < 167) {
            int i8 = ((i2 % 2) * 5) + 117;
            if (i8 == 123) {
                i5 &= 6;
            } else if (i8 == 127) {
                i3 |= i2;
                i += 244;
                i4 = 9;
                while (i4 < 157) {
                    int[] iArr = iArrFld;
                    iArr[i4] = iArr[i4] - i5;
                    this.byFld = (byte) (this.byFld + 3);
                    sArrFld[i4] = 254;
                    instanceCount -= this.fFld;
                    i7 = 1;
                    while (i7 < 2) {
                        long[] jArr = lArrFld[i4 - 1];
                        jArr[i2] = jArr[i2] * i2;
                        i3 *= iFld;
                        i6 >>= -214;
                        i7++;
                    }
                    i4++;
                }
            } else {
                i6 += ((i2 * i5) + i3) - i5;
            }
            i2++;
        }
        FuzzerUtils.out.println("i i15 i16 = " + i + "," + i2 + "," + i3);
        FuzzerUtils.out.println("i17 i18 i19 = " + i4 + "," + i5 + ",-1");
        FuzzerUtils.out.println("i20 b2 i21 = " + i6 + ",1," + i7);
        PrintStream printStream = FuzzerUtils.out;
        StringBuilder sb = new StringBuilder();
        sb.append("i22 = ");
        sb.append(-214);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount Test.sFld byFld = " + instanceCount + "," + ((int) sFld) + "," + ((int) this.byFld));
        FuzzerUtils.out.println("fFld Test.iFld Test.iArrFld = " + Float.floatToIntBits(this.fFld) + "," + iFld + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.lArrFld Test.sArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(sArrFld));
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

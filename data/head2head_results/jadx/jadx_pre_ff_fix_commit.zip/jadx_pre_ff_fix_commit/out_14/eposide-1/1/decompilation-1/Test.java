
import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_14/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld1;
    public static long lMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = 46610;
    public static double dFld = 0.39593d;
    public static int iFld = 204;
    public volatile short sFld = -9595;
    public byte byFld = 116;
    public int[] iArrFld = new int[N];

    static {
        int[] iArr = new int[N];
        iArrFld1 = iArr;
        FuzzerUtils.init(iArr, 2);
        vMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }

    public static void vMeth1(int i, int i2, int i3) {
        int i4 = i2 - i3;
        instanceCount >>= 28;
        int i5 = -9;
        float f = 2.895f;
        int i6 = 2;
        while (i6 > 1) {
            dFld = 8.0f;
            f -= 5.0f;
            i3 += i6;
            i5 += ((i6 * i3) + i5) - 28;
            try {
                int i7 = (-156) % i6;
                i4 = 42850 / i4;
                i3 = i6 % iArrFld1[(int) 1.0d];
            } catch (ArithmeticException e) {
            }
            i6--;
        }
        int[] iArr = iArrFld1;
        int i8 = (int) 0.0d;
        iArr[i8] = iArr[i8] ^ ((int) instanceCount);
        vMeth1_check_sum += ((((((((((((i + i4) + i3) + Float.floatToIntBits(8.0f)) + 28) + Double.doubleToLongBits(1.0d)) + i5) + i6) - 13719) + Float.floatToIntBits(f)) - 129) + 7) + 15996) - 24;
    }

    public static long lMeth(int i) {
        double d;
        byte b;
        double[] dArr = new double[N];
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(zArr, false);
        FuzzerUtils.init(dArr, 0.62971d);
        float f = 2.901f;
        int reverseBytes = i / ((int) (((Integer.reverseBytes(i) - 2.901f) - i) | 1));
        int i2 = -11;
        byte b2 = -64;
        long j = 6;
        double d2 = -112.62639d;
        int i3 = 241;
        while (i3 > 15) {
            zArr[i3] = b2 * reverseBytes == iArrFld1[i3];
            vMeth1(reverseBytes, reverseBytes, i2);
            long j2 = 7;
            do {
                reverseBytes = ((int) instanceCount) - ((int) f);
                d = 1.0d;
                while (d < 2.0d) {
                    instanceCount ^= i3;
                    d += 1.0d;
                    i2 -= i3;
                }
                f = -3;
                i2 *= (int) instanceCount;
                b = (byte) d;
                j2 -= 2;
            } while (j2 > 0);
            i3--;
            j = j2;
            d2 = d;
            b2 = b;
        }
        long floatToIntBits = (((((((reverseBytes + Float.floatToIntBits(f)) + i3) + i2) + b2) + j) + Double.doubleToLongBits(d2)) - 3) + FuzzerUtils.checkSum(zArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
        lMeth_check_sum += floatToIntBits;
        return floatToIntBits;
    }

    public static void vMeth() {
        long j;
        int i;
        int i2 = 47407;
        int i3 = -7;
        double d = -19.3636d;
        long j2 = 16658;
        int i4 = 3;
        int i5 = 5;
        while (i4 < 194) {
            lMeth(i4);
            dFld += 84.0d;
            int i6 = 1;
            do {
                long j3 = instanceCount - i4;
                instanceCount = j3;
                long j4 = j3 & 11;
                instanceCount = j4;
                long j5 = j4 >> 120;
                instanceCount = j5;
                j = j5 - 0.285f;
                instanceCount = j;
                i6++;
            } while (i6 < 8);
            int i7 = (((i4 >>> 1) % 5) * 5) + 106;
            if (i7 == 115) {
                i = i4 + i4;
            } else if (i7 == 123) {
                i = (i4 - i4) + i4;
                d = i4;
                while (d < 8.0d) {
                    j2 = 1;
                    d += 1.0d;
                }
            } else {
                if (i7 == 124) {
                    i = i4;
                } else if (i7 == 128) {
                    i5 += (int) dFld;
                    i = i4;
                } else if (i7 == 129) {
                    i = i4 + i4;
                } else {
                    i5 <<= (int) j;
                    i = i4;
                }
                int[] iArr = iArrFld1;
                int i8 = i4 + 1;
                iArr[i8] = iArr[i8] - ((int) 0.285f);
            }
            i4++;
            int i9 = i;
            i3 = i6;
            i2 = i9;
        }
        vMeth_check_sum += i4 + i2 + Float.floatToIntBits(0.285f) + i3 + Double.doubleToLongBits(d) + i5 + j2 + 15666;
    }

    public void mainTest(String[] strArr) {
        int i;
        float f;
        int i2;
        int i3;
        float f2;
        int i4;
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, 86.101f);
        FuzzerUtils.init(iArr, -9);
        int i5 = 1;
        while (true) {
            this.sFld = (short) (this.sFld + ((short) (i5 * ((this.byFld * (-12)) + 2.188f))));
            short s = this.sFld;
            int[] iArr2 = this.iArrFld;
            int i6 = iArr2[i5];
            iArr2[i5] = i6 + 1;
            this.sFld = (short) (s + ((short) i6));
            i = i5 + 3;
            if (i >= 213) {
                break;
            } else {
                i5 = i;
            }
        }
        int i7 = 4;
        int i8 = -13;
        int i9 = -13;
        float f3 = 2.188f;
        int i10 = 1187;
        int i11 = 38;
        int i12 = -49;
        int i13 = 179;
        int i14 = 1;
        while (true) {
            int i15 = 20282;
            if (i7 < 129) {
                int i16 = i8;
                int i17 = i10;
                int i18 = 2;
                while (i18 < 201) {
                    vMeth();
                    i16 <<= i9;
                    i18++;
                    i17 = 2;
                }
                int i19 = i7 + 1;
                fArr[i19] = fArr[i19] + 37700.0f;
                int[] iArr3 = this.iArrFld;
                int i20 = i7 - 1;
                iArr3[i20] = iArr3[i20] + i11;
                int i21 = 1;
                while (true) {
                    f = -152.0f;
                    i2 = 1;
                    while (true) {
                        switch ((i2 % 8) + 49) {
                            case 49:
                                float f4 = f;
                                long j = i9;
                                long j2 = instanceCount;
                                i3 = i;
                                int i22 = (int) (j + (((i2 * j2) + j) - i11));
                                int i23 = ((i2 % 5) * 5) + 64;
                                if (i23 != 69) {
                                    if (i23 != 75) {
                                        if (i23 == 82) {
                                            instanceCount = j2 + (i2 ^ 20282);
                                            iFld += 63;
                                            instanceCount = -61193L;
                                        } else {
                                            if (i23 == 87) {
                                                int[] iArr4 = iArr[i21 - 1];
                                                int i24 = i2 + 1;
                                                iArr4[i24] = iArr4[i24] & i11;
                                            } else if (i23 == 89) {
                                                i11 += i2 - i3;
                                                f = f4;
                                                i9 = i22;
                                                break;
                                            }
                                            f = f4;
                                            i9 = i22;
                                        }
                                    }
                                    f = f4 - ((float) dFld);
                                    i9 = i22;
                                }
                                this.sFld = (short) (this.sFld + ((short) 20282));
                                f = f4 - ((float) dFld);
                                i9 = i22;
                            case 50:
                                int i25 = i21 - 1;
                                f2 = f;
                                fArr[i25] = fArr[i25] + ((float) instanceCount);
                                i3 = i;
                                f = f2;
                                break;
                            case 51:
                                instanceCount <<= i17;
                            case 52:
                                fArr[i21 + 1] = i15;
                            case 53:
                                i9 -= i17;
                                i3 = i;
                                break;
                            case 54:
                                iArr[i2][i2] = (int) instanceCount;
                            case 55:
                                instanceCount <<= i21;
                                i3 = i;
                                f2 = f;
                                f = f2;
                                break;
                            case 56:
                                i9 += i2 - i2;
                                i3 = i;
                                break;
                            default:
                                i3 = i;
                                f2 = f;
                                f = f2;
                                break;
                        }
                        i2++;
                        if (i2 < 3) {
                            i = i3;
                            i15 = 20282;
                        } else {
                            i4 = i21 + 2;
                            if (i4 >= 201) {
                                break;
                            }
                            i21 = i4;
                            i = i3;
                            i15 = 20282;
                        }
                    }
                }
                i12 = i4;
                f3 = f;
                i14 = i18;
                i13 = i2;
                i10 = i17;
                i7 = i19;
                i = i3;
                i8 = i16;
            } else {
                PrintStream printStream = FuzzerUtils.out;
                printStream.println("i f i1 = " + i + "," + Float.floatToIntBits(f3) + "," + i7);
                FuzzerUtils.out.println("i2 i3 i4 = " + i8 + "," + i14 + ",20282");
                FuzzerUtils.out.println("i24 i25 i26 = " + i9 + "," + i10 + "," + i11);
                FuzzerUtils.out.println("b i27 i28 = 1," + i12 + "," + i13);
                FuzzerUtils.out.println("fArr iArr = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + "," + FuzzerUtils.checkSum(iArr));
                FuzzerUtils.out.println("Test.instanceCount sFld byFld = " + instanceCount + "," + ((int) this.sFld) + "," + ((int) this.byFld));
                FuzzerUtils.out.println("Test.dFld Test.iFld iArrFld = " + Double.doubleToLongBits(dFld) + "," + iFld + "," + FuzzerUtils.checkSum(this.iArrFld));
                PrintStream printStream2 = FuzzerUtils.out;
                long checkSum = FuzzerUtils.checkSum(iArrFld1);
                StringBuilder sb = new StringBuilder();
                sb.append("Test.iArrFld1 = ");
                sb.append(checkSum);
                printStream2.println(sb.toString());
                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

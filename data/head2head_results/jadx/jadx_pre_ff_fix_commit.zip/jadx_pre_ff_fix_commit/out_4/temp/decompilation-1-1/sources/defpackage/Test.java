package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_4/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static float[] fArrFld;
    public static long iMeth1_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = 6995260490916569061L;
    public static byte byFld = 41;
    public static short sFld = 1954;
    public int[] iArrFld = new int[N];
    public boolean[] bArrFld = new boolean[N];

    static {
        float[] fArr = new float[N];
        fArrFld = fArr;
        FuzzerUtils.init(fArr, -1.896f);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
    }

    public static int iMeth1(int i, boolean z, double d) {
        int[] iArr = new int[N];
        long[][] jArr = (long[][]) Array.newInstance((Class<?>) long.class, N, N);
        FuzzerUtils.init(iArr, -3);
        FuzzerUtils.init(jArr, 8939647224501505164L);
        int i2 = 7327;
        int i3 = -54350;
        int i4 = i;
        int i5 = -48511;
        float f = 1.1023f;
        short s = -31219;
        int i6 = 13;
        int i7 = 1;
        while (i6 < 208) {
            i2 += 1701636588;
            i3 = 1;
            while (i3 < 8) {
                int i8 = i2 + (((i3 * i2) + i2) - i2);
                f = 1.0f;
                while (f < 2.0f) {
                    s = (short) i8;
                    f += 1.0f;
                }
                i2 = (i8 - 12) >> i3;
                i3++;
            }
            i4 = (int) instanceCount;
            i7 += 60004;
            i5 = 77;
            i6++;
        }
        iArr[(i5 >>> 1) % N] = (int) f;
        long doubleToLongBits = i4 + (z ? 1 : 0) + Double.doubleToLongBits(d) + i6 + i2 + i3 + i7 + Float.floatToIntBits(f) + i5 + s + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr);
        iMeth1_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static void vMeth(int i, int i2) {
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(iArr, -32679);
        FuzzerUtils.init(fArr, 121.17f);
        double d = 2.68918d;
        int iMeth1 = i << iMeth1(i, true, 2.68918d);
        int i3 = i2;
        int i4 = 5;
        while (i4 < 132) {
            i3 = byFld;
            i4++;
        }
        int i5 = sFld;
        int i6 = 18;
        int i7 = -13;
        while (373 > i6) {
            int i8 = i3 + i6;
            try {
                i8 = (-47) % iMeth1;
                i7 = ((-59946) / iMeth1) % iArr[i6 - 1];
            } catch (ArithmeticException e) {
            }
            i3 = i8;
            d = -7.9030146058376694E18d;
            i5 += i6 + i3;
            i6++;
        }
        int i9 = 136;
        int i10 = -26863;
        int i11 = 12;
        for (int i12 = 5; i12 < i9; i12 = 5) {
            fArr[i9 + 1] = sFld;
            i10 *= iMeth1;
            i11 = 1;
            while (i11 < 35) {
                i5 = (int) instanceCount;
                instanceCount = i10;
                i11++;
                i7 = i7;
            }
            i9 -= 3;
        }
        vMeth_check_sum += (((((((((((iMeth1 + i3) + 1) + Double.doubleToLongBits(d)) + i4) + i5) + i6) + i7) + i9) + i10) + i11) - 13) + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public int iMeth(int i) {
        int i2;
        double[] dArr = new double[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(dArr, 0.126478d);
        FuzzerUtils.init(jArr, -217L);
        vMeth(i, i);
        double d = 7.0d;
        while (d < 353.0d) {
            short s = (short) (sFld - 1);
            sFld = s;
            if (((int) ((d % 1.0d) + 9.0d)) == 9) {
                sFld = s;
                int i3 = (int) d;
                this.iArrFld[i3] = byFld;
                jArr[i3] = instanceCount;
            }
            d += 1.0d;
        }
        int i4 = (int) instanceCount;
        int i5 = -12;
        int i6 = 188;
        int i7 = 1;
        do {
            i2 = i7;
            while (i2 < 4) {
                i5 ^= i2;
                i4 = (int) instanceCount;
                i2++;
                i6 = 1;
            }
            i7++;
        } while (i7 < 388);
        long doubleToLongBits = (((((((i + Double.doubleToLongBits(d)) + i4) + i7) + i2) + i5) + i6) - 34986) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + FuzzerUtils.checkSum(jArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        float f;
        int i = 2;
        long[][] jArr = (long[][]) Array.newInstance((Class<?>) long.class, N, N);
        FuzzerUtils.init(jArr, 15395L);
        instanceCount = iMeth(10);
        int i2 = -47694;
        int i3 = 212;
        int i4 = -6;
        int i5 = -4630;
        double d = -60.100473d;
        int i6 = 244;
        while (true) {
            f = 82.467f;
            if (i6 <= 6) {
                break;
            }
            i3 = 106;
            while (true) {
                i3 -= 2;
                if (i3 > 0) {
                    long[] jArr2 = jArr[i3 - 1];
                    int i7 = i6 + 1;
                    jArr2[i7] = jArr2[i7] | instanceCount;
                    this.iArrFld[i6] = i6;
                    this.iArrFld = FuzzerUtils.int1array(N, 47161);
                    instanceCount >>= i3;
                    float[] fArr = fArrFld;
                    fArr[i6] = fArr[i6] + i3;
                    i2 = ((int) d) + i3;
                    int i8 = 1;
                    while (i > i8) {
                        instanceCount += i8 ^ i8;
                        this.bArrFld[i7] = false;
                        i8++;
                        jArr = jArr;
                        i = 2;
                    }
                    i4 = i8;
                    i = 2;
                }
            }
            this.iArrFld[i6 - 1] = sFld;
            double d2 = i6;
            Double.isNaN(d2);
            d -= d2;
            byFld = (byte) 82.467f;
            instanceCount -= i3;
            i5 = i6 * i6;
            i6--;
            jArr = jArr;
            i = 2;
        }
        long[][] jArr3 = jArr;
        int i9 = 13;
        while (i9 < 354) {
            i2 -= 33;
            i9++;
        }
        int i10 = 9;
        int i11 = -220;
        int i12 = -3;
        while (i10 < 321) {
            i12 = 1;
            do {
                f += (float) instanceCount;
                i11 = (i11 >> i9) + 1007079388;
                i12++;
            } while (i12 < 81);
            i10++;
        }
        FuzzerUtils.out.println("i23 i24 i25 = " + i6 + "," + i2 + "," + i3);
        FuzzerUtils.out.println("b2 d4 i26 = 0," + Double.doubleToLongBits(d) + "," + i4);
        FuzzerUtils.out.println("i27 f1 i29 = " + i5 + "," + Float.floatToIntBits(f) + "," + i9);
        FuzzerUtils.out.println("i30 i31 i32 = 1," + i10 + "," + i11);
        FuzzerUtils.out.println("i33 lArr2 = " + i12 + "," + FuzzerUtils.checkSum(jArr3));
        FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.sFld = " + instanceCount + "," + ((int) byFld) + "," + ((int) sFld));
        FuzzerUtils.out.println("iArrFld Test.fArrFld bArrFld = " + FuzzerUtils.checkSum(this.iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(this.bArrFld));
        PrintStream printStream = FuzzerUtils.out;
        long j = iMeth1_check_sum;
        StringBuilder sb = new StringBuilder();
        sb.append("iMeth1_check_sum: ");
        sb.append(j);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

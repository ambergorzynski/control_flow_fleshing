
import java.io.PrintStream;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_47/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static byte[] byArrFld;
    public static long iMeth1_check_sum;
    public static long iMeth2_check_sum;
    public static long iMeth_check_sum;
    public static long[] lArrFld;
    public int[] iArrFld = new int[N];
    public static long instanceCount = -5914141721094050167L;
    public static int iFld = -7;
    public static byte byFld = -127;
    public static float fFld = 41.168f;

    static {
        long[] jArr = new long[N];
        lArrFld = jArr;
        byArrFld = new byte[N];
        FuzzerUtils.init(jArr, -13149L);
        FuzzerUtils.init(byArrFld, (byte) 82);
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
        iMeth2_check_sum = 0L;
    }

    public int iMeth2(int i) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -116139824L);
        int i2 = iFld;
        int i3 = (i2 >>> 1) % N;
        jArr[i3] = jArr[i3] - i2;
        long checkSum = i + FuzzerUtils.checkSum(jArr);
        iMeth2_check_sum += checkSum;
        return (int) checkSum;
    }

    public int iMeth1(long j, int i, double d) {
        long j2 = j;
        int i2 = 12;
        int i3 = 5766;
        int i4 = -207;
        int i5 = 61737;
        float f = -1.863f;
        int i6 = 8;
        while (i6 < 158) {
            long j3 = instanceCount;
            float f2 = -11;
            float f3 = (f * ((float) (((j2 << ((int) j3)) * (j3 - iFld)) % 9))) + f2;
            int i7 = 1;
            byte b = (byte) (byFld - 1);
            byFld = b;
            iFld = b;
            iFld = (int) (f2 - ((8 - f3) + 9));
            f = f3 - 14521.0f;
            int i8 = 11;
            while (true) {
                i8--;
                if (i8 <= 0) {
                    break;
                }
                i3 = 2;
            }
            instanceCount = j2;
            while (i7 < 11) {
                j2 -= 3;
                iFld += (int) d;
                i5 += i7;
                i7++;
            }
            i6++;
            i2 = i8;
            i4 = i7;
        }
        long doubleToLongBits = ((((((((j2 + i) + Double.doubleToLongBits(d)) + i6) - 11) + Float.floatToIntBits(f)) + i2) + i3) - 29002) + i4 + i5;
        iMeth1_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public int iMeth(boolean z) {
        long j;
        int i = iFld;
        int i2 = i - 1;
        iFld = i2;
        int i3 = i2 - 1;
        iFld = i3;
        int i4 = i - (i2 * i3);
        iFld = i4;
        long j2 = instanceCount;
        iFld = i4 - 1;
        int i5 = i4 ^ i4;
        iFld = i5;
        long j3 = j2 - 1;
        instanceCount = j3;
        long j4 = j2 + (i5 - j3);
        instanceCount = j4;
        double iMeth1 = iMeth1(j4, 58889, 79.266d);
        Double.isNaN(iMeth1);
        double d = iMeth1 + 79.266d;
        double d2 = 1.24112d;
        int i6 = 1;
        int i7 = 3;
        do {
            switch ((i6 % 3) + 105) {
                case 105:
                    d2 = 5.0d;
                    do {
                        fFld *= (float) d2;
                        j = instanceCount;
                        iFld = (int) j;
                        d2 -= 1.0d;
                    } while (d2 > 0.0d);
                    if (z) {
                        instanceCount = j + ((i6 * i6) - 1303);
                        i7 = 5;
                        do {
                            int i8 = (i6 % 4) + 1;
                            if (i8 == 1) {
                                iFld *= i7;
                            } else if (i8 != 2) {
                                if (i8 == 3) {
                                    instanceCount += iFld;
                                } else if (i8 == 4) {
                                    iFld = i7;
                                } else {
                                    iFld += (i7 * i7) + 40;
                                }
                            } else {
                                int i9 = iFld;
                                float f = fFld;
                                int i10 = (int) (i9 + (((i7 * f) + f) - i9));
                                iFld = i10;
                                iFld = i10 - i7;
                            }
                            i7--;
                        } while (i7 > 0);
                    } else {
                        this.iArrFld[(i6 >>> 1) % N] = i6;
                        break;
                    }
                case 106:
                    instanceCount = i6;
                    break;
                case 107:
                    iFld += i6 * i6;
                    break;
                default:
                    lArrFld[i6 - 1] = r8[r9] - 160;
                    break;
            }
            i6++;
        } while (i6 < 374);
        long doubleToLongBits = (z ? 1L : 0L) + Double.doubleToLongBits(d) + i6 + Double.doubleToLongBits(d2) + i7 + 0;
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, -97.728f);
        int i = iFld;
        iFld = i - 1;
        iFld = i;
        long j = instanceCount + 1;
        instanceCount = j;
        iFld = i - ((int) (((j * 4237937842L) + iMeth(true)) + instanceCount));
        int i2 = 6;
        int i3 = 6;
        int i4 = 10;
        int i5 = -63907;
        int i6 = 3445;
        int i7 = -15851;
        while (i2 < 298) {
            int[] iArr = this.iArrFld;
            iArr[i2] = iArr[i2] | (-3);
            instanceCount *= fFld;
            int i8 = i7;
            int i9 = i6;
            int i10 = i5;
            int i11 = 2;
            while (86 > i11) {
                i3 = 1;
                while (i3 < 2) {
                    i10 <<= i11;
                    byFld = (byte) (byFld * ((byte) i9));
                    int[] iArr2 = this.iArrFld;
                    int i12 = i2 + 1;
                    int i13 = iArr2[i12];
                    long j2 = instanceCount;
                    iArr2[i12] = i13 >> ((int) j2);
                    instanceCount = j2 + i3 + i11;
                    long j3 = i10;
                    instanceCount = j3;
                    switch ((i3 % 7) + 125) {
                        case 125:
                            i10 = i10 + i3 + i2 + (i3 - i9);
                            i8 += i3 * i10;
                            i9 = i3;
                            break;
                        case 126:
                            long j4 = j3 + (i3 * i2);
                            instanceCount = j4;
                            instanceCount = j4 - i8;
                            break;
                        case 127:
                            i9 += i3;
                        case 128:
                            long j5 = ((float) instanceCount) + (i3 * fFld);
                            instanceCount = j5;
                            int i14 = iFld;
                            instanceCount = j5 + i14;
                            iFld = i14 * i8;
                            break;
                        case 129:
                        case 130:
                            byArrFld[i3 + 1] = (byte) i8;
                            iArr2[i3] = (int) j3;
                        case 131:
                            int i15 = i3 + 1;
                            fArr[i15] = fArr[i15] + ((float) instanceCount);
                            iFld += i3;
                            instanceCount = 219L;
                            break;
                    }
                    int[] iArr3 = this.iArrFld;
                    i3++;
                    long j6 = instanceCount;
                    iArr3[i3] = (int) j6;
                    instanceCount = j6;
                }
                i11++;
            }
            i2++;
            i4 = i11;
            i5 = i10;
            i6 = i9;
            i7 = i8;
        }
        FuzzerUtils.out.println("b2 i12 i13 = 1," + i2 + ",-3");
        FuzzerUtils.out.println("i14 i15 i16 = " + i4 + "," + i5 + "," + i3);
        FuzzerUtils.out.println("i17 i18 fArr = " + i6 + "," + i7 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.byFld = " + instanceCount + "," + iFld + "," + ((int) byFld));
        FuzzerUtils.out.println("Test.fFld iArrFld Test.lArrFld = " + Float.floatToIntBits(fFld) + "," + FuzzerUtils.checkSum(this.iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        PrintStream printStream = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(byArrFld);
        StringBuilder sb = new StringBuilder();
        sb.append("Test.byArrFld = ");
        sb.append(checkSum);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("iMeth2_check_sum: " + iMeth2_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

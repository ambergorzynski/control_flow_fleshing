
import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_7/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vSmallMeth_check_sum;
    public boolean bFld = true;
    public static long instanceCount = -8273866329805269590L;
    public static int iFld = 0;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, -14318);
        vSmallMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }

    public static void vMeth() {
        int i = iFld;
        iFld = i + i;
        int i2 = 6;
        int i3 = 104;
        int i4 = 213;
        int i5 = 60381;
        int i6 = 40248;
        long j = -7;
        while (i2 < 358) {
            iFld -= (int) instanceCount;
            iFld = i2;
            int i7 = 5;
            int i8 = ((i2 % 6) * 5) + 19;
            if (i8 != 21) {
                if (i8 != 24) {
                    if (i8 == 39) {
                        i3 += i2;
                    } else if (i8 != 43) {
                        if (i8 != 33) {
                            if (i8 == 34) {
                                i6 = i3;
                            }
                        }
                    }
                    int i9 = iFld;
                    iFld = i9 & i9;
                } else {
                    while (i7 > i2) {
                        iFld = 94;
                        i5 += 25966;
                        i7 -= 3;
                    }
                    i4 = i7;
                }
                i2++;
            }
            if (i3 != 0) {
                vMeth_check_sum += (((((i2 + i3) + 0) + i4) + i5) - 25966) + j + i6;
                return;
            }
            j = i2;
            while (5 > j) {
                instanceCount >>>= i5;
                i6 *= i4;
                j++;
                i3 = i2;
            }
            i2++;
        }
        vMeth_check_sum += (((((i2 + i3) + 0) + i4) + i5) - 25966) + j + i6;
    }

    public static int iMeth(int i, long j, short s) {
        int[][][] iArr = (int[][][]) Array.newInstance((Class<?>) int.class, N, N, N);
        double[] dArr = new double[N];
        FuzzerUtils.init((Object[][]) iArr, (Object) (-15912));
        FuzzerUtils.init(dArr, 1.60633d);
        int i2 = 38300;
        int i3 = -162;
        int i4 = -63;
        float f = -6.66f;
        float f2 = -2.278f;
        long j2 = 2;
        while (j2 < 208) {
            int i5 = (int) j2;
            float f3 = f2;
            float f4 = f;
            int i6 = i4;
            int i7 = i3;
            int i8 = i5;
            while (i8 < 8) {
                int[] iArr2 = iArr[i5][i5];
                int i9 = i8 - 1;
                long j3 = i7 - 4191601283830594869L;
                int i10 = i7 - 1;
                long j4 = j2;
                int i11 = i8 + 1;
                int[] iArr3 = iArr[i11][i5];
                int i12 = i5;
                iArr3[i8] = iArr3[i8] - 1;
                f4 += 1.0f;
                float f5 = f3;
                iArr2[i9] = iArr2[i9] - ((int) ((j3 - i10) >> ((int) (r2 - f4))));
                long j5 = instanceCount;
                iFld = iFld + 1;
                int i13 = i10 - 1;
                instanceCount = j5 * Math.max(r2, i10);
                vMeth();
                instanceCount += i8 * i8;
                if (((int) ((j4 % 1) + 83)) != 83) {
                    f3 = f5;
                } else {
                    i6 = 1;
                    f3 = 1.0f;
                }
                i8 = i11;
                i7 = i13;
                j2 = j4;
                i5 = i12;
            }
            j2++;
            i2 = i8;
            i3 = i7;
            i4 = i6;
            f = f4;
            f2 = f3;
        }
        long floatToIntBits = ((((((((((((i + j) + s) + j2) + 8360) + i2) + i3) + Float.floatToIntBits(f)) + 1) + Float.floatToIntBits(f2)) + 208) + i4) - 1) + FuzzerUtils.checkSum((Object[][]) iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vSmallMeth(short s) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -37781);
        int i = iFld;
        int i2 = (i >>> 1) % N;
        int i3 = iArr[i2] + 1;
        iArr[i2] = i3;
        iFld = i * (i3 - iMeth(i, instanceCount, (short) 11125));
        instanceCount -= 115;
        vSmallMeth_check_sum += s + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int i;
        int[] iArr = new int[N];
        byte[] bArr = new byte[N];
        long[] jArr = new long[N];
        double[][] dArr = (double[][]) Array.newInstance((Class<?>) double.class, N, N);
        short[] sArr = new short[N];
        FuzzerUtils.init(jArr, -12L);
        FuzzerUtils.init(bArr, (byte) -74);
        FuzzerUtils.init(iArr, -4);
        FuzzerUtils.init(dArr, -2.81576d);
        FuzzerUtils.init(sArr, (short) 22484);
        int i2 = 1;
        int i3 = 28402;
        int i4 = -109;
        int i5 = -61522;
        int i6 = 49058;
        float f = -2.822f;
        byte b = 104;
        int i7 = 1;
        while (true) {
            i7 += i2;
            if (i7 < 244) {
                double[][] dArr2 = dArr;
                iFld += (int) (jArr[i7] * (instanceCount - i7));
                int i8 = 6;
                i3 = 6;
                while (i3 < 103) {
                    i4 += -(bArr[i3] - 122);
                    double[] dArr3 = dArr2[i7];
                    int i9 = i7 - 1;
                    int i10 = i3;
                    double d = dArr3[i9];
                    dArr3[i9] = d + 1.0d;
                    iFld = (int) d;
                    boolean z = false;
                    for (int i11 = 0; i11 < 1; i11++) {
                        vSmallMeth((short) -30051);
                    }
                    f = 2.0f;
                    while (f > 1.0f) {
                        byte b2 = (byte) 2;
                        i6 = 2 / (i4 | 1);
                        int i12 = iFld;
                        switch (((i12 >>> 1) % i8) + 96) {
                            case 96:
                                i = i10;
                                long j = instanceCount;
                                i4 = (int) j;
                                iFld = i12 | ((int) j);
                                break;
                            case 97:
                                int i13 = (int) f;
                                iFld = i12 + i13;
                                instanceCount = instanceCount + (((i6 * f) + ((float) r5)) - r8);
                                if (((int) ((f % 1.0f) + 57.0f)) == 57) {
                                    i6 *= 283282329;
                                }
                                switch ((int) ((f % 7.0f) + 101.0f)) {
                                    case 101:
                                        i = i10;
                                        int[] iArr2 = iArrFld;
                                        iArr2[i13] = iArr2[i13] + i7;
                                        int i14 = i + 1;
                                        iArr2[i14] = iArr2[i14] * 2;
                                        break;
                                    case 102:
                                        i = i10;
                                        i6 = ((i6 * iFld) >> ((int) instanceCount)) >> (-59149);
                                        break;
                                    case 103:
                                        i = i10;
                                        instanceCount = iFld;
                                        break;
                                    case 104:
                                        i = i10;
                                        int i15 = iFld << i4;
                                        iFld = i15;
                                        b2 = (byte) (b2 >> ((byte) i15));
                                        break;
                                    case 105:
                                        i = i10;
                                        instanceCount = i;
                                        break;
                                    case 106:
                                        sArr[i13] = (short) i4;
                                        i = i10;
                                        break;
                                    case 107:
                                        iFld += i13;
                                        i = i10;
                                        break;
                                    default:
                                        i = i10;
                                        break;
                                }
                            case 98:
                                iArrFld[(int) f] = i7;
                            case 99:
                            case 100:
                                this.bFld = z;
                                i = i10;
                                break;
                            case 101:
                                iFld = i12 + i12;
                                i = i10;
                                break;
                            default:
                                i = i10;
                                break;
                        }
                        b = b2;
                        f -= 1.0f;
                        i10 = i;
                        i8 = 6;
                        z = false;
                    }
                    i3 = i10 + 1;
                    i8 = 6;
                    i5 = 2;
                }
                dArr = dArr2;
                i2 = 1;
            } else {
                double[][] dArr4 = dArr;
                FuzzerUtils.out.println("i i1 i2 = " + i7 + "," + i3 + "," + i4);
                FuzzerUtils.out.println("i3 f2 i16 = " + i5 + "," + Float.floatToIntBits(f) + "," + i6);
                FuzzerUtils.out.println("by lArr byArr = " + ((int) b) + "," + FuzzerUtils.checkSum(jArr) + "," + FuzzerUtils.checkSum(bArr));
                FuzzerUtils.out.println("iArr dArr sArr = " + FuzzerUtils.checkSum(iArr) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr4)) + "," + FuzzerUtils.checkSum(sArr));
                FuzzerUtils.out.println("Test.instanceCount Test.iFld bFld = " + instanceCount + "," + iFld + "," + (this.bFld ? 1 : 0));
                PrintStream printStream = FuzzerUtils.out;
                long checkSum = FuzzerUtils.checkSum(iArrFld);
                StringBuilder sb = new StringBuilder();
                sb.append("Test.iArrFld = ");
                sb.append(checkSum);
                printStream.println(sb.toString());
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

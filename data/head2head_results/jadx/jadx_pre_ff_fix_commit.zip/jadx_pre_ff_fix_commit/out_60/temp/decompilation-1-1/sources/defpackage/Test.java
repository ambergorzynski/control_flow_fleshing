package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_60/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static long[] lArrFld;
    public static long lMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = -8258715466039985572L;
    public static double dFld = 2.2991d;
    public static int iFld = 56;
    public short sFld = -23039;
    public double[] dArrFld = new double[N];

    static {
        long[] jArr = new long[N];
        lArrFld = jArr;
        FuzzerUtils.init(jArr, -61L);
        lMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }

    /* JADX WARN: Removed duplicated region for block: B:45:0x00ab  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x00ba  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static void vMeth1(short r15, int r16, boolean r17) {
        /*
            Method dump skipped, instructions count: 296
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.Test.vMeth1(short, int, boolean):void");
    }

    public static void vMeth() {
        vMeth1((short) -17492, 105, false);
        int i = (int) instanceCount;
        int i2 = 1;
        while (true) {
            i2++;
            if (i2 >= 245) {
                break;
            } else {
                i = (int) instanceCount;
            }
        }
        int i3 = i;
        int i4 = 10;
        int i5 = 1;
        while (i4 < 171) {
            i3 *= 198;
            if (i4 >= 10) {
                i5 = i4;
                i4++;
            } else {
                instanceCount = -235L;
                vMeth_check_sum += (((((((-17492) + i3) + i2) + i4) + 198) + i4) - 49989) + Double.doubleToLongBits(0.0d);
                return;
            }
        }
        vMeth_check_sum += (((((((-17492) + i3) + i2) + i4) + 198) + i5) - 49989) + Double.doubleToLongBits(-1.1605d);
    }

    public static long lMeth(int i, byte b, float f) {
        int i2;
        int[][][] iArr = (int[][][]) Array.newInstance((Class<?>) int.class, N, N, N);
        int[] iArr2 = new int[N];
        FuzzerUtils.init((Object[][]) iArr, (Object) 21207);
        FuzzerUtils.init(iArr2, -2);
        vMeth();
        int i3 = i >>> 1;
        int i4 = i3 % N;
        iArr[i4][397][i4] = (int) instanceCount;
        for (int i5 = 0; i5 < 400; i5++) {
            int i6 = iArr2[i5];
        }
        int i7 = 8;
        while (367 > i7) {
            double d = dFld;
            double d2 = 137;
            Double.isNaN(d2);
            dFld = d * d2;
            i7++;
        }
        float f2 = f;
        int i8 = 3;
        int i9 = 20;
        int i10 = 137;
        int i11 = 243;
        int i12 = -8;
        int i13 = -177;
        short s = 4064;
        while (i9 < 366) {
            int i14 = ((i3 % 6) * 5) + 68;
            if (i14 != 82) {
                if (i14 == 84) {
                    i11 = i13;
                } else if (i14 == 86) {
                    int i15 = 5;
                    do {
                        int i16 = i15;
                        while (i16 < 1) {
                            long j = instanceCount;
                            s = (short) j;
                            double d3 = dFld;
                            double d4 = j;
                            Double.isNaN(d4);
                            double d5 = d3 + d4;
                            dFld = d5;
                            lArrFld[i4] = i9;
                            i13 = (int) d5;
                            i16++;
                        }
                        i2 = i16;
                        long j2 = instanceCount;
                        instanceCount = j2 + j2;
                        i15--;
                    } while (i15 > 0);
                    i8 = i15;
                    i12 = i2;
                } else if (i14 != 89 && i14 != 95 && i14 == 96) {
                    f2 = i7;
                }
                i9++;
            }
            i10 += ((i9 * i11) + i8) - i;
            i9++;
        }
        long floatToIntBits = i + b + Float.floatToIntBits(f2) + i7 + i10 + i9 + i11 + i8 + i12 + i13 + s + 0 + FuzzerUtils.checkSum((Object[][]) iArr) + FuzzerUtils.checkSum(iArr2);
        lMeth_check_sum += floatToIntBits;
        return floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        byte b;
        int i;
        int i2;
        int i3;
        float f;
        long j;
        int i4;
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        FuzzerUtils.init(iArr, -95);
        int i5 = -2;
        int i6 = 200;
        while (true) {
            b = -89;
            if (i6 <= 1) {
                break;
            }
            int[] iArr2 = iArr[i6];
            int i7 = i6 - 1;
            iArr2[i7] = ((int) lMeth(i5, (byte) -89, 5.372f)) | iArr2[i7];
            try {
                iFld = i6 % i6;
                iFld = i5 % 703020699;
                i5 = (-15) / i5;
            } catch (ArithmeticException e) {
            }
            i6--;
        }
        float f2 = 12.0f;
        int i8 = 49531;
        int i9 = 12023;
        int i10 = 120;
        float f3 = -36.428f;
        float f4 = 1.484f;
        long j2 = 180;
        int i11 = 5;
        while (f2 < 244.0f) {
            int[][] iArr3 = iArr;
            instanceCount -= (long) dFld;
            instanceCount = i8;
            switch ((int) ((f2 % 8.0f) + 74.0f)) {
                case 74:
                    float f5 = f4;
                    long j3 = j2;
                    float f6 = 2.0f;
                    while (f6 < 108.0f) {
                        i8 *= (int) instanceCount;
                        f6 += 1.0f;
                    }
                    int i12 = iFld * (-30);
                    iFld = i12;
                    long j4 = instanceCount;
                    iFld = i12 + ((int) (((f2 * f2) + ((float) j4)) - ((float) j4)));
                    f3 = f6;
                    f4 = f5;
                    j2 = j3;
                    i5 = -30;
                    break;
                case 75:
                    int i13 = i5;
                    instanceCount = 166L;
                    instanceCount = 166 + 10;
                    instanceCount = i13;
                    j2 = 108;
                    f4 = f4;
                    i5 = i13;
                    while (j2 > 4) {
                        f4 = iFld;
                        i11 = 1;
                        while (i11 < 4) {
                            i9 += (int) f4;
                            int i14 = (i11 % 2) + 66;
                            if (i14 == 66) {
                                b = (byte) (b + ((byte) i11));
                            } else if (i14 != 67) {
                                dFld = i8;
                                i2 = i8;
                                i11++;
                                i8 = i2;
                            }
                            iFld = i5;
                            int i15 = (((i6 >>> 1) % 2) * 5) + 124;
                            if (i15 == 125) {
                                i10 += ((i11 * (-64)) + i8) - i5;
                                double d = dFld;
                                i2 = i8;
                                double d2 = f2;
                                Double.isNaN(d2);
                                dFld = d + d2;
                            } else if (i15 != 128) {
                                this.sFld = (short) (this.sFld + ((short) i11));
                                i2 = i8;
                            } else {
                                i5 -= 64;
                                this.sFld = b;
                                i2 = i8;
                                i9 = -18855;
                            }
                            i11++;
                            i8 = i2;
                        }
                        j2 -= 3;
                    }
                    i = i8;
                    instanceCount = 20L;
                    i8 = i;
                    break;
                case 76:
                    i = i8;
                    i5 = i5;
                    instanceCount = 20L;
                    i8 = i;
                    break;
                case 77:
                    i3 = i5;
                    long[] jArr = lArrFld;
                    int i16 = (int) f2;
                    f = f4;
                    j = j2;
                    jArr[i16] = jArr[i16] - i9;
                    f4 = f;
                    i5 = i3;
                    j2 = j;
                    break;
                case 78:
                    i4 = i5;
                    b = (byte) (b << ((byte) i6));
                    i9 >>>= (int) instanceCount;
                    i5 = i4;
                    break;
                case 79:
                    i4 = i5;
                    i9 >>>= (int) instanceCount;
                    i5 = i4;
                    break;
                case 80:
                    i3 = i5;
                    this.dArrFld[(int) (f2 - 1.0f)] = i8;
                    f = f4;
                    j = j2;
                    f4 = f;
                    i5 = i3;
                    j2 = j;
                    break;
                case 81:
                    i5 <<= 0;
                    break;
                default:
                    int i17 = i5;
                    float f7 = i11;
                    i8 += (int) (((f2 * f7) + f7) - i17);
                    i5 = i17;
                    break;
            }
            f2 += 1.0f;
            iArr = iArr3;
        }
        int[][] iArr4 = iArr;
        FuzzerUtils.out.println("i i1 by2 = " + i6 + "," + i5 + "," + ((int) b));
        FuzzerUtils.out.println("f3 i23 f4 = " + Float.floatToIntBits(f2) + "," + i8 + "," + Float.floatToIntBits(f3));
        FuzzerUtils.out.println("i24 l i25 = " + i9 + "," + j2 + ",-64");
        FuzzerUtils.out.println("f5 i26 i27 = " + Float.floatToIntBits(f4) + "," + i11 + "," + i10);
        FuzzerUtils.out.println("b3 iArr = 1," + FuzzerUtils.checkSum(iArr4));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.iFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + iFld);
        PrintStream printStream = FuzzerUtils.out;
        short s = this.sFld;
        printStream.println("sFld Test.lArrFld dArrFld = " + ((int) s) + "," + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld)));
        PrintStream printStream2 = FuzzerUtils.out;
        long j5 = vMeth1_check_sum;
        StringBuilder sb = new StringBuilder();
        sb.append("vMeth1_check_sum: ");
        sb.append(j5);
        printStream2.println(sb.toString());
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

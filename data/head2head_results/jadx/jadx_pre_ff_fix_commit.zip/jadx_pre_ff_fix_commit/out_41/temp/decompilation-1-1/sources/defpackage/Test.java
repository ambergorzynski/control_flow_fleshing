package defpackage;

import java.io.PrintStream;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_41/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static byte[] byArrFld;
    public static int[] iArrFld;
    public static long iMeth1_check_sum;
    public static long iMeth_check_sum;
    public static long[] lArrFld;
    public static long sMeth_check_sum;
    public static long vSmallMeth_check_sum;
    public static long instanceCount = 11;
    public static short sFld = 7695;
    public static boolean bFld = false;

    static {
        byte[] bArr = new byte[N];
        byArrFld = bArr;
        iArrFld = new int[N];
        lArrFld = new long[N];
        FuzzerUtils.init(bArr, (byte) -9);
        FuzzerUtils.init(iArrFld, -5);
        FuzzerUtils.init(lArrFld, -12L);
        vSmallMeth_check_sum = 0L;
        sMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
    }

    public static void vSmallMeth(int i, int i2, boolean z) {
        byte[] bArr = byArrFld;
        int i3 = (i >>> 1) % N;
        long j = instanceCount;
        bArr[i3] = (byte) ((((float) (i * j)) * (((float) j) - 2.91f)) + 2.91f);
        vSmallMeth_check_sum += i + i2 + (z ? 1 : 0) + Float.floatToIntBits(2.91f);
    }

    public static int iMeth1() {
        long floatToIntBits = Float.floatToIntBits((-2.548f) - ((float) (-60.117033d))) + Double.doubleToLongBits(-60.117033d) + ((-6) % ((int) (instanceCount | 1)));
        iMeth1_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static int iMeth(float f, long j) {
        short reverseBytes = Short.reverseBytes(sFld);
        int i = reverseBytes - (-(reverseBytes - 1));
        int min = i * Math.min(i, 60823);
        sFld = (short) (min - min);
        int i2 = 8;
        while (i2 < 185) {
            min += iMeth1();
            i2++;
        }
        iArrFld[327] = (int) j;
        long floatToIntBits = Float.floatToIntBits(f) + j + min + i2 + 5;
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public short sMeth(boolean z) {
        int i;
        int i2 = (-11) >> ((int) ((iArrFld[42] - instanceCount) - (-11)));
        int i3 = 11;
        int i4 = -33197;
        int i5 = 4;
        int i6 = 1;
        do {
            int[] iArr = iArrFld;
            iArr[i6] = iArr[i6] * iMeth(89.48f, instanceCount) * i6 * i6;
            i = 1;
            while (i < 5) {
                i4 = 1;
                while (i4 < 2) {
                    i2 *= i4;
                    i5 = 12;
                    switch ((i6 % 3) + 15) {
                        case 15:
                            if (!z) {
                                i3 += (i4 * i4) - 11;
                                instanceCount += i2;
                                instanceCount = 12;
                                break;
                            } else {
                                break;
                            }
                        case 16:
                            i5 = 12 - i6;
                            break;
                        case 17:
                            i2 -= (int) instanceCount;
                            break;
                        default:
                            i5 = i3;
                            break;
                    }
                    i4++;
                }
                i++;
            }
            i6++;
        } while (i6 < 325);
        long floatToIntBits = (z ? 1 : 0) + i2 + i6 + Float.floatToIntBits(89.48f) + i + i3 + i4 + i5;
        sMeth_check_sum += floatToIntBits;
        return (short) floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        double d;
        int i;
        float[] fArr = new float[N];
        short[] sArr = new short[N];
        FuzzerUtils.init(fArr, -65.418f);
        FuzzerUtils.init(sArr, (short) 11492);
        int i2 = 63580;
        int i3 = 0;
        while (true) {
            d = -84.23626d;
            if (i3 >= 792) {
                break;
            }
            i2--;
            double sMeth = sMeth(bFld);
            Double.isNaN(sMeth);
            vSmallMeth(i2, (int) (sMeth - (-84.23626d)), bFld);
            i3++;
        }
        float f = 6.0f;
        int i4 = 8;
        int i5 = 47861;
        int i6 = 49124;
        int i7 = 114;
        int i8 = 60302;
        float f2 = 108.983f;
        while (f < 297.0f) {
            int i9 = 1;
            int i10 = 1;
            double d2 = d;
            int i11 = i2;
            int i12 = i5;
            int i13 = i6;
            double d3 = d2;
            while (true) {
                i10 += i9;
                if (i10 < 86) {
                    d3 = 25277;
                    if (bFld) {
                        i12 = 1;
                        break;
                    }
                    try {
                        int i14 = (int) (f - 1.0f);
                        iArrFld[i14] = 44867 / iArrFld[i10 - 1];
                        iArrFld[(int) (f + 1.0f)] = 25277 % iArrFld[i14];
                        i13 %= -157412944;
                    } catch (ArithmeticException e) {
                    }
                    int i15 = (int) (((f % 9.0f) * 5.0f) + 112.0f);
                    if (i15 != 116) {
                        if (i15 == 130) {
                            instanceCount = instanceCount;
                        } else if (i15 != 134) {
                            if (i15 == 136) {
                                i = i11;
                            } else if (i15 == 148) {
                                int i16 = i11;
                                int[] iArr = iArrFld;
                                int i17 = (int) (f - 1.0f);
                                iArr[i17] = iArr[i17] >>> i16;
                                i11 = i16;
                            } else if (i15 == 153) {
                                instanceCount -= 5685173887424391563L;
                                long[] jArr = lArrFld;
                                int i18 = (int) (f - 1.0f);
                                i = i11;
                                jArr[i18] = jArr[i18] + i10;
                                i8 = (int) f2;
                                i7 = 1;
                            } else if (i15 == 155) {
                                i9 = 1;
                                i13 = i10;
                                i12 = 1;
                            } else if (i15 != 150) {
                                if (i15 == 151) {
                                    i9 = 1;
                                    i11 -= 17024;
                                    i12 = 1;
                                } else {
                                    sArr[(int) (f + 1.0f)] = (short) 1;
                                }
                            }
                            i13 *= 250;
                            i11 = i >> i7;
                            bFld = bFld;
                            i12 = 1;
                            i9 = 1;
                        } else {
                            i11 -= 12145;
                            i12 = 1;
                            i9 = 1;
                        }
                        i12 = 1;
                        i9 = 1;
                    } else {
                        f2 = i8;
                    }
                    i11 = -32;
                    i12 = 1;
                    i9 = 1;
                }
            }
            f += 1.0f;
            i4 = i10;
            double d4 = d3;
            i5 = i12;
            i2 = i11;
            i6 = i13;
            d = d4;
        }
        FuzzerUtils.out.println("i2 d1 f4 = " + i2 + "," + Double.doubleToLongBits(d) + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i13 i14 i15 = 25277," + i4 + "," + i5);
        FuzzerUtils.out.println("i16 i17 i18 = " + i6 + "," + i7 + "," + i8);
        FuzzerUtils.out.println("by f5 fArr = -94," + Float.floatToIntBits(f2) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)));
        PrintStream printStream = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(sArr);
        StringBuilder sb = new StringBuilder();
        sb.append("sArr = ");
        sb.append(checkSum);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.bFld = " + instanceCount + "," + ((int) sFld) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.byArrFld Test.iArrFld Test.lArrFld = " + FuzzerUtils.checkSum(byArrFld) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        PrintStream printStream2 = FuzzerUtils.out;
        long j = vSmallMeth_check_sum;
        StringBuilder sb2 = new StringBuilder();
        sb2.append("vSmallMeth_check_sum: ");
        sb2.append(j);
        printStream2.println(sb2.toString());
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("sMeth_check_sum: " + sMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

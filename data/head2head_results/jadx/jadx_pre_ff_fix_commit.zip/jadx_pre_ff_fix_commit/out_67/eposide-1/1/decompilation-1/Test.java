
/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_67/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static float[] fArrFld;
    public static int[] iArrFld;
    public static long[] lArrFld;
    public static long lMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = -6;
    public static short sFld = -10842;
    public static byte byFld = -99;
    public static double dFld = -2.128444d;
    public static int iFld = -58315;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        fArrFld = new float[N];
        lArrFld = new long[N];
        FuzzerUtils.init(iArr, -9);
        FuzzerUtils.init(fArrFld, 36.785f);
        FuzzerUtils.init(lArrFld, -4102120465L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        lMeth_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }

    public void vMeth1(long j, int i, float f) {
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, -2.1f);
        int i2 = (i >>> 1) % N;
        long j2 = (instanceCount + 3253) - (j - byFld);
        int[] iArr = iArrFld;
        int i3 = iArr[i2] + ((int) dFld);
        iArr[i2] = i3;
        fArr[i2] = (float) (j2 + i3);
        vMeth1_check_sum += j + i + Float.floatToIntBits(f) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x0039, code lost:
    
        if (r0 != 134) goto L40;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static void vMeth2(int r11, long r12, long r14) {
        /*
            Method dump skipped, instructions count: 208
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.Test.vMeth2(int, long, long):void");
    }

    public static long lMeth(byte b, long j) {
        int i = -5;
        vMeth2(-5, 3218347585420365933L, instanceCount);
        int i2 = -11;
        int i3 = -55434;
        float f = -2.297f;
        int i4 = 7;
        while (i4 < 363) {
            int i5 = ((i4 % 2) * 5) + 118;
            if (i5 == 122 || i5 == 124) {
                int i6 = 1;
                int i7 = i4;
                while (i6 < 5) {
                    f -= i7;
                    sFld = (short) (sFld >> ((short) i6));
                    int i8 = (i6 % 2) + 43;
                    if (i8 == 43) {
                        i += (int) instanceCount;
                    } else {
                        if (i8 == 44) {
                            i += ((i6 * i6) + i4) - i6;
                        }
                        i += i6;
                        i7 = i4;
                    }
                    j -= f;
                    i6++;
                }
                int i9 = i7;
                i3 = i6;
                i2 = i9;
            }
            i4++;
        }
        long floatToIntBits = b + j + i + i4 + i2 + i3 + 12 + Float.floatToIntBits(f);
        lMeth_check_sum += floatToIntBits;
        return floatToIntBits;
    }

    public void vMeth(boolean z, int i) {
        int[] iArr = iArrFld;
        int length = iArr.length;
        double d = 29.55081d;
        int i2 = -64795;
        int i3 = 232;
        float f = -1.623f;
        int i4 = 0;
        while (i4 < length) {
            int i5 = iArr[i4];
            short s = (short) (sFld - 1);
            sFld = s;
            long j = s;
            instanceCount = j;
            vMeth1(lMeth(byFld, j), i5, 20.211f);
            double d2 = dFld;
            double d3 = instanceCount;
            Double.isNaN(d3);
            dFld = d2 - d3;
            long[] jArr = lArrFld;
            int i6 = (i5 >>> 1) % N;
            jArr[i6] = jArr[i6] + 11;
            float f2 = f;
            int i7 = i3;
            int i8 = i2;
            int i9 = i5 + i5;
            d = 1.0d;
            while (d < 4.0d) {
                i8 = 1;
                while (i8 < 2) {
                    byte b = (byte) instanceCount;
                    byFld = b;
                    f2 += (i8 * i8) + 0;
                    iArrFld = iArrFld;
                    byFld = (byte) (b + ((byte) (((i8 * (-7727)) + i8) - r14)));
                    instanceCount = 0L;
                    i7 += i9;
                    i9 <<= i8;
                    i8++;
                }
                d += 1.0d;
            }
            i4++;
            i2 = i8;
            i3 = i7;
            f = f2;
        }
        vMeth_check_sum += ((((z ? 1 : 0) + i) + Double.doubleToLongBits(d)) - 7727) + i2 + i3 + Float.floatToIntBits(f);
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        byte[] bArr = new byte[N];
        FuzzerUtils.init(bArr, (byte) -99);
        long j = 1;
        long j2 = instanceCount + 1;
        instanceCount = j2;
        int i3 = (int) (-j2);
        int i4 = 22322;
        long j3 = -245;
        float f = -16.929f;
        int i5 = 22;
        int i6 = -4;
        while (true) {
            char c = 0;
            if (i5 < 365) {
                j3 = j;
                while (73 > j3) {
                    i3++;
                    f = i3;
                    float f2 = 1;
                    long j4 = instanceCount;
                    int i7 = (int) (i4 + (((f2 * f) + ((float) j3)) - ((float) j4)));
                    bArr[c] = (byte) (bArr[c] - ((byte) i6));
                    switch (((i7 >>> 1) % 6) + 65) {
                        case 65:
                            i = i3;
                            iArrFld = FuzzerUtils.int1array(N, -40);
                            instanceCount -= 4;
                            i3 = i;
                            i4 = i7;
                            break;
                        case 66:
                            i4 = i7 + 1;
                            break;
                        case 67:
                            long[] jArr = lArrFld;
                            lArrFld = jArr;
                            long j5 = i6;
                            instanceCount = j5;
                            int i8 = (int) (((j3 % 2) * 5) + 84);
                            if (i8 == 86) {
                                i3 = (int) j5;
                                i7 -= i5;
                                i6 = (int) (i6 + f2 + f);
                            } else {
                                if (i8 == 91) {
                                    int i9 = (int) j3;
                                    jArr[i9] = jArr[i9] + sFld;
                                }
                                i3 = i3;
                            }
                            bArr[2] = (byte) (bArr[2] + ((byte) instanceCount));
                            i4 = i7;
                            break;
                        case 68:
                            i2 = i3;
                            iFld = (int) (iFld + (((1 * j4) + j3) - j4));
                            i7 <<= i5;
                            instanceCount += ((1 * i6) + j3) - 1;
                            iFld = iFld;
                            byFld = (byte) (byFld / ((byte) 1));
                            long j6 = instanceCount;
                            instanceCount = j6 + 1 + j6;
                            i3 = i2;
                            i4 = i7;
                            break;
                        case 69:
                            i2 = i3;
                            instanceCount += ((1 * i6) + j3) - 1;
                            iFld = iFld;
                            byFld = (byte) (byFld / ((byte) 1));
                            long j62 = instanceCount;
                            instanceCount = j62 + 1 + j62;
                            i3 = i2;
                            i4 = i7;
                            break;
                        case 70:
                            i2 = i3;
                            iFld = iFld;
                            byFld = (byte) (byFld / ((byte) 1));
                            long j622 = instanceCount;
                            instanceCount = j622 + 1 + j622;
                            i3 = i2;
                            i4 = i7;
                            break;
                        default:
                            i = i3;
                            i3 = i;
                            i4 = i7;
                            break;
                    }
                    j3++;
                    j = 1;
                    c = 0;
                }
                i5++;
                j = j;
            } else {
                FuzzerUtils.out.println("i i1 i2 = " + i3 + "," + i5 + "," + i4);
                FuzzerUtils.out.println("l i3 i4 = " + j3 + "," + i6 + ",2");
                FuzzerUtils.out.println("f b2 byArr = " + Float.floatToIntBits(f) + ",0," + FuzzerUtils.checkSum(bArr));
                FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.byFld = " + instanceCount + "," + ((int) sFld) + "," + ((int) byFld));
                FuzzerUtils.out.println("Test.dFld Test.iFld Test.iArrFld = " + Double.doubleToLongBits(dFld) + "," + iFld + "," + FuzzerUtils.checkSum(iArrFld));
                FuzzerUtils.out.println("Test.fArrFld Test.lArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(lArrFld));
                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
                FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

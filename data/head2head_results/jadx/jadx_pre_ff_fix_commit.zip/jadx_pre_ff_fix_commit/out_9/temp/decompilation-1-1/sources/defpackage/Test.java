package defpackage;

import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_9/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public float[][] fArrFld = (float[][]) Array.newInstance((Class<?>) float.class, N, N);
    public static volatile long instanceCount = -7040061827462761291L;
    public static double dFld = -105.71119d;
    public static int iFld = -2;
    public static short sFld = 1561;
    public static int iFld1 = -189;
    public static long vMeth_check_sum = 0;
    public static long dMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;

    public static void vMeth1(float f, int i, int i2) {
        int i3;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -11);
        int i4 = i + 4022;
        instanceCount += i2 - 2;
        int i5 = 7;
        int i6 = 8;
        long j = 11;
        int i7 = 1;
        do {
            iArr[i7] = iArr[i7] - ((int) instanceCount);
            f += i7;
            iArr[i7] = 38;
            i4 >>= (int) instanceCount;
            i3 = 1;
            while (i3 < 6) {
                int i8 = (i3 % 2) + 26;
                if (i8 == 26 || i8 == 27) {
                    instanceCount <<= 33424;
                    i5 = 1;
                    while (i5 < 2) {
                        dFld = instanceCount;
                        i6 = (int) instanceCount;
                        i5++;
                    }
                } else {
                    j *= i4;
                }
                i3++;
            }
            i7++;
        } while (i7 < 263);
        vMeth1_check_sum += ((((((Float.floatToIntBits(f) + i4) + r12) + 4022) + i7) + i3) - 30) + i5 + i6 + j + FuzzerUtils.checkSum(iArr);
    }

    public static double dMeth(byte b) {
        double[] dArr;
        double[] dArr2 = new double[N];
        byte[] bArr = new byte[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(dArr2, 1.11744d);
        FuzzerUtils.init(bArr, (byte) 107);
        FuzzerUtils.init(jArr, 3L);
        instanceCount <<= 162;
        int i = -119;
        int i2 = 194;
        short s = 6873;
        byte b2 = b;
        int i3 = 0;
        for (int i4 = N; i3 < i4; i4 = N) {
            double d = dArr2[i3];
            i = 1;
            while (true) {
                vMeth1(61.226f, i, i);
                i2 = (int) instanceCount;
                switch ((i % 6) + 9) {
                    case 9:
                        dArr = dArr2;
                        s = (short) (s - ((short) 2.945f));
                        instanceCount += i - instanceCount;
                        iFld = 2;
                        b2 = (byte) 2;
                        i2 += 2;
                        int i5 = (int) (iFld + (((i * instanceCount) + instanceCount) - instanceCount));
                        iFld = i5;
                        iFld = i5 / ((int) (((long) d) | 1));
                        instanceCount = b2;
                        break;
                    case 10:
                        dArr = dArr2;
                        iFld = 2;
                        b2 = (byte) 2;
                        i2 += 2;
                        int i52 = (int) (iFld + (((i * instanceCount) + instanceCount) - instanceCount));
                        iFld = i52;
                        iFld = i52 / ((int) (((long) d) | 1));
                        instanceCount = b2;
                        break;
                    case 11:
                        dArr = dArr2;
                        int i522 = (int) (iFld + (((i * instanceCount) + instanceCount) - instanceCount));
                        iFld = i522;
                        iFld = i522 / ((int) (((long) d) | 1));
                        instanceCount = b2;
                        break;
                    case 12:
                        dArr = dArr2;
                        bArr[i + 1] = 99;
                        break;
                    case 13:
                        dArr = dArr2;
                        iFld -= i2;
                        break;
                    case 14:
                        dArr = dArr2;
                        jArr[i] = i2 ^ jArr[i];
                        break;
                    default:
                        dArr = dArr2;
                        break;
                }
                i++;
                if (i >= 4) {
                    break;
                }
                dArr2 = dArr;
            }
            i3++;
            dArr2 = dArr;
        }
        long floatToIntBits = b2 + i + i2 + 0 + s + Float.floatToIntBits(2.945f) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr2)) + FuzzerUtils.checkSum(bArr) + FuzzerUtils.checkSum(jArr);
        dMeth_check_sum += floatToIntBits;
        return floatToIntBits;
    }

    public static void vMeth() {
        byte b;
        int i;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 211);
        float f = -94.513f;
        int i2 = 2;
        while (true) {
            b = 96;
            if (i2 >= 355) {
                break;
            }
            double dMeth = dMeth((byte) 96);
            int i3 = iFld;
            double d = i3;
            Double.isNaN(d);
            double d2 = i3;
            Double.isNaN(d2);
            f -= (float) ((dMeth - d) + d2);
            i2 += 3;
        }
        float f2 = f % (iFld | 1);
        int i4 = 10;
        int i5 = -144;
        int i6 = -10;
        int i7 = 0;
        float f3 = -1.144f;
        while (i4 < 194) {
            f3 = 1.0f;
            do {
                try {
                    i6 = (iArr[i4] % i4) % i5;
                    i = 2116236183 % iFld;
                } catch (ArithmeticException e) {
                    i = i6;
                }
                int i8 = iFld;
                int i9 = (((i8 >>> 1) % 7) * 5) + 91;
                if (i9 == 92) {
                    iFld = i8 - i8;
                } else {
                    if (i9 != 99) {
                        if (i9 == 103) {
                            i6 = i + i;
                        } else if (i9 != 105) {
                            if (i9 == 119) {
                                b = (byte) (b - ((byte) f2));
                                i6 = i;
                            } else if (i9 == 122) {
                                int i10 = (int) f3;
                                iArr[i10] = iArr[i10] - ((int) f2);
                                instanceCount = ((float) instanceCount) + ((f3 * f3) - 35149.0f);
                                i6 = i;
                                i7 = 2;
                            } else if (i9 == 124) {
                                i5 *= i7;
                                i6 = i;
                            }
                        }
                        f3 += 1.0f;
                    } else {
                        b = (byte) (b >>> (-74));
                    }
                    if (i == 0) {
                        i6 = i;
                        f3 += 1.0f;
                    } else {
                        vMeth_check_sum += i2 + i5 + Float.floatToIntBits(f2) + b + i4 + i + Float.floatToIntBits(f3) + i7 + FuzzerUtils.checkSum(iArr);
                        return;
                    }
                }
                i6 = i;
                f3 += 1.0f;
            } while (f3 < 9.0f);
            i4++;
        }
        vMeth_check_sum += i2 + i5 + Float.floatToIntBits(f2) + b + i4 + i6 + Float.floatToIntBits(f3) + i7 + FuzzerUtils.checkSum(iArr);
    }

    /* JADX WARN: Can't wrap try/catch for region: R(9:27|(3:29|(3:35|36|(3:41|42|(5:56|57|(1:59)(1:62)|60|61)(2:44|45))(3:38|39|40))(3:31|32|33)|34)(5:63|64|(5:67|(2:70|68)|71|72|65)|73|74)|46|47|48|50|51|52|34) */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x0119, code lost:
    
        r0 = r9;
        r9 = 43;
        r10 = 1;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void mainTest(java.lang.String[] r21) {
        /*
            Method dump skipped, instructions count: 631
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.Test.mainTest(java.lang.String[]):void");
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

package defpackage;

import java.io.PrintStream;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_48/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static double[] dArrFld;
    public static long fMeth_check_sum;
    public static int[] iArrFld;
    public static long iMeth_check_sum;
    public static long[] lArrFld;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public volatile double dFld = 68.47631d;
    public static long instanceCount = 3252565105746521324L;
    public static volatile byte byFld = 68;
    public static short sFld = 8656;

    static {
        double[] dArr = new double[N];
        dArrFld = dArr;
        iArrFld = new int[N];
        lArrFld = new long[N];
        FuzzerUtils.init(dArr, 113.2054d);
        FuzzerUtils.init(iArrFld, 59574);
        FuzzerUtils.init(lArrFld, 8258553528917043290L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
        fMeth_check_sum = 0L;
    }

    public static void vMeth1() {
        int i;
        int i2;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -22);
        int i3 = 17;
        int i4 = -19613;
        double d = 90.53936d;
        int i5 = 1;
        int i6 = 1;
        do {
            i = 1;
            while (i < 5) {
                i6 ^= 1;
                if (i6 != 0) {
                    int i7 = i3 + (i * i) + 5;
                    i2 = i7 >>> i7;
                } else {
                    int i8 = i3 + 1;
                    iArr[i] = iArr[i] - i8;
                    i2 = i8 + (i * i8);
                }
                int max = Math.max(i2 + 1, iArr[i - 1]) - 1;
                long j = instanceCount;
                instanceCount = j + (((i * i) + j) - j);
                double[] dArr = dArrFld;
                double d2 = dArr[i5] + 1.0d;
                dArr[i5] = d2;
                byte b = (byte) (byFld + 1);
                byFld = b;
                double d3 = b;
                Double.isNaN(d3);
                double d4 = d2 + d3;
                double d5 = i;
                Double.isNaN(d5);
                double d6 = max;
                Double.isNaN(d6);
                i3 = (int) (d4 - ((d - d5) - d6));
                i4 = 1;
                while (5 > i4) {
                    d -= 1.0d;
                    byFld = (byte) d;
                    long j2 = instanceCount;
                    instanceCount = 1 + j2;
                    instanceCount = j2 - j2;
                    i4++;
                }
                i += 3;
            }
            i5++;
        } while (i5 < 311);
        vMeth1_check_sum += i5 + i + i3 + i6 + Double.doubleToLongBits(d) + i4 + 225 + FuzzerUtils.checkSum(iArr);
    }

    public static float fMeth(byte b, double d, float f) {
        int i;
        double d2 = d;
        float f2 = f;
        int i2 = 254;
        int i3 = -35337;
        int i4 = 158;
        int i5 = 2;
        do {
            i = 1;
            while (i < 19) {
                int[] iArr = iArrFld;
                iArr[i] = iArr[i] >> (-129);
                int i6 = 1;
                while (i6 < 2) {
                    double d3 = f2;
                    Double.isNaN(d3);
                    d2 += d3;
                    long j = instanceCount + (i6 * i6);
                    instanceCount = j;
                    instanceCount = j << ((int) j);
                    f2 = f2 + (((i6 * (-10171)) + i3) - f2) + ((float) ((-3725063011L) | i6));
                    i6++;
                }
                int i7 = (-10171) + i;
                i3 *= i7;
                i++;
                int i8 = i6;
                i5 = i7;
                i2 = i8;
            }
            i4 -= 2;
        } while (i4 > 0);
        long doubleToLongBits = b + Double.doubleToLongBits(d2) + Float.floatToIntBits(f2) + i4 + i + i5 + i2 + i3;
        fMeth_check_sum += doubleToLongBits;
        return (float) doubleToLongBits;
    }

    public static int iMeth(float f) {
        int i = -27629;
        int i2 = 3;
        while (i2 < 218) {
            double d = dArrFld[i2];
            long fMeth = i2 % (fMeth(byFld, 2.5384d, f) | 1);
            i = -772834576;
            i2++;
        }
        long floatToIntBits = Float.floatToIntBits(f) + i2 + (i * ((int) f)) + Double.doubleToLongBits(2.5384d);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth(double d) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 5);
        int i = -57098;
        float f = -53.246f;
        int i2 = 8;
        while (i2 < 137) {
            long j = instanceCount;
            instanceCount = j - 1;
            int reverseBytes = (int) (Long.reverseBytes(j) + ((-42471) - (i2 + i2)));
            float f2 = f + (i2 * i2);
            i = (int) ((-f2) * (reverseBytes - (-reverseBytes)));
            vMeth1();
            i2++;
            f = 1.0f + f2;
        }
        int i3 = 4;
        int i4 = 0;
        int i5 = -3;
        int i6 = -100;
        while (i3 < 184) {
            int i7 = iArr[i3] - 1;
            iArr[i3] = i7;
            i4 -= i7;
            i5 = 1;
            while (true) {
                i5++;
                if (i5 < 9) {
                    int i8 = iArr[1];
                    iArr[1] = i8 - 1;
                    instanceCount = i8;
                    iMeth(f);
                    vMeth1();
                    i = (i - 1) + 1;
                    i4 -= (int) (((i2 + f) - 575904004) - (i - (i4 + 1)));
                    f++;
                    i6 = 2;
                }
            }
            i3++;
        }
        vMeth_check_sum += ((((((((Double.doubleToLongBits(d) + i2) + i) + Float.floatToIntBits(f)) + i3) + i4) + i5) + i6) - 23998) + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int i = N;
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(zArr, true);
        vMeth(this.dFld);
        int i2 = 234;
        int i3 = 187;
        int i4 = 59;
        int i5 = 59168;
        int i6 = -5;
        int i7 = -4;
        int i8 = 39;
        int i9 = 269;
        int i10 = 11;
        while (i9 > 5) {
            iArrFld = FuzzerUtils.int1array(i, 48480);
            i3 = 5;
            while (95 > i3) {
                if ((i9 % 1) + 63 == 63) {
                    sFld = (short) i2;
                } else {
                    switch ((i9 % 6) + 44) {
                        case 44:
                            i2 += (i3 * i3) - 58850;
                            i4 = 1;
                            while (i4 < 2) {
                                i10 += ((i4 * i10) + i3) - i10;
                                instanceCount += i4;
                                zArr[i3] = false;
                                instanceCount = i9;
                                sFld = (short) i9;
                                this.dFld = i3;
                                i4++;
                            }
                            break;
                        case 45:
                        case 46:
                            switch ((i9 % 7) + 124) {
                                case 124:
                                    long j = instanceCount;
                                    lArrFld[i9 - 1] = j;
                                    int i11 = i10 | i3;
                                    instanceCount = j + 1;
                                    sFld = (short) (sFld + ((short) (((r13 * r16) + i5) - r16)));
                                    i7 = (i7 - i2) + i3;
                                    i10 = (i11 & i9) + (i3 * i3);
                                    i5 = i9;
                                    i6 = 2;
                                    break;
                                case 125:
                                    instanceCount += (long) this.dFld;
                                    break;
                                case 126:
                                    i2 = i4;
                                    break;
                                case 127:
                                    i8 -= i9;
                                    break;
                                case 128:
                                    instanceCount += i3;
                                    break;
                                case 129:
                                case 130:
                                    i7 += i7;
                                    break;
                                default:
                                    i10 *= (int) instanceCount;
                                    break;
                            }
                        case 47:
                            i8 += (i3 * i3) + 11;
                            break;
                        case 48:
                            instanceCount = instanceCount;
                            break;
                        case 49:
                            i5 += (int) ((i3 * i3) + 10);
                            break;
                    }
                }
                i3++;
            }
            i9--;
            i = N;
        }
        FuzzerUtils.out.println("i18 i19 i20 = " + i9 + "," + i2 + "," + i3);
        FuzzerUtils.out.println("i21 i22 i23 = " + i10 + "," + i4 + "," + i5);
        FuzzerUtils.out.println("b2 i24 i25 = 0," + i6 + "," + i7);
        FuzzerUtils.out.println("i26 bArr = " + i8 + "," + FuzzerUtils.checkSum(zArr));
        PrintStream printStream = FuzzerUtils.out;
        long j2 = instanceCount;
        byte b = byFld;
        printStream.println("Test.instanceCount Test.byFld dFld = " + j2 + "," + ((int) b) + "," + Double.doubleToLongBits(this.dFld));
        PrintStream printStream2 = FuzzerUtils.out;
        short s = sFld;
        printStream2.println("Test.sFld Test.dArrFld Test.iArrFld = " + ((int) s) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + FuzzerUtils.checkSum(iArrFld));
        PrintStream printStream3 = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(lArrFld);
        StringBuilder sb = new StringBuilder();
        sb.append("Test.lArrFld = ");
        sb.append(checkSum);
        printStream3.println(sb.toString());
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

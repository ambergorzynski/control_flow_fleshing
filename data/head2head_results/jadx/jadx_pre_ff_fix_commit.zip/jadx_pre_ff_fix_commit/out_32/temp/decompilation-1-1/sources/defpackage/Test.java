package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_32/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vSmallMeth_check_sum;
    public static long instanceCount = 12;
    public static float fFld = 59.163f;
    public static int iFld = -3333;
    public static int iFld1 = 144;
    public static final int N = 400;
    public static float[] fArrFld = new float[N];
    public static volatile double[] dArrFld = new double[N];

    static {
        FuzzerUtils.init(fArrFld, 5.732f);
        FuzzerUtils.init(dArrFld, 109.56779d);
        vSmallMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
    }

    public static int iMeth(int i) {
        int[] iArr = new int[N];
        long[][][] jArr = (long[][][]) Array.newInstance((Class<?>) long.class, N, N, N);
        FuzzerUtils.init((Object[][]) jArr, (Object) 91L);
        FuzzerUtils.init(iArr, -2);
        int i2 = -49804;
        int i3 = -21783;
        int i4 = 7;
        while (123 > i4) {
            i2 = (int) fFld;
            i3 = 13;
            do {
                i2 -= 225;
                i -= 991961511;
                long j = i3;
                instanceCount = j;
                switch ((i4 % 8) + 27) {
                    case 27:
                    case 28:
                        i += i3 * i3;
                        int i5 = i3 + 1;
                        jArr[i3 - 1][i5][i5] = j;
                        break;
                    case 29:
                        i2 *= 3;
                        i += ((i3 * i3) + i2) - i2;
                        break;
                    case 30:
                        iArr[i3] = iArr[i3] + 208;
                        float[] fArr = fArrFld;
                        fArr[i3] = fArr[i3] + ((float) 56.59635d);
                        break;
                    case 31:
                    case 32:
                    case 33:
                        instanceCount >>= -14748;
                        break;
                    case 34:
                        fFld -= (float) j;
                        break;
                    default:
                        iArr[i3 - 1] = -14701;
                        break;
                }
                i3--;
            } while (i3 > 0);
            i4++;
        }
        long doubleToLongBits = ((((((i + i4) + i2) + i3) + Double.doubleToLongBits(56.59635d)) - 14748) - 14701) + FuzzerUtils.checkSum((Object[][]) jArr) + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static void vMeth(int i) {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -2634646219810193193L);
        FuzzerUtils.init(iArr, -23390);
        int i2 = -8;
        short s = 32524;
        int i3 = 376;
        while (13 < i3) {
            float f = fFld;
            int i4 = (((((int) (i3 * f)) >>> 1) % 5) * 5) + 34;
            if (i4 != 56) {
                if (i4 == 59) {
                    long j = jArr[i3];
                    double d = i;
                    Double.isNaN(d);
                    long j2 = (long) (d - (-74.109155d));
                    instanceCount = j2;
                    jArr[i3] = j << ((int) (j2 - ((((-129) - i2) * 151) + i3)));
                    float[] fArr = fArrFld;
                    int i5 = i3 - 1;
                    float f2 = fArr[i5];
                    fArr[i5] = 1.0f + f2;
                    i = (int) ((f2 - ((float) (j2 - 13))) + iMeth(i2));
                    fFld = 58.0f;
                    instanceCount = i2;
                } else {
                    switch (i4) {
                        case 50:
                            break;
                        case 51:
                            i = s - ((int) instanceCount);
                            break;
                        case 52:
                            int i6 = ((i3 % 2) * 5) + 59;
                            if (i6 == 63) {
                                fFld = f - ((float) instanceCount);
                                break;
                            } else if (i6 == 67) {
                                long j3 = instanceCount;
                                long j4 = j3 - j3;
                                instanceCount = j4;
                                s = (short) j4;
                                break;
                            } else {
                                break;
                            }
                        default:
                            fFld = f;
                            break;
                    }
                }
                instanceCount = -22813L;
                i -= i2;
            } else {
                i2 += (int) instanceCount;
            }
            i3--;
        }
        vMeth_check_sum += i + i3 + i2 + s + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr);
    }

    public static void vSmallMeth(long j, float f) {
        vMeth(-64926);
        int i = iFld;
        iFld = i * i;
        vSmallMeth_check_sum += j + Float.floatToIntBits(f);
    }

    public void mainTest(String[] strArr) {
        long[] jArr;
        long[] jArr2;
        int i;
        double d;
        int i2;
        int i3;
        double d2;
        int i4;
        double d3;
        int i5;
        int[] iArr = new int[N];
        long[] jArr3 = new long[N];
        FuzzerUtils.init(iArr, 7);
        FuzzerUtils.init(jArr3, -2456531478691009509L);
        for (int i6 = 0; i6 < 401; i6++) {
            vSmallMeth(instanceCount, fFld);
        }
        long j = 3307735646808791403L;
        double d4 = 0.45279d;
        int i7 = 0;
        int i8 = 0;
        int i9 = -52858;
        int i10 = -57651;
        int i11 = 36401;
        int i12 = 62932;
        short s = -29675;
        int i13 = 0;
        for (int i14 = N; i13 < i14; i14 = N) {
            int i15 = iArr[i13];
            int i16 = i8;
            long j2 = iFld;
            int i17 = i15 >>> 1;
            try {
                iFld = iArr[i17 % N] / iArr[i17 % N];
                iArr[(iFld1 >>> 1) % N] = i15 / 762361316;
                iFld1 = (-154) / iArr[i17 % N];
            } catch (ArithmeticException e) {
            }
            int i18 = (i17 % 2) + 106;
            if (i18 == 106) {
                jArr = jArr3;
                i7 = i15;
                i9 = i7;
            } else if (i18 != 107) {
                jArr = jArr3;
                i7 = i15;
            } else {
                int i19 = i15;
                int i20 = 1;
                while (i20 < 63) {
                    int i21 = i9;
                    int i22 = i16;
                    i12 = 1;
                    long j3 = j2;
                    int i23 = i19;
                    while (i12 < 2) {
                        double[] dArr = dArrFld;
                        double d5 = dArr[i20];
                        int i24 = i20;
                        double d6 = s;
                        Double.isNaN(d6);
                        dArr[i24] = d5 + d6;
                        int i25 = (((i12 >>> 1) % 2) * 5) + 52;
                        if (i25 != 54) {
                            if (i25 != 57) {
                                jArr2 = jArr3;
                                i5 = i23;
                                d3 = d4;
                            } else {
                                float f = fFld;
                                d3 = d4;
                                jArr2 = jArr3;
                                i5 = i23;
                                fFld = f + (((float) ((i12 * j3) + i22)) - f);
                            }
                            i23 = i5;
                            d4 = d3;
                            i = i24;
                        } else {
                            jArr2 = jArr3;
                            int i26 = i23;
                            double d7 = d4;
                            try {
                                iFld1 = i21 / (-142);
                                i21 = 128 / i11;
                                i11 = iArr[i12 + 1] / 1995789820;
                            } catch (ArithmeticException e2) {
                            }
                            s = (short) (s << 95);
                            float f2 = fFld;
                            long j4 = f2;
                            instanceCount = j4;
                            switch ((i12 % 8) + 29) {
                                case 29:
                                    i = i24;
                                    i23 = i26;
                                    d4 = d7;
                                    break;
                                case 30:
                                    int i27 = iFld1;
                                    switch (((i27 >>> 1) % 7) + 113) {
                                        case 113:
                                            int i28 = i26 - s;
                                            switch ((i24 % 9) + 42) {
                                                case 42:
                                                    d = d7;
                                                    iArr[i24 - 1] = (int) j4;
                                                    iFld1 = i28;
                                                    int i29 = ((i12 % 7) * 5) + 98;
                                                    if (i29 != 100) {
                                                        if (i29 != 117) {
                                                            if (i29 != 119) {
                                                                if (i29 != 121) {
                                                                    if (i29 != 125) {
                                                                        if (i29 == 128) {
                                                                            d4 = d;
                                                                            i = i24;
                                                                            break;
                                                                        } else {
                                                                            if (i29 == 129) {
                                                                                i11 += i12 | i22;
                                                                            }
                                                                            j3 *= iFld;
                                                                            d4 = d;
                                                                            i = i24;
                                                                            break;
                                                                        }
                                                                    } else {
                                                                        d4 = i15;
                                                                        i = i24;
                                                                        break;
                                                                    }
                                                                } else {
                                                                    iFld1 = i28 & ((int) j3);
                                                                }
                                                            }
                                                            double d8 = j3;
                                                            Double.isNaN(d8);
                                                            d4 = d * d8;
                                                            i = i24;
                                                            break;
                                                        } else {
                                                            jArr2[i12 - 1] = i11;
                                                            i2 = i21;
                                                            i3 = i11;
                                                            i = i24;
                                                            i21 = i2;
                                                            i11 = i3;
                                                            d4 = d;
                                                            break;
                                                        }
                                                    } else {
                                                        i = i24;
                                                        j3 -= i;
                                                        i22 |= (int) j4;
                                                        i21 = i21;
                                                        i11 = i11;
                                                        d4 = d;
                                                        break;
                                                    }
                                                case 43:
                                                    iFld += i12;
                                                    d = d7;
                                                    i2 = i21;
                                                    i3 = i11;
                                                    i = i24;
                                                    i21 = i2;
                                                    i11 = i3;
                                                    d4 = d;
                                                    break;
                                                case 44:
                                                case 45:
                                                    i22 -= (int) d7;
                                                    d4 = d7;
                                                    i = i24;
                                                    break;
                                                case 46:
                                                    i21 += i27;
                                                    i = i24;
                                                    d4 = d7;
                                                    break;
                                                case 47:
                                                case 48:
                                                    i15 -= 63922;
                                                case 49:
                                                    i21 *= -3;
                                                    i = i24;
                                                    d4 = d7;
                                                    break;
                                                case 50:
                                                    fFld = f2 - f2;
                                                    i2 = i21;
                                                    i3 = i11;
                                                    i = i24;
                                                    d = d7;
                                                    i21 = i2;
                                                    i11 = i3;
                                                    d4 = d;
                                                    break;
                                                default:
                                                    i2 = i21;
                                                    i3 = i11;
                                                    i = i24;
                                                    d = d7;
                                                    i21 = i2;
                                                    i11 = i3;
                                                    d4 = d;
                                                    break;
                                            }
                                            i23 = i28;
                                            break;
                                        case 114:
                                            d2 = d7;
                                            instanceCount = j4 >> 9;
                                            d4 = d2;
                                            i23 = i26;
                                            i = i24;
                                            break;
                                        case 115:
                                            iFld1 = i27 + i12;
                                            d2 = d7;
                                            d4 = d2;
                                            i23 = i26;
                                            i = i24;
                                            break;
                                        case 116:
                                            i21 ^= i27;
                                        case 117:
                                            d4 = d7;
                                            iFld = (int) d4;
                                            i23 = i26;
                                            i = i24;
                                            break;
                                        case 118:
                                            instanceCount = j4 + (((i12 * i26) + i22) - j4);
                                            d2 = d7;
                                            d4 = d2;
                                            i23 = i26;
                                            i = i24;
                                            break;
                                        case 119:
                                            double[] dArr2 = dArrFld;
                                            int i30 = i24 + 1;
                                            dArr2[i30] = dArr2[i30] * 97.7101d;
                                            d2 = d7;
                                            d4 = d2;
                                            i23 = i26;
                                            i = i24;
                                            break;
                                        default:
                                            i = i24;
                                            i23 = i26;
                                            d4 = d7;
                                            break;
                                    }
                                    try {
                                        i22 = 59435 / iFld1;
                                        i21 = iArr[i12] % (-24191);
                                        iArr[i12 + 1] = iFld1 / iArr[i12];
                                        break;
                                    } catch (ArithmeticException e3) {
                                        break;
                                    }
                                case 31:
                                    d2 = d7;
                                    d4 = d2;
                                    i23 = i26;
                                    i = i24;
                                    i22 = 59435 / iFld1;
                                    i21 = iArr[i12] % (-24191);
                                    iArr[i12 + 1] = iFld1 / iArr[i12];
                                    break;
                                case 32:
                                    fFld = (float) j4;
                                    i23 = i26;
                                    d4 = d7;
                                    i = i24;
                                    break;
                                case 33:
                                    j3 += (i12 * i12) - 13;
                                    i23 = i26;
                                    d4 = d7;
                                    i = i24;
                                    break;
                                case 34:
                                    float f3 = i12;
                                    i22 = (int) (i22 + (((f2 * f3) + 11) - f3));
                                    i23 = i26;
                                    d4 = d7;
                                    i = i24;
                                    break;
                                case 35:
                                    i15 = (int) (i15 + (((iFld * i12) + i22) - f2));
                                    i23 = i26;
                                    d4 = d7;
                                    i = i24;
                                    break;
                                case 36:
                                    i4 = i11;
                                    i = i24;
                                    i21 = 0;
                                    i21 <<= -5;
                                    i11 = i4;
                                    i23 = i26;
                                    d4 = d7;
                                    break;
                                default:
                                    i4 = i11;
                                    i = i24;
                                    i21 <<= -5;
                                    i11 = i4;
                                    i23 = i26;
                                    d4 = d7;
                                    break;
                            }
                        }
                        i12++;
                        int i31 = i;
                        jArr3 = jArr2;
                        i20 = i31;
                    }
                    int i32 = i23;
                    jArr3 = jArr3;
                    j2 = j3;
                    i9 = i21;
                    i20++;
                    i19 = i32;
                    i16 = i22;
                }
                long[] jArr4 = jArr3;
                int i33 = i20;
                jArr = jArr4;
                i10 = i33;
                i7 = i15;
            }
            j = j2;
            i8 = i16;
            i13++;
            jArr3 = jArr;
        }
        long[] jArr5 = jArr3;
        FuzzerUtils.out.println("i l1 i11 = " + i7 + "," + j + "," + i9);
        FuzzerUtils.out.println("i12 i13 i14 = " + i10 + "," + i11 + "," + i12);
        FuzzerUtils.out.println("i15 s2 b = " + i8 + "," + ((int) s) + ",0");
        FuzzerUtils.out.println("d2 i16 iArr2 = " + Double.doubleToLongBits(d4) + ",11," + FuzzerUtils.checkSum(iArr));
        PrintStream printStream = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(jArr5);
        StringBuilder sb = new StringBuilder();
        sb.append("lArr2 = ");
        sb.append(checkSum);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.iFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + iFld);
        FuzzerUtils.out.println("Test.iFld1 Test.fArrFld Test.dArrFld = " + iFld1 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        PrintStream printStream2 = FuzzerUtils.out;
        long j5 = iMeth_check_sum;
        StringBuilder sb2 = new StringBuilder();
        sb2.append("iMeth_check_sum: ");
        sb2.append(j5);
        printStream2.println(sb2.toString());
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

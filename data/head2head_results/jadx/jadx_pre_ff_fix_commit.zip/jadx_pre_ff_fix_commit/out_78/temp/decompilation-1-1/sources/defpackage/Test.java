package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_78/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static long iMeth_check_sum;
    public static short[][] sArrFld;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public volatile int iFld = -35510;
    public static long instanceCount = 13;
    public static double dFld = -51.79858d;

    static {
        short[][] sArr = (short[][]) Array.newInstance((Class<?>) short.class, N, N);
        sArrFld = sArr;
        FuzzerUtils.init(sArr, (short) -16302);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
    }

    public static int iMeth(boolean z) {
        int[] iArr = new int[N];
        double[] dArr = new double[N];
        FuzzerUtils.init(iArr, 158);
        FuzzerUtils.init(dArr, -30.1411d);
        instanceCount = instanceCount;
        int i = -37574;
        int i2 = 0;
        short s = -30958;
        int i3 = 16;
        int i4 = 1;
        while (i3 < 281) {
            i = 6;
            while (i > 1) {
                i2 = 1;
                do {
                    i2++;
                } while (i2 < 3);
                iArr[311] = (int) instanceCount;
                i -= 2;
            }
            dArr[i3 - 1] = 109;
            s = (short) (s + 19863);
            iArr[i3] = i3;
            float f = i2;
            i4 = ((int) (f + (((i3 * 0.888f) + f) - f))) | i;
            i3++;
        }
        long doubleToLongBits = (z ? 1 : 0) + i3 + 109 + i + i4 + i2 + s + Double.doubleToLongBits(89.98137d) + Float.floatToIntBits(0.888f) + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static void vMeth1(int i) {
        int[] iArr = new int[N];
        byte[] bArr = new byte[N];
        FuzzerUtils.init(iArr, -12);
        FuzzerUtils.init(bArr, (byte) 73);
        int i2 = 9;
        int i3 = -13;
        int i4 = -197;
        int i5 = 5;
        while (true) {
            int i6 = 1;
            if (i5 < 226) {
                int iMeth = iMeth(true);
                long j = instanceCount;
                i = iMeth - ((int) j);
                switch ((i5 % 4) + 76) {
                    case 76:
                        i = 4;
                        iArr[i5 - 1] = i5;
                        i -= (int) 0.561f;
                        break;
                    case 77:
                        iArr[i5 - 1] = i5;
                        i -= (int) 0.561f;
                        break;
                    case 78:
                        while (7 > i6) {
                            long j2 = instanceCount - i2;
                            instanceCount = j2;
                            long j3 = i6;
                            i4 = (int) (i4 + (((j3 * j2) + j3) - j2));
                            dFld = i;
                            i6 += 2;
                            i2 = i4;
                        }
                        short[] sArr = sArrFld[i5 - 1];
                        sArr[i5] = (short) (sArr[i5] << ((short) i2));
                        i3 = i6;
                        break;
                    case 79:
                        instanceCount = j;
                        int i7 = i5 - 1;
                        bArr[i7] = (byte) (bArr[i7] * ((byte) i4));
                        break;
                }
                i5++;
            } else {
                vMeth1_check_sum += i + i5 + i2 + 1 + Float.floatToIntBits(0.561f) + i3 + i4 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(bArr);
                return;
            }
        }
    }

    public void vMeth(int i, int i2, int i3) {
        int[] iArr = new int[N];
        double[] dArr = new double[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(dArr, 1.74753d);
        FuzzerUtils.init(iArr, 5);
        FuzzerUtils.init(jArr, 104L);
        vMeth1(i3);
        float f = i * 117.72f;
        int i4 = 63009;
        byte b = 101;
        int i5 = 9;
        int i6 = i2;
        while (i5 < 309) {
            f -= -4;
            this.iFld *= i5;
            int i7 = 1;
            while (i7 < 6) {
                double d = dArr[i5];
                double d2 = -4;
                Double.isNaN(d2);
                dArr[i5] = d + d2;
                int i8 = i7 + 1;
                iArr[i8] = -4;
                long j = instanceCount;
                b = (byte) (b + ((byte) j));
                instanceCount = j + (((r5 * j) - 4) - b);
                f -= 12.0f;
                i7 = i8;
            }
            instanceCount /= i5 | 1;
            i5++;
            i4 = i7;
            i6 = -20;
        }
        vMeth_check_sum += (((((((((i + i6) + 4968) + Float.floatToIntBits(f)) + i5) - 4) + i4) - 3) + b) - 20) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr);
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2 = N;
        long[] jArr = new long[N];
        int[] iArr = new int[N];
        FuzzerUtils.init(jArr, 1878158773807813253L);
        FuzzerUtils.init(iArr, -4);
        byte b = (byte) jArr[(this.iFld >>> 1) % N];
        vMeth(-7169, this.iFld, this.iFld);
        int i3 = -10;
        int i4 = -3;
        int i5 = -11;
        int i6 = 3;
        int i7 = 107;
        int i8 = 110;
        int i9 = -26101;
        long j = 3;
        while (337 > j) {
            instanceCount -= 9;
            int i10 = 2;
            int i11 = i7;
            int i12 = i6;
            int i13 = i5;
            float f = (-1.868f) - this.iFld;
            i4 = 2;
            while (true) {
                i = 75;
                if (i4 >= 75) {
                    break;
                }
                int i14 = (i4 * i4) + i3;
                i12 = 1;
                while (i12 < i10) {
                    try {
                        this.iFld = (-133) % i4;
                        int i15 = (-510238578) / iArr[i12 - 1];
                        int i16 = (-179) % this.iFld;
                    } catch (ArithmeticException e) {
                    }
                    int i17 = b - b;
                    i11 = i17 ^ i17;
                    i12++;
                    i13 = i14;
                }
                int i18 = (i4 >>> 1) % i2;
                iArr[i18] = iArr[i18] - ((int) j);
                long j2 = instanceCount;
                instanceCount = j2 >>> ((int) j2);
                this.iFld -= (int) f;
                f = (float) dFld;
                i4++;
                i9 = i9;
                i3 = i14;
                i2 = N;
                i10 = 2;
            }
            while (true) {
                i--;
                if (i > 0) {
                    this.iFld = i11;
                    this.iFld *= i3;
                    i9 = 1;
                    i11 = -11003;
                }
            }
            j++;
            i8 = i;
            i5 = i13;
            i6 = i12;
            i7 = i11 >>> (-39458);
            i2 = N;
        }
        FuzzerUtils.out.println("by l1 i19 = " + ((int) b) + "," + j + "," + i3);
        FuzzerUtils.out.println("i20 i21 i22 = " + i4 + "," + i5 + "," + i6);
        FuzzerUtils.out.println("i23 b2 i24 = " + i7 + ",0," + i8);
        PrintStream printStream = FuzzerUtils.out;
        printStream.println("i25 i26 s1 = " + i9 + ",46322,-11003");
        FuzzerUtils.out.println("lArr iArr3 = " + FuzzerUtils.checkSum(jArr) + "," + FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.dFld = " + instanceCount + "," + this.iFld + "," + Double.doubleToLongBits(dFld));
        PrintStream printStream2 = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(sArrFld);
        StringBuilder sb = new StringBuilder();
        sb.append("Test.sArrFld = ");
        sb.append(checkSum);
        printStream2.println(sb.toString());
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

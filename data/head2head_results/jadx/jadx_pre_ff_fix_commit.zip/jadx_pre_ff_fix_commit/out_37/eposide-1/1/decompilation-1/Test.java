
import java.io.PrintStream;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_37/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public static long lMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = 59861;
    public static double dFld = 33.95048d;
    public static short sFld = -3797;
    public static byte byFld = -109;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, -9);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        lMeth_check_sum = 0L;
    }

    public static long lMeth() {
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(zArr, false);
        int i = 39035;
        int i2 = -14;
        int i3 = 1;
        int i4 = 0;
        while (i3 < 193) {
            int i5 = i3 - ((int) dFld);
            instanceCount -= -97.186f;
            int i6 = 1;
            while (i6 < 8) {
                zArr[i3] = false;
                i4 = i6;
                i6++;
            }
            i3++;
            i2 = i6;
            i = i5;
        }
        long checkSum = i3 + i + 0 + i2 + i4 + 12067 + FuzzerUtils.checkSum(zArr);
        lMeth_check_sum += checkSum;
        return checkSum;
    }

    public static void vMeth1() {
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, -1.51777d);
        lMeth();
        int i = 208;
        int i2 = -47635;
        int i3 = -7;
        int i4 = 8;
        while (i4 < 299) {
            i = 6;
            while (i > 1) {
                switch ((i % 6) + 7) {
                    case 7:
                        iArrFld = iArrFld;
                        i2 -= i;
                        i3 = 2;
                    case 8:
                        dFld -= 13.0d;
                        break;
                    case 9:
                        instanceCount -= 43222;
                        break;
                    case 11:
                        dArr[i - 1] = i4;
                        break;
                    case 12:
                        instanceCount -= 73.329f;
                        break;
                }
                i--;
            }
            i4++;
        }
        vMeth1_check_sum += 43222 + i4 + 11982 + i + i2 + i3 + 10719 + Float.floatToIntBits(73.329f) + 1 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
    }

    public static void vMeth(float f, float f2) {
        byte[] bArr = new byte[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(bArr, (byte) 125);
        FuzzerUtils.init(jArr, 1408872462L);
        double d = 8.0d;
        int i = -65;
        int i2 = -12;
        while (d < 193.0d) {
            i2 = (int) d;
            byte b = bArr[i2];
            bArr[i2] = (byte) (b - 1);
            int[] iArr = iArrFld;
            int i3 = (int) (d - 1.0d);
            int i4 = iArr[i3] - 1;
            iArr[i3] = i4;
            i += b + i4;
            vMeth1();
            while (i2 < 9) {
                long j = instanceCount + (i2 * i2);
                instanceCount = j;
                int[] iArr2 = iArrFld;
                int i5 = iArr2[i3];
                double d2 = dFld;
                iArr2[i3] = i5 - ((int) d2);
                short s = (short) d2;
                sFld = s;
                jArr[i3] = jArr[i3] >> 0;
                int i6 = i - s;
                long j2 = j + j;
                instanceCount = j2;
                instanceCount = j2 & byFld;
                i = i6 + i6;
                i2++;
            }
            d += 1.0d;
        }
        vMeth_check_sum += Float.floatToIntBits(f) + Float.floatToIntBits(f2) + Double.doubleToLongBits(d) + i + i2 + 0 + 1 + FuzzerUtils.checkSum(bArr) + FuzzerUtils.checkSum(jArr);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public void mainTest(String[] strArr) {
        byte[] bArr = new byte[N];
        boolean[] zArr = new boolean[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(bArr, (byte) -55);
        int i = 1;
        FuzzerUtils.init(zArr, true);
        FuzzerUtils.init(jArr, -4683597909419822601L);
        int i2 = (int) ((31792 - instanceCount) + 38912);
        float f = 2.55f;
        vMeth(2.55f, 2.55f);
        int[] iArr = iArrFld;
        int i3 = (i2 >>> 1) % N;
        iArr[i3] = iArr[i3] << (-8);
        int i4 = 16101;
        int i5 = -38936;
        int i6 = 58;
        int i7 = 4;
        int i8 = -11302;
        short s = -20376;
        int i9 = 1;
        while (true) {
            i9 += i;
            if (i9 < 204) {
                i4 = 1;
                do {
                    i2 = -40471;
                    float f2 = f;
                    long j = instanceCount - 40471;
                    instanceCount = j;
                    int i10 = (i9 % 2) + 70;
                    if (i10 == 70) {
                        i2 = (-40471) + i4;
                        switch ((i9 % 9) + 100) {
                            case 100:
                                instanceCount = ((float) j) + (((i4 * f2) + i9) - f2);
                                i5 = i5 + (((i4 * i9) + i4) - i5) + i4;
                                f = f2;
                                break;
                            case 101:
                                i5 >>= i9;
                                instanceCount -= 8686;
                                f = f2;
                                break;
                            case 102:
                                instanceCount -= 8686;
                                f = f2;
                                break;
                            case 103:
                                f = f2;
                                i6 = 1;
                                break;
                            case 104:
                                bArr[i4] = (byte) j;
                                i5 = 148;
                                f = f2;
                                i8 = 1;
                                break;
                            case 105:
                                s = (short) (s + ((short) i4));
                                f = f2 + i5;
                                break;
                            case 106:
                                double d = dFld;
                                double d2 = i4;
                                Double.isNaN(d2);
                                dFld = d - d2;
                                int[] iArr2 = iArrFld;
                                int i11 = i4 + 1;
                                iArr2[i11] = iArr2[i11] - i8;
                                f = f2;
                                break;
                            case 107:
                                int[] iArr22 = iArrFld;
                                int i112 = i4 + 1;
                                iArr22[i112] = iArr22[i112] - i8;
                                f = f2;
                                break;
                            case 108:
                                i7 += ((i4 * 11) + i6) - i4;
                                f = f2;
                                break;
                            default:
                                f = f2;
                                break;
                        }
                    } else {
                        f = i10 != 71 ? f2 : f2 - ((float) j);
                    }
                    i4++;
                } while (i4 < 123);
                i = 1;
            } else {
                FuzzerUtils.out.println("i s f4 = " + i2 + "," + ((int) s) + "," + Float.floatToIntBits(f));
                FuzzerUtils.out.println("i14 i15 i16 = " + i9 + "," + i4 + "," + i5);
                FuzzerUtils.out.println("i17 i18 i19 = " + i6 + "," + i7 + "," + i8);
                FuzzerUtils.out.println("i20 byArr1 bArr1 = 11," + FuzzerUtils.checkSum(bArr) + "," + FuzzerUtils.checkSum(zArr));
                PrintStream printStream = FuzzerUtils.out;
                long checkSum = FuzzerUtils.checkSum(jArr);
                StringBuilder sb = new StringBuilder();
                sb.append("lArr1 = ");
                sb.append(checkSum);
                printStream.println(sb.toString());
                FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.sFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + ((int) sFld));
                PrintStream printStream2 = FuzzerUtils.out;
                byte b = byFld;
                printStream2.println("Test.byFld Test.iArrFld = " + ((int) b) + "," + FuzzerUtils.checkSum(iArrFld));
                FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

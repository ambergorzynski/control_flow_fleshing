package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_62/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public float fFld = 0.951f;
    public long[] lArrFld = new long[N];
    public static volatile long instanceCount = 1404654219;
    public static int iFld = 3126;
    public static boolean bFld = true;
    public static byte byFld = -22;
    public static short sFld = -26070;
    public static long bMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long lMeth_check_sum = 0;

    public static long lMeth() {
        int i;
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, 72.119607d);
        boolean z = bFld;
        bFld = z;
        int i2 = iFld;
        int i3 = i2 - i2;
        iFld = i3;
        int i4 = 46645;
        int i5 = 2073;
        float f = 50.447f;
        byte b = 112;
        if (z) {
            i = 1;
            while (true) {
                i++;
                if (i >= 255) {
                    break;
                }
                int i6 = iFld << (-54762);
                iFld = i6;
                iFld = i6 * ((int) 0.54981d);
                iFld = (int) instanceCount;
                i4 = 1;
                while (i4 < 6) {
                    f = -4834;
                    dArr[i + 1] = -175.0d;
                    i5 = 1;
                    while (i5 < 2) {
                        instanceCount = -60L;
                        b = (byte) (b & ((byte) i));
                        i5++;
                    }
                    i4++;
                }
            }
        } else {
            iFld = i3 * ((int) instanceCount);
            i = -38742;
        }
        long floatToIntBits = i + i4 + 29678 + Float.floatToIntBits(f) + i5 + 213 + b + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
        lMeth_check_sum += floatToIntBits;
        return floatToIntBits;
    }

    public void vMeth(long j, byte b) {
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        FuzzerUtils.init(iArr, -13);
        int[] iArr2 = iArr[96];
        int i = (iFld >>> 1) % N;
        int i2 = iArr2[i];
        long lMeth = lMeth();
        int i3 = iFld;
        iArr2[i] = i2 - ((int) (lMeth - i3));
        iFld = i3;
        bFld = bFld;
        int i4 = -178;
        int i5 = 9;
        while (257 > i5) {
            i4 = (int) j;
            i5++;
        }
        long j2 = j;
        float f = 0.148f;
        double d = 2.12936d;
        int i6 = 1;
        while (true) {
            i6++;
            if (i6 < 250) {
                f -= 5.497827E18f;
                d = instanceCount;
                int i7 = iFld;
                int i8 = i4 << i7;
                int i9 = i7 - i5;
                iFld = i9;
                i4 = i8 + i6;
                iArr[i6 + 1][i6 - 1] = (int) j2;
                long j3 = i6;
                iFld = i9 >>> i6;
                j2 = j2 + j3 + (j3 | f);
            } else {
                vMeth_check_sum += j2 + b + i5 + i4 + i6 + Float.floatToIntBits(f) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(iArr);
                return;
            }
        }
    }

    public boolean bMeth(double d) {
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        FuzzerUtils.init(iArr, -106);
        float f = -2.503f;
        short s = -13;
        int i = -86;
        int i2 = -66;
        int i3 = -64634;
        float f2 = 14.0f;
        while (f2 < 311.0f) {
            vMeth(instanceCount, byFld);
            byte b = byFld;
            iFld = b;
            float f3 = f2 + 1.0f;
            int i4 = (int) f3;
            iArr[i4][i4] = -44;
            int i5 = (int) f2;
            iFld = b + i5;
            iArr[(int) (f2 - 1.0f)][i5] = (int) d;
            s = sFld;
            i = 6;
            while (1 < i) {
                int i6 = (int) ((f2 % 2.0f) + 87.0f);
                if (i6 == 87) {
                    i2 = 1;
                    while (2 > i2) {
                        iFld = s;
                        int[] iArr2 = iArr[i];
                        iArr2[i2] = iArr2[i2] * i2;
                        iFld = ((int) instanceCount) + s;
                        f = i;
                        i3 = (int) instanceCount;
                        i2++;
                    }
                } else {
                    if (i6 == 88) {
                        f -= 175.0f;
                    }
                    sFld = (short) (sFld - 35);
                }
                i--;
            }
            f2 = f3;
        }
        long doubleToLongBits = ((((Double.doubleToLongBits(d) + Float.floatToIntBits(f2)) + s) + i) - 2826) + i2 + i3 + Float.floatToIntBits(f) + FuzzerUtils.checkSum(iArr);
        bMeth_check_sum += doubleToLongBits;
        return doubleToLongBits % 2 > 0;
    }

    public void mainTest(String[] strArr) {
        float[][] fArr;
        float[][] fArr2;
        float[][] fArr3 = (float[][]) Array.newInstance((Class<?>) float.class, N, N);
        FuzzerUtils.init(fArr3, 2.889f);
        iFld = (int) 90.1289d;
        float f = 1.0f;
        int i = 52873;
        int i2 = 7;
        int i3 = -7;
        int i4 = 6;
        int i5 = 61345;
        int i6 = -132;
        int i7 = 4;
        int i8 = -13;
        int i9 = -237;
        float f2 = 1.0f;
        while (true) {
            float[][] fArr4 = fArr3;
            if (f2 >= 273.0f) {
                fArr = fArr4;
            } else if (bMeth(-90.1289d)) {
                fArr = fArr4;
            } else {
                i2 = 184;
                while (f2 < i2) {
                    switch ((i2 % 10) + 96) {
                        case 96:
                            fArr2 = fArr4;
                            instanceCount = f2;
                            float[] fArr5 = fArr2[i2];
                            fArr5[1] = fArr5[1] - ((float) instanceCount);
                            int i10 = iFld >> i3;
                            iFld = i10;
                            float f3 = this.fFld + 2;
                            this.fFld = f3;
                            i3++;
                            byFld = (byte) i3;
                            this.fFld = f3 - i3;
                            i4 = 3;
                            iFld = i10;
                            i = i;
                            instanceCount = i;
                            iFld >>= i3;
                            break;
                        case 97:
                            fArr2 = fArr4;
                            iFld >>= i3;
                            break;
                        case 98:
                        case 99:
                            int i11 = i;
                            i5 = i2;
                            while (1 > i5) {
                                instanceCount -= sFld;
                                i5++;
                                fArr4 = fArr4;
                            }
                            fArr2 = fArr4;
                            bFld = bFld;
                            this.fFld /= (float) (instanceCount | 1);
                            instanceCount += i2 | i3;
                            i = i11;
                            break;
                        case 100:
                            long[] jArr = this.lArrFld;
                            int i12 = (int) (f2 - f);
                            jArr[i12] = jArr[i12] + i6;
                            i6 = i5;
                            fArr2 = fArr4;
                            i = i;
                            i7 = 1;
                            break;
                        case 101:
                            i9 += i2;
                            fArr2 = fArr4;
                            break;
                        case 102:
                            this.fFld += i5;
                            i9 += i2 + i4;
                            i8 += i2;
                            i = i5;
                            fArr2 = fArr4;
                            break;
                        case 103:
                            sFld = (short) (sFld + ((short) (i2 | i8)));
                            fArr2 = fArr4;
                            break;
                        case 104:
                            this.fFld -= i6;
                        case 105:
                            fArr4[(int) (f2 - f)][(int) f2] = i;
                            fArr2 = fArr4;
                            break;
                        default:
                            fArr2 = fArr4;
                            break;
                    }
                    i2--;
                    fArr4 = fArr2;
                    f = 1.0f;
                }
                f2 += 2.0f;
                fArr3 = fArr4;
                f = 1.0f;
            }
        }
        FuzzerUtils.out.println("d f i = " + Double.doubleToLongBits(-90.1289d) + "," + Float.floatToIntBits(f2) + "," + i);
        FuzzerUtils.out.println("i14 i15 i16 = " + i2 + "," + i3 + "," + i4);
        FuzzerUtils.out.println("i17 i18 i19 = " + i5 + "," + i6 + "," + i7);
        FuzzerUtils.out.println("i20 i21 fArr = " + i8 + "," + i9 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.bFld = " + instanceCount + "," + iFld + "," + (bFld ? 1 : 0));
        PrintStream printStream = FuzzerUtils.out;
        byte b = byFld;
        short s = sFld;
        printStream.println("Test.byFld Test.sFld fFld = " + ((int) b) + "," + ((int) s) + "," + Float.floatToIntBits(this.fFld));
        PrintStream printStream2 = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(this.lArrFld);
        StringBuilder sb = new StringBuilder();
        sb.append("lArrFld = ");
        sb.append(checkSum);
        printStream2.println(sb.toString());
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

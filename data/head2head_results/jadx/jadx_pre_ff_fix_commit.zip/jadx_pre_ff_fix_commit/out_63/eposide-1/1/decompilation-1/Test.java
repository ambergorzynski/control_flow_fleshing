
import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_63/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long dMeth_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public byte byFld = 92;
    public static long instanceCount = -179;
    public static boolean bFld = true;
    public static double dFld = -95.25769d;
    public static final int N = 400;
    public static long[] lArrFld = new long[N];
    public static int[][] iArrFld = (int[][]) Array.newInstance((Class<?>) int.class, N, N);

    static {
        FuzzerUtils.init(lArrFld, 48732L);
        FuzzerUtils.init(iArrFld, 236);
        dMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }

    public static void vMeth(short s, int i, double d) {
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, 103.355d);
        int i2 = i + i;
        int i3 = 5117;
        byte b = 39;
        int i4 = 382;
        while (true) {
            instanceCount |= 1;
            int i5 = (int) (i2 + (i4 | (-1.665f)));
            bFld = bFld;
            int i6 = 1;
            while (i6 < 4) {
                int i7 = i6 * i6;
                long j = instanceCount + (i7 - 7553);
                instanceCount = j;
                i5 += i3;
                boolean z = bFld;
                if (!z) {
                    double d2 = dArr[i4];
                    double d3 = i4;
                    Double.isNaN(d3);
                    dArr[i4] = d2 * d3;
                    i5 += i7;
                    d = -1.0d;
                    b = (byte) (b - ((byte) j));
                    i3 = s;
                    if (z) {
                        break;
                    }
                }
                i6++;
            }
            i4--;
            if (i4 > 0) {
                i2 = i5;
            } else {
                vMeth_check_sum += s + i5 + Double.doubleToLongBits(d) + i4 + Float.floatToIntBits(-1.665f) + i6 + i3 + b + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
                return;
            }
        }
    }

    public static int iMeth(long j, int i, double d) {
        vMeth((short) -18043, 214, d);
        long j2 = i;
        instanceCount |= j2;
        long doubleToLongBits = ((j + j2) + Double.doubleToLongBits(d)) - 18043;
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public double dMeth(long j, int i) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 12817);
        int i2 = 199;
        int i3 = -27726;
        int i4 = -16656;
        double d = 62.12403d;
        int i5 = 301;
        while (i5 > 6) {
            i2 = i - iMeth(instanceCount, i, dFld);
            i += ((this.byFld * i5) + i) - i2;
            iArr[i5 + 1] = 48085;
            int i6 = ((i5 % 5) * 5) + 121;
            if (i6 == 128) {
                i3 = (int) (i3 + (i5 ^ j));
            } else if (i6 != 131) {
                if (i6 == 134) {
                    double d2 = 1.0d;
                    while (d2 < 6.0d) {
                        i4 = 3;
                        i3 = (((i3 + 10) - ((int) instanceCount)) >> i5) + i5;
                        d2 += 1.0d;
                    }
                    i3 += ((i5 * i2) + i4) - i5;
                    d = d2;
                } else if (i6 != 142) {
                    if (i6 == 146) {
                        j *= (long) d;
                    }
                }
                instanceCount *= i5;
                this.byFld = (byte) (this.byFld & ((byte) i2));
            } else {
                boolean z = bFld;
            }
            i5--;
        }
        long doubleToLongBits = j + i + i5 + i2 + Double.doubleToLongBits(d) + i3 + i4 + FuzzerUtils.checkSum(iArr);
        dMeth_check_sum += doubleToLongBits;
        return doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        int i = -24;
        dMeth(instanceCount, -24);
        int i2 = 1;
        int i3 = -13;
        int i4 = -37637;
        int i5 = 54690;
        int i6 = -129;
        int i7 = 207;
        float f = 0.929f;
        int i8 = 1;
        while (i8 < 137) {
            long j = instanceCount;
            instanceCount = j & j;
            i3 = i8;
            i4 = 9;
            while (i4 < 184) {
                int i9 = i8 - 1;
                int[] iArr = iArrFld[i9];
                iArr[i4] = iArr[i4] >> i3;
                i6 = 1;
                while (i6 < 2) {
                    int i10 = i3 >>> i;
                    switch ((i8 % 4) + 126) {
                        case 126:
                            int[][] iArr2 = iArrFld;
                            iArr2[i4 + 1] = iArr2[i6];
                            float f2 = i7;
                            i10 += (int) f2;
                            dFld = instanceCount;
                            f = f2 + 39262.0f;
                            break;
                        case 127:
                            instanceCount = i7;
                            i7 *= i8;
                            break;
                    }
                    i3 = i10 >>> i6;
                    i5 = 44450;
                    int[] iArr3 = iArrFld[i4];
                    iArr3[i9] = iArr3[i9] << ((int) instanceCount);
                    i6++;
                }
                instanceCount *= i3;
                i7 = 35;
                long j2 = this.byFld;
                instanceCount = j2;
                i += (int) j2;
                i3 = 27;
                i4++;
            }
            i8++;
        }
        FuzzerUtils.out.println("i10 i11 i12 = " + i + "," + i8 + "," + i3);
        FuzzerUtils.out.println("i13 i14 i15 = " + i4 + "," + i5 + "," + i6);
        FuzzerUtils.out.println("i16 f1 = " + i7 + "," + Float.floatToIntBits(f));
        PrintStream printStream = FuzzerUtils.out;
        long j3 = instanceCount;
        if (!bFld) {
            i2 = 0;
        }
        printStream.println("Test.instanceCount Test.bFld Test.dFld = " + j3 + "," + i2 + "," + Double.doubleToLongBits(dFld));
        PrintStream printStream2 = FuzzerUtils.out;
        byte b = this.byFld;
        printStream2.println("byFld Test.lArrFld Test.iArrFld = " + ((int) b) + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(iArrFld));
        PrintStream printStream3 = FuzzerUtils.out;
        long j4 = vMeth_check_sum;
        StringBuilder sb = new StringBuilder();
        sb.append("vMeth_check_sum: ");
        sb.append(j4);
        printStream3.println(sb.toString());
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

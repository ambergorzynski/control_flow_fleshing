package defpackage;

import java.io.PrintStream;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_11/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public boolean bFld = true;
    public int[] iArrFld = new int[N];
    public static long instanceCount = 56410;
    public static int iFld = 1984;
    public static short sFld = 982;
    public static long sMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;

    public int iMeth() {
        int i = 18;
        while (i < 392) {
            instanceCount = 153L;
            i++;
        }
        int i2 = 199;
        int i3 = -14;
        int i4 = -67;
        int i5 = 11;
        for (double d = 4.0d; 396.0d > d; d += 1.0d) {
            try {
                long j = instanceCount + i;
                instanceCount = j;
                instanceCount = j * sFld;
                i2 = (i2 * (-55741)) + ((int) (d * d));
                i3 = 1;
                while (i3 < 404) {
                    if (this.bFld) {
                        try {
                            int i6 = iFld - iFld;
                            iFld = i6;
                            iFld = i6 + ((int) d);
                            i4 = 1;
                        } catch (ArrayIndexOutOfBoundsException e) {
                            i4 = 1;
                            iFld <<= i3;
                            long doubleToLongBits = (((((i - 55741) + Double.doubleToLongBits(d)) + i2) + i3) - 21) + i4 + i5;
                            iMeth_check_sum += doubleToLongBits;
                            return (int) doubleToLongBits;
                        }
                    } else if (this.bFld) {
                        instanceCount = instanceCount;
                    } else if (this.bFld) {
                        i5 -= i4;
                    }
                    i3++;
                }
            } catch (ArrayIndexOutOfBoundsException e2) {
            }
        }
        long doubleToLongBits2 = (((((i - 55741) + Double.doubleToLongBits(d)) + i2) + i3) - 21) + i4 + i5;
        iMeth_check_sum += doubleToLongBits2;
        return (int) doubleToLongBits2;
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x00cc  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void vMeth(byte r26, int r27, long r28) {
        /*
            Method dump skipped, instructions count: 386
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.Test.vMeth(byte, int, long):void");
    }

    public short sMeth() {
        vMeth((byte) 91, iFld, -209L);
        int i = iFld;
        iFld = i + i;
        long j = 91 - 209;
        sMeth_check_sum += j;
        return (short) j;
    }

    public void mainTest(String[] strArr) {
        short[] sArr = new short[N];
        FuzzerUtils.init(sArr, (short) -29914);
        int i = -4;
        int i2 = -124;
        int i3 = -3;
        float f = -35.753f;
        int i4 = 7;
        while (340 > i4) {
            i += i4;
            float sMeth = sMeth();
            this.iArrFld[i4] = i4;
            long j = instanceCount + i4 + i4;
            instanceCount = j;
            f = ((float) j) + sMeth;
            int i5 = i3;
            int i6 = 2;
            while (i6 < 76) {
                instanceCount -= 14117;
                i5 = 1;
                while (i5 < 2) {
                    boolean z = this.bFld;
                    if (z) {
                        this.bFld = z;
                    }
                    this.iArrFld = FuzzerUtils.int1array(N, -114);
                    long j2 = instanceCount;
                    instanceCount = j2 + (((i5 * 4) + i5) - j2);
                    sArr[i6] = (short) (sArr[i6] + ((short) iFld));
                    i5++;
                }
                i6++;
            }
            i4++;
            i2 = i6;
            i3 = i5;
        }
        FuzzerUtils.out.println("i i1 f = " + i4 + "," + i + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i18 i19 i20 = " + i2 + ",4," + i3);
        FuzzerUtils.out.println("i21 i22 i23 = -8,-2,-15563");
        PrintStream printStream = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(sArr);
        StringBuilder sb = new StringBuilder();
        sb.append("sArr = ");
        sb.append(checkSum);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.sFld = " + instanceCount + "," + iFld + "," + ((int) sFld));
        PrintStream printStream2 = FuzzerUtils.out;
        boolean z2 = this.bFld;
        printStream2.println("bFld iArrFld = " + (z2 ? 1 : 0) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("sMeth_check_sum: " + sMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}


import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_28/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public static long iMeth1_check_sum;
    public static long iMeth_check_sum;
    public static long[] lArrFld;
    public static long vMeth_check_sum;
    public float fFld = 1.114f;
    public int iFld1 = -30409;
    public static long instanceCount = -40602372253886812L;
    public static int iFld = -26520;
    public static short sFld = 12667;
    public static boolean bFld = false;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        lArrFld = new long[N];
        FuzzerUtils.init(iArr, 13);
        FuzzerUtils.init(lArrFld, 8902050703675078920L);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
    }

    public static int iMeth1(float f, float f2, int i) {
        long[][] jArr = (long[][]) Array.newInstance((Class<?>) long.class, N, N);
        FuzzerUtils.init(jArr, -70L);
        int i2 = iFld;
        iArrFld = iArrFld;
        int i3 = 50884;
        byte b = 107;
        int i4 = 171;
        while (true) {
            i4--;
            if (i4 > 0) {
                int i5 = ((i4 % 7) * 5) + 92;
                if (i5 == 104) {
                    instanceCount >>= 10;
                } else if (i5 == 110) {
                    long j = instanceCount >> b;
                    instanceCount = j;
                    instanceCount = j | i2;
                } else if (i5 == 117) {
                    iFld = i4;
                    long[] jArr2 = jArr[i4];
                    int i6 = i4 - 1;
                    long j2 = jArr2[i6];
                    long j3 = instanceCount;
                    jArr2[i6] = j2 << ((int) j3);
                    f = -49190.0f;
                    instanceCount = j3 << ((int) j3);
                } else if (i5 == 119) {
                    iFld = iFld;
                } else if (i5 == 127) {
                    i2 -= (int) instanceCount;
                    i3 = i4;
                    while (i3 < 9) {
                        iFld -= (int) 24.608f;
                        i3++;
                    }
                    iFld -= 10;
                } else if (i5 == 124 || i5 == 125) {
                    b = (byte) (b + ((byte) i3));
                }
            } else {
                long floatToIntBits = Float.floatToIntBits(f) + Float.floatToIntBits(f2) + i2 + i4 + b + i3 + 10 + Float.floatToIntBits(24.608f) + FuzzerUtils.checkSum(jArr);
                iMeth1_check_sum += floatToIntBits;
                return (int) floatToIntBits;
            }
        }
    }

    public static int iMeth(double d, long j) {
        short[][][] sArr = (short[][][]) Array.newInstance((Class<?>) short.class, N, N, N);
        FuzzerUtils.init((Object[][]) sArr, (Object) (short) 14828);
        int i = iFld;
        int i2 = i - sArr[(i >>> 1) % N][(i >>> 1) % N][(i >>> 1) % N];
        iFld = i2;
        int i3 = -113;
        iFld = i2 - (i2 - ((-113) - (iMeth1(0.947f, 0.947f, i2) - 12)));
        iFld = 64;
        int i4 = 142;
        int i5 = 209;
        int i6 = -13;
        int i7 = 4;
        while (i7 < 397) {
            iArrFld[i7] = i3;
            int i8 = i6;
            int i9 = i5;
            int i10 = i3;
            int i11 = 4;
            while (i11 > 1) {
                iFld *= -93;
                i9 = (int) d;
                i11--;
                i10 = 2;
                i8 = 2;
            }
            i7++;
            i4 = i11;
            i3 = i10;
            i5 = i9;
            i6 = i8;
        }
        long doubleToLongBits = (((((Double.doubleToLongBits(d) + j) + i3) + Float.floatToIntBits(0.947f)) + i7) - 225) + i4 + i5 + i6 + FuzzerUtils.checkSum((Object[][]) sArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public void vMeth(int i, int i2, long j) {
        int[] iArr = iArrFld;
        int i3 = (iFld >>> 1) % N;
        iArr[i3] = iArr[i3] + 2;
        int i4 = i;
        long j2 = j;
        double d = 2.54941d;
        int i5 = 13;
        int i6 = 35533;
        int i7 = 32;
        byte b = -51;
        int i8 = 8;
        while (i8 < 156) {
            i5 += i8;
            sFld = (short) (sFld / ((short) ((iMeth(0.39289d, instanceCount) + sFld) | 1)));
            j2 = iFld & j2;
            i6 = 1;
            int i9 = i4;
            while (i6 < 11) {
                try {
                    i9 = i5 % iArrFld[i8 + 1];
                    i5 = (-195) / i2;
                    iArrFld[i8] = i6 / (-256);
                } catch (ArithmeticException e) {
                }
                int[] iArr2 = iArrFld;
                iArr2[i8] = i2;
                b = (byte) instanceCount;
                int i10 = (((i2 >>> 1) % 8) * 5) + 43;
                if (i10 != 50) {
                    if (i10 != 51) {
                        if (i10 == 60) {
                            iArr2[i6 - 1] = i6;
                        } else if (i10 != 67) {
                            if (i10 != 70) {
                                if (i10 == 73) {
                                    double d2 = 1.0d;
                                    double d3 = 1.0d;
                                    while (2.0d > d3) {
                                        i7 *= i2;
                                        instanceCount += 83;
                                        long[] jArr = lArrFld;
                                        int i11 = (int) (d3 + d2);
                                        jArr[i11] = jArr[i11] - iFld;
                                        j2 -= this.fFld;
                                        d3 += 2.0d;
                                        d2 = 1.0d;
                                    }
                                    d = d3;
                                } else if (i10 == 77) {
                                    iArr2[i6] = iArr2[i6] << i5;
                                } else if (i10 == 82) {
                                    sFld = sFld;
                                }
                            }
                            i5 += 94;
                        }
                        i6++;
                    }
                    int[] iArr3 = iArrFld;
                    iArr3[i8] = iArr3[i8] >>> (-109);
                    i6++;
                }
                j2 += ((i6 * i8) + iFld) - j2;
                i6++;
            }
            i8++;
            i4 = i9;
        }
        vMeth_check_sum += (((((((i4 + i2) + j2) + i8) + i5) + Double.doubleToLongBits(0.39289d)) + i6) - 109) + b + Double.doubleToLongBits(d) + i7;
    }

    public void mainTest(String[] strArr) {
        double[] dArr = new double[N];
        byte[] bArr = new byte[N];
        FuzzerUtils.init(bArr, (byte) 114);
        FuzzerUtils.init(dArr, -70.39377d);
        double d = ((iFld >>> 63491) + 63491) * 44108;
        Double.isNaN(d);
        double d2 = d * 72.48837d;
        instanceCount = (long) d2;
        FuzzerUtils.out.println("d i f = " + Double.doubleToLongBits(d2) + ",63491," + Float.floatToIntBits(0.311f));
        FuzzerUtils.out.println("i1 i2 i19 = 0,23253,2");
        FuzzerUtils.out.println("i20 i21 i22 = -209,-12,-148");
        FuzzerUtils.out.println("i23 i24 i25 = 6979,60840,-9");
        FuzzerUtils.out.println("i26 i27 i28 = -14,28595,-188");
        FuzzerUtils.out.println("i29 byArr dArr = -34484," + FuzzerUtils.checkSum(bArr) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.sFld = " + instanceCount + "," + iFld + "," + ((int) sFld));
        PrintStream printStream = FuzzerUtils.out;
        int floatToIntBits = Float.floatToIntBits(this.fFld);
        boolean z = bFld;
        printStream.println("fFld Test.bFld iFld1 = " + floatToIntBits + "," + (z ? 1 : 0) + "," + this.iFld1);
        FuzzerUtils.out.println("Test.iArrFld Test.lArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

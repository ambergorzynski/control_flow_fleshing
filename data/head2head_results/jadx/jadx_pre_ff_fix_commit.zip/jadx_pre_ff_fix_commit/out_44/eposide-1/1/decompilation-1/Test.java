
import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_44/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[][] iArrFld;
    public static long iMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public short[] sArrFld = new short[N];
    public static long instanceCount = 6938988444429917649L;
    public static int iFld = 5;
    public static short sFld = -19361;

    static {
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        iArrFld = iArr;
        FuzzerUtils.init(iArr, -23795);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
    }

    public static int iMeth() {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -227);
        int[][] iArr2 = iArrFld;
        int i = iFld;
        iArr2[(i >>> 1) % N][46] = i;
        int i2 = -8;
        int i3 = 5;
        short s = 6242;
        byte b = -118;
        long j = 1;
        while (j < 236) {
            i3 = 1;
            do {
                long j2 = instanceCount;
                instanceCount = j2 / (j2 | 1);
                try {
                    int i4 = (-1763133889) / i2;
                    i2 = i4 % i4;
                    iFld = i2 / i3;
                } catch (ArithmeticException e) {
                }
                long j3 = instanceCount;
                int i5 = (int) j3;
                iFld = i5;
                int i6 = i5 + i3;
                iFld = i6;
                switch ((i3 % 9) + 24) {
                    case 24:
                        instanceCount = j3 - j;
                        iFld = i6 << s;
                        break;
                    case 25:
                        i2 = ((int) (i2 + (((i3 * 0.272f) + i6) - i6))) * i6;
                        break;
                    case 26:
                        int i7 = (int) (j - 1);
                        iArr[i7] = iArr[i7] - ((int) j3);
                        iFld = i2;
                    case 27:
                        iArr = iArrFld[i3];
                    case 28:
                        iArr[i3] = (int) j;
                        break;
                    case 29:
                        b = (byte) (b + ((byte) i3));
                        break;
                    case 30:
                        iFld = i6 + (i3 * i3);
                        break;
                    case 31:
                        i2 = (int) j;
                    case 32:
                        s = (short) (s + ((short) i2));
                    default:
                        s = (short) (s - 66);
                        break;
                }
                i3++;
            } while (i3 < 7);
            j++;
        }
        long floatToIntBits = j + i2 + i3 + s + Float.floatToIntBits(0.272f) + b + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth1(long j, long j2) {
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        FuzzerUtils.init(iArr, 3);
        int i = iFld;
        int i2 = (i >>> 1) % N;
        int[][] iArr2 = iArrFld;
        int i3 = (i >>> 1) % N;
        int[] iArr3 = iArr2[(i >>> 1) % N];
        iArr2[i3] = iArr3;
        iArr[i2] = iArr3;
        Double.isNaN(-12);
        iFld = i + 1;
        Double.isNaN(i * iMeth());
        vMeth1_check_sum += (((j2 + 55956) + Double.doubleToLongBits((-((-18.61242d) - r1)) - r3)) - 12) + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth(int i) {
        int i2;
        int[][] iArr = iArrFld;
        int i3 = (i >>> 1) % N;
        int[] iArr2 = iArr[i3];
        iArr[i3] = iArr2;
        iArr[i3] = iArr2;
        iArr[i3] = iArr2;
        iArr[i3] = iArr2;
        int i4 = -45393;
        int i5 = -27;
        int i6 = 63531;
        float f = 1.667f;
        int i7 = 1;
        do {
            i2 = 1;
            while (i2 < 5) {
                long j = instanceCount;
                vMeth1(j, j);
                i5 = i7;
                while (i5 < 2) {
                    long j2 = i;
                    instanceCount = j2;
                    instanceCount = j2 - (-174);
                    i5++;
                }
                if (i5 != 0) {
                    vMeth_check_sum += (((((((i + i7) + i2) + i4) + i5) + 14) + Float.floatToIntBits(f)) + i6) - 11542;
                    return;
                }
                try {
                    iFld = 12458 / i4;
                    int i8 = i2 - 1;
                    iArrFld[i8][i2] = iArrFld[i7][i8] / 19133;
                    i4 = i / (-68);
                } catch (ArithmeticException e) {
                }
                instanceCount >>= i7;
                f = iFld;
                i6 = 1;
                while (i6 < 2) {
                    i4 = sFld;
                    i += i6 * i6;
                    i6++;
                }
                i2++;
            }
            i7++;
        } while (i7 < 327);
        vMeth_check_sum += (((((((i + i7) + i2) + i4) + i5) + 14) + Float.floatToIntBits(f)) + i6) - 11542;
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 63937);
        vMeth(iFld);
        int i = 0;
        int i2 = 0;
        int i3 = -118;
        int i4 = 33463;
        byte b = 36;
        while (i < 400) {
            int i5 = iArr[i];
            i3 = 3;
            while (i3 < 63) {
                b = (byte) (b * ((byte) i3));
                i3++;
            }
            int i6 = iFld;
            int i7 = (i6 >>> 1) % N;
            iArr[i7] = iArr[i7] * i6;
            int i8 = 2;
            while (i8 < 63) {
                i2 = 135;
                i8++;
            }
            int[] iArr2 = iArrFld[264];
            iArr2[360] = iArr2[360] >> (-36175);
            i++;
            i4 = i8;
        }
        FuzzerUtils.out.println("f2 i12 i13 = " + Float.floatToIntBits(0.0f) + "," + i3 + "," + i2);
        FuzzerUtils.out.println("by1 i14 i15 = " + ((int) b) + "," + i4 + ",95");
        FuzzerUtils.out.println("i16 i17 i18 = 22845,-13967,-4");
        FuzzerUtils.out.println("i19 i20 i21 = -36175,-2,-11");
        PrintStream printStream = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(iArr);
        StringBuilder sb = new StringBuilder();
        sb.append("iArr2 = ");
        sb.append(checkSum);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.sFld = " + instanceCount + "," + iFld + "," + ((int) sFld));
        FuzzerUtils.out.println("Test.iArrFld sArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(this.sArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

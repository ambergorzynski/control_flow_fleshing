
import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_71/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[][] iArrFld;
    public static long iMeth1_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public short sFld = 16992;
    public static long instanceCount = 2506500517712289440L;
    public static int iFld = 61434;

    static {
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        iArrFld = iArr;
        FuzzerUtils.init(iArr, -70);
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
        vMeth_check_sum = 0L;
    }

    public static void vMeth(int i, int i2, float f) {
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(iArr, -53763);
        FuzzerUtils.init(fArr, 117.343f);
        int i3 = i;
        float f2 = f;
        int i4 = 7;
        int i5 = 45785;
        int i6 = 40513;
        int i7 = 2;
        while (i7 < 153) {
            i4 = 1;
            while (true) {
                i6 = 10;
                if (i4 >= 10) {
                    break;
                } else {
                    i4++;
                }
            }
            fArr[i7] = (float) (-125.88441d);
            i3 = (int) (i3 + (i7 | f2));
            iArr[i7] = iArr[i7] * (-39407);
            while (i6 > 1) {
                f2 -= (float) instanceCount;
                i5 *= i2;
                i6 -= 3;
            }
            i7++;
        }
        vMeth_check_sum += ((((((((((((((i3 + i2) + Float.floatToIntBits(f2)) + i7) + 0) + i4) + i5) + 1) - 7477) + 65108) - 5) + Double.doubleToLongBits(-125.88441d)) - 39407) + i6) - 96) + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public static int iMeth1(int i, double d, int i2) {
        int i3;
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 4L);
        vMeth(i, i, -2.221f);
        long j = instanceCount;
        float f = ((float) j) - 2.221f;
        int i4 = (i >>> 1) % N;
        jArr[i4] = jArr[i4] - j;
        int i5 = -52784;
        int i6 = 4;
        while (i6 < 188) {
            i6++;
            i5 = i;
        }
        int i7 = i5 | ((int) instanceCount);
        int i8 = 219;
        float f2 = 80.735f;
        short s = -134;
        int i9 = -5;
        do {
            instanceCount = -48880L;
            i3 = 1;
            while (i3 < 7) {
                int i10 = i9;
                short s2 = s;
                float f3 = 1.0f;
                while (2.0f > f3) {
                    int i11 = ((i3 % 2) * 5) + 120;
                    if (i11 == 129) {
                        s2 = (short) (s2 | s2);
                    } else if (i11 == 130) {
                        i10 += (int) f3;
                    }
                    f3 += 1.0f;
                }
                i3++;
                f2 = f3;
                s = s2;
                i9 = i10;
            }
            i8--;
        } while (i8 > 0);
        long doubleToLongBits = i + Double.doubleToLongBits(d) + i9 + Float.floatToIntBits(f) + i6 + i7 + i8 + i3 + 21840 + Float.floatToIntBits(f2) + 105 + s + FuzzerUtils.checkSum(jArr);
        iMeth1_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public int iMeth(int i, long j, int i2) {
        short[][][] sArr = (short[][][]) Array.newInstance((Class<?>) short.class, N, N, N);
        FuzzerUtils.init((Object[][]) sArr, (Object) (short) -11315);
        long j2 = instanceCount;
        short[][] sArr2 = sArr[6];
        int i3 = (i2 >>> 1) % N;
        instanceCount = j2 - sArr2[i3][i3];
        int i4 = 180;
        while (i4 > 2) {
            i4--;
        }
        float iMeth1 = iMeth1(i2, 79.66008d, i4) - (-7.667f);
        long j3 = i;
        instanceCount += j3;
        long floatToIntBits = j3 + j + i2 + i4 + 15504 + Float.floatToIntBits(iMeth1) + Double.doubleToLongBits(79.66008d) + FuzzerUtils.checkSum((Object[][]) sArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        float f;
        double[] dArr = new double[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 8006460232895040125L);
        FuzzerUtils.init(dArr, 0.3355d);
        int iMeth = iMeth(49, 145L, 49);
        int i3 = iMeth + iMeth;
        long j = instanceCount;
        float f2 = ((float) j) * 252.0f;
        int[][] iArr = iArrFld;
        int i4 = (i3 >>> 1) % N;
        int[] iArr2 = iArr[i4];
        iArr2[i4] = iArr2[i4] ^ ((int) j);
        int i5 = i3 ^ iFld;
        int i6 = 39431;
        int i7 = -9;
        int i8 = 36153;
        int i9 = -16036;
        int i10 = 44776;
        int i11 = -30564;
        int i12 = 1;
        int i13 = -1;
        while (true) {
            double[] dArr2 = dArr;
            if (206 > i12) {
                float f3 = f2 + (((i12 * (-1)) + this.sFld) - i12);
                int i14 = 6;
                while (i14 < 122) {
                    long j2 = i7;
                    i7 = (int) (j2 + (((i14 * instanceCount) + j2) - j2));
                    iFld = (int) 66.4266d;
                    f3 *= f3;
                    iFld = -1;
                    i14++;
                }
                float f4 = f3;
                instanceCount += i12 * i12;
                instanceCount = 7L;
                int i15 = (((i14 >>> 1) % 6) * 5) + 4;
                if (i15 != 7) {
                    if (i15 == 18) {
                        f = f4;
                        i8 = 1;
                        while (i8 < 122) {
                            i10 = 1;
                            while (i10 < 2) {
                                long j3 = instanceCount;
                                instanceCount = j3 + j3;
                                instanceCount = ((float) r1) + (((float) ((i10 * i10) + r1)) - f);
                                i10++;
                                i7 = i7;
                                i14 = i14;
                            }
                            int i16 = i14;
                            long j4 = instanceCount;
                            jArr[i12] = j4;
                            i11 += i8;
                            i9 += i16;
                            double d = dArr2[i8];
                            double d2 = j4 | 1;
                            Double.isNaN(d2);
                            dArr2[i8] = d / d2;
                            int[] iArr3 = iArrFld[i12];
                            iArr3[i12] = iArr3[i12] & i12;
                            f = 8.3571002E8f;
                            i8++;
                            i14 = i16;
                        }
                        i = i14;
                        i2 = i7;
                    } else if (i15 == 22) {
                        i9 += i11;
                        i = i14;
                        i2 = i7;
                        f2 = f4;
                    } else {
                        if (i15 == 25) {
                            iArrFld[i12 - 1] = FuzzerUtils.int1array(N, -5);
                        } else if (i15 == 30) {
                            i = i14;
                            i2 = i7;
                            f = f4;
                        } else if (i15 == 33) {
                            i = i14;
                            i2 = i7;
                            f2 = f4;
                            i5 = 23;
                        }
                        i = i14;
                        i2 = i7;
                        f2 = f4;
                    }
                    f2 = f - i10;
                } else {
                    i = i14;
                    i2 = i7;
                    i13 = -13393;
                    f2 = f4;
                }
                i12++;
                dArr = dArr2;
                i7 = i2;
                i6 = i;
            } else {
                FuzzerUtils.out.println("i f4 b1 = " + i5 + "," + Float.floatToIntBits(f2) + ",1");
                FuzzerUtils.out.println("i25 i26 by = " + i12 + "," + i13 + ",-1");
                FuzzerUtils.out.println("i27 i28 d3 = " + i6 + "," + i7 + "," + Double.doubleToLongBits(66.4266d));
                FuzzerUtils.out.println("i29 i30 i31 = " + i8 + "," + i9 + "," + i10);
                FuzzerUtils.out.println("i32 lArr1 dArr = " + i11 + "," + FuzzerUtils.checkSum(jArr) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr2)));
                FuzzerUtils.out.println("Test.instanceCount Test.iFld sFld = " + instanceCount + "," + iFld + "," + ((int) this.sFld));
                PrintStream printStream = FuzzerUtils.out;
                long checkSum = FuzzerUtils.checkSum(iArrFld);
                StringBuilder sb = new StringBuilder();
                sb.append("Test.iArrFld = ");
                sb.append(checkSum);
                printStream.println(sb.toString());
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

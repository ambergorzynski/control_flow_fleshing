package defpackage;

import java.io.PrintStream;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_43/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static float[] fArrFld;
    public static long fMeth1_check_sum;
    public static long fMeth_check_sum;
    public static int[] iArrFld;
    public static long[] lArrFld;
    public static long vMeth_check_sum;
    public float fFld = 35.822f;
    public static long instanceCount = 1;
    public static int iFld = 36167;
    public static boolean bFld = false;
    public static double dFld = 1.95297d;
    public static byte byFld = 81;
    public static short sFld = 15491;

    static {
        long[] jArr = new long[N];
        lArrFld = jArr;
        iArrFld = new int[N];
        fArrFld = new float[N];
        FuzzerUtils.init(jArr, -1351535315436778417L);
        FuzzerUtils.init(iArrFld, -192);
        FuzzerUtils.init(fArrFld, 2.417f);
        vMeth_check_sum = 0L;
        fMeth_check_sum = 0L;
        fMeth1_check_sum = 0L;
    }

    public static float fMeth1(long j) {
        double d = dFld;
        double d2 = iFld;
        Double.isNaN(d2);
        dFld = d - d2;
        fMeth1_check_sum += j;
        return (float) j;
    }

    public static float fMeth() {
        int i = 12;
        int i2 = -23627;
        int i3 = -42;
        int i4 = 21;
        while (i4 < 388) {
            int[] iArr = iArrFld;
            int i5 = i4 - 1;
            int i6 = iArr[i5] + 1;
            iArr[i5] = i6;
            bFld = ((float) (i6 + (i4 + (-172)))) >= fMeth1(instanceCount);
            i = i4;
            while (i < 5) {
                fArrFld[i5] = i2;
                boolean z = bFld;
                if (z) {
                    i3 = 1;
                } else if (z) {
                    i2 = -172;
                } else if (z && z) {
                    break;
                }
                i++;
            }
            i4++;
        }
        long floatToIntBits = ((((((i4 + 59342) - 172) + i) + i2) + i3) - 55573) + Float.floatToIntBits(52.366f);
        fMeth_check_sum += floatToIntBits;
        return (float) floatToIntBits;
    }

    public static void vMeth(float f, int i, short s) {
        double d;
        int i2 = i;
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, 65.599d);
        instanceCount += i2;
        int i3 = i2 + i2;
        int i4 = iFld - 1;
        iFld = i4;
        char c = 0;
        int i5 = (i3 < i4 ? 1 : 0) & 1;
        double d2 = lArrFld[(iFld >>> 1) % N];
        Double.isNaN(d2);
        double d3 = d2 * 122.11519d;
        int i6 = 5;
        int i7 = -1;
        int i8 = -15362;
        int i9 = 13;
        while (242 > i6) {
            i7 = (int) (fMeth() - 124.27f);
            i8 = 1;
            while (true) {
                long j = instanceCount;
                int i10 = i2 - ((int) j);
                int i11 = i8 % 1;
                instanceCount = j;
                switch ((i8 % 9) + 33) {
                    case 33:
                        long[] jArr = lArrFld;
                        d = d3;
                        jArr[1] = jArr[1] - i8;
                        iFld -= i8;
                        instanceCount = j + (byFld ^ 1);
                        fArrFld[1] = i6;
                        i2 = i10;
                        d3 = d;
                        break;
                    case 34:
                        fArrFld[i8 - 1] = 1;
                        d = d3;
                        i2 = i10;
                        d3 = d;
                        break;
                    case 35:
                        lArrFld = lArrFld;
                        d = d3;
                        i2 = i10;
                        d3 = d;
                        break;
                    case 36:
                        int i12 = i6 + 1;
                        dArr[i12] = dArr[i12] * (-6.4713278086234092E18d);
                        d = d3;
                        i2 = i10;
                        d3 = d;
                        break;
                    case 37:
                        iArrFld[c] = (int) j;
                        d = d3;
                        i2 = i10;
                        d3 = d;
                        break;
                    case 38:
                        d = d3;
                        i2 = i10;
                        d3 = d;
                        break;
                    case 39:
                        iFld = -31392;
                    case 40:
                        try {
                            i7 = 173 / i10;
                            i10 %= i10;
                            iFld = i6 / 1874519772;
                            i2 = i10;
                            break;
                        } catch (ArithmeticException e) {
                            i2 = i10;
                            break;
                        }
                    case 41:
                        instanceCount = 13709L;
                        d = d3;
                        i2 = i10;
                        d3 = d;
                        break;
                    default:
                        d3 += 7.3814147840287194E17d;
                        i2 = i10;
                        break;
                }
                i9 = 4;
                i8++;
                if (i8 >= 13) {
                    break;
                } else {
                    c = 0;
                }
            }
            i6 += 2;
            c = 0;
        }
        vMeth_check_sum += Float.floatToIntBits(f) + i2 + s + i5 + Double.doubleToLongBits(d3) + i6 + i7 + i8 + i9 + 1 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
    }

    public void mainTest(String[] strArr) {
        int i;
        byte[] bArr = new byte[N];
        FuzzerUtils.init(bArr, (byte) -13);
        int i2 = iFld;
        iFld = i2 * bArr[(i2 >>> 1) % N];
        instanceCount = instanceCount;
        long j = 16;
        while (true) {
            i = -6;
            if (331 <= j) {
                break;
            }
            instanceCount = -13226L;
            vMeth(1.2f, iFld, (short) -2285);
            sFld = (short) (-6);
            j++;
            iArrFld[(int) j] = (int) dFld;
        }
        long j2 = 218 - iFld;
        int i3 = 17;
        int i4 = 60615;
        int i5 = 63049;
        int i6 = 19488;
        int i7 = 23152;
        int i8 = -43546;
        byte b = 2;
        while (309 > i3) {
            j2 += i3;
            i4 = 8;
            i7 = i7;
            i8 = i8;
            while (i4 < 172) {
                int i9 = 1;
                int i10 = 1;
                while (i10 < 2) {
                    bFld = bFld;
                    i10++;
                    i5 = i7;
                }
                i5 -= i5;
                this.fFld = b;
                while (i9 < 2) {
                    b = (byte) i5;
                    byFld = b;
                    i -= i4;
                    iFld += i9 - i3;
                    int[] iArr = iArrFld;
                    int i11 = i3 + 1;
                    iArr[i11] = iArr[i11] << i5;
                    j2 >>>= 709222718;
                    instanceCount <<= -56695;
                    iFld = 22;
                    i7 += i9;
                    i9 += 2;
                }
                i7 -= i4;
                i4++;
                int i12 = i10;
                i8 = i9;
                i6 = i12;
            }
            i3 += 2;
        }
        int i13 = i7;
        FuzzerUtils.out.println("l i l2 = " + j + "," + i + "," + j2);
        FuzzerUtils.out.println("i13 i14 i15 = " + i3 + "," + ((int) b) + "," + i4);
        FuzzerUtils.out.println("i16 i17 i18 = " + i5 + "," + i6 + "," + i13);
        PrintStream printStream = FuzzerUtils.out;
        printStream.println("i19 i20 byArr = " + i8 + ",-56695," + FuzzerUtils.checkSum(bArr));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.bFld = " + instanceCount + "," + iFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.dFld Test.byFld Test.sFld = " + Double.doubleToLongBits(dFld) + "," + ((int) byFld) + "," + ((int) sFld));
        FuzzerUtils.out.println("fFld Test.lArrFld Test.iArrFld = " + Float.floatToIntBits(this.fFld) + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(iArrFld));
        PrintStream printStream2 = FuzzerUtils.out;
        long doubleToLongBits = Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld));
        StringBuilder sb = new StringBuilder();
        sb.append("Test.fArrFld = ");
        sb.append(doubleToLongBits);
        printStream2.println(sb.toString());
        FuzzerUtils.out.println("fMeth1_check_sum: " + fMeth1_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

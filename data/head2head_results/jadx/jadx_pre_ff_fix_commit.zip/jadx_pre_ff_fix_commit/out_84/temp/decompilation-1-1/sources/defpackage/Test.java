package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_84/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[][] iArrFld;
    public static long iMeth_check_sum;
    public static long lMeth_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = -41322;
    public static double dFld = 71.56315d;
    public static volatile float fFld = 1.755f;
    public static boolean bFld = false;
    public static volatile byte byFld = -23;

    static {
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 75);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
    }

    public static long lMeth(double d, boolean z) {
        int i;
        int[] iArr = new int[N];
        byte[] bArr = new byte[N];
        int i2 = 14;
        FuzzerUtils.init(bArr, (byte) 14);
        FuzzerUtils.init(iArr, 9);
        int i3 = -34465;
        int i4 = 58;
        int i5 = 24635;
        int i6 = 32597;
        int i7 = -4;
        int i8 = -3;
        long j = -50086;
        while (i2 < 279) {
            int i9 = (int) instanceCount;
            i4 = 1;
            while (true) {
                i = 6;
                if (i4 >= 6) {
                    break;
                }
                long j2 = instanceCount;
                instanceCount = j2 >> ((int) j2);
                i9 >>= (int) j;
                i4++;
            }
            int i10 = i9 + (((i2 * i2) + i9) - i4);
            while (i > 1) {
                bArr[i] = (byte) (bArr[i] << ((byte) i7));
                iArr[i2 - 1] = iArr[r5] - 25740;
                int i11 = i - 1;
                iArr[i11] = iArr[i11] >> (-923607282);
                i5 = 1490117828;
                i8 = 2;
                j = ((float) j) + (((i * (-78.807f)) + 1490117828) - (-78.807f));
                i--;
                i7 = -923607282;
            }
            i2++;
            i3 = i10;
            i6 = i;
        }
        long doubleToLongBits = Double.doubleToLongBits(d) + (z ? 1L : 0L) + i2 + i3 + i4 + i5 + j + i6 + i7 + i8 + Float.floatToIntBits(-78.807f) + FuzzerUtils.checkSum(bArr) + FuzzerUtils.checkSum(iArr);
        lMeth_check_sum += doubleToLongBits;
        return doubleToLongBits;
    }

    public static void vMeth(int i, short s) {
        int i2 = 152;
        int i3 = 0;
        while (i2 > 9) {
            i3 = lMeth(dFld, true) + (-221) != ((long) s) ? 1 : 0;
            i2--;
        }
        instanceCount &= i;
        vMeth_check_sum += i + s + i2 + ((int) 55.394f) + i3 + Float.floatToIntBits(55.394f);
    }

    public static int iMeth() {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -12L);
        int i = 13 << ((int) (13 + instanceCount));
        vMeth(i, (short) 16320);
        int i2 = -5;
        long j = -26203;
        int i3 = 1;
        while (true) {
            i3++;
            if (i3 < 258) {
                long j2 = i3;
                jArr[i3] = j2;
                if (bFld) {
                    fFld = i;
                } else {
                    instanceCount -= j2;
                }
                int[][] iArr = iArrFld;
                int i4 = i3 + 1;
                int[] iArr2 = iArr[i4];
                int i5 = i3 - 1;
                iArr2[i5] = iArr2[i5] + ((int) j);
                bFld = bFld;
                int[] iArr3 = iArr[i4];
                iArr3[i4] = iArr3[i4] << i;
                j = i;
                i2 = 1;
                while (i2 < 6) {
                    instanceCount = j2;
                    iArrFld[i3][i3] = byFld;
                    i2++;
                }
            } else {
                long checkSum = i + i3 + j + i2 + 4 + FuzzerUtils.checkSum(jArr);
                iMeth_check_sum += checkSum;
                return (int) checkSum;
            }
        }
    }

    public void mainTest(String[] strArr) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -2L);
        int i = 156;
        int i2 = 234;
        int i3 = 0;
        int i4 = -32028;
        byte b = 3345;
        int i5 = 1;
        while (i5 < 128) {
            i2 = 8;
            while (i2 < 197) {
                i4 = 1;
                while (2 > i4) {
                    instanceCount = iMeth() >>> i4;
                    b = byFld;
                    try {
                        iArrFld[i4][i2] = -60;
                        iArrFld[i5][i5 + 1] = i5 / 168;
                        iArrFld[i2 - 1][i5 - 1] = i / (-22050);
                    } catch (ArithmeticException e) {
                    }
                    int[] iArr = iArrFld[i4];
                    int i6 = i4 + 1;
                    long j = instanceCount;
                    iArr[i6] = (int) j;
                    long j2 = j + (((i4 * (-7216)) + i4) - (-7216));
                    instanceCount = j2;
                    i >>= (int) j2;
                    i4 = i6;
                    i3 = -7216;
                }
                i2++;
            }
            i5++;
        }
        FuzzerUtils.out.println("i i1 i2 = " + i5 + "," + i + "," + i2);
        FuzzerUtils.out.println("i3 i4 i5 = " + i3 + "," + i4 + "," + ((int) b));
        FuzzerUtils.out.println("i20 s1 lArr1 = -49109,-7216," + FuzzerUtils.checkSum(jArr));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.fFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(fFld));
        PrintStream printStream = FuzzerUtils.out;
        boolean z = bFld;
        byte b2 = byFld;
        printStream.println("Test.bFld Test.byFld Test.iArrFld = " + (z ? 1 : 0) + "," + ((int) b2) + "," + FuzzerUtils.checkSum(iArrFld));
        PrintStream printStream2 = FuzzerUtils.out;
        long j3 = lMeth_check_sum;
        StringBuilder sb = new StringBuilder();
        sb.append("lMeth_check_sum: ");
        sb.append(j3);
        printStream2.println(sb.toString());
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

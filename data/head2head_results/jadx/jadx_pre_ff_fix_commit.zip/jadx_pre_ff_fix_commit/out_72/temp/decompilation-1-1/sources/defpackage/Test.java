package defpackage;

import java.io.PrintStream;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_72/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public static long lMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vSmallMeth_check_sum;
    public static long instanceCount = 20069;
    public static double dFld = 2.96271d;
    public static boolean bFld = true;
    public float fFld = 37.35f;
    public float[] fArrFld = new float[N];

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, -12);
        vSmallMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
    }

    public static long lMeth() {
        byte[] bArr = new byte[N];
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, -15.84402d);
        FuzzerUtils.init(bArr, (byte) -117);
        double d = dArr[339];
        int i = -218;
        double d2 = -218;
        Double.isNaN(d2);
        dArr[339] = d * d2;
        bArr[339] = 4;
        int i2 = -53;
        int i3 = 101;
        int i4 = -5967;
        int i5 = -5018;
        float f = 27.1018f;
        float f2 = 8.0f;
        while (f2 < 249.0f) {
            instanceCount <<= i;
            i3 = 1;
            while (i3 < 13) {
                f -= 59041.0f;
                int i6 = i4 >> 1839932890;
                bArr[i3] = (byte) (bArr[i3] + ((byte) i2));
                i5 = i3;
                while (i5 < 2) {
                    i2 = -2;
                    i5++;
                }
                try {
                    iArrFld[i3] = i5 / 187200594;
                    i = i6 / i6;
                    i2 = iArrFld[(int) f2] / i;
                } catch (ArithmeticException e) {
                }
                instanceCount += i3 ^ i;
                i4 = -7685;
                i3++;
            }
            f2 += 2.0f;
        }
        long floatToIntBits = ((((((((i + 4) + Float.floatToIntBits(f2)) + i2) + i3) + i4) + Float.floatToIntBits(f)) + i5) - 242) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + FuzzerUtils.checkSum(bArr);
        lMeth_check_sum += floatToIntBits;
        return floatToIntBits;
    }

    public static void vMeth(long j, float f) {
        int i = (int) (59 + 2);
        long lMeth = (((float) (j + 249)) + (((float) lMeth()) - 107.188f)) * j;
        int i2 = 4;
        int i3 = -9333;
        int i4 = 1590;
        int i5 = 21;
        int i6 = -5;
        int i7 = 2;
        while (i7 < 205) {
            i3 = i7;
            while (true) {
                i6 = 8;
                if (8 <= i3) {
                    break;
                }
                int i8 = i2 + i3;
                i3++;
                i5 = 1;
                i4 = i2;
                i2 = i8;
            }
            while (1 < i6) {
                i2 = 27131;
                lMeth -= f;
                i6--;
            }
            i7++;
        }
        vMeth_check_sum += lMeth + Float.floatToIntBits(f) + i + i7 + i2 + i3 + i4 + i5 + 2 + Double.doubleToLongBits(-2.127976d) + 14965 + 1 + i6 + 24025;
    }

    public static void vSmallMeth(int i) {
        vMeth(9L, 58.466f);
        vSmallMeth_check_sum -= 118;
    }

    public void mainTest(String[] strArr) {
        for (int i = 0; i < 340; i++) {
            vSmallMeth(62569);
        }
        float[] fArr = this.fArrFld;
        int length = fArr.length;
        int i2 = 246;
        int i3 = 84;
        int i4 = -5;
        int i5 = -246;
        int i6 = -14;
        int i7 = 0;
        while (true) {
            int i8 = 2;
            if (i7 >= length) {
                break;
            }
            float f = fArr[i7];
            int i9 = i2;
            int i10 = 2;
            while (63 > i10) {
                int i11 = 1021;
                try {
                    i11 = (40333 / iArrFld[i10]) % (-1676347533);
                    i9 = (-43865) / i10;
                } catch (ArithmeticException e) {
                    i9 = i11;
                }
                long j = instanceCount;
                instanceCount = j + (((i10 * i9) + j) - i9);
                i3 = 1;
                while (i3 < 2) {
                    i4 = -13998;
                    long j2 = instanceCount * ((long) dFld);
                    instanceCount = j2;
                    int i12 = i3 % 1;
                    instanceCount = j2 / 152;
                    i3++;
                }
                i10++;
            }
            while (i8 < 63) {
                i4 += i8;
                i9 *= -8;
                instanceCount = -8;
                i8 += 2;
            }
            instanceCount = i3;
            i7++;
            i5 = i8;
            int i13 = i10;
            i2 = i9;
            i6 = i13;
        }
        int i14 = i2 ^ 153;
        int i15 = 374;
        int i16 = 27414;
        int i17 = 25;
        int i18 = -8;
        while (1 < i15) {
            if (bFld) {
                int i19 = (((i6 >>> 1) % 2) * 5) + 89;
                if (i19 == 93 || i19 == 95) {
                    int i20 = i16;
                    instanceCount = instanceCount;
                    i4 = i6;
                    i18 = ((int) (i18 + (this.fFld | i15))) + i5;
                    i16 = i20;
                    i17 = i17;
                } else {
                    i16 = 2;
                    while (i16 < 68) {
                        i17 += (int) this.fFld;
                        i14 += i16;
                        i16++;
                    }
                }
            } else {
                int i21 = i16;
                int i22 = i17;
                int[] iArr = iArrFld;
                int i23 = i15 + 1;
                iArr[i23] = iArr[i23] - 75;
                i16 = i21;
                i17 = i22;
            }
            i15--;
        }
        int i24 = i16;
        FuzzerUtils.out.println("i17 i18 i19 = " + i6 + "," + i14 + "," + i3);
        FuzzerUtils.out.println("i20 i21 i22 = " + i4 + "," + i5 + "," + i18);
        FuzzerUtils.out.println("i24 i25 i26 = " + i15 + ",6," + i24);
        PrintStream printStream = FuzzerUtils.out;
        StringBuilder sb = new StringBuilder();
        sb.append("i27 by2 = ");
        sb.append(i17);
        sb.append(",");
        sb.append(75);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount Test.dFld fFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(this.fFld));
        PrintStream printStream2 = FuzzerUtils.out;
        boolean z = bFld;
        printStream2.println("Test.bFld Test.iArrFld fArrFld = " + (z ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
        PrintStream printStream3 = FuzzerUtils.out;
        long j3 = lMeth_check_sum;
        StringBuilder sb2 = new StringBuilder();
        sb2.append("lMeth_check_sum: ");
        sb2.append(j3);
        printStream3.println(sb2.toString());
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

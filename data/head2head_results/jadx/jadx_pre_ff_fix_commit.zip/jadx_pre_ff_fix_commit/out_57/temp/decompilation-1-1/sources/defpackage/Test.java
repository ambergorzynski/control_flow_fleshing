package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_57/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public double dFld = -10.119587d;
    public volatile int[] iArrFld = new int[N];
    public short[] sArrFld = new short[N];
    public static long instanceCount = 4121316606801551289L;
    public static boolean bFld = false;
    public static int iFld = -52248;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long vMeth2_check_sum = 0;

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static void vMeth2(float f, int i, int i2) {
        long[][] jArr;
        int i3;
        int[][][] iArr = (int[][][]) Array.newInstance((Class<?>) int.class, N, N, N);
        long[][] jArr2 = (long[][]) Array.newInstance((Class<?>) long.class, N, N);
        FuzzerUtils.init(jArr2, 3L);
        FuzzerUtils.init((Object[][]) iArr, (Object) (-6029));
        long[] jArr3 = jArr2[(i2 >>> 1) % N];
        int i4 = i >>> 1;
        int i5 = i4 % N;
        jArr3[i5] = jArr3[i5] - (-21903);
        instanceCount = -123L;
        float f2 = f;
        int i6 = i2;
        double d = 9.0d;
        int i7 = 22299;
        int i8 = -13;
        int i9 = 0;
        int i10 = 12;
        int i11 = -48511;
        while (d < 391.0d) {
            float f3 = f2 / (-50283.0f);
            i7 <<= i6;
            int i12 = i6 | i6;
            if ((i4 % 2) + 93 == 93) {
                i6 = i12 - i12;
                jArr = jArr2;
                switch ((int) ((d % 7.0d) + 125.0d)) {
                    case 125:
                        int i13 = 1;
                        while (i13 < 8) {
                            int i14 = i4;
                            int i15 = (int) (d + 1.0d);
                            iArr[i13 - 1][i15][i15] = 36;
                            i10 = 2;
                            while (i10 > 1) {
                                float f4 = i10;
                                f3 += ((f4 * f3) + i) - f4;
                                i7 >>= i7;
                                i6 -= i11;
                                i10--;
                            }
                            i13++;
                            i4 = i14;
                        }
                        i3 = i4;
                        i8 = i13;
                        f2 = f3;
                        break;
                    case 126:
                        instanceCount <<= i7;
                        i3 = i4;
                        f2 = f3;
                        break;
                    case 127:
                        i7 %= 13146;
                        i11 = i;
                        i3 = i4;
                        f2 = f3;
                        break;
                    case 128:
                        i11 = i;
                        i3 = i4;
                        f2 = f3;
                        break;
                    case 129:
                        i6 *= -43;
                        i3 = i4;
                        f2 = f3;
                        break;
                    case 130:
                        f2 = i;
                        i3 = i4;
                        break;
                    case 131:
                        i3 = i4;
                        f2 = f3;
                        break;
                    default:
                        i3 = i4;
                        try {
                            int i16 = i10 % i7;
                            i11 = i / (-23382);
                            i9 = 15027 / i11;
                            f2 = f3;
                            break;
                        } catch (ArithmeticException e) {
                            f2 = f3;
                            break;
                        }
                }
            } else {
                i6 = i12;
                jArr = jArr2;
                i3 = i4;
                f2 = f3;
            }
            d += 2.0d;
            jArr2 = jArr;
            i4 = i3;
        }
        vMeth2_check_sum += (((((((((Float.floatToIntBits(f2) + i) + i6) + Double.doubleToLongBits(d)) + i7) + i8) + i9) + i10) + i11) - 43) + 1 + FuzzerUtils.checkSum(jArr2) + FuzzerUtils.checkSum((Object[][]) iArr);
    }

    public static void vMeth1(double d, int i, int i2) {
        boolean[] zArr = new boolean[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(zArr, true);
        FuzzerUtils.init(jArr, 13494L);
        int i3 = i;
        int i4 = i2;
        int i5 = -67;
        int i6 = 128;
        int i7 = 13;
        int i8 = -238;
        int i9 = 0;
        short s = -19502;
        int i10 = 9;
        while (215 > i10) {
            vMeth2(41.96f, i3, i4);
            i5 = 1;
            while (i5 < 8) {
                int i11 = 2;
                while (i5 < i11) {
                    instanceCount = i11;
                    i3 >>= i5;
                    i11--;
                }
                s = (short) (s - 11819);
                int i12 = (int) instanceCount;
                i6 <<= i5;
                int i13 = 1;
                for (int i14 = 2; i13 < i14; i14 = 2) {
                    i4 += 6214;
                    zArr[i10] = bFld;
                    instanceCount = 59857 | instanceCount;
                    jArr[i5] = jArr[i5] + i5;
                    i13++;
                    i11 = i11;
                    i3 = -173;
                }
                int i15 = i11;
                i5++;
                i8 = i12;
                i9 = i13;
                i7 = i15;
            }
            i10++;
        }
        vMeth1_check_sum += ((((Double.doubleToLongBits(d) + i3) + i4) + i10) - 173) + Float.floatToIntBits(41.96f) + i5 + i6 + i7 + i8 + s + i9 + 157 + 59857 + FuzzerUtils.checkSum(zArr) + FuzzerUtils.checkSum(jArr);
    }

    public void vMeth(float f, int i, double d) {
        double d2;
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -767148025840482052L);
        vMeth1(d, i, i);
        int i2 = (int) f;
        int i3 = 2;
        while (i3 < 186) {
            this.iArrFld = this.iArrFld;
            i3++;
        }
        double d3 = 6.0d;
        int i4 = 0;
        int i5 = 247;
        while (d3 < 264.0d) {
            int i6 = 1;
            do {
                int[] iArr = this.iArrFld;
                d2 = 1.0d + d3;
                int i7 = (int) d2;
                iArr[i7] = iArr[i7] << 133;
                i6++;
            } while (i6 < 6);
            i4 = 12544;
            i5 = i6;
            d3 = d2;
            i2 = 112;
        }
        int i8 = 112 - ((int) instanceCount);
        int i9 = 12;
        int i10 = -10275;
        while (i9 < 315) {
            i10 += (int) instanceCount;
            i2 += ((i9 * i2) - 4213) - i9;
            i9++;
        }
        vMeth_check_sum += Float.floatToIntBits(f) + i2 + Double.doubleToLongBits(d) + i3 + i8 + Double.doubleToLongBits(d3) + i4 + i5 + i9 + i10 + FuzzerUtils.checkSum(jArr);
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        int i3;
        float f;
        int i4;
        float f2;
        int i5;
        short s;
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, 4.66226d);
        vMeth(-119.144f, iFld, this.dFld);
        int i6 = -5;
        int i7 = 45436;
        int i8 = 13376;
        short s2 = -18705;
        short s3 = -9;
        float f3 = -76.997f;
        if (!bFld) {
            i = 97;
            i2 = 24102;
            i3 = 22778;
            f = -10.329f;
            i4 = 0;
        } else {
            int i9 = 1;
            i4 = 0;
            while (true) {
                i2 = 4;
                while (112 > i2) {
                    int i10 = iFld << i2;
                    iFld = i10;
                    boolean z = bFld;
                    if (z) {
                        s2 = (short) i10;
                        instanceCount %= 5;
                        i6 += (int) (-2.303f);
                    } else if (z) {
                        iFld = i10 >>> i2;
                    }
                    i2++;
                }
                int i11 = 1;
                while (112 > i11) {
                    int[] iArr = this.iArrFld;
                    iArr[i9] = iArr[i9] << i6;
                    instanceCount = i9;
                    i11++;
                }
                short[] sArr = this.sArrFld;
                int i12 = i9 - 1;
                sArr[i12] = (short) (sArr[i12] - s3);
                iFld -= i9;
                double d = this.dFld;
                f2 = f3;
                double d2 = i6;
                Double.isNaN(d2);
                this.dFld = d - d2;
                int[] iArr2 = this.iArrFld;
                i = i9 + 1;
                i5 = i11;
                iArr2[i] = iArr2[i] + ((int) instanceCount);
                f = i9;
                while (112.0f > f) {
                    f2 -= s2;
                    i4 = (i4 + ((int) (f - i6))) - 117;
                    instanceCount = instanceCount + (((float) r13) * f);
                    i7 -= i4;
                    f += 1.0f;
                    s2 = s2;
                    i8 = 1;
                }
                s = s2;
                if (i >= 225) {
                    break;
                }
                i9 = i;
                s2 = s;
                f3 = f2;
                s3 = -9;
            }
            s2 = s;
            i3 = i5;
            f3 = f2;
        }
        FuzzerUtils.out.println("i25 i26 i27 = " + i + "," + i2 + "," + i6);
        FuzzerUtils.out.println("s2 i28 i29 = " + ((int) s2) + "," + i3 + ",29350");
        FuzzerUtils.out.println("by1 f4 i30 = -9," + Float.floatToIntBits(f) + "," + i7);
        FuzzerUtils.out.println("f5 i31 i32 = " + Float.floatToIntBits(f3) + "," + i8 + "," + i4);
        PrintStream printStream = FuzzerUtils.out;
        long doubleToLongBits = Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
        StringBuilder sb = new StringBuilder();
        sb.append("dArr = ");
        sb.append(doubleToLongBits);
        printStream.println(sb.toString());
        PrintStream printStream2 = FuzzerUtils.out;
        long j = instanceCount;
        int i13 = bFld ? 1 : 0;
        printStream2.println("Test.instanceCount Test.bFld Test.iFld = " + j + "," + i13 + "," + iFld);
        FuzzerUtils.out.println("dFld iArrFld sArrFld = " + Double.doubleToLongBits(this.dFld) + "," + FuzzerUtils.checkSum(this.iArrFld) + "," + FuzzerUtils.checkSum(this.sArrFld));
        PrintStream printStream3 = FuzzerUtils.out;
        long j2 = vMeth2_check_sum;
        StringBuilder sb2 = new StringBuilder();
        sb2.append("vMeth2_check_sum: ");
        sb2.append(j2);
        printStream3.println(sb2.toString());
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

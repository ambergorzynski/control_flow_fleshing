package defpackage;

import java.io.PrintStream;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_39/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public static long iMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = -7211750700865241249L;
    public static int iFld = 148;
    public static volatile float fFld = 100.279f;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 91);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r8v13 */
    /* JADX WARN: Type inference failed for: r8v14 */
    /* JADX WARN: Type inference failed for: r8v15, types: [int] */
    /* JADX WARN: Type inference failed for: r8v16 */
    /* JADX WARN: Type inference failed for: r8v17 */
    /* JADX WARN: Type inference failed for: r8v18 */
    /* JADX WARN: Type inference failed for: r8v19 */
    /* JADX WARN: Type inference failed for: r9v2 */
    /* JADX WARN: Type inference failed for: r9v3, types: [int] */
    /* JADX WARN: Type inference failed for: r9v5, types: [int] */
    /* JADX WARN: Type inference failed for: r9v6 */
    public static int iMeth() {
        ?? r8;
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr, 60);
        FuzzerUtils.init(jArr, 62L);
        short s = 32442;
        int i = 11;
        while (323 > i) {
            s = (short) (s + ((short) i));
            i++;
        }
        int i2 = 7;
        int i3 = 48941;
        short s2 = -47;
        int i4 = 4;
        int i5 = -5;
        int i6 = -14;
        int i7 = 3;
        long j = 3829236259L;
        float f = -2.973f;
        float f2 = 13.226f;
        long j2 = 7;
        int i8 = 7;
        while (243 > j2) {
            ?? r9 = s2;
            int i9 = i8;
            float f3 = f2;
            float f4 = f;
            long j3 = j;
            int i10 = i7;
            int i11 = i6;
            int i12 = i5;
            int i13 = 1;
            short s3 = s2;
            while (i2 > i13) {
                s = (short) r9;
                int i14 = i9 / (r9 | 1);
                short s4 = s3;
                switch ((int) ((j2 % 7) + 35)) {
                    case 35:
                        iArr[i13 - 1] = (int) j3;
                        f4 = 1.0f;
                        while (f4 < 2.0f) {
                            f4 += 1.0f;
                        }
                        iArr[i13 + 1] = 42244;
                        i11 = 2;
                        i9 = (int) (i14 + (((1 * f4) + ((float) r9)) - s));
                        r8 = s4;
                        break;
                    case 36:
                        r9 -= i12;
                        i9 = i14;
                        r8 = s4;
                        break;
                    case 37:
                        r8 = s4 - s;
                        i9 = i14;
                        break;
                    case 38:
                        f3 += i13;
                    case 39:
                        i12 += i13;
                    case 40:
                        i10 = (int) 2.45909d;
                        i9 = i14;
                        r8 = s4;
                        break;
                    case 41:
                        instanceCount = -9L;
                        i9 = i14;
                        r8 = s4;
                        break;
                    default:
                        j3 = i12;
                        i9 = i14;
                        r8 = s4;
                        break;
                }
                i13++;
                i2 = 7;
                s3 = r8;
            }
            short s5 = s3;
            j2++;
            s2 = r9;
            i4 = i13;
            i5 = i12;
            i6 = i11;
            i7 = i10;
            j = j3;
            f = f4;
            f2 = f3;
            i8 = i9;
            i3 = s5;
            i2 = 7;
        }
        long floatToIntBits = i + i3 + s + j2 + s2 + i4 + i8 + j + Float.floatToIntBits(f) + i5 + Double.doubleToLongBits(2.45909d) + i6 + Float.floatToIntBits(f2) + i7 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth1() {
        int i = -1;
        int i2 = 160;
        while (i2 > 3) {
            i = iMeth();
            i2 -= 2;
        }
        vMeth1_check_sum += (((((((i2 + (i - 42180)) + 152) - 29639) + 1) - 65223) + Double.doubleToLongBits(1.0d)) - 8) + Float.floatToIntBits(-14.61f);
    }

    public static void vMeth(int i, long j, int i2) {
        vMeth1();
        vMeth_check_sum += i + j + i2 + ((-14) >> ((int) instanceCount));
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(iArr, 5);
        FuzzerUtils.init(jArr, 53L);
        FuzzerUtils.init(fArr, -123.64f);
        int i = iFld;
        vMeth(i, -13L, i);
        int i2 = 9;
        for (int i3 = 0; i3 < 400; i3++) {
            int i4 = iArr[i3] >>> 1;
            int i5 = ((i4 % 4) * 5) + 37;
            if (i5 == 46) {
                int i6 = i4 % N;
                iArr[i6] = iArr[i6] + 4855;
                i2 = 2;
                while (i2 < 63) {
                    int i7 = iFld >> i2;
                    iFld = i7;
                    int i8 = i7 + i7;
                    iFld = i8;
                    instanceCount += (i2 * i2) - 95;
                    iFld = i8 << 826460940;
                    i2++;
                }
            } else if (i5 == 51) {
                iFld &= -181;
            } else if (i5 == 56) {
                int i9 = (i2 >>> 1) % N;
                fArr[i9] = fArr[i9] + ((float) instanceCount);
            } else {
                int[] iArr2 = iArrFld;
                iArr2[309] = iArr2[309] * i2;
            }
        }
        FuzzerUtils.out.println("i19 i20 i21 = " + i2 + ",-6,10");
        FuzzerUtils.out.println("i22 i23 by = -253,1440,69");
        FuzzerUtils.out.println("s1 i24 i25 = -263,-6,113");
        FuzzerUtils.out.println("b1 iArr1 lArr1 = 1," + FuzzerUtils.checkSum(iArr) + "," + FuzzerUtils.checkSum(jArr));
        PrintStream printStream = FuzzerUtils.out;
        long doubleToLongBits = Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
        StringBuilder sb = new StringBuilder();
        sb.append("fArr = ");
        sb.append(doubleToLongBits);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(fFld));
        PrintStream printStream2 = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(iArrFld);
        StringBuilder sb2 = new StringBuilder();
        sb2.append("Test.iArrFld = ");
        sb2.append(checkSum);
        printStream2.println(sb2.toString());
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

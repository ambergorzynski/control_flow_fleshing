
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_86/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long sMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vSmallMeth_check_sum;
    public double dFld = 2.37892d;
    public static long instanceCount = 232;
    public static volatile float fFld = -86.991f;
    public static final int N = 400;
    public static byte[] byArrFld = new byte[N];
    public static short[][] sArrFld = (short[][]) Array.newInstance((Class<?>) short.class, N, N);

    static {
        FuzzerUtils.init(byArrFld, (byte) -97);
        FuzzerUtils.init(sArrFld, (short) 5519);
        vSmallMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        sMeth_check_sum = 0L;
    }

    public static short sMeth() {
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(iArr, -18910);
        FuzzerUtils.init(fArr, 0.48f);
        int i = 7;
        int i2 = 30252;
        int i3 = -239;
        long j = -134;
        double d = -123.39129d;
        int i4 = 1;
        while (i4 < 316) {
            byte[] bArr = byArrFld;
            bArr[i4] = (byte) (bArr[i4] - ((byte) instanceCount));
            j = i4;
            while (j < 5) {
                double d2 = 41117;
                Double.isNaN(d2);
                d += d2;
                float f = (float) j;
                i2 += (int) (((fFld * f) + f) - 41117);
                j++;
                i = 1;
                i3 = 1;
            }
            i4++;
        }
        long doubleToLongBits = ((((((((((((i4 + 41117) + j) - 104) + Double.doubleToLongBits(d)) + i) + i2) + i3) + 218) + 2699) - 3245) + 1) - 9) + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
        sMeth_check_sum += doubleToLongBits;
        return (short) doubleToLongBits;
    }

    public static void vMeth(int i, int i2) {
        vMeth_check_sum += ((i2 * ((int) ((fFld + sMeth()) * (-4560)))) + 2456) - 4560;
    }

    public static void vSmallMeth() {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 13243);
        int i = iArr[76] - 1;
        iArr[76] = i;
        int abs = Math.abs(i) * 16953;
        vMeth(abs, abs);
        vSmallMeth_check_sum += abs + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int i;
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr, -49280);
        FuzzerUtils.init(jArr, -1014568331L);
        for (int i2 = 0; i2 < 482; i2++) {
            vSmallMeth();
        }
        int i3 = -7;
        int i4 = -10;
        int i5 = -65056;
        int i6 = -9;
        int i7 = 102;
        int i8 = 228;
        float f = -103.334f;
        int i9 = 5;
        while (133 > i9) {
            instanceCount = i3;
            float f2 = f;
            int i10 = i8;
            int i11 = i7;
            int i12 = i6;
            int i13 = i5;
            int i14 = 12;
            while (i14 < 196) {
                i3 -= 23;
                long j = instanceCount;
                i13 <<= (int) j;
                int i15 = i14 + 1;
                iArr[i15] = i9;
                if (i14 >= 2) {
                    i = i14;
                } else {
                    i = i14;
                    f2 += (float) (((i14 * i14) + j) - i13);
                    instanceCount = j - j;
                }
                int i16 = ((i % 7) * 5) + 74;
                if (i16 == 79) {
                    short[][] sArr = sArrFld;
                    sArr[i15] = sArr[i - 1];
                } else if (i16 == 96) {
                    iArr[i9] = i3;
                    this.dFld = 32308;
                    i13 -= (int) instanceCount;
                    jArr[i15] = 110;
                } else {
                    if (i16 != 103) {
                        if (i16 != 108) {
                            switch (i16) {
                                case 81:
                                    i13 <<= -1088928052;
                                    break;
                                case 82:
                                    instanceCount = -55227L;
                                    break;
                                case 83:
                                    i11 = 2;
                                    break;
                            }
                        }
                    } else {
                        int i17 = 1;
                        while (i17 < 2) {
                            jArr[i17 - 1] = i17;
                            iArr[i17] = iArr[i17] - i11;
                            i17++;
                            i13 = 12;
                        }
                        i10 = i17;
                    }
                    i3 &= (int) instanceCount;
                    instanceCount = -55227L;
                }
                i14 = i15;
                i12 = i;
            }
            int i18 = i14;
            i9++;
            i5 = i13;
            i6 = i12;
            i7 = i11;
            i8 = i10;
            f = f2;
            i4 = i18;
        }
        FuzzerUtils.out.println("i11 i12 i13 = " + i9 + "," + i3 + "," + i4);
        FuzzerUtils.out.println("i14 i15 i16 = " + i5 + "," + i6 + ",2829");
        FuzzerUtils.out.println("f b1 i17 = " + Float.floatToIntBits(f) + ",0," + i7);
        FuzzerUtils.out.println("s2 i18 i19 = 32308," + i8 + ",27748");
        FuzzerUtils.out.println("iArr2 lArr = " + FuzzerUtils.checkSum(iArr) + "," + FuzzerUtils.checkSum(jArr));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld dFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("Test.byArrFld Test.sArrFld = " + FuzzerUtils.checkSum(byArrFld) + "," + FuzzerUtils.checkSum(sArrFld));
        FuzzerUtils.out.println("sMeth_check_sum: " + sMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

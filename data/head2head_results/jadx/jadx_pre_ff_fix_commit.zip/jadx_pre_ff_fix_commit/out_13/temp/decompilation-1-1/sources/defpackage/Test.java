package defpackage;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_13/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -10;
    public static long vSmallMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;

    public static void vMeth1(int i) {
        int i2;
        int[] iArr = new int[N];
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(iArr, -4);
        FuzzerUtils.init(zArr, false);
        int i3 = 1;
        while (true) {
            iArr[i3] = i;
            i2 = i3 + 1;
            iArr[i2] = i3;
            if (i2 >= 259) {
                break;
            } else {
                i3 = i2;
            }
        }
        int i4 = -2080374784;
        byte b = -20;
        int i5 = 1;
        do {
            i4 += i5 * i5;
            b = (byte) (b << ((byte) i2));
            i5 += 3;
        } while (i5 < 231);
        vMeth1_check_sum += ((((((((i + i2) + i4) + Float.floatToIntBits(2.71f)) + i5) + b) + 1) + 60) - 178) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(zArr);
    }

    public static void vMeth(int i, double d) {
        float[] fArr = new float[N];
        int[] iArr = new int[N];
        FuzzerUtils.init(fArr, 75.466f);
        FuzzerUtils.init(iArr, 11047);
        vMeth1(i);
        instanceCount = 2.555f;
        byte b = (byte) i;
        int i2 = i << i;
        int i3 = 3;
        int i4 = -12;
        int i5 = 10;
        while (i5 < 275) {
            i3 = 1;
            while (i3 < 6) {
                i4 = 2;
                i3++;
            }
            i5++;
        }
        vMeth_check_sum += ((((((((((i2 + Double.doubleToLongBits(d)) + Float.floatToIntBits(2.555f)) + b) + i5) - 21407) + i3) - 5) + i4) + 12) - 27391) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(iArr);
    }

    public static void vSmallMeth(int i) {
        vMeth(i, 75.98246d);
        vSmallMeth_check_sum += i + Double.doubleToLongBits(75.98246d);
    }

    public void mainTest(String[] strArr) {
        for (int i = 0; i < 349; i++) {
            vSmallMeth(3);
        }
        long j = instanceCount;
        instanceCount = j + j;
        FuzzerUtils.out.println("i14 = 3");
        FuzzerUtils.out.println("Test.instanceCount = " + instanceCount);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

package defpackage;

import java.io.PrintStream;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_70/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long fMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = 81994945733705874L;
    public static byte byFld = 76;
    public static float fFld = -114.63f;
    public static short sFld = -3279;
    public static volatile boolean bFld = true;
    public static double dFld = 1.23986d;
    public static final int N = 400;
    public static volatile long[] lArrFld = new long[N];

    static {
        FuzzerUtils.init(lArrFld, -12056L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        fMeth_check_sum = 0L;
    }

    public static float fMeth(short s, int i, int i2) {
        int[] iArr = new int[N];
        int[] iArr2 = new int[N];
        FuzzerUtils.init(iArr, -6);
        FuzzerUtils.init(iArr2, 8);
        int i3 = i;
        long j = 12933;
        int i4 = 8;
        int i5 = -61;
        float f = 172.0f;
        while (f > 6.0f) {
            int i6 = i4 | s;
            int i7 = (int) (f + 1.0f);
            iArr[i7] = iArr[i7] >> i6;
            fFld += i6;
            long j2 = instanceCount;
            int i8 = (int) j2;
            instanceCount = j2 / (j2 | 1);
            long j3 = 1;
            do {
                i8 -= (int) j3;
                i3 += i3;
                j3++;
            } while (j3 < 10);
            f -= 1.0f;
            i4 = i8;
            j = j3;
            i5 = 2;
        }
        long floatToIntBits = s + i3 + i2 + Float.floatToIntBits(f) + i4 + j + i5 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(iArr2);
        fMeth_check_sum += floatToIntBits;
        return (float) floatToIntBits;
    }

    public static void vMeth1(long j, int i, double d) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -8);
        float f = iArr[(i >>> 1) % N];
        int i2 = 69;
        int i3 = 169;
        while (i3 > 7) {
            f += i3 * i3;
            iArr[i3 + 1] = (int) f;
            i2 |= byFld;
            i3--;
        }
        int i4 = i;
        double d2 = 2.114438d;
        int i5 = 5;
        int i6 = -120;
        int i7 = -19354;
        while (i5 < 184) {
            fMeth(sFld, -109, i3);
            int i8 = i6 + i5;
            double d3 = 9.0d;
            while (true) {
                lArrFld[(int) d3] = fFld;
                if (bFld) {
                    d2 = d3;
                    break;
                }
                d3 -= 3.0d;
                if (d3 <= 0.0d) {
                    i4 = i2;
                    d2 = d3;
                    break;
                }
                i4 = i2;
            }
            i6 = i8;
            i7 = 1;
            while (9 > i7) {
                long j2 = byFld * i7;
                long j3 = instanceCount;
                i6 = (int) (i6 + ((j2 + j3) - j3));
                i7++;
                iArr[i7] = i4;
            }
            i5++;
        }
        vMeth1_check_sum += j + i4 + Double.doubleToLongBits(d) + Float.floatToIntBits(f) + i3 + i2 + i5 + i6 + Double.doubleToLongBits(d2) + i7 + 8 + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth() {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 12L);
        FuzzerUtils.init(iArr, 41);
        long j = instanceCount + 1;
        instanceCount = j;
        jArr[63] = j;
        int i = 127;
        vMeth1(j, 127, dFld);
        instanceCount -= 127;
        int i2 = 1;
        while (true) {
            i2++;
            if (i2 < 259) {
                if (!bFld) {
                    dFld = i2;
                }
                i = i2;
            } else {
                float f = i;
                fFld = f;
                int i3 = (i >>> 1) % N;
                iArr[i3] = iArr[i3] - ((int) f);
                iArr[i3] = 39900;
                long j2 = i2;
                jArr[6] = jArr[6] - j2;
                instanceCount = j2;
                int i4 = (int) j2;
                vMeth_check_sum += (i4 - i4) + i2 + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr);
                return;
            }
        }
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -4);
        vMeth();
        int i = 14;
        long j = 309;
        int i2 = 14;
        int i3 = -212;
        int i4 = -15563;
        int i5 = -146;
        int i6 = 7;
        int i7 = 134400;
        while (j > 2) {
            fFld *= (float) instanceCount;
            byFld = (byte) (byFld * ((byte) i7));
            int i8 = (int) j;
            int i9 = i5;
            int i10 = i4;
            int i11 = i8;
            while (i11 < 246) {
                dFld = 2.0d;
                iArr[i8] = sFld;
                byFld = (byte) (byFld + ((byte) i11));
                instanceCount += ((i2 * i11) + i7) - j;
                fFld = 1.64317244E18f;
                i11++;
                i9 = 1;
                i2 = -21;
                i10 = -21;
            }
            double d = dFld;
            double d2 = i10;
            Double.isNaN(d2);
            dFld = d - d2;
            i7 = i10 + ((int) (j * j));
            int i12 = i7;
            i6 = 246;
            while (i6 > 6) {
                i -= byFld;
                i6--;
                i12 = i8;
            }
            instanceCount |= j;
            j -= 3;
            i3 = i11;
            i5 = i9;
            i4 = i12;
            i2 = -76;
        }
        int i13 = (i4 >>> 1) % N;
        iArr[i13] = iArr[i13] * i7;
        FuzzerUtils.out.println("i13 l2 i14 = " + i + "," + j + "," + i2);
        FuzzerUtils.out.println("i15 i16 i17 = " + i3 + "," + i4 + "," + i5);
        FuzzerUtils.out.println("i18 i19 i20 = " + i + ",56965," + i6);
        FuzzerUtils.out.println("i21 iArr4 = -76," + FuzzerUtils.checkSum(iArr));
        PrintStream printStream = FuzzerUtils.out;
        long j2 = instanceCount;
        byte b = byFld;
        printStream.println("Test.instanceCount Test.byFld Test.fFld = " + j2 + "," + ((int) b) + "," + Float.floatToIntBits(fFld));
        PrintStream printStream2 = FuzzerUtils.out;
        short s = sFld;
        boolean z = bFld;
        printStream2.println("Test.sFld Test.bFld Test.dFld = " + ((int) s) + "," + (z ? 1 : 0) + "," + Double.doubleToLongBits(dFld));
        PrintStream printStream3 = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(lArrFld);
        StringBuilder sb = new StringBuilder();
        sb.append("Test.lArrFld = ");
        sb.append(checkSum);
        printStream3.println(sb.toString());
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

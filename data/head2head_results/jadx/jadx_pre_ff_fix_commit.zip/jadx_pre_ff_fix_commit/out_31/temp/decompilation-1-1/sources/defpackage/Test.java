package defpackage;

import java.io.PrintStream;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_31/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public static long iMeth_check_sum;
    public static long[] lArrFld;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = 137;
    public static int iFld = -95;
    public static int iFld1 = 40107;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        lArrFld = new long[N];
        FuzzerUtils.init(iArr, 0);
        FuzzerUtils.init(lArrFld, 44848L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
    }

    public static void vMeth1(int i) {
        instanceCount = (long) 6.5522d;
        vMeth1_check_sum += i + Double.doubleToLongBits(6.5522d);
    }

    public static int iMeth(double d, int i) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 63525);
        vMeth1(i);
        int i2 = 13329;
        int i3 = -9441;
        int i4 = -27921;
        int i5 = -14;
        long j = -14;
        int i6 = 7;
        while (i6 < 223) {
            j = 7;
            while (i6 < j) {
                d = i;
                long j2 = instanceCount;
                i = (int) j2;
                i3 = (int) j2;
                int i7 = i6 + 1;
                iArr[i7] = iArr[i7] + ((int) (-2.108f));
                i2 &= iFld;
                j--;
            }
            i5 = (int) j;
            i6++;
            i4 = 1;
        }
        long doubleToLongBits = Double.doubleToLongBits(d) + i + i6 + i2 + j + i3 + Float.floatToIntBits(-2.108f) + i4 + i5 + 1 + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static void vMeth(float f) {
        int i = 7;
        int i2 = 3;
        int i3 = -15060;
        int i4 = 8;
        int i5 = 5;
        while (i4 < 324) {
            vMeth1(iMeth(0.120648d, iFld));
            int i6 = iFld;
            if ((((i6 >>> 1) % 1) * 5) + 88 == 93) {
                instanceCount *= -21;
                int[] iArr = iArrFld;
                iArr[i4] = iArr[i4] - 22742;
                try {
                    i = i6 % i6;
                    iArr[i4 + 1] = i4 / iArr[i4 - 1];
                    iFld = i6 % i4;
                } catch (ArithmeticException e) {
                }
            } else {
                i2 = 1;
                while (i2 < 5) {
                    float f2 = i;
                    float f3 = i2;
                    i = (int) (f2 + (((f3 * f) + iFld) - f2));
                    i5 += i2 * i2;
                    f -= f;
                    int i7 = 1;
                    while (i7 < 2) {
                        i *= (int) 0.120648d;
                        long[] jArr = lArrFld;
                        long j = instanceCount;
                        jArr[i7] = j;
                        f = f3 - ((float) j);
                        i7++;
                    }
                    i2++;
                    i3 = i7;
                }
            }
            i4++;
        }
        vMeth_check_sum += Float.floatToIntBits(f) + i4 + i + Double.doubleToLongBits(0.120648d) + i2 + i5 + i3 + 57;
    }

    public void mainTest(String[] strArr) {
        int i;
        boolean[] zArr = new boolean[N];
        boolean z = true;
        FuzzerUtils.init(zArr, true);
        int i2 = -90;
        int i3 = -122;
        int i4 = 172;
        int i5 = -215;
        int i6 = 13637;
        int i7 = 12;
        int i8 = -11;
        double d = 102.212d;
        byte b = -127;
        int i9 = 8;
        int i10 = 9;
        while (i9 < 133) {
            i3 = 7;
            while (true) {
                if (201 <= i3) {
                    break;
                }
                vMeth(2.41f);
                i3++;
            }
            i5 = 5;
            while (i5 < 201) {
                d -= 10.0d;
                iFld += iFld1 * i5;
                iArrFld[i5 - 1] = (int) 2.41f;
                i5++;
                i4 = -32118;
            }
            int[] iArr = iArrFld;
            iArr[i9] = iArr[i9] << 11;
            long j = instanceCount + 2.41f;
            instanceCount = j;
            instanceCount = j >> (-54927);
            zArr[i9] = z;
            i7 = i7;
            i6 = 9;
            int i11 = 10955;
            for (i = 201; i > i6; i = 201) {
                if ((i6 % 1) + 38 == 38) {
                    int i12 = (int) instanceCount;
                    i7 = i9;
                    while (2 > i7) {
                        d = 2.41f;
                        i4 >>>= iFld;
                        i8 = iFld1;
                        i7++;
                    }
                    i11 = (int) d;
                    i10 = i12;
                }
                b = (byte) (b / ((byte) (instanceCount | 1)));
                i6++;
            }
            i9++;
            i2 = i11;
            z = true;
        }
        int i13 = i7;
        long[] jArr = lArrFld;
        int i14 = (i13 >>> 1) % N;
        long j2 = jArr[i14];
        long j3 = instanceCount;
        jArr[i14] = j2 + j3;
        int[] iArr2 = iArrFld;
        iArr2[125] = iArr2[125] << ((int) j3);
        int i15 = (i8 >>> 1) % N;
        jArr[i15] = jArr[i15] >> i2;
        FuzzerUtils.out.println("i i1 i2 = " + i9 + "," + (i2 ^ i9) + "," + i3);
        FuzzerUtils.out.println("i3 f2 i17 = " + i4 + "," + Float.floatToIntBits((float) j3) + "," + i5);
        FuzzerUtils.out.println("i18 d3 s = -7," + Double.doubleToLongBits(d) + ",-8778");
        FuzzerUtils.out.println("b1 i20 i21 = 1," + i6 + "," + i10);
        FuzzerUtils.out.println("i22 i23 by = " + i13 + "," + i8 + "," + ((int) b));
        PrintStream printStream = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(zArr);
        StringBuilder sb = new StringBuilder();
        sb.append("bArr = ");
        sb.append(checkSum);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.iFld1 = " + instanceCount + "," + iFld + "," + iFld1);
        FuzzerUtils.out.println("Test.iArrFld Test.lArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

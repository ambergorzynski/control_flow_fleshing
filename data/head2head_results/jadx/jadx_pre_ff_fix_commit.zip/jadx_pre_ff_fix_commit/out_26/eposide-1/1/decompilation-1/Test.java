
import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_26/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long fMeth_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = -39077;
    public static int iFld = 135;
    public static int iFld1 = 14623;
    public static float fFld = 0.997f;
    public static int iFld2 = 8;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static long[][] lArrFld = (long[][]) Array.newInstance((Class<?>) long.class, N, N);

    static {
        FuzzerUtils.init(iArrFld, 8);
        FuzzerUtils.init(lArrFld, 3510373190503364430L);
        fMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }

    public static void vMeth(boolean z) {
        int[] iArr = iArrFld;
        int length = iArr.length;
        float f = 1.54f;
        byte b = -77;
        int i = 0;
        while (i < length) {
            int i2 = iArr[i];
            long[][] jArr = lArrFld;
            int i3 = (i2 >>> 1) % N;
            jArr[i3][i3] = 185;
            float f2 = 1.0f;
            while (true) {
                f2 += 1.0f;
                if (f2 < 4.0f) {
                    int i4 = (int) f2;
                    b = (byte) (b + ((byte) i4));
                    lArrFld[i4][(int) (f2 - 1.0f)] = i2;
                }
            }
            i++;
            f = f2;
        }
        vMeth_check_sum += (z ? 1 : 0) + Float.floatToIntBits(f) + b;
    }

    public static int iMeth(int i, long j) {
        int i2;
        double[] dArr = new double[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, 96.676f);
        FuzzerUtils.init(dArr, -83.111089d);
        vMeth(true);
        int i3 = 1;
        do {
            i2 = 1;
            while (true) {
                i2++;
                if (i2 >= 5) {
                    break;
                }
                try {
                    iFld = iArrFld[i3] / (-944698204);
                    iFld = i % 545156714;
                    int i4 = i2 % i2;
                } catch (ArithmeticException e) {
                }
                i = iFld;
                fArr[i2] = fArr[i2] - 17794;
                int i5 = i ^ i2;
                iFld = i5;
                iFld = i5 * 0;
            }
            i3++;
        } while (i3 < 325);
        long doubleToLongBits = (((((i + j) + 1) + i3) + i2) - 17794) + Double.doubleToLongBits(78.45499d) + 8 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static float fMeth(int i, double d, short s) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 0);
        int i2 = -61034;
        int i3 = 13;
        while (true) {
            i3--;
            if (i3 > 0) {
                int i4 = i3 - 1;
                int i5 = iArr[i4] + 1;
                iArr[i4] = i5;
                i += i5;
                i2 = 1;
            } else {
                long doubleToLongBits = ((((i + Double.doubleToLongBits(d)) + s) + 7) - 205) + i3 + i2 + 14 + 1 + FuzzerUtils.checkSum(iArr);
                fMeth_check_sum += doubleToLongBits;
                return (float) doubleToLongBits;
            }
        }
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        int i3;
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(zArr, true);
        iFld *= (int) fMeth(iFld1, 0.59363d, (short) 3870);
        long j = -4005793888L;
        int i4 = -11;
        int i5 = 49437;
        int i6 = 21431;
        long j2 = 1;
        while (true) {
            i = 5;
            int i7 = i5;
            i2 = i4;
            i3 = i7;
            while (i < 82) {
                try {
                    iArrFld[i] = iFld / 227;
                    int i8 = 35562 / i;
                    iFld = i8;
                    i2 = 92 % i8;
                } catch (ArithmeticException e) {
                }
                int i9 = iFld1;
                iFld1 = i9 - i9;
                fFld -= i2;
                int i10 = i6;
                long j3 = j;
                int i11 = 1;
                while (i11 < 2) {
                    int i12 = iFld;
                    try {
                        iFld = i / iFld1;
                        i12 = iFld1 % i11;
                        iFld = i11 / iArrFld[(int) (j2 - 1)];
                    } catch (ArithmeticException e2) {
                    }
                    i10 = i12 - ((int) fFld);
                    float f = iFld2;
                    fFld = f;
                    j3 = (j3 - f) - f;
                    iFld *= 2;
                    instanceCount = iFld1;
                    i11++;
                    i2 = i2;
                }
                i++;
                i6 = i10;
                i3 = i11;
                j = j3;
            }
            j2++;
            if (j2 >= 307) {
                break;
            }
            int i13 = i2;
            i5 = i3;
            i4 = i13;
        }
        iFld2 = iFld;
        iFld1 = i2;
        int i14 = 7;
        int i15 = 152;
        int i16 = 48784;
        while (i14 < 133) {
            int i17 = iFld1;
            i2 *= i17;
            int[] iArr = iArrFld;
            i14++;
            iArr[i14] = iArr[i14] << i17;
            i15 = 1;
            while (true) {
                i15++;
                if (i15 < 199) {
                    iArrFld[i15] = -39027;
                    i16 = 1;
                }
            }
        }
        FuzzerUtils.out.println("d2 s2 l1 = " + Double.doubleToLongBits(0.59363d) + ",3870," + j2);
        FuzzerUtils.out.println("i11 i12 i13 = " + i + "," + i2 + "," + i3);
        FuzzerUtils.out.println("i14 l2 i15 = " + i6 + "," + j + "," + i14);
        FuzzerUtils.out.println("i16 i17 i18 = -14410," + i15 + "," + i16);
        FuzzerUtils.out.println("i19 b3 bArr = -166,1," + FuzzerUtils.checkSum(zArr));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.iFld1 = " + instanceCount + "," + iFld + "," + iFld1);
        FuzzerUtils.out.println("Test.fFld Test.iFld2 Test.iArrFld = " + Float.floatToIntBits(fFld) + "," + iFld2 + "," + FuzzerUtils.checkSum(iArrFld));
        PrintStream printStream = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(lArrFld);
        StringBuilder sb = new StringBuilder();
        sb.append("Test.lArrFld = ");
        sb.append(checkSum);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

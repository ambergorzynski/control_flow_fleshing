package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_66/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long iMeth1_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public long[] lArrFld = new long[N];
    public static long instanceCount = -149;
    public static float fFld = 0.553f;
    public static byte byFld = -74;
    public static double dFld = 71.116644d;
    public static boolean bFld = false;
    public static final int N = 400;
    public static volatile int[] iArrFld = new int[N];

    static {
        FuzzerUtils.init(iArrFld, 13);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
    }

    public static int iMeth1() {
        int[] iArr = new int[N];
        byte[] bArr = new byte[N];
        FuzzerUtils.init(bArr, (byte) -30);
        FuzzerUtils.init(iArr, -42549);
        int i = -31117;
        int i2 = -109;
        int i3 = 42060;
        int i4 = -11106;
        int i5 = -13980;
        int i6 = 1;
        while (true) {
            i6++;
            if (i6 < 388) {
                int i7 = (int) (i + i6 + instanceCount);
                bArr[i6] = (byte) 2942650806L;
                i4 = 1;
                while (true) {
                    iArr[i4 - 1] = byFld;
                    i2 = i4 + 1;
                    if (i2 >= 4) {
                        break;
                    }
                    i4 = i2;
                }
                i = i7;
                i3 = 1;
                i5 = 1;
            } else {
                long doubleToLongBits = i6 + i + 2942650806L + i2 + i3 + i4 + 0 + Double.doubleToLongBits(62.43747d) + i5 + 2 + FuzzerUtils.checkSum(bArr) + FuzzerUtils.checkSum(iArr);
                iMeth1_check_sum += doubleToLongBits;
                return (int) doubleToLongBits;
            }
        }
    }

    public static int iMeth(double d, byte b, long j) {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr, -1);
        FuzzerUtils.init(jArr, 130L);
        float f = -15452;
        fFld = fFld + 1.0f;
        int iMeth1 = iMeth1() | (((int) ((f - r7) + f)) - 15452);
        long j2 = instanceCount * 19;
        instanceCount = j2;
        int i = (iMeth1 - 9) * ((int) j2);
        int i2 = -13401;
        int i3 = 109;
        int i4 = 312;
        while (i4 > 13) {
            iArr[i4 - 1] = i4;
            i3 = 1;
            while (i3 < 6) {
                fFld = (float) j;
                i2 = i - ((int) d);
                iArr[i4 + 1] = -38;
                i3++;
            }
            i4--;
        }
        double d2 = 21.0d;
        while (d2 < 398.0d) {
            fFld += (float) j;
            d2 += 1.0d;
        }
        int i5 = (i3 >>> 1) % N;
        long j3 = i4;
        jArr[i5] = jArr[i5] - j3;
        long doubleToLongBits = Double.doubleToLongBits(d) + b + j + i + j3 + i2 + i3 + 0 + Double.doubleToLongBits(d2) + 82 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static void vMeth() {
        int i;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 231);
        int i2 = (int) instanceCount;
        int i3 = -11668;
        short s = -23002;
        int i4 = 314;
        while (i4 > 3) {
            i3 += s * iMeth(0.69251d, byFld, instanceCount);
            i4--;
            s = (short) (s - 1);
        }
        int i5 = 12;
        int i6 = -27067;
        int i7 = 1;
        do {
            instanceCount += i7;
            iArr[i7] = i4;
            i = 1;
            while (i < 4) {
                i5 <<= (int) instanceCount;
                i++;
                i6 = -1;
            }
            i7++;
        } while (i7 < 391);
        vMeth_check_sum += i2 + i4 + i3 + s + Double.doubleToLongBits(0.69251d) + i7 + i + i5 + i6 + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(zArr, false);
        FuzzerUtils.init(iArr, -63);
        int i = 4;
        int i2 = 27111;
        int i3 = 299;
        int i4 = 177;
        while (i3 > 14) {
            i <<= i - 1;
            vMeth();
            int i5 = 1;
            while (true) {
                i5++;
                if (i5 < 177) {
                    i -= (int) instanceCount;
                    i4 = 1;
                }
            }
            i3 -= 2;
            i2 = i5;
        }
        FuzzerUtils.out.println("i i1 i23 = " + i3 + "," + i + "," + i2);
        FuzzerUtils.out.println("i24 i25 bArr = " + i4 + ",6315," + FuzzerUtils.checkSum(zArr));
        PrintStream printStream = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(iArr);
        StringBuilder sb = new StringBuilder();
        sb.append("iArr3 = ");
        sb.append(checkSum);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.byFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + ((int) byFld));
        PrintStream printStream2 = FuzzerUtils.out;
        long doubleToLongBits = Double.doubleToLongBits(dFld);
        boolean z = bFld;
        printStream2.println("Test.dFld Test.bFld Test.iArrFld = " + doubleToLongBits + "," + (z ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld));
        PrintStream printStream3 = FuzzerUtils.out;
        long checkSum2 = FuzzerUtils.checkSum(this.lArrFld);
        StringBuilder sb2 = new StringBuilder();
        sb2.append("lArrFld = ");
        sb2.append(checkSum2);
        printStream3.println(sb2.toString());
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}


import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_56/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static long dMeth_check_sum;
    public static long[] lArrFld;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public boolean bFld = false;
    public byte byFld = -22;
    public static volatile long instanceCount = -30508;
    public static float fFld = -2.25f;
    public static int iFld = 196;

    static {
        long[] jArr = new long[N];
        lArrFld = jArr;
        FuzzerUtils.init(jArr, -8448380060350832484L);
        dMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }

    public static void vMeth1(byte b, int i, byte b2) {
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(fArr, -16.502f);
        FuzzerUtils.init(iArr, -241);
        FuzzerUtils.init(jArr, 0L);
        int i2 = (i >>> 1) % N;
        fArr[i2] = i;
        iArr[i2] = iArr[i2] + i;
        jArr[i2] = instanceCount;
        int i3 = i + ((int) (-54.71098d));
        int i4 = 63445;
        int i5 = 7;
        int i6 = 67;
        int i7 = 6;
        while (true) {
            int i8 = 1;
            if (i7 < 128) {
                int i9 = ((i7 % 2) * 5) + 24;
                if (i9 == 27) {
                    i6 = (int) instanceCount;
                } else if (i9 == 30) {
                    while (13 > i8) {
                        i8++;
                        jArr[i8] = i3;
                    }
                    if (i7 < 13) {
                        int i10 = i7 + 1;
                        iArr[i10] = iArr[i10] ^ i3;
                    }
                    i5 = i7;
                    i4 = i8;
                } else {
                    instanceCount += ((i7 * instanceCount) + instanceCount) - i3;
                }
                i7++;
            } else {
                vMeth1_check_sum += b + i3 + b2 + Double.doubleToLongBits(-54.71098d) + i7 + 30564 + i4 + 22029 + 1 + i5 + i6 + Float.floatToIntBits(-1.654f) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr);
                return;
            }
        }
    }

    public static void vMeth(long j, int i, int i2) {
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, 0.355f);
        instanceCount = i2 - 39657;
        vMeth_check_sum += (((((((((j + i) + i2) - 14) + 52502) - 36) + 252) + 44395) + 0) - 12) + 197 + Double.doubleToLongBits(-4.5380687697145293E18d) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public double dMeth(int i, double d) {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(iArr, -38);
        FuzzerUtils.init(jArr, 4723721422641378916L);
        FuzzerUtils.init(fArr, 1.32f);
        int i2 = i;
        vMeth(-71L, 215, i2);
        int i3 = -91;
        double d2 = -86.28923d;
        int i4 = -1653;
        double d3 = 2.0d;
        double d4 = d;
        while (true) {
            int i5 = 8;
            int i6 = 12475;
            if (d3 < 208.0d) {
                i4 = 1;
                while (i4 < i5) {
                    d2 = 1.0d;
                    while (d2 < 2.0d) {
                        int i7 = (int) d2;
                        iArr[i7] = iArr[i7] - i5;
                        float f = fFld;
                        float f2 = f * f;
                        fFld = f2;
                        this.bFld = false;
                        double d5 = i6;
                        Double.isNaN(d5);
                        double d6 = f2;
                        Double.isNaN(d6);
                        double d7 = (d5 * d2) + d6;
                        double d8 = 201;
                        Double.isNaN(d8);
                        fFld = f2 + ((float) (d7 - d8));
                        d2 += 1.0d;
                        d4 = 13.0d;
                        iArr = iArr;
                        i5 = 8;
                        i6 = 12475;
                    }
                    i2 = -11;
                    i4++;
                    i5 = 8;
                    i6 = 12475;
                    i3 = -51;
                }
                d3 += 1.0d;
            } else {
                int i8 = (i4 >>> 1) % N;
                long j = i4;
                jArr[i8] = jArr[i8] * j;
                fArr[4] = fArr[4] * (-5.8800299E18f);
                long doubleToLongBits = i2 + Double.doubleToLongBits(d4) + Double.doubleToLongBits(d3) + i3 + j + 8 + Double.doubleToLongBits(d2) + 201 + 12475 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
                dMeth_check_sum += doubleToLongBits;
                return doubleToLongBits;
            }
        }
    }

    public void mainTest(String[] strArr) {
        double d;
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        float[] fArr = new float[N];
        FuzzerUtils.init(iArr, -198);
        FuzzerUtils.init(fArr, 2.656f);
        double dMeth = 2.47044d - dMeth(iFld, 2.47044d);
        double d2 = 1.127365d;
        double d3 = -45.121533d;
        int i = -4112;
        int i2 = -50980;
        int i3 = 53;
        int i4 = -20979;
        int i5 = 23538;
        int i6 = -11;
        int i7 = 12;
        while (true) {
            float[] fArr2 = fArr;
            double d4 = d3;
            if (i7 < 393) {
                i2 = 3;
                while (i2 < 66) {
                    i4 = 1;
                    while (2 > i4) {
                        iFld = (int) instanceCount;
                        long[] jArr = lArrFld;
                        int i8 = i2 - 1;
                        jArr[i8] = jArr[i8] >> i3;
                        i3 += (int) ((i4 * i4) + 2);
                        iArr[i4][i8] = i4;
                        i4++;
                        i = i3;
                    }
                    i2++;
                }
                double d5 = 4.0d;
                while (d5 < 66.0d) {
                    instanceCount <<= -38;
                    i5 ^= i7;
                    int i9 = i7 - 1;
                    iArr[(int) d5][i9] = this.byFld;
                    i6 = 1;
                    while (2 > i6) {
                        double d6 = d5;
                        iFld = (int) instanceCount;
                        long[] jArr2 = lArrFld;
                        int i10 = i7 + 1;
                        jArr2[i10] = jArr2[i10] >>> ((int) instanceCount);
                        i3 += i6 - 10708;
                        long[] jArr3 = lArrFld;
                        jArr3[i9] = jArr3[i9] & instanceCount;
                        float f = fFld;
                        float f2 = f * f;
                        fFld = f2;
                        iFld += (int) f2;
                        i += i6;
                        i6++;
                        d5 = d6;
                    }
                    double d7 = d5;
                    int i11 = i;
                    instanceCount += this.byFld;
                    if (!this.bFld) {
                        d = 1.0d;
                        i = i11;
                    } else {
                        i = i11 * ((int) fFld);
                        d4 = i7;
                        while (d4 < 2.0d) {
                            double d8 = -1;
                            Double.isNaN(d8);
                            dMeth -= d8;
                            instanceCount += (long) (d4 * d4);
                            d4 += 1.0d;
                        }
                        d = 1.0d;
                    }
                    d5 = d7 + d;
                }
                i7++;
                fArr = fArr2;
                d3 = d4;
                d2 = d5;
            } else {
                FuzzerUtils.out.println("d i20 i21 = " + Double.doubleToLongBits(dMeth) + "," + i7 + "," + i);
                FuzzerUtils.out.println("i22 i23 i24 = " + i2 + "," + i3 + "," + i4);
                FuzzerUtils.out.println("i25 d6 i26 = 65376," + Double.doubleToLongBits(d2) + "," + i5);
                FuzzerUtils.out.println("i27 i28 s1 = " + i6 + ",-1,10708");
                FuzzerUtils.out.println("d7 i29 iArr2 = " + Double.doubleToLongBits(d4) + ",46142," + FuzzerUtils.checkSum(iArr));
                PrintStream printStream = FuzzerUtils.out;
                long doubleToLongBits = Double.doubleToLongBits(FuzzerUtils.checkSum(fArr2));
                StringBuilder sb = new StringBuilder();
                sb.append("fArr3 = ");
                sb.append(doubleToLongBits);
                printStream.println(sb.toString());
                FuzzerUtils.out.println("Test.instanceCount Test.fFld bFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + (this.bFld ? 1 : 0));
                PrintStream printStream2 = FuzzerUtils.out;
                int i12 = iFld;
                byte b = this.byFld;
                printStream2.println("Test.iFld byFld Test.lArrFld = " + i12 + "," + ((int) b) + "," + FuzzerUtils.checkSum(lArrFld));
                PrintStream printStream3 = FuzzerUtils.out;
                long j = vMeth1_check_sum;
                StringBuilder sb2 = new StringBuilder();
                sb2.append("vMeth1_check_sum: ");
                sb2.append(j);
                printStream3.println(sb2.toString());
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

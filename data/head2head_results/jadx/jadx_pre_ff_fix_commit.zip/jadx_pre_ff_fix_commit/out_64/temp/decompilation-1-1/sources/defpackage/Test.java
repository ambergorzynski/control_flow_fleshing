package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_64/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long iMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = 194;
    public static boolean bFld = false;
    public static volatile byte byFld = 50;
    public static int iFld = -62197;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static volatile double[] dArrFld = new double[N];

    static {
        FuzzerUtils.init(iArrFld, -29936);
        FuzzerUtils.init(dArrFld, 0.31411d);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }

    public static void vMeth1() {
        int i;
        long[][] jArr = (long[][]) Array.newInstance((Class<?>) long.class, N, N);
        FuzzerUtils.init(jArr, -127L);
        long[] jArr2 = jArr[258];
        jArr2[136] = jArr2[136] - 2916;
        int i2 = 52543;
        iArrFld[271] = 52543;
        int i3 = 152;
        int i4 = -4;
        int i5 = 9;
        float f = 2.355f;
        double d = 2.99655d;
        double d2 = -1.124659d;
        int i6 = 15;
        while (i6 < 282) {
            i2 += i6;
            f = i6;
            while (6.0f > f) {
                i3 += (int) ((((-158) * f) + i3) - ((float) instanceCount));
                instanceCount = i3;
                f += 1.0f;
            }
            d = 6.0d;
            while (true) {
                double d3 = i6;
                if (d3 < d) {
                    int i7 = 441693264 * i3;
                    int i8 = ((int) instanceCount) - i7;
                    try {
                        i = i8;
                        int i9 = i2;
                        try {
                            i2 = iArrFld[(int) (d - 1.0d)] / (-170);
                            try {
                                i5 = (-723445758) % i5;
                                i4 = i5 % 5832;
                            } catch (ArithmeticException e) {
                                i4 = i;
                                Double.isNaN(d3);
                                d2 += d3;
                                d -= 1.0d;
                                i3 = i7;
                            }
                        } catch (ArithmeticException e2) {
                            i2 = i9;
                        }
                    } catch (ArithmeticException e3) {
                        i = i8;
                    }
                    Double.isNaN(d3);
                    d2 += d3;
                    d -= 1.0d;
                    i3 = i7;
                }
            }
            i6++;
        }
        vMeth1_check_sum += (((5832 + i2) + i6) - 158) + Float.floatToIntBits(f) + i3 + Double.doubleToLongBits(d) + i4 + i5 + Double.doubleToLongBits(d2) + FuzzerUtils.checkSum(jArr);
    }

    public static int iMeth(int i, short s) {
        int i2;
        int i3;
        int i4 = i | (-3);
        short s2 = (short) (s - ((short) (iArrFld[(i >>> 1) % N] & i4)));
        vMeth1();
        int i5 = -116;
        int i6 = -196;
        long j = -6;
        int i7 = 4;
        while (i7 < 135) {
            i4 >>= 27;
            instanceCount -= i4;
            if (bFld) {
                long j2 = 12;
                do {
                    int i8 = (int) 2.125f;
                    i5 += i8;
                    i2 = ((int) j2) - i8;
                    i3 = 1;
                    while (2 > i3 && !bFld) {
                        i5 += (int) ((i3 * i3) + 0.333f);
                        i3++;
                    }
                    j2 -= 2;
                } while (j2 > 0);
                i6 = i3;
                i4 = i2;
                j = j2;
            } else {
                i5 /= (int) (((long) 0.108869d) | 1);
            }
            i7++;
        }
        long floatToIntBits = ((((((((i4 + s2) + i7) + 27) + j) + i5) + Float.floatToIntBits(2.125f)) + i6) - 7) + Double.doubleToLongBits(0.108869d);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth(int i, int i2, boolean z) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -81);
        double d = 62.126301d;
        int i3 = -13;
        int i4 = -195;
        int i5 = i;
        int i6 = i2;
        for (int i7 = 0; i7 < 400; i7++) {
            int i8 = iArr[i7];
            d = 1.0d;
            do {
                iMeth(i6, (short) 15707);
                i3 = (int) d;
                while (i3 < 1) {
                    if (i5 != 0) {
                        vMeth_check_sum += (((((i5 + i6) + (z ? 1 : 0)) + Double.doubleToLongBits(d)) + i3) - 10) + i4 + FuzzerUtils.checkSum(iArr);
                        return;
                    }
                    i5 *= i5;
                    instanceCount = i4;
                    dArrFld[i3 - 1] = 32250;
                    i4 = 1741500;
                    instanceCount += i3;
                    i3++;
                }
                dArrFld[(int) (d - 1.0d)] = byFld;
                d += 1.0d;
            } while (d < 4.0d);
            i4 = (int) instanceCount;
            i6 -= 6;
        }
        vMeth_check_sum += (((((i5 + i6) + (z ? 1 : 0)) + Double.doubleToLongBits(d)) + i3) - 10) + i4 + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        vMeth(0, 0, bFld);
        int i = -5214;
        int i2 = 58919;
        int i3 = 6;
        int i4 = 52258;
        int i5 = -5571;
        float f = -2.14f;
        float f2 = -1.134f;
        int i6 = 8;
        int i7 = 0;
        while (i6 < 157) {
            byFld = (byte) (byFld + ((byte) (((i6 * f) + i7) - i)));
            i2 = 1;
            while (i2 < 168) {
                double[] dArr = dArrFld;
                int i8 = i6 + 1;
                double d = dArr[i8];
                double d2 = instanceCount;
                Double.isNaN(d2);
                dArr[i8] = d * d2;
                f2 = 2.0f;
                i4 = 2;
                while (i4 > i2) {
                    long j = i4 * i4;
                    instanceCount += j;
                    f += (float) (j + 462733926);
                    int i9 = i7 >> i6;
                    i3 = i2 * (-10);
                    int i10 = ((i4 % 3) * 5) + 118;
                    if (i10 != 120) {
                        if (i10 == 131) {
                            i5 -= i5;
                        } else if (i10 == 133) {
                            dArrFld[i6] = instanceCount;
                            i9 += iFld;
                            bFld = true;
                            instanceCount = i5;
                        }
                        i7 = i9;
                        i4--;
                        i = -25804;
                    }
                    i9 = (int) (i9 + (((i4 * i5) + instanceCount) - i5));
                    i7 = i9;
                    i4--;
                    i = -25804;
                }
                i2++;
            }
            i6++;
        }
        FuzzerUtils.out.println("i19 i20 i21 = " + i7 + "," + i6 + "," + i);
        FuzzerUtils.out.println("f2 i22 i23 = " + Float.floatToIntBits(f) + "," + i2 + "," + i3);
        FuzzerUtils.out.println("f3 i24 i25 = " + Float.floatToIntBits(f2) + "," + i4 + "," + i5);
        PrintStream printStream = FuzzerUtils.out;
        long j2 = instanceCount;
        int i11 = bFld ? 1 : 0;
        printStream.println("Test.instanceCount Test.bFld Test.byFld = " + j2 + "," + i11 + "," + ((int) byFld));
        FuzzerUtils.out.println("Test.iFld Test.iArrFld Test.dArrFld = " + iFld + "," + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        PrintStream printStream2 = FuzzerUtils.out;
        long j3 = vMeth1_check_sum;
        StringBuilder sb = new StringBuilder();
        sb.append("vMeth1_check_sum: ");
        sb.append(j3);
        printStream2.println(sb.toString());
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

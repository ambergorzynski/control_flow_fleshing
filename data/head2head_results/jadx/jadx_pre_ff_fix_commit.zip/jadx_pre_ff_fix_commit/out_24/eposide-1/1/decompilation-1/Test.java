
import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_24/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[][] iArrFld;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;
    public static long vMeth_check_sum;
    public static long instanceCount = 41484;
    public static float fFld = 2.791f;
    public static boolean bFld = true;
    public static byte byFld = 59;

    static {
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) int.class, N, N);
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 49883);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }

    public static void vMeth2(long j) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 6);
        int i = -62180;
        iArr[158] = iArr[158] - 62180;
        double d = -62180;
        Double.isNaN(d);
        double d2 = d - 1.48477d;
        instanceCount -= 62180;
        iArr[158] = (int) j;
        int i2 = 50772;
        int i3 = -239;
        int i4 = 8;
        byte b = 39;
        int i5 = 5;
        while (i5 < 136) {
            instanceCount *= fFld;
            int i6 = 1;
            while (true) {
                i6++;
                if (i6 >= 12) {
                    break;
                }
                fFld -= i6;
                b = (byte) (b & ((byte) i));
                instanceCount += i6 ^ i6;
            }
            int i7 = i5;
            while (12 > i7) {
                boolean z = bFld;
                if (z) {
                    long j2 = instanceCount + (i7 * i7);
                    instanceCount = j2;
                    i = -39;
                    instanceCount = j2 << i6;
                } else if (z) {
                    i2 /= i6 | 1;
                } else {
                    i2 = (int) fFld;
                }
                i7++;
            }
            i5++;
            i4 = i7;
            i3 = i6;
        }
        vMeth2_check_sum += j + i + Double.doubleToLongBits(d2) + i5 + i2 + i3 + b + i4 + 48842 + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth1(boolean z, byte b) {
        double[] dArr = new double[N];
        int[] iArr = new int[N];
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(dArr, 2.113453d);
        int i = 1;
        FuzzerUtils.init(zArr, true);
        FuzzerUtils.init(iArr, 107);
        double d = dArr[352];
        double d2 = -191;
        Double.isNaN(d2);
        double d3 = d - d2;
        float f = (-2.913f) % ((float) ((-2.913f) | 1));
        int i2 = (-191) % ((int) (((191 - 3532952010L) - (-192)) | 1));
        int i3 = -168;
        int i4 = 1;
        while (true) {
            long j = i2 - i2;
            instanceCount = j;
            vMeth2(j);
            i2 = (i2 + 1) - ((int) instanceCount);
            int i5 = 1;
            while (true) {
                i5 += i;
                if (i5 >= 4) {
                    break;
                }
                long j2 = instanceCount;
                instanceCount = j2 + (((i5 * i2) + j2) - i4);
                instanceCount = 14L;
                d3 = d3;
                i = 1;
                i3 = 1;
            }
            double d4 = d3;
            i4++;
            if (i4 < 397) {
                d3 = d4;
                i = 1;
            } else {
                vMeth1_check_sum += (((((((((z ? 1 : 0) + b) + Double.doubleToLongBits(d4)) + i2) + Float.floatToIntBits(f)) + i4) + i5) + i3) - 42) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + FuzzerUtils.checkSum(zArr) + FuzzerUtils.checkSum(iArr);
                return;
            }
        }
    }

    public static void vMeth(float f, float f2) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -1507);
        int i = 2;
        int i2 = 1;
        while (i < 141) {
            i2 += i;
            instanceCount++;
            iArr[i] = iArr[i] + 1;
            i++;
        }
        vMeth1(bFld, byFld);
        int i3 = 0;
        int i4 = 0;
        int i5 = -5;
        int i6 = -63821;
        while (i3 < 400) {
            int i7 = iArr[i3];
            int i8 = 1;
            while (true) {
                i8++;
                if (i8 < 4) {
                    fFld += i8 + i7;
                    i6 = i8;
                    while (i6 < 1) {
                        i2 -= i;
                        f2 += i6;
                        int i9 = i8 - 1;
                        iArr[i9] = iArr[i9] >> i2;
                        i6++;
                    }
                    long j = instanceCount + f;
                    instanceCount = j;
                    instanceCount = j * j;
                    i4 = 1;
                }
            }
            i3++;
            i5 = i8;
        }
        vMeth_check_sum += Float.floatToIntBits(f) + Float.floatToIntBits(f2) + i + i2 + 24857 + i5 + i6 + 52330 + i4 + 11 + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        double d;
        int i8;
        int i9;
        int i10;
        int i11;
        double d2;
        int i12;
        int i13;
        double d3;
        int i14;
        double d4;
        float[] fArr = new float[N];
        long[][] jArr = (long[][]) Array.newInstance((Class<?>) long.class, N, N);
        FuzzerUtils.init(fArr, -88.79f);
        FuzzerUtils.init(jArr, 1L);
        int i15 = -10;
        int i16 = 11;
        double d5 = 0.100147d;
        try {
            vMeth(fFld, 29.483f);
            int i17 = ((int) instanceCount) * (-10);
            double d6 = 1.0d;
            double d7 = 1.0d;
            while (true) {
                i15 = i17 * i17;
                try {
                    fFld += (float) (i15 ^ ((long) d7));
                    long j = instanceCount;
                    double d8 = i15;
                    Double.isNaN(d8);
                    Double.isNaN(d8);
                    Double.isNaN(d8);
                    instanceCount = j + ((long) (((d7 * d8) + d8) - d8));
                    d3 = d7 + d6;
                    int i18 = (int) d3;
                    iArrFld[i18][i18] = -640311262;
                    i14 = ((int) d7) + (i15 | 24997);
                    instanceCount = i14;
                    if (d3 >= 300.0d) {
                        break;
                    }
                    i17 = i14;
                    d7 = d3;
                    d6 = 1.0d;
                } catch (ArithmeticException e) {
                    d5 = d7;
                    i8 = 6;
                    i9 = -8;
                    i10 = -14;
                    i11 = -5;
                    d2 = 2.53817d;
                    int i19 = i8;
                    i13 = i15;
                    i12 = i9;
                    i = (-18819) >> ((int) instanceCount);
                    d3 = d5;
                    i2 = i19;
                    FuzzerUtils.out.println("i19 d2 i20 = " + i13 + "," + Double.doubleToLongBits(d3) + "," + i2);
                    FuzzerUtils.out.println("i21 i22 i23 = 1," + i12 + "," + i);
                    FuzzerUtils.out.println("d3 i24 i25 = " + Double.doubleToLongBits(d2) + "," + i10 + "," + i11);
                    FuzzerUtils.out.println("i26 fArr lArr = " + i16 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + "," + FuzzerUtils.checkSum(jArr));
                    FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.bFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + (bFld ? 1 : 0));
                    PrintStream printStream = FuzzerUtils.out;
                    byte b = byFld;
                    printStream.println("Test.byFld Test.iArrFld = " + ((int) b) + "," + FuzzerUtils.checkSum(iArrFld));
                    FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
                    FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                    FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                } catch (NullPointerException e2) {
                    d5 = d7;
                    i = -18819;
                    i3 = -8;
                    i5 = -14;
                    i6 = -5;
                    i7 = 11;
                    d = 2.53817d;
                    i4 = i15;
                    i2 = 6;
                }
            }
            i13 = i14;
            i2 = 9;
            i10 = -14;
            i11 = -5;
            d2 = 2.53817d;
            int i20 = -8;
            while (i2 < 210) {
                d = d2;
                int i21 = 6;
                i7 = i16;
                i6 = i11;
                i5 = i10;
                i4 = i13;
                while (i21 < 125) {
                    d = d6;
                    while (d < 2.0d) {
                        try {
                            try {
                                bFld = bFld;
                                int i22 = i21 + 1;
                                fArr[i22] = fArr[i22] * i5;
                                d += d6;
                            } catch (ArithmeticException e3) {
                                d5 = d3;
                                i9 = i21;
                                i8 = i2;
                                i15 = i4;
                                i10 = i5;
                                i11 = i6;
                                i16 = i7;
                                d2 = d;
                                int i192 = i8;
                                i13 = i15;
                                i12 = i9;
                                i = (-18819) >> ((int) instanceCount);
                                d3 = d5;
                                i2 = i192;
                                FuzzerUtils.out.println("i19 d2 i20 = " + i13 + "," + Double.doubleToLongBits(d3) + "," + i2);
                                FuzzerUtils.out.println("i21 i22 i23 = 1," + i12 + "," + i);
                                FuzzerUtils.out.println("d3 i24 i25 = " + Double.doubleToLongBits(d2) + "," + i10 + "," + i11);
                                FuzzerUtils.out.println("i26 fArr lArr = " + i16 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + "," + FuzzerUtils.checkSum(jArr));
                                FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.bFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + (bFld ? 1 : 0));
                                PrintStream printStream2 = FuzzerUtils.out;
                                byte b2 = byFld;
                                printStream2.println("Test.byFld Test.iArrFld = " + ((int) b2) + "," + FuzzerUtils.checkSum(iArrFld));
                                FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
                                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                            }
                        } catch (NullPointerException e4) {
                            d5 = d3;
                            i3 = i21;
                            i = -18819;
                            bFld = bFld;
                            i12 = i3;
                            i13 = i4;
                            i10 = i5;
                            i11 = i6;
                            d3 = d5;
                            i16 = i7;
                            d2 = d;
                            FuzzerUtils.out.println("i19 d2 i20 = " + i13 + "," + Double.doubleToLongBits(d3) + "," + i2);
                            FuzzerUtils.out.println("i21 i22 i23 = 1," + i12 + "," + i);
                            FuzzerUtils.out.println("d3 i24 i25 = " + Double.doubleToLongBits(d2) + "," + i10 + "," + i11);
                            FuzzerUtils.out.println("i26 fArr lArr = " + i16 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + "," + FuzzerUtils.checkSum(jArr));
                            FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.bFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + (bFld ? 1 : 0));
                            PrintStream printStream22 = FuzzerUtils.out;
                            byte b22 = byFld;
                            printStream22.println("Test.byFld Test.iArrFld = " + ((int) b22) + "," + FuzzerUtils.checkSum(iArrFld));
                            FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
                            FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                            FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                        }
                    }
                    try {
                        if (bFld) {
                            fFld += (float) instanceCount;
                        } else {
                            fFld += (i21 * i21) + 5;
                        }
                        i6 = 2;
                        while (1 < i6) {
                            i4 *= i4;
                            fFld *= i21;
                            i7 = -19762;
                            i5 += i6 ^ (-18819);
                            try {
                                iArrFld[i21][i2] = 1;
                                i6--;
                            } catch (ArithmeticException e5) {
                                d5 = d3;
                                d2 = d;
                                i9 = i21;
                                i8 = i2;
                                i15 = i4;
                                i10 = i5;
                                i11 = i6;
                                i16 = -19762;
                                int i1922 = i8;
                                i13 = i15;
                                i12 = i9;
                                i = (-18819) >> ((int) instanceCount);
                                d3 = d5;
                                i2 = i1922;
                                FuzzerUtils.out.println("i19 d2 i20 = " + i13 + "," + Double.doubleToLongBits(d3) + "," + i2);
                                FuzzerUtils.out.println("i21 i22 i23 = 1," + i12 + "," + i);
                                FuzzerUtils.out.println("d3 i24 i25 = " + Double.doubleToLongBits(d2) + "," + i10 + "," + i11);
                                FuzzerUtils.out.println("i26 fArr lArr = " + i16 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + "," + FuzzerUtils.checkSum(jArr));
                                FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.bFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + (bFld ? 1 : 0));
                                PrintStream printStream222 = FuzzerUtils.out;
                                byte b222 = byFld;
                                printStream222.println("Test.byFld Test.iArrFld = " + ((int) b222) + "," + FuzzerUtils.checkSum(iArrFld));
                                FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
                                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                            }
                        }
                        d4 = d3;
                        long j2 = instanceCount + i7;
                        try {
                            instanceCount = j2;
                            instanceCount = j2 + (i21 * i5);
                            fFld *= 8.0f;
                            instanceCount = i5;
                            i21++;
                            d3 = d4;
                            d6 = 1.0d;
                        } catch (ArithmeticException e6) {
                            i9 = i21;
                            i8 = i2;
                            i15 = i4;
                            i10 = i5;
                            i11 = i6;
                            i16 = i7;
                            d2 = d;
                            d5 = d4;
                            int i19222 = i8;
                            i13 = i15;
                            i12 = i9;
                            i = (-18819) >> ((int) instanceCount);
                            d3 = d5;
                            i2 = i19222;
                            FuzzerUtils.out.println("i19 d2 i20 = " + i13 + "," + Double.doubleToLongBits(d3) + "," + i2);
                            FuzzerUtils.out.println("i21 i22 i23 = 1," + i12 + "," + i);
                            FuzzerUtils.out.println("d3 i24 i25 = " + Double.doubleToLongBits(d2) + "," + i10 + "," + i11);
                            FuzzerUtils.out.println("i26 fArr lArr = " + i16 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + "," + FuzzerUtils.checkSum(jArr));
                            FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.bFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + (bFld ? 1 : 0));
                            PrintStream printStream2222 = FuzzerUtils.out;
                            byte b2222 = byFld;
                            printStream2222.println("Test.byFld Test.iArrFld = " + ((int) b2222) + "," + FuzzerUtils.checkSum(iArrFld));
                            FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
                            FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                            FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                        } catch (NullPointerException e7) {
                            i3 = i21;
                            d5 = d4;
                            i = -18819;
                            bFld = bFld;
                            i12 = i3;
                            i13 = i4;
                            i10 = i5;
                            i11 = i6;
                            d3 = d5;
                            i16 = i7;
                            d2 = d;
                            FuzzerUtils.out.println("i19 d2 i20 = " + i13 + "," + Double.doubleToLongBits(d3) + "," + i2);
                            FuzzerUtils.out.println("i21 i22 i23 = 1," + i12 + "," + i);
                            FuzzerUtils.out.println("d3 i24 i25 = " + Double.doubleToLongBits(d2) + "," + i10 + "," + i11);
                            FuzzerUtils.out.println("i26 fArr lArr = " + i16 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + "," + FuzzerUtils.checkSum(jArr));
                            FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.bFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + (bFld ? 1 : 0));
                            PrintStream printStream22222 = FuzzerUtils.out;
                            byte b22222 = byFld;
                            printStream22222.println("Test.byFld Test.iArrFld = " + ((int) b22222) + "," + FuzzerUtils.checkSum(iArrFld));
                            FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
                            FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                            FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                        }
                    } catch (ArithmeticException e8) {
                        d4 = d3;
                    } catch (NullPointerException e9) {
                        d4 = d3;
                    }
                }
                i2++;
                i20 = i21;
                i13 = i4;
                i10 = i5;
                i11 = i6;
                i16 = i7;
                d2 = d;
                d6 = 1.0d;
            }
            i12 = i20;
            i = -18819;
        } catch (ArithmeticException e10) {
        } catch (NullPointerException e11) {
            i = -18819;
            i2 = 6;
            i3 = -8;
            i4 = -10;
            i5 = -14;
            i6 = -5;
            i7 = 11;
            d = 2.53817d;
        }
        FuzzerUtils.out.println("i19 d2 i20 = " + i13 + "," + Double.doubleToLongBits(d3) + "," + i2);
        FuzzerUtils.out.println("i21 i22 i23 = 1," + i12 + "," + i);
        FuzzerUtils.out.println("d3 i24 i25 = " + Double.doubleToLongBits(d2) + "," + i10 + "," + i11);
        FuzzerUtils.out.println("i26 fArr lArr = " + i16 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + "," + FuzzerUtils.checkSum(jArr));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.bFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + (bFld ? 1 : 0));
        PrintStream printStream222222 = FuzzerUtils.out;
        byte b222222 = byFld;
        printStream222222.println("Test.byFld Test.iArrFld = " + ((int) b222222) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}


import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_58/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static byte[] byArrFld;
    public static int[] iArrFld;
    public static long[][] lArrFld;
    public static long lMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public float fFld = 1.17f;
    public static long instanceCount = -27869840979981097L;
    public static byte byFld = -46;

    static {
        long[][] jArr = (long[][]) Array.newInstance((Class<?>) long.class, N, N);
        lArrFld = jArr;
        byArrFld = new byte[N];
        iArrFld = new int[N];
        FuzzerUtils.init(jArr, -190L);
        FuzzerUtils.init(byArrFld, (byte) -80);
        FuzzerUtils.init(iArrFld, -2);
        lMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }

    public static void vMeth1(int i, int i2, int i3) {
        long[][][] jArr = (long[][][]) Array.newInstance((Class<?>) long.class, N, N, N);
        FuzzerUtils.init((Object[][]) jArr, (Object) (-326364552744312529L));
        int i4 = -1;
        int i5 = 238;
        int i6 = -4851;
        int i7 = -185;
        int i8 = -3;
        int i9 = 1;
        int i10 = i;
        double d = -125.8967d;
        int i11 = 8;
        int i12 = 64720;
        while (212 > i11) {
            d = -86;
            i6 = 1;
            while (i6 < 8) {
                i7 = 4;
                while (i7 > 1) {
                    int i13 = i6 - 1;
                    jArr[i13][i7] = jArr[i13][i13];
                    i8 += i7 | (-86);
                    i7--;
                }
                i10 += i6;
                i12 = i11;
                while (i12 < 4) {
                    i12++;
                }
                i5 = 6;
                int i14 = i9;
                int i15 = i11;
                while (i15 < 4) {
                    i14 = 0;
                    i15++;
                }
                i6 += 3;
                i4 = i15;
                i9 = i14;
            }
            i11++;
        }
        vMeth1_check_sum += ((((((((((((((i10 + i2) + i3) + i11) + i5) + Double.doubleToLongBits(d)) - 86) + i6) - 248) + i7) + i8) + i12) + 21866) + i4) - 77) + i9 + FuzzerUtils.checkSum((Object[][]) jArr);
    }

    public static void vMeth() {
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, 48.227f);
        FuzzerUtils.init(iArr, 152);
        vMeth1(4, -46955, -58348);
        int i = -52521;
        float f = -56.33f;
        double d = 1.0d;
        while (d < 126.0d) {
            i = 1;
            do {
                f = 1.0f;
                i++;
            } while (i < 13);
            d += 1.0d;
        }
        vMeth_check_sum += ((0 + Double.doubleToLongBits(d)) - 58966) + i + Float.floatToIntBits(f) + 235 + Float.floatToIntBits(33.953f) + 0 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(iArr);
    }

    public static long lMeth(double d) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 220);
        vMeth();
        long j = instanceCount ^ (-1);
        instanceCount = j;
        int i = ((int) j) & (-1);
        int i2 = i * i;
        int i3 = i2 | i2;
        float f = 122.29f;
        int i4 = 7;
        while (i4 < 171) {
            int i5 = i4 - 1;
            iArr[i5] = iArr[i5] - i3;
            i3 += 123;
            f -= i3;
            if (((i3 >>> 1) % 1) + 26 == 26) {
                long j2 = instanceCount;
                instanceCount = j2 * j2;
                lArrFld[i5][i5] = f;
                byArrFld[i5] = (byte) 0.67f;
                i3 /= 9341;
            }
            i4++;
        }
        long doubleToLongBits = Double.doubleToLongBits(d) + i3 + i4 + 53199 + Float.floatToIntBits(f) + Float.floatToIntBits(0.67f) + FuzzerUtils.checkSum(iArr);
        lMeth_check_sum += doubleToLongBits;
        return doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        int i;
        short s;
        int i2 = 1;
        int i3 = 111;
        int i4 = 205;
        int i5 = -9;
        int i6 = -32;
        double d = 2.54214d;
        short s2 = 8638;
        int i7 = 6;
        int i8 = 0;
        while (i7 < 146) {
            int i9 = 2;
            int i10 = i8;
            short s3 = s2;
            double d2 = d;
            int i11 = i6;
            int i12 = i5;
            int i13 = 2;
            while (i13 < 179) {
                lMeth(-2.256d);
                int i14 = i2;
                i11 = i7;
                while (i11 < i9) {
                    instanceCount += i11 * i12;
                    try {
                        i12 = i13 % i13;
                        int i15 = 28096 % iArrFld[i11];
                        i14 = i13 % (-833932605);
                    } catch (ArithmeticException e) {
                    }
                    long j = instanceCount * i14;
                    instanceCount = j;
                    long j2 = j + i11;
                    instanceCount = j2;
                    i12 >>= (int) j2;
                    i11++;
                }
                long j3 = instanceCount + (i13 * i14);
                instanceCount = j3;
                int i16 = (int) j3;
                int i17 = i14 + i16;
                short s4 = s3;
                double d3 = 1.0d;
                while (d3 < 2.0d) {
                    int[] iArr = iArrFld;
                    int i18 = i7 + 1;
                    iArr[i18] = iArr[i18] * 8;
                    int i19 = i13;
                    double d4 = d3 * d3;
                    int i20 = i17;
                    long j4 = instanceCount + ((long) d4);
                    instanceCount = j4;
                    long j5 = j4 >>> i16;
                    instanceCount = j5;
                    int i21 = ((i7 % 5) * 5) + 56;
                    if (i21 != 57) {
                        if (i21 != 73) {
                            switch (i21) {
                                case 60:
                                    this.fFld = -82.0f;
                                case 59:
                                    this.fFld = (float) instanceCount;
                                    s = s4;
                                    i = i20;
                                    break;
                                case 61:
                                    iArr[i7] = iArr[i7] - 79;
                                    s4 = (short) (s4 + ((short) d4));
                                    i = i20;
                                    break;
                                default:
                                    s = s4;
                                    i = i20;
                                    break;
                            }
                        } else {
                            byte[] bArr = byArrFld;
                            s = s4;
                            int i22 = (int) (d3 + 1.0d);
                            i = i20;
                            bArr[i22] = (byte) (bArr[i22] >> ((byte) i));
                            instanceCount = j5 & i16;
                            byFld = (byte) 8;
                        }
                        s4 = s;
                    } else {
                        i = i20;
                        s4 = (short) (s4 - ((short) i12));
                    }
                    d3 += 1.0d;
                    i17 = i;
                    i13 = i19;
                }
                int i23 = i17;
                i3 = i16;
                d2 = d3;
                i2 = i23;
                i9 = 2;
                i10 = 2;
                s3 = s4;
                i13++;
            }
            int i24 = i13;
            i7++;
            i5 = i12;
            i6 = i11;
            d = d2;
            s2 = s3;
            i8 = i10;
            i4 = i24;
        }
        FuzzerUtils.out.println("i i1 i2 = " + i7 + "," + i3 + "," + i4);
        FuzzerUtils.out.println("i3 i24 i25 = " + i5 + "," + i6 + "," + i2);
        FuzzerUtils.out.println("b2 i26 d3 = 0," + i8 + "," + Double.doubleToLongBits(d));
        PrintStream printStream = FuzzerUtils.out;
        StringBuilder sb = new StringBuilder();
        sb.append("i27 s = ");
        sb.append(8);
        sb.append(",");
        sb.append((int) s2);
        printStream.println(sb.toString());
        PrintStream printStream2 = FuzzerUtils.out;
        long j6 = instanceCount;
        byte b = byFld;
        printStream2.println("Test.instanceCount Test.byFld fFld = " + j6 + "," + ((int) b) + "," + Float.floatToIntBits(this.fFld));
        FuzzerUtils.out.println("Test.lArrFld Test.byArrFld Test.iArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(byArrFld) + "," + FuzzerUtils.checkSum(iArrFld));
        PrintStream printStream3 = FuzzerUtils.out;
        long j7 = vMeth1_check_sum;
        StringBuilder sb2 = new StringBuilder();
        sb2.append("vMeth1_check_sum: ");
        sb2.append(j7);
        printStream3.println(sb2.toString());
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

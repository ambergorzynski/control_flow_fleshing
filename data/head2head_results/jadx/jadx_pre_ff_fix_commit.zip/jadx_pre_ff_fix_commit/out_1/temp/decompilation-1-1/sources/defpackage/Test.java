package defpackage;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_1/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static float[] fArrFld;
    public static long fMeth_check_sum;
    public static int[] iArrFld;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public byte byFld = -112;
    public static long instanceCount = -12;
    public static float fFld = -2.773f;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        fArrFld = new float[N];
        FuzzerUtils.init(iArr, 50031);
        FuzzerUtils.init(fArrFld, -31.34f);
        vMeth_check_sum = 0L;
        fMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }

    public static void vMeth1(int i) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 0);
        double d = -61.10718d;
        int i2 = iArr[0];
        int i3 = 1;
        while (i3 < 4) {
            i += i3;
            d *= -5.0d;
            iArr[i3] = 12356;
            i3++;
        }
        instanceCount <<= i3;
        int i4 = 16;
        int i5 = -177;
        int i6 = -25069;
        while (i4 < 263) {
            i5 = 1;
            while (i5 < 7) {
                instanceCount >>= -14124;
                i5++;
            }
            int i7 = i4;
            while (i7 < 7) {
                long j = instanceCount + i4;
                instanceCount = j;
                instanceCount = j;
                i7++;
            }
            i4++;
            i6 = i7;
        }
        vMeth1_check_sum += (((((((((i + i3) - 21383) + Double.doubleToLongBits(d)) + 1) + i4) + r1) + i5) - 20095) - 14124) + i6 + 5 + FuzzerUtils.checkSum(iArr);
    }

    public static float fMeth() {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -9);
        vMeth1(-142);
        fFld = (float) instanceCount;
        int i = 53348;
        int i2 = -2;
        int i3 = 9;
        int i4 = -109;
        int i5 = -131;
        int i6 = 4;
        while (i6 < 384) {
            iArr[i6 - 1] = i6;
            int i7 = 1;
            while (true) {
                i7++;
                if (i7 < 4) {
                    instanceCount += (i7 * i7) - 201;
                    i4 -= i;
                    i5 = i6;
                    while (i5 < 1) {
                        long j = instanceCount + ((long) (-1.51357d));
                        instanceCount = j;
                        instanceCount = j >> ((int) j);
                        i5++;
                        i = i4;
                    }
                    i3 = 1;
                }
            }
            i6++;
            i2 = i7;
        }
        long doubleToLongBits = ((((((((-142) + i6) + i) + i2) + i3) + i4) + i5) - 38) + Double.doubleToLongBits(-1.51357d) + FuzzerUtils.checkSum(iArr);
        fMeth_check_sum += doubleToLongBits;
        return (float) doubleToLongBits;
    }

    public static void vMeth() {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -41712L);
        FuzzerUtils.init(iArr, 11729);
        fMeth();
        int i = -34876;
        int i2 = -41010;
        int i3 = -95;
        int i4 = 16;
        while (i4 < 274) {
            instanceCount = 95L;
            i2 = 6;
            while (true) {
                i2--;
                if (i2 > 0) {
                    i += i;
                    jArr[i2] = jArr[i2] + 31136;
                    i3 = 1;
                }
            }
            i4++;
        }
        vMeth_check_sum += ((((i4 + i) + i2) + i3) - 9772) + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int i;
        vMeth();
        int[] iArr = iArrFld;
        int length = iArr.length;
        int i2 = -14;
        int i3 = -38;
        int i4 = 62;
        int i5 = 0;
        while (true) {
            i = 3;
            if (i5 >= length) {
                break;
            }
            int i6 = iArr[i5];
            int[] iArr2 = iArrFld;
            iArr2[21] = iArr2[21] * (-5);
            i2 = 1;
            while (63 > i2) {
                i4 = 1;
                while (i4 < 2) {
                    i4++;
                    fArrFld[i4] = this.byFld;
                    long j = instanceCount;
                    instanceCount = j - j;
                    iArrFld[i2 - 1] = i2;
                }
                fFld -= 3;
                i2++;
            }
            i3 = ((int) fFld) + this.byFld + 41;
            i5++;
        }
        int i7 = 392;
        int i8 = 20099;
        int i9 = -15504;
        int i10 = -235;
        int i11 = 129;
        int i12 = 17261;
        while (i7 > 22) {
            int i13 = i7;
            while (i13 < 68) {
                instanceCount -= -93;
                i13++;
            }
            int i14 = 68;
            while (i14 > i7) {
                i14 -= 3;
            }
            int i15 = i - this.byFld;
            int i16 = i10 * i10;
            int i17 = 1;
            do {
                i17++;
            } while (i17 < 68);
            i7--;
            i11 = i17;
            i8 = i13;
            i9 = i14;
            i = i15;
            i10 = i16;
            i12 = 1;
        }
        FuzzerUtils.out.println("i24 i25 i26 = " + i2 + "," + i3 + "," + i4);
        FuzzerUtils.out.println("i27 b2 i28 = " + i + ",1," + i7);
        FuzzerUtils.out.println("i29 i30 i31 = -98," + i8 + ",-18707");
        FuzzerUtils.out.println("i32 i33 i34 = " + i9 + "," + i10 + "," + i11);
        FuzzerUtils.out.println("i35 i36 d2 = " + i12 + ",-26," + Double.doubleToLongBits(-35.99299d));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld byFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + ((int) this.byFld));
        FuzzerUtils.out.println("Test.iArrFld Test.fArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

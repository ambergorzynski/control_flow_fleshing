
import java.io.PrintStream;
import java.lang.reflect.Array;

/* loaded from: /data/dev/jdtester_backup/./results/pre_ff_fix_commit/out_76/eposide-1/1/original-1/Test.dex */
public class Test {
    public static final int N = 400;
    public static byte[] byArrFld;
    public static double[] dArrFld;
    public static int[] iArrFld;
    public static long lMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth_check_sum;
    public static volatile long instanceCount = -3;
    public static double dFld = 98.95974d;
    public static boolean bFld = false;
    public static short sFld = -29133;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        dArrFld = new double[N];
        byArrFld = new byte[N];
        FuzzerUtils.init(iArr, 231);
        FuzzerUtils.init(dArrFld, 0.83597d);
        FuzzerUtils.init(byArrFld, (byte) -67);
        lMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }

    public static void vMeth1(int i, int i2, int i3) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 62480);
        double d = i3;
        Double.isNaN(d);
        double d2 = (-6.42056d) - d;
        int i4 = -14;
        long j = 215;
        int i5 = 7;
        while (i5 < 385) {
            long j2 = 1;
            while (true) {
                j2++;
                if (j2 < 4) {
                    i2 += i3;
                    i4 = 1;
                }
            }
            i5++;
            j = j2;
        }
        vMeth1_check_sum += (((((i + i2) + i3) + Double.doubleToLongBits(d2)) + i5) - 230) + j + i4 + 14 + Float.floatToIntBits(1.653f * ((float) j)) + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth() {
        boolean z;
        long[][] jArr = (long[][]) Array.newInstance((Class<?>) long.class, N, N);
        FuzzerUtils.init(jArr, -177L);
        int i = 1;
        while (true) {
            i++;
            if (i >= 300) {
                break;
            } else {
                vMeth1(i, 6827, i);
            }
        }
        double d = dFld;
        double d2 = i;
        Double.isNaN(d2);
        dFld = d + d2;
        int i2 = 12;
        int i3 = 19050;
        int i4 = -69;
        for (int i5 : iArrFld) {
            i2 = 1;
            while (true) {
                i2++;
                if (i2 < 4 && !(z = bFld)) {
                    jArr[i2] = jArr[i2];
                    if (z) {
                        i3 = i2;
                        while (i3 < 1) {
                            int i6 = i3 + 1;
                            iArrFld[i6] = (int) instanceCount;
                            sFld = sFld;
                            instanceCount = ((float) instanceCount) + i3 + 1.268f;
                            i3 = i6;
                        }
                    } else {
                        i4 = -1;
                    }
                }
            }
        }
        vMeth_check_sum += i + i2 + i3 + i4 + Float.floatToIntBits(1.268f) + FuzzerUtils.checkSum(jArr);
    }

    public static long lMeth(float f) {
        long[] jArr = new long[N];
        int i = 2;
        long[][] jArr2 = (long[][]) Array.newInstance((Class<?>) long.class, N, N);
        float[] fArr = new float[N];
        FuzzerUtils.init(jArr, 1931863716L);
        FuzzerUtils.init(fArr, -43.369f);
        FuzzerUtils.init(jArr2, 1170304343L);
        vMeth();
        instanceCount += instanceCount;
        int i2 = (-27) - ((int) f);
        int i3 = 14;
        int i4 = 0;
        while (i3 < 284) {
            int i5 = 1;
            while (true) {
                i5++;
                if (i5 < 6) {
                    i4 += i2;
                    int[] iArr = iArrFld;
                    iArr[i3 + 1] = -705950624;
                    i2 = (int) (i2 + (((i5 * i4) + i3) - f));
                    int i6 = i3 - 1;
                    dArrFld[i6] = i5;
                    iArrFld = iArr;
                    bFld = false;
                    switch ((i5 % 9) + 65) {
                        case 65:
                            int i7 = i2 + 51571;
                            i2 = i7 + (((i5 * i7) + i3) - i4);
                            jArr[i6] = jArr[i6] * i5;
                            break;
                        case 66:
                            f = i3;
                            i2 <<= -201;
                            fArr[i3] = 2.358f;
                            break;
                        case 67:
                            i2 <<= -201;
                            fArr[i3] = 2.358f;
                            break;
                        case 68:
                            fArr[i3] = 2.358f;
                            break;
                        case 69:
                            i4 += 0;
                            break;
                        case 70:
                            f += (float) (((i5 * instanceCount) + instanceCount) - instanceCount);
                            break;
                        case 71:
                            iArr[i3] = iArr[i3] >>> i4;
                            break;
                        case 72:
                            i2 -= (int) instanceCount;
                            break;
                        case 73:
                            jArr2 = FuzzerUtils.long2array(N, -143L);
                            break;
                        default:
                            i4 = 101;
                            break;
                    }
                }
            }
            i3++;
            i = i5;
        }
        long floatToIntBits = Float.floatToIntBits(f) + i2 + i3 + i4 + i + FuzzerUtils.checkSum(jArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(jArr2);
        lMeth_check_sum += floatToIntBits;
        return floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        float f;
        int i;
        float lMeth = ((float) (lMeth(-26.928f) - 61724)) - 26.928f;
        int i2 = 26593;
        int i3 = -250;
        int i4 = -1642;
        int i5 = -3897;
        int i6 = 42261;
        int i7 = -1;
        int i8 = 19;
        while (i8 < 360) {
            boolean z = bFld;
            if (z) {
                i7 *= (int) instanceCount;
                double d = dFld;
                dFld = d * d;
                byArrFld = FuzzerUtils.byte1array(N, (byte) -30);
                int i9 = 1;
                do {
                    i7 += i9;
                    int i10 = (i9 * i9) + i5;
                    f = i9;
                    instanceCount >>>= i8;
                    int[] iArr = iArrFld;
                    int i11 = i8 + 1;
                    iArr[i11] = iArr[i11] * 1;
                    i5 <<= i9;
                    i = i10 * i8;
                    i9++;
                } while (i9 < 74);
                lMeth = f;
                i4 = 1;
                i6 = 2;
                i3 = i9;
                i2 = i;
            } else if (z) {
                i7 *= (int) instanceCount;
            } else if (z) {
                i2 = (int) instanceCount;
                lMeth = (float) instanceCount;
            }
            try {
                iArrFld[i8] = i6 / 20189;
                i2 = i8 % i4;
                i5 = iArrFld[i8 + 1] % 139;
            } catch (ArithmeticException e) {
            }
            i8++;
        }
        FuzzerUtils.out.println("f i16 i17 = " + Float.floatToIntBits(lMeth) + "," + i7 + "," + i8);
        FuzzerUtils.out.println("i18 i19 i20 = " + i2 + "," + i3 + "," + i4);
        PrintStream printStream = FuzzerUtils.out;
        StringBuilder sb = new StringBuilder();
        sb.append("i21 i22 = ");
        sb.append(i5);
        sb.append(",");
        sb.append(i6);
        printStream.println(sb.toString());
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.bFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
        PrintStream printStream2 = FuzzerUtils.out;
        short s = sFld;
        printStream2.println("Test.sFld Test.iArrFld Test.dArrFld = " + ((int) s) + "," + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        PrintStream printStream3 = FuzzerUtils.out;
        long checkSum = FuzzerUtils.checkSum(byArrFld);
        StringBuilder sb2 = new StringBuilder();
        sb2.append("Test.byArrFld = ");
        sb2.append(checkSum);
        printStream3.println(sb2.toString());
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}

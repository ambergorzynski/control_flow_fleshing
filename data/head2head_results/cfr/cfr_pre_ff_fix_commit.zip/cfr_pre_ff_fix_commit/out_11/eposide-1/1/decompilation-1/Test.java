/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -1984528026L;
    public static double dFld = 1.2558;
    public static int iFld = 249;
    public static int iFld1 = -156;
    public static volatile float fFld = -125.131f;
    public boolean bFld = true;
    public static double[] dArrFld = new double[400];
    public short[] sArrFld = new short[400];
    public static long vSmallMeth_check_sum;
    public static long vMeth_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vSmallMeth() {
        int n = -65261;
        vSmallMeth_check_sum += (long)(n &= 6);
    }

    public static void vMeth1() {
        int n = 144;
        int n2 = 42;
        int n3 = -52865;
        int n4 = -196;
        int n5 = 11;
        int[] nArray = new int[400];
        float f = 2.51f;
        int n6 = -60;
        long l = 184L;
        boolean bl = false;
        FuzzerUtils.init(nArray, 4);
        int n7 = (iFld >>> 1) % 400;
        nArray[n7] = nArray[n7] - (int)instanceCount;
        if (bl) {
            iFld -= iFld;
            for (n = 198; n > 11; --n) {
                for (n3 = 9; n3 > 1; --n3) {
                }
                iFld = (int)instanceCount;
                instanceCount = -3L;
                n6 = (byte)(n6 >>> (byte)n2);
                iFld1 = 48330;
            }
            l = 1L;
            while (++l < 389L) {
                n5 = 1;
                do {
                    nArray[(int)(l + 1L)] = n3;
                    n2 += n5 * n5;
                } while (++n5 < 4);
            }
        } else {
            n4 -= n4;
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + Float.floatToIntBits(f) + n6) + l + (long)n5 + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray);
    }

    public static int iMeth(int n) {
        int n2 = -9;
        boolean bl = true;
        boolean[][] blArray = new boolean[400][400];
        int n3 = -11962;
        int n4 = 4;
        int n5 = -6;
        int[] nArray = new int[400];
        long l = 0L;
        int n6 = 8958;
        FuzzerUtils.init(blArray, false);
        FuzzerUtils.init(nArray, -3);
        Test.vMeth1();
        n2 = (byte)iFld;
        iFld1 = (int)instanceCount;
        instanceCount += (long)iFld;
        blArray[(n >>> 1) % 400][(n >>> 1) % 400] = bl;
        iFld1 -= iFld;
        iFld1 = n;
        for (n3 = 3; n3 < 241; ++n3) {
            for (l = 1L; l < 7L; ++l) {
                iFld1 += -62;
                iFld *= n6;
                n4 += (int)(l + (long)n2);
                iFld = n3;
                n5 += iFld;
            }
        }
        long l2 = (long)(n + n2 + (bl ? 1 : 0) + n3 + n4) + l + (long)n5 + (long)n6 + FuzzerUtils.checkSum(blArray) + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public static void vMeth(int n) {
        double d = 47.32133;
        int n2 = -47;
        int n3 = -11;
        int n4 = 64031;
        int n5 = 4;
        int n6 = -18900;
        int[] nArray = new int[400];
        float f = -2.87f;
        int n7 = 74;
        byte[] byArray = new byte[400];
        FuzzerUtils.init(nArray, -55234);
        FuzzerUtils.init(byArray, (byte)-116);
        n %= 2;
        for (d = 16.0; d < 366.0; d += 1.0) {
            nArray[(int)d] = n2;
            for (n3 = 1; n3 < 5; ++n3) {
                for (f = 1.0f; f < 2.0f; f += 1.0f) {
                    Test.vSmallMeth();
                    int n8 = n5++;
                    int n9 = (int)d;
                    nArray[(int)(d - 1.0)] = n9;
                    byArray[n3 - 1] = (byte)((double)n8 + dArrFld[(int)(f + 1.0f)] * (double)n9);
                    instanceCount = n2--;
                    int n10 = n3;
                    int n11 = nArray[n10];
                    nArray[n10] = n11 + 1;
                    n4 <<= (int)((long)(-nArray[(n4 >>> 1) % 400] * n11) + --instanceCount);
                    dFld -= (double)instanceCount;
                    n6 = (int)instanceCount;
                    n5 = (int)((float)n6 - f * (float)n7);
                    n += n5;
                }
                n6 += Test.iMeth(n);
                instanceCount += (long)n3;
                instanceCount = (long)f;
                int n12 = n3 - 1;
                dArrFld[n12] = dArrFld[n12] * 13.0;
            }
        }
        vMeth_check_sum += (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)Float.floatToIntBits(f) + (long)n5 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(byArray);
    }

    public void mainTest(String[] stringArray) {
        short s = -26048;
        int n = 65;
        int n2 = 37211;
        int n3 = 54337;
        int n4 = -229;
        int n5 = 51838;
        int n6 = 32940;
        int n7 = 64;
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, 12);
        for (int i = 0; i < 803; ++i) {
            Test.vSmallMeth();
        }
        Test.vMeth(iFld1);
        iFld1 -= -32005;
        fFld -= 169.0f;
        iFld1 *= s;
        dFld = iFld;
        for (n = 12; n < 301; ++n) {
            n2 = 107;
            iFld1 -= (int)instanceCount;
            iFld += (int)instanceCount;
            if (!this.bFld) continue;
            iFld = (int)((long)iFld + ((long)n * instanceCount + (long)s - (long)n2));
            iFld1 += n + n;
            block13: for (n3 = 87; n3 > 2; n3 -= 2) {
                iFld = (int)instanceCount;
                instanceCount -= 240L;
                switch (n % 2 * 5 + 40) {
                    case 47: {
                        block14: for (n5 = 1; 3 > n5; ++n5) {
                            n6 <<= iFld;
                            this.bFld = this.bFld;
                            n6 -= n3;
                            n6 += -12 + n5 * n5;
                            n2 = (int)instanceCount;
                            n7 |= iFld;
                            switch ((iFld >>> 1) % 2 + 11) {
                                case 11: {
                                    instanceCount >>>= n6;
                                    switch (n3 % 1 + 111) {
                                        case 111: {
                                            n7 <<= n7;
                                            int n8 = n5;
                                            this.sArrFld[n8] = (short)(this.sArrFld[n8] * (short)n5);
                                            s = (short)n2;
                                            continue block14;
                                        }
                                    }
                                    n2 >>= (int)instanceCount;
                                    continue block14;
                                }
                                case 12: {
                                    nArray[n5 + 1] = -14;
                                }
                            }
                        }
                        continue block13;
                    }
                    case 49: {
                        n7 = n3;
                    }
                }
            }
        }
        FuzzerUtils.out.println("s1 i16 i17 = " + s + "," + n + "," + n2);
        FuzzerUtils.out.println("i18 i19 i20 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i21 i22 iArr3 = " + n6 + "," + n7 + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.iFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + iFld);
        FuzzerUtils.out.println("Test.iFld1 Test.fFld bFld = " + iFld1 + "," + Float.floatToIntBits(fFld) + "," + (this.bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.dArrFld sArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + FuzzerUtils.checkSum(this.sArrFld));
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(dArrFld, -77.111009);
        vSmallMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}


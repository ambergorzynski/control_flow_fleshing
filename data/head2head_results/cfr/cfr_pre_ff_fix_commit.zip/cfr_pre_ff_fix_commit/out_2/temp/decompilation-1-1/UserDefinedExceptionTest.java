/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
class UserDefinedExceptionTest
extends RuntimeException {
    public int field;

    UserDefinedExceptionTest() {
    }
}


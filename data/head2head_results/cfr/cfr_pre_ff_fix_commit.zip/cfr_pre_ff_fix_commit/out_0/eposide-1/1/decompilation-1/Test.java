/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -4L;
    public static int iFld = 36189;
    public static short sFld = (short)-27994;
    public static long vMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;
    public static long vMeth2_check_sum = 0L;

    public static void vMeth2(int n, long l, short s) {
        int n2 = 6;
        int n3 = -5;
        int n4 = 216;
        int n5 = -36272;
        int n6 = 3;
        int n7 = 30230;
        int[] nArray = new int[400];
        float f = 35.705f;
        int n8 = 126;
        FuzzerUtils.init(nArray, -3);
        for (n2 = 10; n2 < 234; ++n2) {
            l = n3;
        }
        f += (float)n3;
        n -= 2;
        n3 <<= (int)(instanceCount -= l);
        for (n4 = 3; n4 < 367; ++n4) {
            n = n8;
            for (n6 = n4; n6 < 5; ++n6) {
                int n9 = (n >>> 1) % 400;
                nArray[n9] = nArray[n9] << n2;
                instanceCount >>= (int)l;
                n5 += n;
                n7 -= n4;
                n3 += n6 * n2 + (n5 *= (int)f) - n2;
            }
        }
        vMeth2_check_sum += (long)n + l + (long)s + (long)n2 + (long)n3 + (long)Float.floatToIntBits(f) + (long)n4 + (long)n5 + (long)n8 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth1(int n, short s) {
        float f = 0.605f;
        int n2 = 6;
        int n3 = 7;
        int n4 = -14;
        int n5 = 11;
        int[] nArray = new int[400];
        int n6 = 127;
        boolean bl = true;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -8912305766661705814L);
        FuzzerUtils.init(nArray, -154);
        for (f = 5.0f; f < 318.0f; f += 1.0f) {
            Test.vMeth2(n2 *= (int)instanceCount--, instanceCount, s);
            int n7 = (int)f;
            lArray[n7] = lArray[n7] + instanceCount;
            if (!bl) continue;
            n2 = (int)instanceCount;
            for (n3 = 1; n3 < 5; ++n3) {
                n5 = 2;
                while (--n5 > 0) {
                    boolean bl2 = false;
                    instanceCount += (long)n5;
                    n = n3;
                    nArray[(int)f] = 1732888849;
                    try {
                        nArray[n5 - 1] = n5 % n5;
                        n4 = n5 % n3;
                        n = n3 / 2019069922;
                    } catch (ArithmeticException arithmeticException) {}
                }
                n6 = -13;
            }
        }
        vMeth1_check_sum += (long)(n + s + Float.floatToIntBits(f) + n2 + n3 + n4 + n5 + n6 + (bl ? 1 : 0)) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth(double d) {
        int n = 71;
        int n2 = 38014;
        int n3 = -12;
        int n4 = 8407;
        int n5 = -37069;
        int n6 = 0;
        int n7 = 35;
        boolean bl = false;
        boolean[] blArray = new boolean[400];
        float f = -48.271f;
        float f2 = 43.528f;
        int n8 = 88;
        FuzzerUtils.init(blArray, true);
        Test.vMeth1(iFld, sFld);
        n = 1;
        do {
            block22: for (n2 = 1; n2 < 5; ++n2) {
                switch (n2 % 9 * 5 + 111) {
                    case 131: {
                        n4 = 1;
                        while (++n4 < 2) {
                        }
                        for (n5 = 1; 2 > n5; ++n5) {
                            sFld = (short)(sFld + (short)(-21 + n5 * n5));
                            blArray[n - 1] = bl;
                        }
                        continue block22;
                    }
                    case 120: {
                        block25: for (f = 1.0f; f < 2.0f; f += 1.0f) {
                            switch (n2 % 10 * 5 + 116) {
                                case 161: {
                                    iFld = n5;
                                    if (bl) continue block25;
                                    n3 += 36;
                                    continue block25;
                                }
                                case 142: {
                                    continue block25;
                                }
                                case 151: {
                                    n7 >>= n;
                                    continue block25;
                                }
                                case 127: {
                                    n6 = n7;
                                    continue block25;
                                }
                                case 146: {
                                    n8 = (byte)(n8 - (byte)iFld);
                                    continue block25;
                                }
                                case 120: {
                                    n3 >>>= n2;
                                    continue block25;
                                }
                                case 119: {
                                    n6 = (int)((float)n6 + (6.0f + f * f));
                                    continue block25;
                                }
                                case 162: {
                                    instanceCount += (long)n6;
                                }
                                case 143: {
                                    iFld += -93;
                                    continue block25;
                                }
                                case 131: {
                                    if (!bl) continue block25;
                                    continue block25;
                                }
                                default: {
                                    instanceCount *= (long)n8;
                                }
                            }
                        }
                        continue block22;
                    }
                    case 135: 
                    case 141: {
                        f2 *= (float)iFld;
                        continue block22;
                    }
                    case 125: {
                        n7 = n5;
                        continue block22;
                    }
                    case 136: 
                    case 151: {
                        sFld = (short)10615;
                    }
                    case 139: {
                        f2 = n4;
                        continue block22;
                    }
                    case 128: {
                        iFld = n6;
                    }
                }
            }
        } while (++n < 351);
        vMeth_check_sum += Double.doubleToLongBits(d) + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)(bl ? 1 : 0) + (long)n5 + (long)n6 + (long)Float.floatToIntBits(f) + (long)n7 + (long)n8 + (long)Float.floatToIntBits(f2) + FuzzerUtils.checkSum(blArray);
    }

    public void mainTest(String[] stringArray) {
        double d = 42.85579;
        Test.vMeth(d);
        FuzzerUtils.out.println("d1 = " + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.sFld = " + instanceCount + "," + iFld + "," + sFld);
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}


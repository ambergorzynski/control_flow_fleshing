/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -3865165905L;
    public int iFld = 89;
    public static short sFld = (short)1381;
    public static int iFld1 = -12096;
    public static int iFld2 = -116;
    public int[] iArrFld = new int[400];
    public static long[] lArrFld = new long[400];
    public static double[] dArrFld = new double[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long lMeth_check_sum;

    public static long lMeth() {
        float f = 71.348f;
        int n = -48;
        int n2 = -50182;
        int n3 = 8;
        int n4 = 51;
        int n5 = -239;
        double d = 2.10268;
        iFld1 -= (int)f;
        f += (float)instanceCount;
        int n6 = (iFld1 >>> 1) % 400;
        dArrFld[n6] = dArrFld[n6] + (double)iFld1;
        iFld1 >>= (int)instanceCount;
        n = 291;
        do {
            iFld1 >>= 156;
            d += (double)(iFld1 += n);
            for (n2 = 1; 16 > n2; n2 += 2) {
                iFld1 += n2 - iFld1;
                instanceCount |= 0x63L;
                for (n4 = 1; n4 < 3; ++n4) {
                    n5 = n;
                    iFld1 *= (int)d;
                    n3 += n4 * n4;
                }
            }
        } while ((n -= 3) > 0);
        long l = (long)(Float.floatToIntBits(f) + n) + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)n5;
        lMeth_check_sum += l;
        return l;
    }

    public static void vMeth1(long l) {
        int n = 116;
        int n2 = -94;
        int n3 = 4;
        int n4 = -18;
        int n5 = -53408;
        int[] nArray = new int[400];
        double d = 2.130062;
        float f = 2.139f;
        boolean[][][] blArray = new boolean[400][400][400];
        FuzzerUtils.init((Object[][])blArray, (Object)true);
        FuzzerUtils.init(nArray, -56861);
        n = 304;
        do {
            for (n2 = 1; n2 < 10; ++n2) {
                block15: for (n4 = 2; n4 > 1; --n4) {
                    switch ((sFld - 48 >>> 1) % 2 * 5 + 96) {
                        case 100: {
                            blArray[n2 + 1][n4][n2 - 1] = (double)((instanceCount - (long)n3) * (long)(n3 << n2)) < d;
                            int n6 = n4 + 1;
                            d -= (double)n4 * (d - (double)n5);
                            nArray[n6] = nArray[n6] * (int)d;
                        }
                        case 99: {
                            l = Test.lMeth();
                            switch (n % 2 * 5 + 28) {
                                case 37: {
                                    f += (float)(n4 + n5);
                                    switch (n2 % 4 + 111) {
                                        case 111: 
                                        case 112: {
                                            iFld1 = (int)(d += (double)n3);
                                            iFld1 = -8958;
                                            continue block15;
                                        }
                                        case 113: {
                                            Test.dArrFld[n - 1] = n2;
                                            continue block15;
                                        }
                                        case 114: {
                                            instanceCount = n3;
                                            continue block15;
                                        }
                                    }
                                    nArray[n2 + 1] = n5;
                                    continue block15;
                                }
                                case 32: {
                                    n5 += n4;
                                }
                            }
                            l = n2;
                        }
                    }
                }
            }
        } while ((n -= 2) > 0);
        vMeth1_check_sum += l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + FuzzerUtils.checkSum((Object[][])blArray) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth(double d, int n, byte by) {
        int n2 = -1;
        int n3 = -1;
        int n4 = -179;
        int n5 = -49;
        int n6 = -200;
        int[] nArray = new int[400];
        boolean bl = true;
        FuzzerUtils.init(nArray, -92);
        try {
            try {
                Test.vMeth1(instanceCount);
                n2 = 1;
                if (++n2 < 380) {
                    instanceCount *= -19754L;
                    n -= 14;
                }
            } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
                nArray[(n5 >>> 1) % 400] = iFld2;
            }
        } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
            instanceCount -= 6L;
        }
        vMeth_check_sum += Double.doubleToLongBits(d) + (long)n + (long)by + (long)n2 + (long)n3 + (long)n4 + (long)(bl ? 1 : 0) + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        byte by = 73;
        byte by2 = 9;
        short s = 10983;
        int n = -131;
        int n2 = 1;
        int n3 = -7;
        int n4 = 12;
        int n5 = -5;
        int n6 = 54169;
        int n7 = -3;
        int n8 = 12;
        int n9 = -27911;
        double d = -96.23647;
        float f = -17.739f;
        float f2 = 0.133f;
        boolean bl = false;
        int n10 = (this.iFld >>> 1) % 400;
        int n11 = this.iArrFld[n10] * (int)((long)(s * this.iFld) + lArrFld[(this.iFld >>> 1) % 400]);
        this.iArrFld[n10] = n11;
        by = (byte)(by * (byte)n11);
        for (n = 3; 263 > n; ++n) {
            for (n3 = 6; n3 < 97; ++n3) {
                n2 += (int)((long)by2 + instanceCount + (long)n4++ - (long)n);
                int n12 = n3 + 1;
                this.iArrFld[n12] = this.iArrFld[n12] + n4;
                Test.vMeth(d, n4, by2);
                instanceCount += (long)(-7 + n3 * n3);
            }
        }
        n4 *= this.iFld;
        block21: for (n5 = 21; n5 < 356; ++n5) {
            this.iArrFld = FuzzerUtils.int1array(400, -41537);
            n2 += n4;
            iFld1 = n3;
            this.iFld = (int)((long)this.iFld + (long)n5 * instanceCount);
            switch (n5 % 10 + 107) {
                case 107: {
                    for (n7 = 4; n7 < 75; ++n7) {
                        instanceCount *= instanceCount;
                        d += 36444.0;
                    }
                    switch ((n7 >>> 1) % 1 + 69) {
                        case 69: {
                            iFld1 += -52;
                        }
                    }
                }
                case 108: {
                    block23: for (f = 75.0f; f > 1.0f; f -= 1.0f) {
                        switch (n5 % 2 * 5 + 52) {
                            case 58: {
                                n4 ^= n6;
                                f2 = 1.0f;
                                do {
                                    int n13 = -28398;
                                    s = (short)(s - 62);
                                    n8 *= (n6 += (int)(f2 * f2));
                                    instanceCount += (long)f2;
                                } while ((f2 += 1.0f) < 2.0f);
                                continue block23;
                            }
                            case 53: {
                                iFld1 += (int)(f * f);
                            }
                        }
                    }
                    continue block21;
                }
                case 109: {
                    int n14 = n5;
                    lArrFld[n14] = lArrFld[n14] - (long)iFld2;
                    continue block21;
                }
                case 110: {
                    instanceCount += (long)this.iFld;
                    continue block21;
                }
                case 111: {
                    n4 += n5;
                    continue block21;
                }
                case 112: {
                    iFld2 *= (int)instanceCount;
                    continue block21;
                }
                case 113: {
                    if (!bl) continue block21;
                    continue block21;
                }
                case 114: {
                    this.iFld = iFld2;
                    continue block21;
                }
                case 115: {
                    iFld1 = (int)instanceCount;
                    continue block21;
                }
                case 116: {
                    n6 ^= 0x64;
                }
            }
        }
        FuzzerUtils.out.println("by s i = " + by + "," + s + "," + n);
        FuzzerUtils.out.println("i1 i2 i3 = " + n2 + "," + n3 + "," + n4);
        FuzzerUtils.out.println("by1 d3 i20 = " + by2 + "," + Double.doubleToLongBits(d) + "," + n5);
        FuzzerUtils.out.println("i21 i22 i23 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("f2 i24 b1 = " + Float.floatToIntBits(f) + "," + n9 + "," + (bl ? 1 : 0));
        FuzzerUtils.out.println("f3 = " + Float.floatToIntBits(f2));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.sFld = " + instanceCount + "," + this.iFld + "," + sFld);
        FuzzerUtils.out.println("Test.iFld1 Test.iFld2 iArrFld = " + iFld1 + "," + iFld2 + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("Test.lArrFld Test.dArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, -8170282211557344849L);
        FuzzerUtils.init(dArrFld, 1.122512);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        lMeth_check_sum = 0L;
    }
}


/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 1357939091223354103L;
    public static volatile byte byFld = (byte)-99;
    public static short sFld = (short)-6987;
    public static volatile float fFld = 17.903f;
    public static boolean bFld = true;
    public static byte[] byArrFld = new byte[400];
    public static volatile int[][] iArrFld = new int[400][400];
    public int[][][] iArrFld1 = new int[400][400][400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2(int n, int n2) {
        int[][] nArray = new int[400][400];
        FuzzerUtils.init(nArray, -201);
        instanceCount >>= (int)instanceCount;
        nArray[(n2 >>> 1) % 400][(n2 >>> 1) % 400] = n2;
        vMeth2_check_sum += (long)(n + n2) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth1(int n) {
        long l = 247L;
        long[] lArray = new long[400];
        int n2 = 12;
        int n3 = 0;
        int n4 = 145;
        int n5 = -43482;
        int n6 = -52068;
        int[] nArray = new int[400];
        float f = -87.492f;
        int n7 = -31492;
        FuzzerUtils.init(nArray, 231);
        FuzzerUtils.init(lArray, -5L);
        Test.vMeth2(n, n);
        instanceCount = n;
        n = -5;
        for (l = 7L; l < 176L; ++l) {
            for (n3 = 1; n3 < 9; ++n3) {
                for (n5 = 1; n5 < 2; ++n5) {
                    nArray[(int)l] = byFld;
                    n7 = (short)n5;
                    int n8 = n3;
                    lArray[n8] = lArray[n8] + (long)f;
                    instanceCount = n6;
                    n4 += n5 * n5 + n4 - n2;
                    n6 = (int)((long)n6 + ((long)n5 - instanceCount));
                    int n9 = (int)l;
                    byArrFld[n9] = (byte)(byArrFld[n9] + (byte)n4);
                }
            }
        }
        vMeth1_check_sum += (long)n + l + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)Float.floatToIntBits(f) + (long)n7 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
    }

    public static void vMeth() {
        int n = 244;
        int n2 = 3;
        int n3 = -211;
        int n4 = 1839;
        int n5 = 41349;
        int n6 = -105;
        boolean bl = true;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 8526806788229371650L);
        Test.vMeth1(n);
        int[] nArray = iArrFld[11];
        int n7 = (n >>> 1) % 400;
        nArray[n7] = nArray[n7] + n;
        n2 = 1;
        while (++n2 < 295) {
            for (n3 = 6; n3 > n2; n3 -= 2) {
                sFld = (short)n3;
                int n8 = n2;
                lArray[n8] = lArray[n8] * (long)n4;
                Test.iArrFld[n2 + 1][n2 + 1] = n3;
                n5 = 1;
                while (++n5 < 1) {
                    float f = 6.709f;
                    n6 = n3;
                    f -= (float)sFld;
                }
                sFld = (short)6;
                fFld += (float)n3;
                byFld = 1;
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + (bl ? 1 : 0)) + FuzzerUtils.checkSum(lArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -14401;
        int n2 = -67;
        int n3 = 4264;
        int n4 = 15349;
        long l = 209104693303269339L;
        long[] lArray = new long[400];
        float[][] fArray = new float[400][400];
        FuzzerUtils.init(fArray, 88.909f);
        FuzzerUtils.init(lArray, 230L);
        Test.vMeth();
        for (n = 13; n < 359; ++n) {
            for (l = 2L; l < 73L; ++l) {
                n4 = 1;
                block17: do {
                    switch ((int)(l % 8L + 21L)) {
                        case 21: {
                            n3 += n3;
                            n3 = n4;
                        }
                        case 22: {
                            this.iArrFld1 = this.iArrFld1;
                            instanceCount += (long)(4 + n4 * n4);
                            instanceCount *= (long)fFld;
                            instanceCount <<= n3;
                        }
                        case 23: {
                            n3 += n4;
                            n2 = (int)l;
                            break;
                        }
                        case 24: {
                            instanceCount ^= (long)n4;
                            fFld += 3.0f;
                            instanceCount = l;
                            switch (n4 % 4 + 58) {
                                case 58: 
                                case 59: {
                                    sFld = (short)(sFld + (short)n4);
                                    n3 = (int)((float)n3 + ((float)n4 * fFld + (float)n4 - (float)n4));
                                    instanceCount += (long)(n4 * n3 + n4 - n2);
                                }
                                case 60: {
                                    n2 += 6278 + n4 * n4;
                                    fArray[n4 + 1][n4] = byFld;
                                    break;
                                }
                                case 61: {
                                    n2 = n3;
                                    n3 *= (int)instanceCount;
                                    n3 *= n3;
                                    n3 >>= 23;
                                }
                            }
                            continue block17;
                        }
                        case 25: {
                            int[] nArray = iArrFld[n4 + 1];
                            int n5 = n;
                            nArray[n5] = nArray[n5] - sFld;
                            if (bFld) continue block17;
                            n2 = 5872;
                        }
                        case 26: {
                            this.iArrFld1[n4][(int)(l - 1L)][(int)(l + 1L)] = n;
                            break;
                        }
                        case 27: {
                            int n6 = n - 1;
                            lArray[n6] = lArray[n6] + (long)n4;
                            break;
                        }
                        case 28: {
                            byFld = (byte)(byFld - (byte)n3);
                        }
                    }
                } while (++n4 < 2);
            }
        }
        FuzzerUtils.out.println("i14 i15 l1 = " + n + "," + n2 + "," + l);
        FuzzerUtils.out.println("i16 i17 fArr = " + n3 + "," + n4 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("lArr2 = " + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.sFld = " + instanceCount + "," + byFld + "," + sFld);
        FuzzerUtils.out.println("Test.fFld Test.bFld Test.byArrFld = " + Float.floatToIntBits(fFld) + "," + (bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(byArrFld));
        FuzzerUtils.out.println("Test.iArrFld iArrFld1 = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum((Object[][])this.iArrFld1));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(byArrFld, (byte)-24);
        FuzzerUtils.init(iArrFld, -8064);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}


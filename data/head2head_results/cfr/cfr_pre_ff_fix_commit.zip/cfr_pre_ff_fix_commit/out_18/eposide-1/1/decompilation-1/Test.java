/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 117L;
    public static double dFld = 0.61587;
    public static int iFld = 169;
    public static short sFld = (short)31544;
    public static boolean bFld = false;
    public static int[] iArrFld = new int[400];
    public static long[] lArrFld = new long[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2(long l, long l2, long l3) {
        int n = -20;
        int n2 = -26447;
        int n3 = 209;
        int n4 = 4;
        int n5 = 10;
        int n6 = 248;
        int n7 = -53419;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, 23.31567);
        int n8 = (n >>> 1) % 400;
        iArrFld[n8] = iArrFld[n8] * (int)instanceCount;
        n = 121;
        n2 = 1;
        do {
            n = (int)((long)n + ((long)n2 * l2 + (long)(n3 &= 0x454A312E) - l));
            for (n4 = 1; n4 < 7; ++n4) {
                for (n6 = 1; 2 > n6; ++n6) {
                    n = (int)l3;
                    n5 = (int)l;
                    n5 += n6 * n7 + n7 - n6;
                }
                Test.iArrFld[n4 - 1] = n3;
                dFld = n4;
                n3 >>= n7;
            }
        } while (++n2 < 247);
        vMeth2_check_sum += l + l2 + l3 + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public static void vMeth1(int n, int n2, long l) {
        Test.vMeth2(instanceCount, -5539L, instanceCount);
        vMeth1_check_sum += (long)(n + n2) + l;
    }

    public static void vMeth() {
        int n = 194;
        int n2 = 183;
        int n3 = 118;
        int n4 = 250;
        float f = -82.745f;
        boolean bl = false;
        Test.vMeth1(iFld, iFld, instanceCount);
        n = 135;
        while ((n -= 3) > 0) {
            if (!bl) continue;
            for (f = 2.0f; f < 34.0f; f += 1.0f) {
                iFld += (int)f;
                dFld = instanceCount;
                int n5 = n;
                iArrFld[n5] = iArrFld[n5] & sFld;
                block8: for (n3 = 1; n3 < 2; n3 += 2) {
                    int n6 = n - 1;
                    iArrFld[n6] = iArrFld[n6] << -6;
                    iFld -= (int)instanceCount;
                    n2 += n2;
                    switch ((int)(f % 4.0f * 5.0f + 114.0f)) {
                        case 132: {
                            n4 += n;
                            int n7 = (n >>> 1) % 400;
                            iArrFld[n7] = iArrFld[n7] * (int)instanceCount;
                        }
                        case 129: {
                            instanceCount = 38114L;
                        }
                        case 119: {
                            instanceCount += (long)n3;
                            continue block8;
                        }
                        case 128: {
                            int n8 = (int)f;
                            iArrFld[n8] = iArrFld[n8] - (int)f;
                            continue block8;
                        }
                        default: {
                            n2 += n3;
                        }
                    }
                }
            }
        }
        vMeth_check_sum += (long)(n + Float.floatToIntBits(f) + n2 + n3 + n4 + (bl ? 1 : 0));
    }

    public void mainTest(String[] stringArray) {
        int n = 9136;
        int n2 = 1;
        int n3 = 240;
        int n4 = 9;
        int n5 = 0;
        int n6 = -5299;
        int n7 = 51304;
        int n8 = 40;
        int n9 = 159;
        int n10 = -96;
        int n11 = 17219;
        byte by = 72;
        float f = -2.636f;
        float f2 = -96.131f;
        long l = 3L;
        short[] sArray = new short[400];
        FuzzerUtils.init(sArray, (short)-9447);
        Test.vMeth();
        dFld += dFld;
        n = 1;
        do {
            int n12 = -18;
            Test.lArrFld[n - 1] = iFld;
            n12 = (byte)dFld;
            iFld &= (int)instanceCount;
            sArray[n + 1] = 184;
            n2 += n;
            Test.iArrFld[n + 1] = (int)instanceCount;
        } while (++n < 226);
        for (n3 = 5; n3 < 150; ++n3) {
            try {
                Test.iArrFld[n3] = iFld / n;
                Test.iArrFld[n3 - 1] = 211 / iFld;
                n2 = -449118972 % n2;
            } catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            block16: for (n5 = 3; n5 < 173; ++n5) {
                Test.lArrFld[n5 - 1] = n;
                n7 = 1;
                while (++n7 < 2) {
                    n2 = -99549986;
                }
                instanceCount = n5;
                n6 += n5 * iFld;
                switch (n3 % 10 + 80) {
                    case 80: {
                        n2 -= by;
                        n4 = -4;
                        for (n8 = 2; n8 > 1; --n8) {
                            n2 += n8 - n2;
                            n4 <<= n2;
                            n4 = (int)((float)n4 + ((float)n8 + f));
                            bFld = true;
                            instanceCount <<= n8;
                            n2 *= (int)f;
                        }
                        for (f2 = 1.0f; f2 < 2.0f; f2 += 1.0f) {
                            n6 += (int)(f2 * (float)instanceCount + (float)n3 - (float)n3);
                            if (bFld) break;
                        }
                    }
                    case 81: {
                        n6 = sFld;
                        continue block16;
                    }
                    case 82: {
                        f += (float)n5;
                        continue block16;
                    }
                    case 83: {
                        int n13 = n3 - 1;
                        lArrFld[n13] = lArrFld[n13] >> -2;
                    }
                    case 84: {
                        n9 *= (int)l;
                        continue block16;
                    }
                    case 85: {
                        lArrFld[0] = lArrFld[0] & instanceCount;
                    }
                    case 86: {
                        n4 = -10;
                    }
                    case 87: {
                        iFld = n8;
                        continue block16;
                    }
                    case 88: {
                        iFld *= n4;
                    }
                    case 89: {
                        dFld += 27.0;
                        continue block16;
                    }
                    default: {
                        iFld = (int)((float)iFld + ((float)(n5 * n11 + iFld) - f2));
                    }
                }
            }
        }
        FuzzerUtils.out.println("i13 i14 i15 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i16 i17 i18 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i19 by1 i20 = " + n7 + "," + by + "," + n8);
        FuzzerUtils.out.println("i21 f1 f2 = " + n9 + "," + Float.floatToIntBits(f) + "," + Float.floatToIntBits(f2));
        FuzzerUtils.out.println("i22 l4 i23 = " + n10 + "," + l + "," + n11);
        FuzzerUtils.out.println("sArr = " + FuzzerUtils.checkSum(sArray));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.iFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + iFld);
        FuzzerUtils.out.println("Test.sFld Test.bFld Test.iArrFld = " + sFld + "," + (bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.lArrFld = " + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 7);
        FuzzerUtils.init(lArrFld, 30L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}


/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 4219720187L;
    public static float fFld = -2.135f;
    public int iFld = -8;
    public boolean bFld = false;
    public static short sFld = (short)8347;
    public long lFld = -52954L;
    public static int iFld1 = 4916;
    public static float[] fArrFld = new float[400];
    public static long[] lArrFld = new long[400];
    public static int[] iArrFld = new int[400];
    public static double[] dArrFld = new double[400];
    public static long vMeth_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1() {
        int n = -454;
        int n2 = -11;
        int n3 = -7;
        int n4 = -1850;
        int n5 = -9;
        int n6 = 140;
        int[] nArray = new int[400];
        float f = 2.24f;
        FuzzerUtils.init(nArray, -228);
        for (n = 148; n > 8; --n) {
            n2 -= (int)instanceCount;
            n2 = -2;
            instanceCount *= (long)fFld;
        }
        for (n3 = 1; 351 > n3; ++n3) {
            n2 += n2;
            for (n5 = 1; n5 < 5; ++n5) {
                n2 += 28;
            }
            nArray[n3] = 46857;
            f = 1.0f;
            do {
                int n7 = n3 + 1;
                nArray[n7] = nArray[n7] ^ n;
                n6 = (int)instanceCount;
                n4 = n5;
                Test.fArrFld[n3 - 1] = n3;
                fFld += f * (float)n6;
            } while ((f += 1.0f) < 5.0f);
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + Float.floatToIntBits(f)) + FuzzerUtils.checkSum(nArray);
    }

    public static int iMeth(long l) {
        int n = 43757;
        int n2 = 6;
        int n3 = -12502;
        int n4 = -80;
        int n5 = -58622;
        int n6 = 190;
        int n7 = 13;
        int n8 = -42485;
        double d = 61.7661;
        boolean[][][] blArray = new boolean[400][400][400];
        FuzzerUtils.init((Object[][])blArray, (Object)true);
        for (n = 18; n < 333; ++n) {
            Test.vMeth1();
        }
        for (n3 = 11; n3 < 262; ++n3) {
            instanceCount -= (long)n3;
            fFld += (float)n3;
            for (n5 = n3; 6 > n5; ++n5) {
                Test.lArrFld[n3 - 1] = n;
                n2 *= (int)l;
                n2 -= (int)d;
                n6 &= 0xFFFFFF39;
                for (n7 = 1; n7 < 1; ++n7) {
                    n6 <<= 24893;
                    l = -6L;
                    blArray[n3 - 1][n3 + 1][n7 - 1] = false;
                    n4 = n3;
                }
            }
        }
        long l2 = l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + Double.doubleToLongBits(d) + (long)n7 + (long)n8 + FuzzerUtils.checkSum((Object[][])blArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public static void vMeth() {
        int n = -4;
        int n2 = -8630;
        int n3 = -2;
        int n4 = 223;
        int n5 = 40501;
        int n6 = -90;
        int n7 = 148;
        int n8 = 50961;
        double d = -25.83243;
        for (n = 1; n < 212; ++n) {
            for (n3 = 1; n3 < 8; ++n3) {
                Test.iMeth(instanceCount);
                fFld = instanceCount;
            }
            Test.fArrFld[n] = 2.58f;
            n2 -= 46;
            instanceCount = n4;
            if (n4 != 0) {
                vMeth_check_sum += (long)(n + n2 + n3 + n4) + Double.doubleToLongBits(d) + (long)n5 + (long)n6 + (long)n7 + (long)n8;
                return;
            }
            n4 += (int)(33.947f + (float)(n * n));
        }
        fFld = (float)d;
        for (n5 = 12; n5 < 224; ++n5) {
            for (n7 = 1; n7 < 8; ++n7) {
                Test.dArrFld[n7] = n8;
                instanceCount *= (long)n;
                try {
                    n2 = n7 % iArrFld[n5];
                    n4 = 251 / n2;
                    n8 = n4 % n6;
                    continue;
                } catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4) + Double.doubleToLongBits(d) + (long)n5 + (long)n6 + (long)n7 + (long)n8;
    }

    public void mainTest(String[] stringArray) {
        int n = 59881;
        int n2 = -116;
        int n3 = 26812;
        int n4 = -22286;
        double d = 50.49779;
        boolean[] blArray = new boolean[400];
        float[] fArray = new float[400];
        byte[] byArray = new byte[400];
        FuzzerUtils.init(blArray, true);
        FuzzerUtils.init(fArray, 0.764f);
        FuzzerUtils.init(byArray, (byte)-94);
        fFld += (float)this.iFld;
        this.iFld >>= (int)instanceCount;
        Test.vMeth();
        fFld = this.iFld;
        this.iFld = this.iFld;
        fFld = this.iFld;
        this.iFld <<= this.iFld;
        for (n = 4; n < 206; ++n) {
            double d2 = -124.2196;
            n2 -= n2;
        }
        FuzzerUtils.out.println("i23 i24 i25 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("d3 i26 bArr1 = " + Double.doubleToLongBits(d) + "," + n4 + "," + FuzzerUtils.checkSum(blArray));
        FuzzerUtils.out.println("fArr byArr = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + "," + FuzzerUtils.checkSum(byArray));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld iFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + this.iFld);
        FuzzerUtils.out.println("bFld Test.sFld lFld = " + (this.bFld ? 1 : 0) + "," + sFld + "," + this.lFld);
        FuzzerUtils.out.println("Test.iFld1 Test.fArrFld Test.lArrFld = " + iFld1 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("Test.iArrFld Test.dArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(fArrFld, 0.289f);
        FuzzerUtils.init(lArrFld, -6681482347934281268L);
        FuzzerUtils.init(iArrFld, -172);
        FuzzerUtils.init(dArrFld, -1.93797);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}


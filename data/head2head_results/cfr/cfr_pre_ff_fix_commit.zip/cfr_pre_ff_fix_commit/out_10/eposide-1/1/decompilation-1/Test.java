/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 822963037027084301L;
    public volatile int iFld = 98;
    public static double dFld = 2.65278;
    public static int iFld1 = 186;
    public static int iFld2 = -61913;
    public static boolean bFld = false;
    public static long vMeth_check_sum = 0L;
    public static long iMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;

    public static void vMeth1() {
        int n = 41;
        int n2 = -14;
        int n3 = -96;
        int n4 = 122;
        int n5 = 85;
        int[] nArray = new int[400];
        float f = 55.398f;
        FuzzerUtils.init(nArray, -15821);
        for (int n6 : nArray) {
            for (n = 1; n < 4; ++n) {
                n6 *= (int)instanceCount;
                int n7 = n - 1;
                nArray[n7] = nArray[n7] + n;
            }
            nArray[(n2 >>> 1) % 400] = (int)f;
            instanceCount -= (long)n;
            n3 = 1;
            while (++n3 < 4) {
                n6 += n2;
                instanceCount += (long)(n3 * n3);
            }
            for (n4 = 1; 4 > n4; n4 += 2) {
                f += (float)n4;
                n5 <<= n3;
            }
            if (n2 != 0) {
                vMeth1_check_sum += (long)(n + n2 + Float.floatToIntBits(f) + n3 + n4 + n5) + FuzzerUtils.checkSum(nArray);
                return;
            }
            n6 *= (int)f;
        }
        f = 54446.0f;
        vMeth1_check_sum += (long)(n + n2 + Float.floatToIntBits(f) + n3 + n4 + n5) + FuzzerUtils.checkSum(nArray);
    }

    public static int iMeth(float f, int n, int n2) {
        int n3 = 155;
        int n4 = 6;
        int n5 = 58334;
        int n6 = -38661;
        int n7 = 32;
        int n8 = -6;
        int[][] nArray = new int[400][400];
        boolean bl = true;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, 36287);
        FuzzerUtils.init(lArray, 1020975308L);
        int[] nArray2 = nArray[(n >>> 1) % 400];
        int n9 = (n2 >>> 1) % 400;
        int n10 = nArray2[n9] + 1;
        nArray2[n9] = n10;
        n2 = n10;
        for (n3 = 4; n3 < 155; ++n3) {
            for (n5 = 10; n3 < n5; --n5) {
                Test.vMeth1();
                int n11 = n5;
                lArray[n11] = lArray[n11] + -5L;
                for (n7 = 1; n7 < 1; ++n7) {
                    f *= (float)n8;
                    n8 += n;
                    n6 >>= (int)(instanceCount *= -14387L);
                    n2 *= n2;
                    n4 = (int)instanceCount;
                    instanceCount >>= (int)instanceCount;
                    f = n2;
                }
            }
        }
        long l = (long)(Float.floatToIntBits(f) + n + n2 + n3 + n4 + n5 + n6 + (bl ? 1 : 0) + n7 + n8) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void vMeth(int n, int n2, double d) {
        n = Test.iMeth(-114.61f, n2, n2);
        instanceCount -= (long)n;
        vMeth_check_sum += (long)(n + n2) + Double.doubleToLongBits(d);
    }

    public void mainTest(String[] stringArray) {
        int n = -245;
        int n2 = -12;
        int n3 = 13;
        int n4 = -126;
        int n5 = -3;
        int n6 = 63136;
        int n7 = 158;
        int[] nArray = new int[400];
        float f = -115.405f;
        byte by = 27;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, -37063);
        FuzzerUtils.init(lArray, 207L);
        this.vMeth(this.iFld, -237, dFld);
        instanceCount += instanceCount;
        this.iFld >>= this.iFld;
        for (n = 10; 272 > n; n += 3) {
            instanceCount >>= (int)instanceCount;
            try {
                nArray[n] = n2 % this.iFld;
                nArray[n - 1] = nArray[n] / -21;
                n2 = this.iFld % n2;
            } catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            this.iFld %= n | 1;
            for (n3 = n; n3 < 288; ++n3) {
                switch ((n3 >>> 1) % 1 + 80) {
                    case 80: {
                        iFld1 = (int)(instanceCount *= -24445L);
                        for (n5 = n; n5 < 1; ++n5) {
                            switch ((iFld1 >>> 1) % 2 + 73) {
                                case 73: {
                                    iFld1 += n5;
                                    int n8 = n3;
                                    lArray[n8] = lArray[n8] * (long)n6;
                                }
                                case 74: {
                                    iFld2 += iFld2;
                                    n6 = (int)instanceCount;
                                    iFld2 *= (int)instanceCount;
                                    instanceCount += instanceCount;
                                }
                            }
                            n4 = (int)dFld;
                            f *= (float)n6;
                        }
                        iFld2 -= (int)f;
                    }
                }
                iFld1 = 28978;
            }
            if (!bFld) continue;
            by = (byte)instanceCount;
            n7 = 1;
            do {
                iFld2 = n2 += (int)instanceCount;
                int n9 = n7 + 1;
                nArray[n9] = nArray[n9] << n3;
                instanceCount += instanceCount;
            } while (++n7 < 288);
        }
        FuzzerUtils.out.println("i16 i17 i18 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i19 i20 i21 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("f2 by i22 = " + Float.floatToIntBits(f) + "," + by + "," + n7);
        FuzzerUtils.out.println("iArr2 lArr1 = " + FuzzerUtils.checkSum(nArray) + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.dFld = " + instanceCount + "," + this.iFld + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.iFld1 Test.iFld2 Test.bFld = " + iFld1 + "," + iFld2 + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}


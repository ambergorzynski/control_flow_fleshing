/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -3636L;
    public static double dFld = -2.14782;
    public static float fFld = -2.435f;
    public volatile short sFld = (short)10924;
    public static int iFld = 186;
    public static int[] iArrFld = new int[400];
    public static long iMeth_check_sum;
    public static long bMeth_check_sum;
    public static long iMeth1_check_sum;

    public static int iMeth1(int n, int n2, int n3) {
        float f = 2.94f;
        int n4 = -5;
        int n5 = -20584;
        int n6 = 25337;
        int n7 = -44210;
        int n8 = -12;
        int n9 = -17130;
        instanceCount *= (long)f;
        for (n4 = 1; n4 < 191; n4 += 2) {
            f = 205.0f;
            n += (int)(-7092688650316294824L + (long)(n4 * n4));
            f = instanceCount;
        }
        f *= (float)n3;
        instanceCount = n9;
        n6 = 1;
        do {
            n7 = 1;
            while (++n7 < 12) {
                n3 += n2;
                n8 = 1;
                do {
                    n5 = n3;
                    n2 += n7;
                    f += (float)n8;
                } while (++n8 < 1);
                n2 = (int)instanceCount;
            }
        } while (++n6 < 131);
        long l = n + n2 + n3 + Float.floatToIntBits(f) + n4 + n5 + n9 + n6 + n7 + n8;
        iMeth1_check_sum += l;
        return (int)l;
    }

    public static boolean bMeth() {
        int n = 13;
        int n2 = 10;
        int n3 = 4;
        int n4 = 162;
        int n5 = -14;
        double d = -61.84157;
        int n6 = -6568;
        boolean bl = true;
        for (n = 3; n < 378; ++n) {
            n2 += (int)(((double)n2 + dFld) * (double)Test.iMeth1(n2, n, 13) - dFld);
            n2 -= (int)fFld;
            if (n != 0) {
                return (int)((long)(n + n2 + n3 + n4) + Double.doubleToLongBits(d) + (long)n5 + (long)n6 + (long)(bl ? 1 : 0)) % 2 > 0;
            }
            if (bl) {
                for (n3 = 1; n3 < 5; ++n3) {
                    n4 += n3;
                    instanceCount += (long)n3;
                    instanceCount += (long)n3 * instanceCount + instanceCount - (long)n3;
                }
                for (d = 5.0; d > 1.0; d -= 1.0) {
                    n6 = (short)(n6 + (short)d);
                    instanceCount += (long)d;
                    n5 += n4;
                }
                continue;
            }
            n6 = (short)(n6 & (short)n3);
            bl = false;
        }
        long l = (long)(n + n2 + n3 + n4) + Double.doubleToLongBits(d) + (long)n5 + (long)n6 + (long)(bl ? 1 : 0);
        bMeth_check_sum += l;
        return l % 2L > 0L;
    }

    public static int iMeth(int n, int n2) {
        boolean bl = false;
        int n3 = -55;
        int n4 = 1;
        int n5 = -14;
        int n6 = 77;
        int n7 = 3;
        int n8 = -131;
        int n9 = -3;
        int n10 = 23035;
        float f = 64.54f;
        int n11 = -3510;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 7024398404642483959L);
        bl = Test.bMeth();
        for (n3 = 3; n3 < 179; ++n3) {
            n5 = 1;
            block12: while (++n5 < 9) {
                instanceCount = n5;
                instanceCount = n5;
                for (n6 = 1; n6 < 1; ++n6) {
                    if (bl) continue;
                    f += (float)n;
                    instanceCount <<= (int)instanceCount;
                    n += n;
                }
                switch (n5 % 9 + 39) {
                    case 39: {
                        n += 101 + n5 * n5;
                        for (n8 = 1; n8 < 1; ++n8) {
                            fFld = n2;
                        }
                        continue block12;
                    }
                    case 40: {
                        continue block12;
                    }
                    case 41: {
                        n7 = 73;
                    }
                    case 42: {
                        int n12 = n3;
                        iArrFld[n12] = iArrFld[n12] << n3;
                        continue block12;
                    }
                    case 43: {
                        n7 = n3;
                        continue block12;
                    }
                    case 44: {
                        n >>= 193;
                        continue block12;
                    }
                    case 45: {
                        n10 += n5 * n9 + n11 - n10;
                        continue block12;
                    }
                    case 46: {
                        n7 = (int)((long)n7 + ((long)n5 * instanceCount + (long)n9 - (long)n9));
                        continue block12;
                    }
                    case 47: {
                        instanceCount += (long)n10;
                    }
                }
                if (!bl) continue;
            }
        }
        long l = (long)(n + n2 + (bl ? 1 : 0) + n3 + n4 + n5 + n6 + n7 + Float.floatToIntBits(f) + n8 + n9 + n10 + n11) + FuzzerUtils.checkSum(lArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        int n = 31067;
        int n2 = -65278;
        int n3 = -12;
        int n4 = -32278;
        int n5 = 12448;
        int n6 = 48933;
        int n7 = -99;
        int n8 = 7;
        int n9 = 33685;
        int n10 = -93;
        double d = 22.53105;
        byte by = 88;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -4159366500L);
        n = 1;
        do {
            instanceCount += (long)(-15641 + n * n);
            for (n2 = 1; n2 < 68; ++n2) {
                Test.iMeth(112, n);
                n3 = -124;
                this.sFld = (short)n3;
            }
            for (n4 = n; n4 < 68; ++n4) {
                int n11 = n + 1;
                lArray[n11] = lArray[n11] * (long)n5;
                n3 *= (int)instanceCount;
                n3 += -15122 + n4 * n4;
            }
            Test.iArrFld[n] = n;
            int n12 = n + 1;
            iArrFld[n12] = iArrFld[n12] * iFld;
            n5 += n4;
        } while (++n < 369);
        for (n6 = 1; n6 < 153; ++n6) {
            n7 *= (int)instanceCount;
        }
        for (d = 4.0; 137.0 > d; d += 1.0) {
            by = (byte)(by - (byte)n5);
            n8 = n;
            instanceCount >>= n8;
            int n13 = (int)d;
            lArray[n13] = lArray[n13] - (long)n4;
            instanceCount = iFld %= -1;
            int n14 = (int)(d - 1.0);
            lArray[n14] = lArray[n14] - instanceCount;
            instanceCount >>>= n6;
            n3 *= (int)fFld;
            n7 *= -179;
        }
        for (n9 = 2; n9 < 124; ++n9) {
            n7 = this.sFld;
            iFld -= n5;
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i26 i27 i28 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i29 d1 i31 = " + n7 + "," + Double.doubleToLongBits(d) + "," + n8);
        FuzzerUtils.out.println("by i32 i33 = " + by + "," + n9 + "," + n10);
        FuzzerUtils.out.println("lArr1 = " + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.fFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("sFld Test.iFld Test.iArrFld = " + this.sFld + "," + iFld + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -32113);
        iMeth_check_sum = 0L;
        bMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
    }
}


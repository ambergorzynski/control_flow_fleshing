/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -1546288703L;
    public static float fFld = 10.391f;
    public static volatile int iFld = -19298;
    public static byte byFld = (byte)63;
    public int[] iArrFld = new int[400];
    public short[] sArrFld = new short[400];
    public static long vMeth_check_sum = 0L;
    public static long iMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;

    public static void vMeth1(short s, int n, int n2) {
        vMeth1_check_sum += (long)(s + n + n2);
    }

    public static int iMeth(long l) {
        int n = 157;
        int n2 = 1;
        int n3 = -20370;
        int[] nArray = new int[400];
        short s = 26358;
        boolean bl = true;
        FuzzerUtils.init(nArray, 46184);
        if (bl) {
            for (n = 1; n < 279; ++n) {
                l += (long)nArray[(n2 >>> 1) % 400];
                long l2 = l--;
                int n4 = n;
                int n5 = nArray[n4];
                nArray[n4] = n5 + 1;
                n2 = (int)(l2 + (long)Math.min((int)(instanceCount - (long)n), n5));
                Test.vMeth1(s, n2, n);
                int n6 = n + 1;
                nArray[n6] = nArray[n6] - n2;
                n3 = 1;
                do {
                    n2 >>>= 0;
                    n2 &= n3;
                    n2 *= n2;
                    n2 = n;
                    n2 = -13;
                    l += (long)(177 + n3 * n3);
                    if (n2 != 0) {
                        // empty if block
                    }
                    int n7 = n - 1;
                    nArray[n7] = nArray[n7] + n2;
                } while (++n3 < 6);
            }
        }
        long l3 = l + (long)n + (long)n2 + (long)s + (long)n3 + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l3;
        return (int)l3;
    }

    public static void vMeth(long l, int n) {
        int n2 = 36205;
        int n3 = -6920;
        int n4 = 11;
        int n5 = 181;
        int n6 = 1972;
        int n7 = -15;
        int n8 = -32548;
        int[][] nArray = new int[400][400];
        int n9 = 78;
        int n10 = 25757;
        boolean bl = false;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, 0);
        FuzzerUtils.init(lArray, -4189685778495759308L);
        for (n2 = 6; n2 < 164; ++n2) {
            n4 = 1;
            do {
                int[] nArray2 = nArray[n4 - 1];
                int n11 = n4;
                nArray2[n11] = nArray2[n11] + (int)((long)(n4 * n4 * -Test.iMeth(l)) * 2L);
                n = n9;
                int[] nArray3 = nArray[n4 + 1];
                int n12 = n4 + 1;
                nArray3[n12] = nArray3[n12] - n10;
                n3 += n4;
                n -= n4;
                for (n5 = 1; n5 > n4; --n5) {
                    n3 += n5;
                }
                int n13 = n4 - 1;
                lArray[n13] = lArray[n13] - 23683L;
                for (n7 = 1; n7 > 1; n7 -= 2) {
                    n3 = n -= 117;
                    n3 = (int)((long)n3 + ((long)n7 | (long)fFld));
                }
            } while (++n4 < 10);
        }
        vMeth_check_sum += l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n9 + (long)n10 + (long)n5 + (long)n6 + (long)(bl ? 1 : 0) + (long)n7 + (long)n8 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 9;
        int n2 = -30116;
        int n3 = -76;
        int n4 = 61018;
        int n5 = 8;
        int n6 = 11;
        int n7 = -112;
        int n8 = 9;
        int n9 = 33;
        int n10 = 60;
        short s = -9941;
        n = 1;
        do {
            Test.vMeth(-7656502963534235558L, n);
            iFld += (int)instanceCount;
            iFld >>= n;
            this.iArrFld[n + 1] = (int)instanceCount;
            for (n2 = n; 130 > n2; ++n2) {
                iFld = (int)((long)iFld + ((long)n2 | instanceCount));
                for (n4 = n2; n4 < 1; n4 += 3) {
                    n5 += n4 * n4;
                }
                for (n6 = n; n6 < 1; ++n6) {
                    n5 = (int)instanceCount;
                    n3 += n3;
                    n7 = n5;
                    this.iArrFld[n2] = n3;
                    instanceCount += (long)(n6 * n4 + iFld - iFld);
                }
                iFld >>= byFld;
                this.iArrFld[n2] = n6;
                n7 -= (n5 += n2 * n2);
                n5 = 1;
                n3 += s;
            }
            n8 = 1;
            while (++n8 < 130) {
                for (n9 = 1; n9 > 1; --n9) {
                    n3 += n9;
                    n3 += n9 * n9;
                    int n11 = n;
                    this.iArrFld[n11] = this.iArrFld[n11] & n9;
                    iFld -= (int)instanceCount;
                    int n12 = n8;
                    this.sArrFld[n12] = (short)(this.sArrFld[n12] * (short)n4);
                    n10 += (int)(-15924L + (long)(n9 * n9));
                    n3 *= s;
                }
            }
        } while (++n < 193);
        FuzzerUtils.out.println("i i14 i15 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i16 i17 i18 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i19 s3 i20 = " + n7 + "," + s + "," + n8);
        FuzzerUtils.out.println("i21 i22 = " + n9 + "," + n10);
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.iFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + iFld);
        FuzzerUtils.out.println("Test.byFld iArrFld sArrFld = " + byFld + "," + FuzzerUtils.checkSum(this.iArrFld) + "," + FuzzerUtils.checkSum(this.sArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}


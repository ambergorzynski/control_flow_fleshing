/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 4L;
    public static double dFld = 69.63166;
    public static float fFld = -94.864f;
    public static long[] lArrFld = new long[400];
    public static byte[] byArrFld = new byte[400];
    public static long vMeth_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n, int n2, int n3) {
        n2 -= n2;
        n2 = 60431;
        vMeth1_check_sum += (long)(n + n2 + n3);
    }

    public static int iMeth(int n) {
        double d = 0.129846;
        int n2 = -4;
        int n3 = 216;
        int n4 = 7105;
        int n5 = 7;
        int[] nArray = new int[400];
        boolean bl = false;
        int n6 = -11;
        FuzzerUtils.init(nArray, -60333);
        if (bl) {
            Test.vMeth1(3453, n, n);
            for (d = 12.0; d < 390.0; d += 1.0) {
                n += n2;
                n3 = 1;
                block4: do {
                    switch ((n2 >>> 1) % 1 * 5 + 98) {
                        case 99: {
                            n2 *= n;
                            n6 = (byte)(n6 * (byte)(instanceCount -= (long)n));
                        }
                    }
                    instanceCount <<= n2;
                    for (n4 = 1; n4 < 1; ++n4) {
                        int n7 = -21155;
                        n7 = 1745;
                        n5 += n4 + n3;
                        if (bl) continue block4;
                    }
                } while (++n3 < 4);
            }
        } else if (bl) {
            instanceCount += (long)n;
        }
        long l = (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)(bl ? 1 : 0) + (long)n3 + (long)n6 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public static void vMeth(int n, int n2) {
        int n3 = 45888;
        int n4 = -50;
        int n5 = -15;
        int n6 = 11;
        int[] nArray = new int[400];
        long l = -3402885753L;
        float f = -9.639f;
        FuzzerUtils.init(nArray, 5);
        n += (int)((long)Math.abs(n - n2) - ((long)n2 - -2911703536L * (long)(n2 * n)));
        n2 *= (int)Float.intBitsToFloat(n2 * n2 + nArray[(n >>> 1) % 400]);
        ++n2;
        instanceCount = n;
        int n7 = ((n2 += Test.iMeth(-30974)) >>> 1) % 400;
        nArray[n7] = nArray[n7] + n3;
        block4: for (l = 2L; 275L > l; l += 2L) {
            n3 = n;
            switch ((int)(l % 2L + 121L)) {
                case 121: {
                    for (n5 = 1; n5 < 12; ++n5) {
                        dFld -= (double)n2;
                        nArray[(int)(l + 1L)] = n2;
                        int n8 = (int)l;
                        byArrFld[n8] = (byte)(byArrFld[n8] + (byte)f);
                        n += n5;
                        n3 += n2;
                    }
                    continue block4;
                }
                case 122: {
                    n4 += (int)(l + (long)n6);
                    continue block4;
                }
                default: {
                    n -= n4;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3) + l + (long)n4 + (long)n5 + (long)n6 + (long)Float.floatToIntBits(f) + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 61395;
        int n2 = 39;
        int n3 = -11;
        int n4 = -2;
        int n5 = 69;
        int[] nArray = new int[400];
        float f = -33.637f;
        boolean bl = true;
        short s = -25642;
        FuzzerUtils.init(nArray, -11951);
        for (n = 13; n < 337; n += 3) {
            for (n3 = n; 232 > n3; ++n3) {
                block11: for (f = 1.0f; f < 1.0f; f += 1.0f) {
                    n4 = (int)((float)n4 + (17273.0f + f * f));
                    switch ((n3 >>> 1) % 7 + 122) {
                        case 122: {
                            n5 = n5++ - (int)((long)(n4 + n5) * lArrFld[n]);
                            instanceCount += (long)f;
                            Test.vMeth(n4, n4);
                            nArray[n3 - 1] = n;
                            continue block11;
                        }
                        case 123: {
                            n4 >>= n5;
                        }
                        case 124: {
                            int n6 = n;
                            lArrFld[n6] = lArrFld[n6] * instanceCount;
                            instanceCount += (long)f;
                            continue block11;
                        }
                        case 125: {
                            n2 -= n4;
                            continue block11;
                        }
                        case 126: {
                            fFld = n2;
                            instanceCount += instanceCount;
                            instanceCount += (long)f;
                            instanceCount |= instanceCount;
                            continue block11;
                        }
                        case 127: {
                            int n7 = n3;
                            nArray[n7] = nArray[n7] << n;
                            if (!bl) continue block11;
                            continue block11;
                        }
                        case 128: {
                            instanceCount *= (long)f;
                            n4 = n3;
                            s = (short)(s - (short)n4);
                            n4 += n2;
                            continue block11;
                        }
                        default: {
                            fFld += 3.7837545E9f;
                            s = (short)(s >> -2);
                            fFld += (float)((long)f ^ (long)n);
                        }
                    }
                }
                instanceCount >>= n5;
                instanceCount = n2;
                instanceCount -= (long)n4;
            }
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i3 f i4 = " + n4 + "," + Float.floatToIntBits(f) + "," + n5);
        FuzzerUtils.out.println("b1 s1 iArr2 = " + (bl ? 1 : 0) + "," + s + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.fFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.lArrFld Test.byArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(byArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, -9L);
        FuzzerUtils.init(byArrFld, (byte)-106);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}


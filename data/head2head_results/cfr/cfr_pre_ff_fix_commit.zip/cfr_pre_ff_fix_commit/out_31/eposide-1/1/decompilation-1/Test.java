/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -153L;
    public static int iFld = -2;
    public static volatile short sFld = (short)9171;
    public double dFld = 1.80407;
    public static float fFld = 0.498f;
    public int[] iArrFld = new int[400];
    public long[] lArrFld = new long[400];
    public static long vMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;
    public static long bMeth_check_sum = 0L;

    public static boolean bMeth(int n, int n2, float f) {
        int n3 = -9;
        int n4 = 85;
        int n5 = 59880;
        int n6 = 125;
        int n7 = 52947;
        int n8 = -3;
        int n9 = -189;
        double d = 42.78609;
        int n10 = -20;
        for (n3 = 12; 230 > n3; ++n3) {
            iFld <<= n2;
        }
        d += (double)instanceCount;
        iFld += -12;
        n = 0;
        for (n5 = 8; n5 < 167; ++n5) {
            n2 = (int)instanceCount;
            n7 = 10;
            do {
                for (n8 = 1; n8 > 1; --n8) {
                    n6 += 5 + n8 * n8;
                }
                sFld = (short)(sFld + -25587);
                n2 = 10;
                f -= (float)n8;
                n10 = (byte)(n10 & 5);
                sFld = (short)(sFld + (short)n6);
            } while (--n7 > 0);
        }
        long l = (long)(n + n2 + Float.floatToIntBits(f) + n3 + n4) + Double.doubleToLongBits(d) + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)n9 + (long)n10;
        bMeth_check_sum += l;
        return l % 2L > 0L;
    }

    public void vMeth1(int n, float f) {
        int n2 = 5;
        int n3 = 10;
        boolean bl = false;
        boolean[] blArray = new boolean[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(blArray, false);
        FuzzerUtils.init(lArray, -2907133733L);
        if (Test.bMeth(n, n, 101.609f)) {
            this.dFld = this.dFld;
            n = (int)instanceCount++;
            int n4 = (iFld >>> 1) % 400;
            long l = lArray[n4] - 1L;
            lArray[n4] = l;
            boolean bl2 = blArray[63] = (long)(n >> -186) + 8954L != l;
        }
        if (bl) {
            n += n;
            vMeth1_check_sum += (long)(n + Float.floatToIntBits(f) + n2 + n3 + (bl ? 1 : 0)) + FuzzerUtils.checkSum(blArray) + FuzzerUtils.checkSum(lArray);
            return;
        }
        if (bl) {
            n2 = 10;
            while (n2 < 238) {
                try {
                    iFld = n2 / 26955;
                    iFld = -188 / this.iArrFld[n2];
                    iFld = n2 % n3;
                } catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                n = (int)instanceCount;
                int n5 = n2++;
                lArray[n5] = lArray[n5] * (long)n3;
                n3 += (int)instanceCount;
                iFld = (int)f;
            }
            for (long l : lArray) {
                n <<= (int)instanceCount;
                n <<= n2;
            }
        }
        vMeth1_check_sum += (long)(n + Float.floatToIntBits(f) + n2 + n3 + (bl ? 1 : 0)) + FuzzerUtils.checkSum(blArray) + FuzzerUtils.checkSum(lArray);
    }

    public void vMeth(long l, long l2, int n) {
        int n2 = 12;
        int n3 = -222;
        int n4 = -21;
        int n5 = 64125;
        int n6 = -132;
        int n7 = 45209;
        int n8 = 134;
        float f = -82.986f;
        int n9 = -116;
        int n10 = 29605;
        for (n2 = 5; n2 < 277; n2 += 2) {
            n = (int)((float)n + ((float)(n2 * iFld) + f - (float)n9));
        }
        n4 = 1;
        do {
            switch ((sFld + n10 >>> 1) % 1 + 117) {
                default: 
            }
            this.vMeth1(2, f);
            iFld = 63;
            int n11 = ((n += n4 + n2) >>> 1) % 400;
            this.iArrFld[n11] = this.iArrFld[n11] ^ iFld;
            iFld = (int)l;
            for (n5 = 1; n5 < 5; ++n5) {
                for (n7 = 1; 2 > n7; ++n7) {
                    int n12 = n5 - 1;
                    this.iArrFld[n12] = this.iArrFld[n12] * (int)l;
                    n += n;
                    n10 = (short)(n10 + (short)n7);
                    l2 = instanceCount;
                }
            }
        } while (++n4 < 308);
        vMeth_check_sum += l + l2 + (long)n + (long)n2 + (long)n3 + (long)Float.floatToIntBits(f) + (long)n9 + (long)n4 + (long)n10 + (long)n5 + (long)n6 + (long)n7 + (long)n8;
    }

    public void mainTest(String[] stringArray) {
        int n = -228;
        int n2 = 27720;
        int n3 = 216;
        int n4 = -5;
        int n5 = -11446;
        int n6 = 4;
        int n7 = 1;
        int[] nArray = new int[400];
        int n8 = 79;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, -11.287f);
        FuzzerUtils.init(nArray, -232);
        int n9 = (iFld >>> 1) % 400;
        int n10 = this.iArrFld[n9];
        this.iArrFld[n9] = n10 + 1;
        instanceCount = n10;
        this.vMeth(instanceCount, instanceCount, iFld);
        this.iArrFld = this.iArrFld;
        iFld |= iFld;
        for (n = 6; 389 > n; ++n) {
            this.lArrFld[n - 1] = n;
            iFld <<= 124;
            for (n3 = 1; 66 > n3; ++n3) {
                n4 -= n8;
                sFld = (short)(sFld - 1);
                n2 += iFld;
                for (n5 = 1; n5 < 2; ++n5) {
                    n2 = n8;
                }
                n7 = 2;
                while (--n7 > 0) {
                    n2 <<= (int)instanceCount;
                    switch ((n3 >>> 1) % 2 + 116) {
                        case 116: 
                        case 117: {
                            try {
                                iFld = n3 / -41;
                                n4 = 4582 / n;
                                n6 = 17 % this.iArrFld[(iFld >>> 1) % 400];
                                break;
                            } catch (ArithmeticException arithmeticException) {
                                // empty catch block
                            }
                        }
                    }
                    ++n4;
                    iFld *= (int)fFld;
                    instanceCount >>>= n5;
                    fArray[n3] = n6;
                    n4 += n7;
                    n2 = n3;
                }
                fFld -= (float)n8;
                n6 = n2;
                iFld *= n5;
            }
            n2 -= n3;
            n4 += (int)instanceCount;
            int n11 = n - 1;
            nArray[n11] = nArray[n11] << n5;
        }
        FuzzerUtils.out.println("i20 i21 i22 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i23 by2 i24 = " + n4 + "," + (byte)n8 + "," + n5);
        FuzzerUtils.out.println("i25 i26 fArr = " + n6 + "," + n7 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("iArr = " + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.sFld = " + instanceCount + "," + iFld + "," + sFld);
        FuzzerUtils.out.println("dFld Test.fFld iArrFld = " + Double.doubleToLongBits(this.dFld) + "," + Float.floatToIntBits(fFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("lArrFld = " + FuzzerUtils.checkSum(this.lArrFld));
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}


/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -4835306811843744761L;
    public int iFld = 243;
    public static float fFld = 0.421f;
    public static long lFld = -24L;
    public volatile double[][][] dArrFld = new double[400][400][400];
    public static int[] iArrFld = new int[400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(float f) {
        int n = 11;
        int n2 = 6;
        int n3 = -142;
        int n4 = -25433;
        int n5 = 250;
        int n6 = -6;
        int n7 = 32596;
        int[] nArray = new int[400];
        double d = -90.68057;
        boolean bl = true;
        boolean bl2 = true;
        FuzzerUtils.init(nArray, 19);
        for (n = 8; n < 231; ++n) {
            try {
                n2 %= nArray[n];
                n2 = 50425 % nArray[n - 1];
                n2 /= -15256;
            } catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            d -= (double)instanceCount;
            for (n3 = 7; n < n3; --n3) {
                d += (double)n2;
                for (n5 = 1; n5 < 1; ++n5) {
                    int n8 = -16905;
                    switch ((n7 >>> 1) % 1 * 5 + 89) {
                        case 90: {
                            n6 = n2;
                            n8 = (short)(n8 << (short)(instanceCount += -248L + (long)(n5 * n5)));
                            break;
                        }
                        default: {
                            n4 *= -1;
                            n4 -= n5;
                            int n9 = n5;
                            nArray[n9] = nArray[n9] - n3;
                            bl = bl2;
                        }
                    }
                    try {
                        nArray[n5 - 1] = n7 / -24109;
                        n7 = nArray[n3 - 1] / n;
                        nArray[n3] = -153 % n6;
                        continue;
                    } catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                }
            }
        }
        vMeth1_check_sum += (long)(Float.floatToIntBits(f) + n + n2) + Double.doubleToLongBits(d) + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)(bl ? 1 : 0) + (long)(bl2 ? 1 : 0) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth(int n, int n2, int n3) {
        int n4 = -12640;
        int n5 = -47235;
        int n6 = -4065;
        int n7 = 62149;
        int n8 = 238;
        int n9 = 4347;
        int n10 = -79;
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, 80);
        Test.vMeth1(fFld);
        n4 = (short)instanceCount;
        for (n5 = 5; n5 < 188; n5 += 2) {
            instanceCount |= (long)n3;
            instanceCount |= (long)n;
            if (n5 != 0) {
                vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + n10) + FuzzerUtils.checkSum(nArray);
                return;
            }
            n3 *= n;
            for (n7 = n5; 17 > n7; ++n7) {
                n2 += 9 + n7 * n7;
                instanceCount >>= -16;
                n2 = -15502;
                try {
                    n6 = n % 138;
                    n2 = 11490 / n2;
                    nArray[n7 - 1] = n5 % 1348503984;
                } catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                n9 = 1;
                while (n9 < 1) {
                    if (n6 != 0) {
                        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + n10) + FuzzerUtils.checkSum(nArray);
                        return;
                    }
                    n3 = n9++;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + n10) + FuzzerUtils.checkSum(nArray);
    }

    public static int iMeth(long l) {
        int n = -37847;
        int n2 = 245;
        int n3 = -27031;
        int n4 = -59;
        int n5 = -7;
        int n6 = 62872;
        int n7 = 38641;
        int n8 = -8638;
        int n9 = -9;
        double d = -125.100651;
        double[] dArray = new double[400];
        float[] fArray = new float[400];
        FuzzerUtils.init(dArray, 51.1084);
        FuzzerUtils.init(fArray, -13.822f);
        for (n = 18; n < 295; ++n) {
            Test.vMeth(n, -5, n);
            dArray[n] = -84.245f;
            fFld += fFld;
            for (n3 = 1; n3 < 6; ++n3) {
                n2 += 4;
                d = 1.0;
                do {
                    fFld = n2;
                    int n10 = (int)(d + 1.0);
                    dArray[n10] = dArray[n10] / (double)(n2 | 1);
                    instanceCount *= (long)n5;
                } while ((d += 1.0) < 2.0);
            }
            n2 *= (int)fFld;
        }
        for (n6 = 9; n6 < 318; ++n6) {
            for (n8 = 5; n8 > 1; --n8) {
                fArray[n8 - 1] = 62.0f;
            }
            fFld += (float)(n6 * n4);
        }
        long l2 = l + (long)n + (long)n2 + (long)n3 + (long)n4 + Double.doubleToLongBits(d) + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)n9 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public void mainTest(String[] stringArray) {
        int n = 53;
        int n2 = -57401;
        int n3 = -60500;
        int n4 = -14066;
        int n5 = 29930;
        int n6 = 2641;
        int n7 = 882;
        short s = -25625;
        short[] sArray = new short[400];
        byte by = -113;
        long l = 0L;
        double d = 98.61442;
        FuzzerUtils.init(sArray, (short)-20604);
        n = 1;
        do {
            this.iFld = (int)(-((float)this.iFld + fFld + -4.50404424E17f));
            this.iFld = 11 + Test.iMeth(instanceCount);
            this.dArrFld[n + 1][n][n - 1] = 6.0;
            instanceCount <<= 50113;
            n2 = 1;
            while (++n2 < 83) {
                int n8 = n2;
                iArrFld[n8] = iArrFld[n8] - n2;
                int n9 = n;
                iArrFld[n9] = iArrFld[n9] - this.iFld;
            }
            instanceCount -= (long)n2;
            s = (short)(s + (short)(n * n));
        } while (++n < 302);
        fFld *= (float)n2;
        this.iFld += this.iFld;
        n3 = 1;
        while (++n3 < 390) {
            try {
                this.iFld = iArrFld[n3 + 1] / iArrFld[n3 - 1];
                this.iFld = n2 % -231;
                this.iFld = iArrFld[n3] % iArrFld[n3 + 1];
            } catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            this.iFld = n3;
            this.iFld -= n2;
            for (n4 = 2; n4 < 65; ++n4) {
                s = (short)(s + (short)((float)(n4 * n) + fFld - fFld));
                by = (byte)l;
                for (n6 = 1; n6 < 2; ++n6) {
                    n5 -= (int)l;
                    fFld = n2;
                    d -= (double)n2;
                    int n10 = n3 + 1;
                    iArrFld[n10] = iArrFld[n10] * s;
                    sArray[n3] = 9;
                    fFld += (float)n6;
                }
                by = (byte)(by - (byte)n2);
                this.iFld = (int)((long)this.iFld + ((long)(n4 * n3 + n2) - lFld));
                n7 >>= -384353483;
            }
        }
        FuzzerUtils.out.println("i i26 s2 = " + n + "," + n2 + "," + s);
        FuzzerUtils.out.println("i27 i28 i29 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("by l1 i30 = " + by + "," + l + "," + n6);
        FuzzerUtils.out.println("i31 d2 sArr = " + n7 + "," + Double.doubleToLongBits(d) + "," + FuzzerUtils.checkSum(sArray));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.fFld = " + instanceCount + "," + this.iFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.lFld dArrFld Test.iArrFld = " + lFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][])this.dArrFld)) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -75);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}


/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 46601L;
    public static int iFld = -7;
    public static long[] lArrFld = new long[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2(long l, boolean bl, int n) {
        double d = 120.99682;
        int n2 = 2;
        int n3 = 29252;
        int n4 = 60369;
        int[][] nArray = new int[400][400];
        long l2 = 5L;
        float f = -2.806f;
        FuzzerUtils.init(nArray, -54071);
        n *= n;
        int[] nArray2 = nArray[(n >>> 1) % 400];
        int n5 = (n >>> 1) % 400;
        nArray2[n5] = nArray2[n5] * (int)d;
        for (n2 = 8; 137 > n2; ++n2) {
            n = 1;
        }
        l2 = 1L;
        do {
            n %= n2 | 1;
            n4 = 1;
            while (++n4 < 11 && !bl) {
            }
            n3 %= n2 | 1;
            d -= (double)n;
            n3 += (int)l;
            if (n4 != 0) {
                vMeth2_check_sum += l + (long)(bl ? 1 : 0) + (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + l2 + (long)n4 + (long)Float.floatToIntBits(f) + FuzzerUtils.checkSum(nArray);
                return;
            }
            nArray[(int)l2][(int)(l2 + 1L)] = (int)f;
            f = n;
        } while (++l2 < 145L);
        vMeth2_check_sum += l + (long)(bl ? 1 : 0) + (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + l2 + (long)n4 + (long)Float.floatToIntBits(f) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth1(int n) {
        boolean bl = false;
        boolean[] blArray = new boolean[400];
        float f = -69.143f;
        float f2 = 0.541f;
        float[] fArray = new float[400];
        int n2 = -60725;
        int n3 = -5;
        int n4 = 94;
        int n5 = 83;
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, -2);
        FuzzerUtils.init(blArray, true);
        FuzzerUtils.init(fArray, 0.727f);
        Test.vMeth2(instanceCount, bl, n);
        for (f = 17.0f; 307.0f > f; f += 1.0f) {
            f2 -= (float)n;
            int n6 = (int)(f + 1.0f);
            nArray[n6] = nArray[n6] - n;
            int n7 = (int)(f + 1.0f);
            nArray[n7] = nArray[n7] << (int)(instanceCount >>= n);
            instanceCount &= 0xFFFFFFFFFFFFFFFAL;
            n3 = 1;
            while (++n3 < 6) {
                blArray[n3 - 1] = true;
                n2 -= n;
            }
        }
        fArray[(n2 >>> 1) % 400] = n;
        for (n4 = 168; 5 < n4; n4 -= 3) {
            n2 = (int)((long)n2 + ((long)(n4 * n) + instanceCount - (long)n5));
            n2 >>= n4;
        }
        vMeth1_check_sum += (long)(n + (bl ? 1 : 0) + Float.floatToIntBits(f) + n2 + Float.floatToIntBits(f2) + n3 + n4 + n5) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(blArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public static void vMeth(int n) {
        double d = 99.9076;
        int n2 = 7;
        int n3 = 55573;
        int n4 = 78;
        int n5 = -16073;
        int n6 = -5;
        int n7 = 110;
        float f = -1.611f;
        boolean bl = true;
        Test.vMeth1(n);
        try {
            Test.lArrFld[(n >>> 1) % 400] = instanceCount;
            d /= (double)(n | 1);
        } catch (NullPointerException nullPointerException) {
            for (n2 = 7; 188 > n2; ++n2) {
                d = n;
                n3 &= n7;
                for (n4 = n2; 9 > n4; ++n4) {
                    n6 = 1;
                    do {
                        if (bl) {
                            n = (int)((long)n + ((long)n6 * instanceCount + instanceCount - (long)n3));
                            continue;
                        }
                        if (bl) {
                            n = (int)instanceCount;
                            n -= (int)instanceCount;
                            continue;
                        }
                        if (!bl) continue;
                        instanceCount <<= 43326;
                        f -= (float)n6;
                    } while (++n6 < 1);
                }
            }
        }
        vMeth_check_sum += (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n7 + (long)n4 + (long)n5 + (long)n6 + (long)Float.floatToIntBits(f) + (long)(bl ? 1 : 0);
    }

    public void mainTest(String[] stringArray) {
        Test.vMeth(iFld);
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.lArrFld = " + instanceCount + "," + (iFld ^= 0xAA) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 56790L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}


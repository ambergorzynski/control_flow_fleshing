/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -232L;
    public static float fFld = -1.717f;
    public static byte byFld = (byte)-11;
    public double dFld = 14.70771;
    public static short sFld = (short)21697;
    public static int[] iArrFld = new int[400];
    public static volatile short[] sArrFld = new short[400];
    public static long bMeth_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth(float f, long l) {
        int n = 0;
        int n2 = -27431;
        int n3 = -127;
        double d = 2.99479;
        double d2 = 0.121771;
        long l2 = -7L;
        int n4 = 27396;
        for (int n5 : iArrFld) {
            for (n = 1; n < 4; ++n) {
                int n6 = 45;
                for (d = (double)n; d < 2.0; d += 1.0) {
                    d2 += (double)n2;
                    instanceCount = n2;
                    n5 = n2;
                    l2 += (long)d;
                    Test.iArrFld[(int)(d - 1.0)] = n2;
                    n2 -= (int)f;
                }
                n2 = n4;
                Test.iArrFld[n - 1] = n6;
                int n7 = n;
                iArrFld[n7] = iArrFld[n7] - (int)instanceCount;
                l2 -= -8197400782500670015L;
                n2 += (int)(-4099152058L + (long)(n * n));
                n2 += (int)f;
            }
        }
        vMeth_check_sum += (long)Float.floatToIntBits(f) + l + (long)n + (long)n2 + Double.doubleToLongBits(d) + (long)n3 + Double.doubleToLongBits(d2) + l2 + (long)n4;
    }

    public static int iMeth(int n, long l) {
        int n2 = -87;
        int n3 = -1;
        int n4 = 13;
        int n5 = 56337;
        int n6 = 14;
        int n7 = -8;
        int n8 = 62;
        int n9 = -150;
        boolean bl = true;
        Test.vMeth(fFld, instanceCount);
        for (n2 = 17; 292 > n2; ++n2) {
            instanceCount = n2;
            for (n4 = n2; 6 > n4; ++n4) {
                int n10 = n2;
                iArrFld[n10] = iArrFld[n10] + (int)instanceCount;
                Test.iArrFld[n2 + 1] = n2;
                n3 += n5;
            }
            n3 += n2 - n2;
            n3 += n2;
            for (n6 = 1; n6 < 6; n6 += 2) {
                for (n8 = n2; 3 > n8; ++n8) {
                    l = n6;
                    if (!bl) continue;
                }
            }
        }
        long l2 = (long)n + l + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)n9 + (long)(bl ? 1 : 0);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public static boolean bMeth(float f, long l, double d) {
        int n = 27882;
        int n2 = -60835;
        int n3 = -249;
        int n4 = 51053;
        int n5 = -137;
        int n6 = -39;
        boolean bl = true;
        int n7 = 16558;
        short[] sArray = new short[400];
        FuzzerUtils.init(sArray, (short)-4452);
        float f2 = f;
        f = f2 + 1.0f;
        l = (long)f2;
        n = n++ << (int)((float)n - ((float)n2 + f) + (float)instanceCount--);
        for (n3 = 1; n3 < 128; ++n3) {
            for (n5 = 1; n5 < 12; ++n5) {
                int n8 = 3135;
                instanceCount = (long)(-((double)l * 24.83958) - (double)(n3 >> Test.iMeth(n2, instanceCount)));
                l += (long)n5;
                if (bl) break;
                l += (long)n8;
            }
            n7 = (short)(n7 - (short)l);
            l = n4 += n3 * n5 + n3 - n2;
            n2 += (int)f;
            l *= instanceCount;
        }
        sArray = FuzzerUtils.short1array(400, (short)3053);
        byFld = (byte)-93;
        long l2 = (long)Float.floatToIntBits(f) + l + Double.doubleToLongBits(d) + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)(bl ? 1 : 0) + (long)n7 + FuzzerUtils.checkSum(sArray);
        bMeth_check_sum += l2;
        return l2 % 2L > 0L;
    }

    public void mainTest(String[] stringArray) {
        int n = 8;
        int n2 = 41145;
        int n3 = -3;
        int n4 = 117;
        int n5 = 53;
        int n6 = 25581;
        int n7 = -11;
        int n8 = 135;
        int n9 = -3;
        int n10 = -254;
        int n11 = -12;
        int n12 = -1;
        int n13 = 83;
        boolean bl = false;
        boolean bl2 = true;
        float f = -88.955f;
        for (n = 8; n < 174 && !Test.bMeth(fFld, instanceCount, this.dFld); ++n) {
            this.dFld += (double)n2;
            this.dFld += (double)n;
            for (n3 = 3; 151 > n3; ++n3) {
                n4 *= (int)fFld;
            }
            n4 += n | sFld;
        }
        for (n5 = 15; n5 < 386; ++n5) {
            if (!bl) continue;
        }
        n4 = (int)instanceCount;
        n4 -= n4;
        n4 += 120;
        for (n7 = 15; 384 > n7; ++n7) {
            n2 >>>= (int)instanceCount;
            n9 = 1;
            do {
                n2 *= n8;
                switch ((n10 >>> 1) % 4 * 5 + 16) {
                    case 35: {
                        for (f = 1.0f; f < 1.0f; f += 1.0f) {
                            int n14 = n7;
                            iArrFld[n14] = iArrFld[n14] - (int)instanceCount;
                            n8 += (int)f;
                            bl = bl2;
                            int n15 = n9;
                            sArrFld[n15] = (short)(sArrFld[n15] >>> (short)n6);
                        }
                        n11 = n2;
                        break;
                    }
                    case 34: {
                        break;
                    }
                    case 24: {
                        n12 = 1;
                        do {
                            n8 = n13;
                            Test.iArrFld[n9 - 1] = (int)instanceCount;
                            try {
                                n4 = n12 % -1416672441;
                                n11 = n2 / n6;
                                n13 /= -22882;
                            } catch (ArithmeticException arithmeticException) {
                                // empty catch block
                            }
                            n4 += n4;
                        } while (++n12 < 1);
                        break;
                    }
                    case 20: {
                        instanceCount = n10;
                    }
                }
            } while (++n9 < 68);
        }
        FuzzerUtils.out.println("i i1 i22 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i23 i24 i25 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("b2 i26 i27 = " + (bl ? 1 : 0) + "," + n7 + "," + n8);
        FuzzerUtils.out.println("i28 i29 f2 = " + n9 + "," + n10 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i30 b3 i31 = " + n11 + "," + (bl2 ? 1 : 0) + "," + n12);
        FuzzerUtils.out.println("i32 = " + n13);
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.byFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + byFld);
        FuzzerUtils.out.println("dFld Test.sFld Test.iArrFld = " + Double.doubleToLongBits(this.dFld) + "," + sFld + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.sArrFld = " + FuzzerUtils.checkSum(sArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 227);
        FuzzerUtils.init(sArrFld, (short)-20189);
        bMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}


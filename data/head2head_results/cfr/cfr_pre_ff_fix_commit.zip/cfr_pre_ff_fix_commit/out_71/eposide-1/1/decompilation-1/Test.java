/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -3L;
    public static byte byFld = (byte)-74;
    public static short sFld = (short)29557;
    public int[] iArrFld = new int[400];
    public static long vMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;
    public static long vMeth2_check_sum = 0L;

    public static void vMeth2(long l) {
        int n = 10;
        int n2 = 21;
        int n3 = -42;
        int n4 = -54764;
        int n5 = -39328;
        int[][][] nArray = new int[400][400][400];
        float f = 1.243f;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 10L);
        FuzzerUtils.init((Object[][])nArray, (Object)0);
        n &= 0xFFFFFFF8;
        block4: for (long l2 : lArray) {
            n2 = 1;
            while (++n2 < 4) {
                n = (int)f;
                n3 = 1;
                while ((n3 += 2) < 1) {
                    n += n3;
                }
                n = -6275;
            }
            l2 -= (long)n;
            switch ((n3 >>> 1) % 2 + 100) {
                case 100: {
                    nArray[(n2 >>> 1) % 400][37][(n2 >>> 1) % 400] = (int)l;
                    int[] nArray2 = nArray[(n3 >>> 1) % 400][(n2 >>> 1) % 400];
                    nArray2[42] = nArray2[42] << n;
                    continue block4;
                }
                case 101: {
                    byFld = (byte)(byFld * -36);
                    for (n4 = 1; n4 < 4; ++n4) {
                        l2 = l;
                        n <<= -6;
                    }
                    continue block4;
                }
                default: {
                    n *= -67;
                }
            }
        }
        vMeth2_check_sum += l + (long)n + (long)n2 + (long)Float.floatToIntBits(f) + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum((Object[][])nArray);
    }

    public static void vMeth1() {
        Test.vMeth2(instanceCount);
        vMeth1_check_sum += 0L;
    }

    public static void vMeth(float f) {
        int n = -7377;
        int n2 = -8;
        int n3 = -29411;
        int n4 = 8;
        int n5 = 7;
        int n6 = 61374;
        int n7 = 10;
        int[] nArray = new int[400];
        double d = 0.83098;
        float[] fArray = new float[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(fArray, 0.537f);
        FuzzerUtils.init(lArray, 3762580291L);
        FuzzerUtils.init(nArray, -12);
        Test.vMeth1();
        for (n = 12; n < 386; ++n) {
            int n8 = n;
            fArray[n8] = fArray[n8] - (float)n2;
            lArray[41] = lArray[41] - (long)n2;
            for (n3 = 5; n3 > n; n3 -= 3) {
            }
            n4 += n;
            if (n3 != 0) {
                vMeth_check_sum += (long)(Float.floatToIntBits(f) + n + n2 + n3 + n4 + n5 + n6) + Double.doubleToLongBits(d) + (long)n7 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(nArray);
                return;
            }
            int n9 = n - 1;
            nArray[n9] = nArray[n9] + n3;
            for (n5 = 1; 5 > n5; ++n5) {
                d += -9.0;
                n7 = 2;
                do {
                    n6 *= (int)d;
                    n4 = -4;
                } while (--n7 > 0);
            }
        }
        vMeth_check_sum += (long)(Float.floatToIntBits(f) + n + n2 + n3 + n4 + n5 + n6) + Double.doubleToLongBits(d) + (long)n7 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        float f = -2.582f;
        float[] fArray = new float[400];
        double d = -2.70824;
        double d2 = 109.88066;
        int n = -452;
        int n2 = -56;
        int n3 = 12;
        int n4 = 61136;
        int n5 = -44967;
        int n6 = -118;
        boolean bl = false;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -253L);
        FuzzerUtils.init(fArray, -1.661f);
        block19: for (int n7 : this.iArrFld) {
            switch ((n7 >>> 1) % 7 * 5 + 104) {
                case 139: {
                    Test.vMeth(f);
                    continue block19;
                }
                case 106: {
                    lArray[(n7 >>> 1) % 400] = (long)d;
                    for (n = 63; n > 3; n -= 3) {
                    }
                    int n8 = (n2 >>> 1) % 400;
                    this.iArrFld[n8] = this.iArrFld[n8] + n7;
                    continue block19;
                }
                case 119: {
                    d2 = 1.0;
                    block21: do {
                        n7 = -130;
                        n3 = 1;
                        do {
                            boolean bl2 = false;
                            n2 = n7;
                            n7 += 3;
                            n7 = (int)instanceCount;
                            int n9 = (int)d2;
                            this.iArrFld[n9] = this.iArrFld[n9] >> n2;
                            int n10 = n3 + 1;
                            lArray[n10] = lArray[n10] >> n7;
                            instanceCount <<= n3;
                            n4 = 38067;
                        } while (++n3 < 1);
                        switch (65) {
                            case 59: {
                                n7 -= n2;
                            }
                            case 60: {
                                for (n5 = 1; n5 < 1; ++n5) {
                                    if (bl) {
                                        n6 >>>= (int)instanceCount;
                                        n2 *= n4;
                                        continue;
                                    }
                                    f = n2;
                                    int n11 = (int)d2;
                                    this.iArrFld[n11] = this.iArrFld[n11] * n;
                                    instanceCount = n6;
                                    byFld = (byte)(byFld - -39);
                                }
                                continue block21;
                            }
                            case 61: {
                                n7 >>= n;
                                break;
                            }
                            case 62: {
                                fArray[(int)(d2 - 1.0)] = n5;
                                break;
                            }
                            case 63: {
                                byFld = (byte)(byFld - (byte)n7);
                                break;
                            }
                            case 64: {
                                instanceCount += (long)n4;
                                break;
                            }
                            case 65: {
                                n6 |= n;
                                break;
                            }
                            case 66: {
                                n6 -= n3;
                                break;
                            }
                            case 67: {
                                instanceCount += (long)n;
                                break;
                            }
                            case 68: {
                                this.iArrFld[(int)(d2 - 1.0)] = n3;
                                break;
                            }
                            default: {
                                sFld = (short)(sFld + (short)n4);
                            }
                        }
                    } while ((d2 += 1.0) < 63.0);
                    continue block19;
                }
                case 111: 
                case 122: {
                    byFld = (byte)n5;
                    continue block19;
                }
                case 113: 
                case 135: {
                    this.iArrFld[(n3 >>> 1) % 400] = 62485;
                }
            }
        }
        FuzzerUtils.out.println("f2 d1 i13 = " + Float.floatToIntBits(f) + "," + Double.doubleToLongBits(d) + "," + n);
        FuzzerUtils.out.println("i14 d2 i15 = " + n2 + "," + Double.doubleToLongBits(d2) + "," + n3);
        FuzzerUtils.out.println("i16 i17 i18 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("b1 lArr2 fArr1 = " + (bl ? 1 : 0) + "," + FuzzerUtils.checkSum(lArray) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.sFld = " + instanceCount + "," + byFld + "," + sFld);
        FuzzerUtils.out.println("iArrFld = " + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}


/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -22346L;
    public static boolean bFld = false;
    public static float fFld = 30.491f;
    public static int[] iArrFld = new int[400];
    public static long vMeth_check_sum;
    public static long lMeth_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth(int n) {
        instanceCount += instanceCount;
        long l = n;
        iMeth_check_sum += l;
        return (int)l;
    }

    public static long lMeth() {
        int n = -52061;
        int n2 = 4;
        int n3 = -5334;
        int n4 = -196;
        int n5 = 3728;
        int n6 = 122;
        float f = -69.551f;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 185L);
        n = 391;
        while ((n -= 2) > 0) {
            instanceCount = Test.iMeth(n);
            n2 <<= 10;
            f += (float)(n * (n2 += (int)(7L + (long)(n * n))));
            f += (float)n;
        }
        for (n3 = 131; 3 < n3; --n3) {
            n4 += (int)instanceCount;
            if (bFld) continue;
            n5 = 1;
            while (++n5 < 12) {
                n4 += 77 + n5 * n5;
                n6 = 1;
                while (++n6 < 1) {
                    Test.iArrFld[n6 + 1] = 22496426;
                    try {
                        Test.iArrFld[n5] = n / -73;
                        Test.iArrFld[n3] = n6 / 237;
                        Test.iArrFld[n6] = iArrFld[n6 + 1] / 127;
                    } catch (ArithmeticException arithmeticException) {}
                }
            }
        }
        long l = (long)(n + n2 + Float.floatToIntBits(f) + n3 + n4 + n5 + n6) + FuzzerUtils.checkSum(lArray);
        lMeth_check_sum += l;
        return l;
    }

    public static void vMeth() {
        int n = 13734;
        int n2 = -5;
        int n3 = 13;
        int n4 = 194;
        int n5 = -8;
        int n6 = -171;
        int n7 = 5;
        long l = 4152526230490583939L;
        switch (((int)(instanceCount - instanceCount) >>> 1) % 2 + 119) {
            case 119: {
                for (n = 12; n < 336; ++n) {
                    block5: for (n3 = 1; n3 < 5; ++n3) {
                        float f = 124.324f;
                        f *= (float)Test.lMeth();
                        n5 = 1;
                        while (2 > n5) {
                            n6 = n2;
                            n2 <<= n7;
                            instanceCount *= (long)n4;
                            Test.iArrFld[n + 1] = n5++;
                            if (bFld) continue block5;
                            n4 *= n7;
                        }
                    }
                }
                fFld += (float)n6;
                n6 <<= (int)instanceCount;
                n2 = (int)l;
                break;
            }
            case 120: {
                n4 = n2;
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7) + l;
    }

    public void mainTest(String[] stringArray) {
        int n = 25169;
        int n2 = -10;
        int n3 = -202;
        int n4 = 63145;
        int n5 = 37;
        int n6 = -12;
        short s = 30476;
        double d = 2.98343;
        double[][] dArray = new double[400][400];
        long[][] lArray = new long[400][400];
        byte[] byArray = new byte[400];
        FuzzerUtils.init(dArray, -101.109532);
        FuzzerUtils.init(lArray, -7394276029538680878L);
        FuzzerUtils.init(byArray, (byte)-3);
        Test.vMeth();
        n -= n;
        fFld = instanceCount;
        for (int n7 : iArrFld) {
            dArray[(n7 >>> 1) % 400][(n7 >>> 1) % 400] = n7;
        }
        Test.iArrFld[(n >>> 1) % 400] = s;
        fFld -= fFld;
        for (int n7 : iArrFld) {
            int n8 = (n >>> 1) % 400;
            iArrFld[n8] = iArrFld[n8] | (int)instanceCount;
            n >>= 14;
            for (n2 = 3; n2 < 63; ++n2) {
                n7 = n3;
                d = instanceCount;
                n4 = 1;
                do {
                    fFld = -211.0f;
                } while (++n4 < 2);
                n3 += n4;
                for (n5 = 1; 2 > n5; ++n5) {
                    n3 -= (n7 *= -13312);
                    n -= n5;
                    long[] lArray2 = lArray[n2 - 1];
                    int n9 = n5 + 1;
                    lArray2[n9] = lArray2[n9] - -1955201832L;
                    d *= (double)n5;
                    d = n7;
                }
                n6 &= 0x9B59;
                n *= n2;
            }
            byArray[(n3 >>> 1) % 400] = 5;
            if (bFld) break;
            fFld -= (float)n2;
        }
        FuzzerUtils.out.println("i13 s i16 = " + n + "," + s + "," + n2);
        FuzzerUtils.out.println("i17 d i18 = " + n3 + "," + Double.doubleToLongBits(d) + "," + n4);
        FuzzerUtils.out.println("i19 i20 dArr = " + n5 + "," + n6 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("lArr1 byArr = " + FuzzerUtils.checkSum(lArray) + "," + FuzzerUtils.checkSum(byArray));
        FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.fFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.iArrFld = " + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -123);
        vMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}


/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 115801572497770259L;
    public float fFld = -3.314f;
    public static double dFld = -70.72051;
    public static short sFld = (short)6663;
    public static float fFld1 = 1.75f;
    public static volatile boolean bFld = true;
    public static long[] lArrFld = new long[400];
    public static short[] sArrFld = new short[400];
    public static byte[] byArrFld = new byte[400];
    public static double[] dArrFld = new double[400];
    public int[] iArrFld = new int[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2(float f, int n) {
        int n2 = -181;
        int n3 = 99;
        int n4 = -206;
        int n5 = 51300;
        int n6 = 12;
        int n7 = 13;
        int n8 = -127;
        int[] nArray = new int[400];
        boolean bl = false;
        FuzzerUtils.init(nArray, 7492);
        for (n2 = 1; n2 < 127; ++n2) {
            n3 |= 0xFFFF4511;
            int n9 = n2;
            lArrFld[n9] = lArrFld[n9] - instanceCount;
            instanceCount = 2L;
            block12: for (n4 = 1; n4 < 12; ++n4) {
                switch (n4 % 5 * 5 + 54) {
                    case 65: {
                        nArray[n4] = n4;
                        continue block12;
                    }
                    case 64: {
                        n = (int)instanceCount;
                        continue block12;
                    }
                    case 63: {
                        Test.sArrFld[n2] = (short)n6;
                        block13: for (n7 = 1; n7 < 2; ++n7) {
                            switch ((n2 >>> 1) % 2 + 16) {
                                case 16: {
                                    int n10 = n7;
                                    nArray[n10] = nArray[n10] - -14001;
                                    if (bl) continue block13;
                                    n5 -= n5;
                                    continue block13;
                                }
                                case 17: {
                                    nArray[n7] = n;
                                }
                            }
                        }
                        continue block12;
                    }
                    case 59: {
                        f *= (float)instanceCount;
                        continue block12;
                    }
                    case 68: 
                }
            }
        }
        vMeth2_check_sum += (long)(Float.floatToIntBits(f) + n + n2 + n3 + n4 + n5 + n6 + n7 + n8 + (bl ? 1 : 0)) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth1() {
        int n = 183;
        int n2 = 14;
        int n3 = 46;
        int n4 = -25;
        long l = -74L;
        float[] fArray = new float[400];
        double[] dArray = new double[400];
        FuzzerUtils.init(fArray, -2.949f);
        FuzzerUtils.init(dArray, -2.90062);
        Test.vMeth2(fFld1, n);
        n = (int)instanceCount;
        instanceCount = n;
        int n5 = (n >>> 1) % 400;
        fArray[n5] = fArray[n5] * (float)instanceCount;
        dArray[(n >>> 1) % 400] = n;
        for (n2 = 397; 23 < n2; --n2) {
            n3 *= (n *= (int)instanceCount);
            n3 += n3;
            instanceCount -= (long)n2;
            for (l = 1L; l < 5L; ++l) {
                n += (int)(l * (long)n2 + (long)n4 - (long)n2);
                instanceCount = -14L;
                byArrFld = FuzzerUtils.byte1array(400, (byte)-50);
                Test.byArrFld[n2 + 1] = (byte)n3;
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3) + l + (long)n4 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public void vMeth(int n, long l, int n2) {
        double d = -55.60257;
        int n3 = 60235;
        int n4 = -4227;
        int n5 = -11;
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(blArray, false);
        if (bFld) {
            dFld = 21128L + ((long)n + l - (long)Math.min(n2, -133));
            Test.vMeth1();
            dFld -= (double)n;
        } else if (bFld) {
            n2 = -6391;
            for (d = 15.0; 273.0 > d; d += 1.0) {
                n4 = 6;
                while (--n4 > 0) {
                    if ((n3 += n4) != 0) {
                        vMeth_check_sum += (long)n + l + (long)n2 + Double.doubleToLongBits(d) + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(blArray);
                        return;
                    }
                    this.fFld = n3;
                    n5 = 1;
                    do {
                        int n6 = -1838;
                        int n7 = n5;
                        dArrFld[n7] = dArrFld[n7] + (double)n6;
                        blArray[n5] = bFld;
                        l += (long)n5;
                        n &= n5;
                    } while (++n5 < 1);
                }
            }
        }
        vMeth_check_sum += (long)n + l + (long)n2 + Double.doubleToLongBits(d) + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(blArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -242;
        int n2 = -7280;
        int n3 = 243;
        int n4 = 119;
        int n5 = -197;
        int n6 = 26687;
        int n7 = 24;
        float f = 0.702f;
        byte by = 0;
        n = -13;
        this.fFld += (float)((double)32.55f - dFld * 76.0 - (double)(n + n) + (double)((long)(n - 5394) - (long)n2 * instanceCount));
        f = 1.0f;
        do {
            n2 += (int)(f * (float)n2 + (float)n2 - (float)n);
            this.vMeth(n += sFld, instanceCount, n);
            n3 = 1;
            while (++n3 < 64) {
                n2 -= n3;
                fFld1 += (float)(n2 += n);
                for (n4 = 1; n4 < 1; n4 += 3) {
                    if (bFld) continue;
                    n = (int)instanceCount;
                    int n8 = n4;
                    dArrFld[n8] = dArrFld[n8] - 2.84582512E9;
                }
                instanceCount = n3;
                n2 += n;
                n2 -= n5;
                sFld = (short)(sFld + (short)((float)n3 + fFld1));
                n2 += n5;
                switch (n3 % 5 + 41) {
                    case 41: {
                        n += by;
                        n = (int)((float)n + ((float)n3 + f));
                        break;
                    }
                    case 42: {
                        n ^= (int)instanceCount;
                        for (n6 = n3; n6 < 1; ++n6) {
                            n5 *= (int)f;
                            n7 = n2;
                            n -= 3;
                            fFld1 *= f;
                            Test.lArrFld[n3] = instanceCount;
                            instanceCount = 1L;
                        }
                        break;
                    }
                    case 43: {
                        int n9 = (int)f;
                        this.iArrFld[n9] = this.iArrFld[n9] * (int)instanceCount;
                        break;
                    }
                    case 44: {
                        instanceCount += (long)n3 * instanceCount;
                        break;
                    }
                    case 45: {
                        n2 = n3;
                    }
                }
            }
        } while ((f += 1.0f) < 396.0f);
        FuzzerUtils.out.println("i i1 f = " + n + "," + n2 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i20 i21 i22 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("by i23 i24 = " + by + "," + n6 + "," + n7);
        FuzzerUtils.out.println("Test.instanceCount fFld Test.dFld = " + instanceCount + "," + Float.floatToIntBits(this.fFld) + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.sFld Test.fFld1 Test.bFld = " + sFld + "," + Float.floatToIntBits(fFld1) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.lArrFld Test.sArrFld Test.byArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(sArrFld) + "," + FuzzerUtils.checkSum(byArrFld));
        FuzzerUtils.out.println("Test.dArrFld iArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 194L);
        FuzzerUtils.init(sArrFld, (short)5456);
        FuzzerUtils.init(byArrFld, (byte)106);
        FuzzerUtils.init(dArrFld, -1.19736);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}


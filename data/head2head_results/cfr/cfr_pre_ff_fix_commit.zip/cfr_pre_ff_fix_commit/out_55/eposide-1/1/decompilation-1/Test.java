/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 219L;
    public static int iFld = -56176;
    public static boolean bFld = true;
    public static byte byFld = (byte)44;
    public static float fFld = -2.7f;
    public static byte byFld1 = (byte)33;
    public static volatile short sFld = (short)-27180;
    public static long[] lArrFld = new long[400];
    public static float[] fArrFld = new float[400];
    public int[] iArrFld = new int[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2(int n, long l, long l2) {
        int n2 = 8;
        int n3 = -12;
        int n4 = 18649;
        int n5 = -39;
        int n6 = 63618;
        int[] nArray = new int[400];
        float f = 0.238f;
        int n7 = -80;
        FuzzerUtils.init(nArray, -4);
        iFld = 5436;
        n2 = 268;
        block5: do {
            if (n != 0) {
                vMeth2_check_sum += (long)n + l + l2 + (long)n2 + (long)n3 + (long)n4 + (long)Float.floatToIntBits(f) + (long)n5 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(nArray);
                return;
            }
            for (n3 = n2; n3 < 6; ++n3) {
                l += (long)f;
                n -= iFld;
            }
            switch ((n >>> 1) % 3 * 5 + 111) {
                case 123: {
                    for (n5 = n2; n5 < 6 && !bFld; ++n5) {
                        int n8 = n5 - 1;
                        fArrFld[n8] = fArrFld[n8] + (float)n6;
                        n = -13;
                        n4 &= 3;
                    }
                    continue block5;
                }
                case 122: {
                    n7 = (byte)n5;
                    break;
                }
                case 126: {
                    n4 -= n4;
                }
                default: {
                    l2 += (long)(n2 * n2);
                }
            }
        } while (--n2 > 0);
        vMeth2_check_sum += (long)n + l + l2 + (long)n2 + (long)n3 + (long)n4 + (long)Float.floatToIntBits(f) + (long)n5 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth1(int n) {
        int n2 = 58846;
        int n3 = 12;
        float f = 74.561f;
        double d = 0.100983;
        double[][] dArray = new double[400][400];
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(dArray, 0.85371);
        FuzzerUtils.init(blArray, true);
        instanceCount = (long)((float)(n - (n >>> n)) - 97.4f / (float)(59261L + (long)n | 1L) * (float)(n - n));
        n2 = 1;
        do {
            f -= (float)n2;
            int n4 = n;
            int n5 = (int)((long)n2 - instanceCount);
            n = n5;
            --n;
            n = n4 - (n5 - n);
            int n6 = n2 + 1;
            lArrFld[n6] = lArrFld[n6] - Long.reverseBytes(instanceCount);
            dArray[n2 + 1][n2 + 1] = (double)((long)n3 - ((long)n3 + instanceCount)) * ((d -= 1.0) + (double)instanceCount++);
            n3 = (int)lArrFld[n2];
            switch (n2 % 8 + 49) {
                case 49: {
                    n *= -n2;
                    Test.vMeth2(n3, instanceCount, instanceCount);
                    byFld = (byte)(byFld - (byte)(instanceCount += (long)iFld));
                    break;
                }
                case 50: {
                    n3 += n2 - n;
                    bFld = true;
                    break;
                }
                case 51: {
                    int n7 = n2 + 1;
                    lArrFld[n7] = lArrFld[n7] << n2;
                    break;
                }
                case 52: {
                    iFld += n2;
                    break;
                }
                case 53: {
                    n3 *= 1;
                    break;
                }
                case 54: {
                    n3 += (int)(-3753862003L + (long)(n2 * n2));
                    break;
                }
                case 55: {
                    d = n2;
                }
                case 56: {
                    instanceCount += (long)(n2 * n2);
                }
            }
        } while (++n2 < 391);
        vMeth1_check_sum += (long)(n + n2 + Float.floatToIntBits(f) + n3) + Double.doubleToLongBits(d) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + FuzzerUtils.checkSum(blArray);
    }

    public void vMeth(int n, long l, int n2) {
        int n3 = 5;
        int n4 = -48;
        int n5 = 12;
        int n6 = 0;
        int n7 = -56112;
        int n8 = 60;
        int n9 = -40257;
        double d = -33.66457;
        float f = 0.168f;
        int n10 = 28345;
        n3 = 160;
        while (--n3 > 0) {
            n2 = (int)((long)n2 + ((long)(n3 * n3) + l - (long)n));
            n += 10;
            Test.vMeth1(n3);
            l |= (long)n4;
            for (n5 = 1; n5 < 10; n5 += 2) {
                n2 += (int)instanceCount;
                iFld -= (int)instanceCount;
                d += (double)n6;
            }
            f = n7;
            for (n8 = 10; n8 > n3; --n8) {
                n2 *= iFld;
                n9 = (int)((long)n9 + ((long)n8 | l));
                n4 += n8 * n8;
                n9 -= n10;
            }
        }
        vMeth_check_sum += (long)n + l + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + (long)n7 + (long)n8 + (long)n9 + (long)n10;
    }

    public void mainTest(String[] stringArray) {
        int n = -59579;
        int n2 = -11;
        int n3 = -239;
        int n4 = -10;
        int n5 = 158;
        int n6 = 26528;
        double d = 2.93226;
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(blArray, false);
        for (n = 14; n < 235; ++n) {
            if (bFld) continue;
            if (bFld) {
                this.vMeth(iFld, instanceCount, n);
                instanceCount &= 0xFFFFFFFFFFFFFFF3L;
                block35: for (n3 = 4; n3 < 114; ++n3) {
                    switch (n3 % 8 * 5 + 117) {
                        case 142: {
                            if (bFld) {
                                if (bFld) continue block35;
                                switch (n3 % 1 + 62) {
                                    case 62: {
                                        block36: for (n5 = 1; n5 < 2; ++n5) {
                                            int n7 = -229;
                                            n7 -= (int)fFld;
                                            fFld = -139.0f;
                                            switch (n3 % 6 * 5 + 118) {
                                                case 129: {
                                                    n4 = iFld;
                                                    int n8 = n5 - 1;
                                                    this.iArrFld[n8] = this.iArrFld[n8] * n3;
                                                    continue block36;
                                                }
                                                case 145: {
                                                    if (bFld) continue block36;
                                                    int n9 = n3 + 1;
                                                    this.iArrFld[n9] = this.iArrFld[n9] - n3;
                                                    n4 = byFld1;
                                                    n2 = (int)instanceCount;
                                                    continue block36;
                                                }
                                                case 136: {
                                                    switch (n5 % 7 * 5 + 94) {
                                                        case 102: {
                                                            blArray[n3] = bFld;
                                                            this.iArrFld[n] = n5;
                                                            fFld += (float)((long)n5 * instanceCount + instanceCount - (long)n2);
                                                            continue block36;
                                                        }
                                                        case 111: {
                                                            Test.lArrFld[n3 - 1] = n6;
                                                            n4 = n5;
                                                            n7 = n3;
                                                            instanceCount = sFld;
                                                            continue block36;
                                                        }
                                                        case 99: {
                                                            instanceCount = (long)((float)instanceCount + ((float)(n5 * byFld1) + fFld - (float)iFld));
                                                            continue block36;
                                                        }
                                                        case 110: {
                                                            n2 += n3;
                                                            instanceCount += (long)(n5 * n5);
                                                        }
                                                        case 122: {
                                                            n6 = (int)d;
                                                            continue block36;
                                                        }
                                                        case 103: {
                                                            this.iArrFld[n - 1] = (int)d;
                                                            continue block36;
                                                        }
                                                        case 126: {
                                                            n2 = -1;
                                                            continue block36;
                                                        }
                                                    }
                                                    try {
                                                        this.iArrFld[n5 - 1] = 58 % n6;
                                                        this.iArrFld[n5] = n5 / n4;
                                                        n6 = 1126483615 % n5;
                                                    } catch (ArithmeticException arithmeticException) {}
                                                    continue block36;
                                                }
                                                case 134: {
                                                    n4 <<= n7;
                                                }
                                                case 125: {
                                                    n7 = 10;
                                                    continue block36;
                                                }
                                                case 127: {
                                                    instanceCount += (long)(-35133 + n5 * n5);
                                                }
                                            }
                                        }
                                        continue block35;
                                    }
                                }
                                n4 = (int)((float)n4 + ((float)n3 * fFld + (float)n6 - (float)n2));
                                continue block35;
                            }
                            n4 -= n;
                            continue block35;
                        }
                        case 152: {
                            iFld = (int)instanceCount;
                            continue block35;
                        }
                        case 145: {
                            instanceCount += (long)(n3 * n3);
                            continue block35;
                        }
                        case 140: {
                            blArray[n3 - 1] = bFld;
                        }
                        case 156: {
                            d -= 2.0;
                            continue block35;
                        }
                        case 129: {
                            n6 *= n2;
                        }
                        case 130: {
                            d += (double)instanceCount;
                            continue block35;
                        }
                        case 141: {
                            try {
                                n2 = 245 % iFld;
                                n6 = 189 % iFld;
                                this.iArrFld[n3] = iFld / iFld;
                                continue block35;
                            } catch (ArithmeticException arithmeticException) {
                                // empty catch block
                            }
                        }
                    }
                }
                continue;
            }
            if (bFld) {
                n4 >>= 6;
                continue;
            }
            sFld = (short)(sFld - (short)instanceCount);
        }
        FuzzerUtils.out.println("i i1 i20 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i21 i22 i23 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("d2 bArr1 = " + Double.doubleToLongBits(d) + "," + FuzzerUtils.checkSum(blArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.bFld = " + instanceCount + "," + iFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.byFld Test.fFld Test.byFld1 = " + byFld + "," + Float.floatToIntBits(fFld) + "," + byFld1);
        FuzzerUtils.out.println("Test.sFld Test.lArrFld Test.fArrFld = " + sFld + "," + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("iArrFld = " + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 43307L);
        FuzzerUtils.init(fArrFld, 119.227f);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}


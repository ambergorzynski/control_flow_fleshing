/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -5L;
    public static byte byFld = (byte)47;
    public static volatile float fFld = 2.744f;
    public static boolean bFld = true;
    public static int[] iArrFld = new int[400];
    public static byte[] byArrFld = new byte[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2() {
        int n = 58202;
        int n2 = 129;
        int n3 = 0;
        int n4 = -87;
        int n5 = 12;
        int n6 = 250;
        double d = 66.73938;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -7845743217009734605L);
        for (n = 7; n < 143; ++n) {
            byFld = (byte)(byFld * (byte)n);
            for (n3 = 1; n3 < 12; ++n3) {
                d = -151.0;
                for (n5 = 1; 2 > n5; ++n5) {
                    float f = -113.181f;
                    d = 9.19641254E8;
                    n6 -= (int)fFld;
                    f -= (float)instanceCount;
                    f *= f;
                    n2 &= 0xFFFFFFF6;
                    n6 = 29792;
                    n4 = -151;
                    d += (double)instanceCount;
                    int n7 = n5 - 1;
                    lArray[n7] = lArray[n7] & 0x67L;
                }
            }
        }
        vMeth2_check_sum += (long)(n + n2 + n3 + n4) + Double.doubleToLongBits(d) + (long)n5 + (long)n6 + FuzzerUtils.checkSum(lArray);
    }

    public static void vMeth1(int n, int n2) {
        int n3 = -51244;
        int n4 = -13;
        int n5 = -32;
        int n6 = -191;
        Test.vMeth2();
        n2 -= n;
        int n7 = (n >>> 1) % 400;
        iArrFld[n7] = iArrFld[n7] + (n2 += 108);
        for (n3 = 326; n3 > 13; n3 -= 3) {
            n += n3;
            n = n4;
            for (n5 = 1; n5 < 15; ++n5) {
                n2 = (int)fFld;
                n = (int)instanceCount;
                n4 |= n2;
                n6 = 114;
            }
        }
        instanceCount = n4;
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6);
    }

    public void vMeth(int n, int n2) {
        int n3 = -224;
        int n4 = -12;
        int n5 = 122;
        int n6 = 57955;
        int n7 = -2;
        int n8 = -199;
        int[] nArray = new int[400];
        int[][] nArray2 = new int[400][400];
        float[][][] fArray = new float[400][400][400];
        FuzzerUtils.init((Object[][])fArray, (Object)Float.valueOf(-1.464f));
        FuzzerUtils.init(nArray, 202);
        FuzzerUtils.init(nArray2, 38361);
        Test.vMeth1(n, n);
        for (n3 = 7; n3 < 175; n3 += 2) {
            fFld += (float)n3;
            n4 = -1;
            fArray[n3 + 1][n3][n3] = byFld;
            for (n5 = 1; n5 < 18; ++n5) {
                for (n7 = n5; n7 < 2 && !bFld; ++n7) {
                    Test.byArrFld[n5] = (byte)(n6 += n7);
                    int n9 = n5 + 1;
                    nArray[n9] = nArray[n9] + (int)instanceCount;
                    n6 += (int)instanceCount;
                    n4 += n7 * n7;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8) + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][])fArray)) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(nArray2);
    }

    public void mainTest(String[] stringArray) {
        int n = -7;
        this.vMeth(n, n);
        FuzzerUtils.out.println("i20 = " + n);
        FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.fFld = " + instanceCount + "," + byFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.bFld Test.iArrFld Test.byArrFld = " + (bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(byArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -175);
        FuzzerUtils.init(byArrFld, (byte)11);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}


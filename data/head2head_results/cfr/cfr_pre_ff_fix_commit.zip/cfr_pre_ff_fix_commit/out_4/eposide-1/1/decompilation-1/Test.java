/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 7L;
    public static byte byFld = (byte)107;
    public static int iFld = 3;
    public static volatile long[] lArrFld = new long[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2(int n) {
        int n2 = -4;
        int n3 = 12;
        int n4 = -102;
        int n5 = -127;
        int n6 = -29364;
        int[] nArray = new int[400];
        int n7 = -17000;
        float f = 54.439f;
        FuzzerUtils.init(nArray, -14);
        for (int n8 : nArray) {
            n8 = n;
            for (n2 = 1; n2 < 4; ++n2) {
                instanceCount = n2;
            }
            n3 *= (int)instanceCount;
            block10: for (n4 = 4; n4 > 1; n4 -= 2) {
                n3 = n2;
                int n9 = n4;
                lArrFld[n9] = lArrFld[n9] * instanceCount;
                n5 = 8;
                n -= n;
                switch (n4 % 4 + 73) {
                    case 73: {
                        n8 += n4;
                        n6 = 1;
                        while (++n6 < 4) {
                            try {
                                n3 = -158 / n4;
                                n5 = n8 % nArray[n4 + 1];
                                n /= n6;
                            } catch (ArithmeticException arithmeticException) {
                                // empty catch block
                            }
                            if (n3 == 0) continue;
                            vMeth2_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + Float.floatToIntBits(f)) + FuzzerUtils.checkSum(nArray);
                            return;
                        }
                        continue block10;
                    }
                    case 74: {
                        n7 = (short)(n7 * n7);
                        continue block10;
                    }
                    case 75: {
                        n8 = (int)((float)n8 + ((float)n4 * f + (float)n4 - (float)n4));
                    }
                    case 76: {
                        n3 -= (int)instanceCount;
                        continue block10;
                    }
                    default: {
                        n8 ^= (int)instanceCount;
                    }
                }
            }
        }
        vMeth2_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + Float.floatToIntBits(f)) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth1(int n) {
        float f = 0.78f;
        float[] fArray = new float[400];
        int n2 = -55;
        int n3 = 39398;
        int n4 = -152;
        int n5 = 20860;
        int n6 = -3;
        int[] nArray = new int[400];
        int n7 = -13910;
        boolean bl = false;
        FuzzerUtils.init(nArray, 27307);
        FuzzerUtils.init(fArray, 0.455f);
        instanceCount += (long)(((float)(-n) + (f - (float)instanceCount)) / (float)(Math.max(instanceCount, instanceCount) - (long)(n - byFld) | 1L));
        block6: for (n2 = 3; n2 < 303; ++n2) {
            try {
                n3 %= nArray[n2];
                nArray[n2 + 1] = n2 / n2;
                n = n2 % nArray[n2 + 1];
            } catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            switch (n2 % 2 + 60) {
                case 60: {
                    for (n4 = 1; n4 < 6; ++n4) {
                        n += n5;
                        n6 = 2;
                        do {
                            if (n3 != 0) {
                                vMeth1_check_sum += (long)(n + Float.floatToIntBits(f) + n2 + n3 + n4 + n5 + n6 + n7 + (bl ? 1 : 0)) + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
                                return;
                            }
                            n7 = (short)(n7 + 1);
                            n5 += n7;
                            int n8 = n6 + 1;
                            int n9 = nArray[n8];
                            nArray[n8] = n9 + 1;
                            bl = -11642.0f + fArray[n4 + 1] - (float)(-(instanceCount + (long)n)) >= (float)n9;
                            n = n5++;
                            Test.vMeth2(190);
                            byFld = (byte)11;
                        } while ((n6 -= 3) > 0);
                        n = byFld;
                    }
                    continue block6;
                }
                case 61: {
                    instanceCount %= (long)(n5 | 1);
                }
            }
        }
        vMeth1_check_sum += (long)(n + Float.floatToIntBits(f) + n2 + n3 + n4 + n5 + n6 + n7 + (bl ? 1 : 0)) + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public static void vMeth(int n) {
        float f = -43.24f;
        int n2 = -92;
        int n3 = -3;
        int n4 = -6;
        int n5 = 252;
        double d = 0.737;
        Test.vMeth1(n);
        instanceCount -= (long)f;
        for (n2 = 321; n2 > 9; n2 -= 2) {
            n += -7 + n2 * n2;
            instanceCount = iFld;
            iFld *= n2;
            f += (float)(n2 * n2 + n2 - n3);
            n = (int)instanceCount;
        }
        n4 = 1;
        while (++n4 < 176) {
            n5 = 1;
            while (++n5 < 9) {
                n = n4;
                d *= (double)n3;
                iFld -= n5;
                iFld = n5;
                byFld = (byte)n3;
            }
        }
        vMeth_check_sum += (long)(n + Float.floatToIntBits(f) + n2 + n3 + n4 + n5) + Double.doubleToLongBits(d);
    }

    public void mainTest(String[] stringArray) {
        int n = 14;
        int n2 = -16959;
        int n3 = 219;
        int n4 = 181;
        int n5 = -4;
        int n6 = 4;
        int n7 = -172;
        int n8 = 140;
        int[] nArray = new int[400];
        float f = 0.82f;
        float f2 = -2.278f;
        double d = -2.40152;
        boolean bl = false;
        FuzzerUtils.init(nArray, 57911);
        n = 1;
        do {
            n2 |= (int)instanceCount;
            n2 += -22324 + n * n;
            Test.vMeth(n);
            iFld = -1;
            n3 = n;
            if (n3 >= 89) continue;
            iFld -= n2;
            if (bl) {
                f = 1.0f;
                do {
                    n4 += n3;
                    instanceCount -= (long)d;
                    iFld >>= 59737;
                } while ((f += 1.0f) < 1.0f);
                n4 = n;
                n4 -= 37414;
                f2 -= (float)n;
            }
            iFld += n3;
        } while (++n < 283);
        FuzzerUtils.out.println("i i1 i20 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i21 f3 d1 = " + n4 + "," + Float.floatToIntBits(f) + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("f4 b1 i22 = " + Float.floatToIntBits(f2) + "," + (bl ? 1 : 0) + "," + n5);
        FuzzerUtils.out.println("i23 i24 i25 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("iArr2 = " + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.iFld = " + instanceCount + "," + byFld + "," + iFld);
        FuzzerUtils.out.println("Test.lArrFld = " + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, -4L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}


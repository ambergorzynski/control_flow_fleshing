/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 93568178520217321L;
    public static volatile int iFld = 58420;
    public static float fFld = -34.817f;
    public static short sFld = (short)-3319;
    public double dFld = -37.51248;
    public static int[] iArrFld = new int[400];
    public static byte[] byArrFld = new byte[400];
    public static long[] lArrFld = new long[400];
    public static long vSmallMeth_check_sum;
    public static long lMeth_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth() {
        int n = 90;
        int n2 = -24506;
        int n3 = -46752;
        int n4 = -41;
        boolean bl = false;
        iFld <<= iFld;
        for (n = 4; n < 206; ++n) {
            iFld += n * n4;
            n3 = 1;
            while (++n3 < 8) {
                fFld -= 97.0f;
                instanceCount *= (long)n2;
                try {
                    Test.iArrFld[n3] = n / -322957304;
                    Test.iArrFld[n3] = n3 % 48312;
                    n2 = 37571 % n3;
                } catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                n2 += (int)fFld;
                Test.byArrFld[n] = -115;
                n4 = (byte)instanceCount;
                n2 <<= sFld;
            }
            if (bl) break;
            iFld &= n2;
            instanceCount >>= -82;
            if (n == 0) continue;
            vMeth_check_sum += (long)(n + n2 + n4 + n3 + (bl ? 1 : 0));
            return;
        }
        vMeth_check_sum += (long)(n + n2 + n4 + n3 + (bl ? 1 : 0));
    }

    public static long lMeth(short s, int n) {
        int n2 = -27464;
        int n3 = -114;
        int n4 = 12;
        int n5 = 48069;
        int n6 = 0;
        boolean bl = false;
        n2 = 1;
        while (++n2 < 252) {
            if (bl) {
                n = -14183;
            } else {
                iFld += n2;
            }
            instanceCount += (long)(n2 * iFld + n - n);
            iFld = -27996;
            for (n3 = 1; n3 < 6; ++n3) {
                int n7 = n2 - 1;
                iArrFld[n7] = iArrFld[n7] << (int)instanceCount;
                for (n5 = 1; n5 < 2; ++n5) {
                    n4 -= n5;
                    iFld = (int)instanceCount;
                    fFld += (float)instanceCount;
                    instanceCount -= (long)n;
                }
            }
        }
        long l = s + n + n2 + (bl ? 1 : 0) + n3 + n4 + n5 + n6;
        lMeth_check_sum += l;
        return l;
    }

    public static void vSmallMeth(double d, int n, int n2) {
        vSmallMeth_check_sum += Double.doubleToLongBits(d) + (long)(n += (int)Test.lMeth(sFld, -49879)) + (long)n2;
    }

    public void mainTest(String[] stringArray) {
        int n = 157;
        int n2 = 56807;
        int n3 = 159;
        int n4 = -14;
        int n5 = 95;
        boolean bl = false;
        double[][][] dArray = new double[400][400][400];
        FuzzerUtils.init((Object[][])dArray, (Object)2.6349);
        for (int i = 0; i < 485; ++i) {
            Test.vSmallMeth(this.dFld, iFld, iFld);
        }
        this.dFld = instanceCount;
        iFld += iFld;
        for (n = 2; n < 154; ++n) {
            n3 = 1;
            while (++n3 < 165) {
                block10: for (n4 = 1; n4 < 1; ++n4) {
                    iFld += 158;
                    iFld = n;
                    int n6 = n3;
                    lArrFld[n6] = lArrFld[n6] * instanceCount;
                    fFld += (float)n4;
                    instanceCount *= -7563773077878464896L;
                    switch (n4 % 6 * 5 + 98) {
                        case 106: {
                            n5 ^= 0xFFFFC5E0;
                            int n7 = n3;
                            iArrFld[n7] = iArrFld[n7] * n4;
                            continue block10;
                        }
                        case 109: {
                            fFld -= (float)instanceCount;
                            instanceCount += (long)n4 + instanceCount;
                            n5 += n4 * n5 + n4 - n2;
                            continue block10;
                        }
                        case 100: {
                            n5 = (int)instanceCount;
                            n2 = (int)instanceCount;
                            continue block10;
                        }
                        case 101: {
                            n5 = 515;
                            sFld = (short)instanceCount;
                            instanceCount = n4;
                        }
                        case 122: 
                        case 128: {
                            n5 += (int)(116995420L + (long)(n4 * n4));
                            if (bl) {
                                instanceCount |= (long)n;
                            } else {
                                n2 >>= n2;
                                Test.iArrFld[n4] = n;
                                iFld ^= (int)instanceCount;
                            }
                            double[] dArray2 = dArray[n3 + 1][n + 1];
                            int n8 = n;
                            dArray2[n8] = dArray2[n8] * (double)iFld;
                        }
                    }
                }
            }
        }
        FuzzerUtils.out.println("i11 i12 i13 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i14 i15 b2 = " + n4 + "," + n5 + "," + (bl ? 1 : 0));
        FuzzerUtils.out.println("dArr = " + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][])dArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.sFld dFld Test.iArrFld = " + sFld + "," + Double.doubleToLongBits(this.dFld) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.byArrFld Test.lArrFld = " + FuzzerUtils.checkSum(byArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -53728);
        FuzzerUtils.init(byArrFld, (byte)-46);
        FuzzerUtils.init(lArrFld, -4L);
        vSmallMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}


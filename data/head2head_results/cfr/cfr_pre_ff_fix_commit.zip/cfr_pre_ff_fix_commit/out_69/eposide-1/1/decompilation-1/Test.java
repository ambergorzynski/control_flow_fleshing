/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -1L;
    public static volatile double dFld = -1.47951;
    public static boolean bFld = true;
    public static float[] fArrFld = new float[400];
    public static int[] iArrFld = new int[400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1() {
        int n = 38219;
        int n2 = 65250;
        int n3 = -34391;
        int n4 = -41322;
        int n5 = -2;
        int[] nArray = new int[400];
        long[] lArray = new long[400];
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(lArray, -1605L);
        FuzzerUtils.init(blArray, true);
        FuzzerUtils.init(nArray, 13);
        n = 127;
        while (--n > 0) {
            int n6 = -73;
            n6 = (int)instanceCount;
            n2 = 1;
            do {
                n6 = 39;
                instanceCount = 81L;
                if (n2 == 0) continue;
                vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(blArray) + FuzzerUtils.checkSum(nArray);
                return;
            } while ((n2 += 2) < 12);
            dFld -= 32917.0;
            n3 = 1;
            while (++n3 < 12) {
                boolean bl;
                blArray[n + 1] = bl = false;
                n6 -= n;
                for (n4 = 1; n4 < 1; ++n4) {
                    n6 <<= (int)instanceCount;
                    try {
                        nArray[n - 1] = n5 % 50578;
                        n5 = nArray[n4 - 1] / -251;
                        nArray[n + 1] = -90 / n2;
                    } catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    n6 *= (int)instanceCount;
                }
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(blArray) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth(int n, int n2, boolean bl) {
        int n3 = 52523;
        int n4 = 18;
        int[][][] nArray = new int[400][400][400];
        float f = -2.489f;
        int n5 = 7917;
        short[] sArray = new short[400];
        int n6 = -1;
        double[] dArray = new double[400];
        FuzzerUtils.init((Object[][])nArray, (Object)13);
        FuzzerUtils.init(sArray, (short)5689);
        FuzzerUtils.init(dArray, 51.14484);
        Test.vMeth1();
        block14: for (n3 = 9; n3 < 158; ++n3) {
            switch ((n3 >>> 1) % 1 + 26) {
                case 26: {
                    switch (n3 % 1 * 5 + 91) {
                        case 92: {
                            n4 = n;
                            n2 = n;
                            n4 -= (int)dFld;
                            n2 += n3;
                        }
                    }
                    switch (n3 % 6 + 47) {
                        case 47: {
                            int[] nArray2 = nArray[n3 + 1][n3 + 1];
                            int n7 = n3;
                            nArray2[n7] = nArray2[n7] - 2;
                            break;
                        }
                        case 48: {
                            f -= (float)n2;
                            n4 = -59210;
                            n4 -= n4;
                            n4 += 3;
                        }
                        case 49: {
                            n2 *= (int)dFld;
                            break;
                        }
                        case 50: {
                            n = n5;
                        }
                        case 51: {
                            int n8 = n3;
                            dArray[n8] = dArray[n8] - (double)n3;
                            break;
                        }
                        case 52: {
                            n += n2;
                        }
                    }
                    continue block14;
                }
                default: {
                    n4 = n6;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + (bl ? 1 : 0) + n3 + n4 + Float.floatToIntBits(f) + n5 + n6) + FuzzerUtils.checkSum((Object[][])nArray) + FuzzerUtils.checkSum(sArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public static int iMeth(long l) {
        int n = 48039;
        int n2 = 3;
        int n3 = -242;
        int n4 = -6331;
        int n5 = 38;
        int n6 = -218;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, 13.8219);
        Test.vMeth(1, -204, bFld);
        n = 4;
        while (n < 283) {
            int n7 = n - 1;
            dArray[n7] = dArray[n7] + (double)n;
            for (n3 = 1; n3 < 6; ++n3) {
                if (n3 != 0) {
                    // empty if block
                }
                dFld += (double)n4;
                n4 *= n;
                n2 = 54170;
                n5 = 1;
                while (2 > n5) {
                    n6 += 253 + n5 * n5;
                    bFld = true;
                    n4 += 51640;
                    n2 = n5++;
                }
            }
            int n8 = n++;
            dArray[n8] = dArray[n8] * (double)n6;
            n4 -= 51456;
        }
        long l2 = l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public void mainTest(String[] stringArray) {
        int n = -147;
        int n2 = -41843;
        int n3 = 3;
        int n4 = -188;
        int n5 = -38213;
        int n6 = -48864;
        int n7 = 31876;
        int n8 = 0;
        int n9 = -9;
        int n10 = 1;
        int n11 = -12;
        int n12 = 7;
        float f = 0.463f;
        short s = -30924;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, -84.13271);
        dFld = (long)(-(n >> n)) / (instanceCount | 1L);
        n2 = 1;
        while (++n2 < 155) {
            instanceCount += (long)n2 - instanceCount;
            n += (int)((long)Test.iMeth(instanceCount) - instanceCount);
            n *= n;
            instanceCount *= (long)n12;
            instanceCount *= (long)f;
            for (n3 = 8; 162 > n3; ++n3) {
                int n13 = n2;
                iArrFld[n13] = iArrFld[n13] + (int)instanceCount;
            }
        }
        n4 >>>= n;
        for (n5 = 5; n5 < 143; ++n5) {
            f -= (float)n6;
            dFld *= (double)n;
            if (bFld) {
                Test.iArrFld[n5 - 1] = n2;
                n7 = n4;
                for (n8 = 182; n8 > 11; --n8) {
                    f = -74.0f;
                    n12 = (byte)(n12 + (byte)n8);
                    int n14 = n8 - 1;
                    dArray[n14] = dArray[n14] / (double)(n8 | 1);
                }
                continue;
            }
            n12 = (byte)(n12 + (byte)((long)n5 * instanceCount + (long)n12 - instanceCount));
            n4 += n5 * s + n5 - n7;
            block14: for (n10 = n5; n10 < 182; ++n10) {
                switch (n10 % 8 + 38) {
                    case 38: {
                        n7 -= n;
                        continue block14;
                    }
                    case 39: {
                        n4 = n12;
                        f += f;
                        continue block14;
                    }
                    case 40: {
                        f = n3;
                        n4 = n9;
                        continue block14;
                    }
                    case 41: {
                        n -= n12;
                        continue block14;
                    }
                    case 42: {
                        f -= (float)instanceCount;
                        continue block14;
                    }
                    case 43: {
                        f -= (float)n;
                    }
                    case 44: {
                        n6 = (int)instanceCount;
                        continue block14;
                    }
                    case 45: {
                        n4 += -49 + n10 * n10;
                    }
                }
            }
        }
        FuzzerUtils.out.println("i i1 by1 = " + n + "," + n2 + "," + (byte)n12);
        FuzzerUtils.out.println("f2 i18 i19 = " + Float.floatToIntBits(f) + "," + n3 + "," + n4);
        FuzzerUtils.out.println("i20 i21 i23 = " + n5 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("i24 i25 s2 = " + n8 + "," + n9 + "," + s);
        FuzzerUtils.out.println("i26 i27 dArr2 = " + n10 + "," + n11 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.bFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.fArrFld Test.iArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(fArrFld, -42.43f);
        FuzzerUtils.init(iArrFld, 14);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}


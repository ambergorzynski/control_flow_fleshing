/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -602120661L;
    public static byte byFld = (byte)116;
    public volatile int iFld = 15629;
    public short sFld = (short)32440;
    public static long[] lArrFld = new long[400];
    public static volatile float[] fArrFld = new float[400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long dMeth_check_sum;
    public static long iMeth1_check_sum;

    public static void vMeth(double d, int n, float f) {
        int n2 = -10;
        int n3 = 100;
        for (n2 = 4; n2 < 234; ++n2) {
            n += n2 - n3;
        }
        vMeth_check_sum += Double.doubleToLongBits(d) + (long)n + (long)Float.floatToIntBits(f) + (long)n2 + (long)n3;
    }

    public static int iMeth1(double d) {
        int n = 49;
        int n2 = 5;
        int n3 = -49;
        int n4 = 51;
        int n5 = 133;
        int n6 = -28456;
        int n7 = 14;
        long l = 0L;
        n *= n;
        n >>= n;
        n *= n;
        n += (int)d;
        n &= (int)instanceCount;
        block4: for (l = 1L; 267L > l; ++l) {
            switch ((int)(l % 2L + 54L)) {
                case 54: {
                    for (n3 = 1; n3 < 6; n3 += 2) {
                        n5 -= (int)d;
                        n4 |= n;
                    }
                    n2 = n4;
                    continue block4;
                }
                case 55: {
                    for (n6 = 1; n6 < 6; ++n6) {
                        d = n4;
                        n7 >>= (int)instanceCount;
                    }
                }
                default: {
                    n = -126;
                }
            }
        }
        long l2 = Double.doubleToLongBits(d) + (long)n + l + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7;
        iMeth1_check_sum += l2;
        return (int)l2;
    }

    public static double dMeth(boolean bl, long l) {
        int n = -1;
        int n2 = 9;
        int n3 = 0;
        int n4 = 38599;
        int n5 = 92;
        int n6 = -23889;
        int n7 = 1;
        double d = 0.28089;
        float f = 113.43f;
        int n8 = -92;
        int n9 = -19458;
        n <<= (int)((long)(n - n) * ((long)Test.iMeth1(-1.30002) * l));
        fArrFld[0] = fArrFld[0] - 6.0f;
        d -= (double)n;
        for (n2 = 10; n2 < 263; ++n2) {
            d = instanceCount;
            l = n2;
            for (n4 = n2; n4 < 6; ++n4) {
                f -= (float)d;
                n8 = (byte)(n8 + (byte)(-13 + n4 * n4));
                l -= (long)n4;
            }
            n6 = 1;
            while (++n6 < 6) {
                n7 = 1;
                while (++n7 < 1) {
                    n = n9;
                    d += (double)(f -= (float)n5);
                }
            }
        }
        long l2 = (long)(bl ? 1 : 0) + l + (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)Float.floatToIntBits(f) + (long)n8 + (long)n6 + (long)n7 + (long)n9;
        dMeth_check_sum += l2;
        return l2;
    }

    public static int iMeth(byte by, float f) {
        int n = 8;
        int n2 = 3;
        int n3 = -37387;
        int n4 = 7794;
        int[] nArray = new int[400];
        boolean bl = true;
        double[] dArray = new double[400];
        FuzzerUtils.init(nArray, -46937);
        FuzzerUtils.init(dArray, 2.9824);
        for (n = 389; n > 16; n -= 3) {
            int n5 = n;
            long l = lArrFld[n5] + 1L;
            lArrFld[n5] = l;
            n2 = n2-- + (20938 - n2);
            Test.vMeth(l * (long)n2, n2, fArrFld[n]);
            if (bl) {
                int n6 = n;
                dArray[n6] = dArray[n6] + ((double)(-7.03187E18f + ((float)n + -26.841f)) - Test.dMeth(true, instanceCount) - (double)n2);
                n2 -= (int)(instanceCount >>>= n);
                n2 = (int)((float)n2 + ((float)n * f + (float)n2 - (float)instanceCount));
                continue;
            }
            instanceCount += (long)n;
            for (n3 = n; n3 < 13; ++n3) {
                nArray[n3 + 1] = n3;
                int n7 = n + 1;
                nArray[n7] = nArray[n7] * 138;
                n2 = (int)((long)n2 + ((long)(n3 * n2) + instanceCount - (long)n3));
                by = (byte)(by - 25);
                int n8 = n;
                nArray[n8] = nArray[n8] + n2;
            }
        }
        long l = (long)(by + Float.floatToIntBits(f) + n + n2 + (bl ? 1 : 0) + n3 + n4) + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        float f = 0.54f;
        double d = 1.12446;
        int n = 11;
        int n2 = 14456;
        int n3 = 143;
        int n4 = 0;
        int n5 = 54950;
        int n6 = 94;
        int n7 = -9;
        int n8 = -12;
        int[] nArray = new int[400];
        long l = -9167193240035170393L;
        FuzzerUtils.init(nArray, 0);
        instanceCount -= (long)Test.iMeth(byFld, f);
        instanceCount = this.iFld;
        for (int n9 : nArray) {
            for (d = 2.0; d < 63.0; d += 1.0) {
                n |= this.iFld;
                int n10 = (int)d;
                lArrFld[n10] = lArrFld[n10] - instanceCount;
                f = (float)d;
            }
            nArray[348] = nArray[348] - 40629;
            for (l = 63L; 1L < l; l -= 3L) {
                n9 += (int)l;
                nArray[(int)(l + 1L)] = 161;
                n9 *= n9;
                int n11 = (int)(l + 1L);
                lArrFld[n11] = lArrFld[n11] + l;
                n2 += (int)f;
                for (n3 = 1; 4 > n3; ++n3) {
                    int n12 = 63;
                    this.iFld = (int)instanceCount;
                    nArray[(int)(l - 1L)] = n;
                    n12 ^= (int)l;
                }
            }
            for (n5 = 63; n5 > 3; n5 -= 2) {
                this.iFld ^= (int)instanceCount;
                n6 = (int)((long)n6 + ((long)n5 * l + (long)n4 - (long)n));
                for (n7 = 1; n7 < 3; ++n7) {
                    f -= (float)n;
                    Test.lArrFld[n7] = n2;
                    this.sFld = (short)21780;
                    instanceCount += (long)n7;
                }
                int n13 = n5 - 1;
                fArrFld[n13] = fArrFld[n13] - (float)instanceCount;
                n4 += n3;
                f = byFld;
            }
        }
        FuzzerUtils.out.println("f3 d3 i23 = " + Float.floatToIntBits(f) + "," + Double.doubleToLongBits(d) + "," + n);
        FuzzerUtils.out.println("l2 i24 i25 = " + l + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i26 i28 i29 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i30 i31 iArr1 = " + n7 + "," + n8 + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.byFld iFld = " + instanceCount + "," + byFld + "," + this.iFld);
        FuzzerUtils.out.println("sFld Test.lArrFld Test.fArrFld = " + this.sFld + "," + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 1L);
        FuzzerUtils.init(fArrFld, 0.672f);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        dMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
    }
}


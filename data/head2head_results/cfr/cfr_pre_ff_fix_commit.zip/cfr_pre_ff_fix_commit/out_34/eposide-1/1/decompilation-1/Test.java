/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 5925429322338312142L;
    public static float fFld = 58.276f;
    public static long[] lArrFld = new long[400];
    public static long vMeth_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(long l, float f, int n) {
        int n2 = 3;
        int n3 = -251;
        int n4 = -40125;
        int n5 = 1;
        int n6 = 171;
        int n7 = -9;
        int n8 = -235;
        int n9 = -127;
        boolean bl = false;
        short[] sArray = new short[400];
        FuzzerUtils.init(sArray, (short)12524);
        for (n2 = 17; n2 < 306; ++n2) {
            for (n4 = 1; n4 < 6; ++n4) {
                n6 = 1;
                do {
                    n5 += n6 * n6;
                    n3 = (int)f;
                    n3 >>>= 0;
                    l += (long)n;
                    n7 += n6 * n6;
                } while (++n6 < 2);
                int n10 = n4;
                sArray[n10] = (short)(sArray[n10] >> (short)n2);
                f = n4;
                n7 += 14;
                for (n8 = 1; n8 < 2 && !bl; ++n8) {
                    n = n6;
                    instanceCount += (long)n9;
                }
            }
        }
        vMeth1_check_sum += l + (long)Float.floatToIntBits(f) + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)n9 + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(sArray);
    }

    public static int iMeth() {
        int n = -49942;
        int n2 = -3;
        int n3 = 2;
        int n4 = -42024;
        int[] nArray = new int[400];
        int n5 = 3339;
        boolean bl = false;
        FuzzerUtils.init(nArray, 7013);
        for (n = 7; n < 263; ++n) {
            Test.vMeth1(instanceCount, fFld, n2);
            nArray[n - 1] = n2;
            n5 = (short)(n5 * 30121);
            for (n3 = n; 6 > n3; ++n3) {
                n2 += (int)fFld;
                if (bl) {
                    instanceCount += (long)n3;
                    int n6 = n3 + 1;
                    nArray[n6] = nArray[n6] * n3;
                    n4 -= 38596;
                }
                n5 = (short)(n5 + (short)(n3 | n5));
                if (bl) continue;
                int n7 = n3 + 1;
                nArray[n7] = nArray[n7] + n;
            }
            if (bl) break;
        }
        long l = (long)(n + n2 + n5 + n3 + n4 + (bl ? 1 : 0)) + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public static void vMeth(int n, double d, long l) {
        int n2 = 22;
        int n3 = -8;
        int n4 = 162;
        int n5 = 12060;
        int n6 = -14610;
        int n7 = 29538;
        int n8 = -15512;
        double d2 = -2.85552;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, -78.494f);
        instanceCount = (long)(fArray[6] + (float)Test.iMeth());
        for (n2 = 277; n2 > 14; --n2) {
            n += n2 * n2;
            for (n4 = 6; n4 > 1; n4 -= 2) {
                l *= 1L;
                int n9 = n4;
                lArrFld[n9] = lArrFld[n9] * (long)n8;
                for (n6 = 1; n6 < 3; ++n6) {
                    n7 = n6;
                    l &= (long)n8;
                    fArray[n6 - 1] = 39.0f;
                    fFld += (float)(n5 += n2);
                    d2 = n4;
                    n3 = (int)d;
                }
                n = n6;
            }
        }
        vMeth_check_sum += (long)n + Double.doubleToLongBits(d) + l + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n8 + (long)n6 + (long)n7 + Double.doubleToLongBits(d2) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public void mainTest(String[] stringArray) {
        float f = -2.468f;
        int n = 5;
        double d = 68.106352;
        f = n;
        Test.vMeth(n, d, instanceCount);
        n *= (int)d;
        FuzzerUtils.out.println("f i d2 = " + Float.floatToIntBits(f) + "," + (n ^= 0xFFFFFFA9) + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.lArrFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 6L);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}


/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = 217L;
    public static int iFld = 17611;
    public static float fFld = -12.737f;
    public static boolean bFld = true;
    public short sFld = (short)-23447;
    public static int iFld1 = 0;
    public byte byFld = (byte)-21;
    public int iFld2 = -17600;
    public byte[] byArrFld = new byte[400];
    public static int[][] iArrFld = new int[400][400];
    public static double[] dArrFld = new double[400];
    public static long fMeth_check_sum;
    public static long lMeth_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth() {
        int n = 19547;
        int n2 = 48572;
        int n3 = 34998;
        int n4 = 40175;
        int n5 = -24;
        byte[] byArray = new byte[400];
        double d = 0.61017;
        FuzzerUtils.init(byArray, (byte)26);
        n = 1;
        while (++n < 395) {
        }
        for (n2 = 3; n2 < 233; ++n2) {
            double d2 = 22.125832;
            if (!bFld) continue;
            iFld >>= iFld;
            n3 = n;
            n5 = (byte)(n5 - (byte)d2);
        }
        Test.iArrFld[(n2 >>> 1) % 400][(n2 >>> 1) % 400] = 22313954;
        d = 1.0;
        do {
            switch ((int)(d % 5.0 + 20.0)) {
                case 20: 
                case 21: {
                    break;
                }
                case 22: {
                    n4 = 1;
                    do {
                        instanceCount *= (long)n5;
                        int n6 = (int)(d - 1.0);
                        byArray[n6] = (byte)(byArray[n6] << (byte)n4);
                    } while (++n4 < 9);
                    break;
                }
                case 23: {
                    n3 *= 21820;
                    break;
                }
                case 24: {
                    iFld = n4;
                }
            }
        } while ((d += 1.0) < 171.0);
        long l = (long)(n + n2 + n3 + n5) + Double.doubleToLongBits(d) + (long)n4 + FuzzerUtils.checkSum(byArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public long lMeth(int n, int n2, int n3) {
        int n4 = -221;
        int n5 = -14;
        int n6 = 231;
        int n7 = 5;
        int n8 = 4;
        int n9 = -207;
        double d = -60.57645;
        short[] sArray = new short[400];
        FuzzerUtils.init(sArray, (short)-31717);
        int n10 = n3--;
        int n11 = (iFld >>> 1) % 400;
        byte by = this.byArrFld[n11];
        this.byArrFld[n11] = (byte)(by + 1);
        n3 = n10 * (Math.abs(n3) * by);
        n = (int)(instanceCount + (long)iFld);
        block13: for (n4 = 14; n4 < 294; ++n4) {
            for (n6 = 1; n6 < 6; ++n6) {
                fFld -= (float)iArrFld[n4 + 1][n4 - 1];
            }
            switch ((Math.abs(n3) >>> 1) % 9 * 5 + 93) {
                case 135: {
                    d *= (double)(Test.iMeth() - iFld);
                    int[] nArray = iArrFld[n4];
                    int n12 = n4 - 1;
                    nArray[n12] = nArray[n12] + iFld;
                    for (n8 = 1; n8 < 6; ++n8) {
                        iFld = n4;
                        int n13 = n4 + 1;
                        sArray[n13] = (short)(sArray[n13] - (short)n4);
                        try {
                            n2 = n3 / n8;
                            Test.iArrFld[n8][n4 + 1] = -43820 % n4;
                            n2 = n4 / n;
                            continue;
                        } catch (ArithmeticException arithmeticException) {
                            // empty catch block
                        }
                    }
                    instanceCount += -1L;
                    continue block13;
                }
                case 131: {
                    n5 = (int)((long)n5 + ((long)(n4 * n2) + instanceCount - (long)n9));
                }
                case 100: {
                    n9 += n4;
                    continue block13;
                }
                case 120: {
                    n3 %= n4 | 1;
                    continue block13;
                }
                case 129: {
                    instanceCount += (long)n4;
                    continue block13;
                }
                case 125: {
                    n9 += (int)(-127L + (long)(n4 * n4));
                    continue block13;
                }
                case 117: {
                    n9 += -15764 + n4 * n4;
                    continue block13;
                }
                case 126: {
                    n3 <<= this.sFld;
                    continue block13;
                }
                case 94: {
                    instanceCount *= 25L;
                    continue block13;
                }
                default: {
                    this.sFld = (short)n6;
                }
            }
        }
        long l = (long)(n + n2 + n3 + n4 + n5 + n6 + n7) + Double.doubleToLongBits(d) + (long)n8 + (long)n9 + FuzzerUtils.checkSum(sArray);
        lMeth_check_sum += l;
        return l;
    }

    public float fMeth(long l, byte by) {
        int n = 0;
        int n2 = 5836;
        int n3 = -9;
        int n4 = -32179;
        int n5 = 116;
        int n6 = -53;
        int[] nArray = new int[400];
        float f = -47.811f;
        long[] lArray = new long[400];
        double[] dArray = new double[400];
        FuzzerUtils.init(nArray, -167);
        FuzzerUtils.init(lArray, 26273L);
        FuzzerUtils.init(dArray, -1.11461);
        for (n = 6; n < 160; ++n) {
            for (n3 = 1; n3 < 10; ++n3) {
                block7: for (f = 1.0f; 2.0f > f; f += 2.0f) {
                    fFld += f;
                    n5 = n4;
                    nArray[(int)(f + 1.0f)] = (int)((long)n5 - --l + ((long)(++n2) - (instanceCount + (long)n)));
                    n2 += Math.min(iFld, 4) - (n3 - n) + --n6 * Math.min(n5, n6);
                    fFld -= (float)(-n4);
                    n6 = nArray[n];
                    nArray[n] = n2 &= 0xFFFFFFCA;
                    int n7 = (int)(f - 1.0f);
                    lArray[n7] = lArray[n7] << (int)this.lMeth(n2, n, n);
                    switch (107) {
                        case 107: {
                            try {
                                nArray[(int)(f - 1.0f)] = n4 % 17099;
                                iFld1 = -810560336 % iArrFld[n + 1][(int)f];
                                n6 = iFld % -203;
                            } catch (ArithmeticException arithmeticException) {
                                // empty catch block
                            }
                            n5 = iFld1;
                            continue block7;
                        }
                        default: {
                            iFld = n6;
                        }
                    }
                }
            }
        }
        long l2 = l + (long)by + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)Float.floatToIntBits(f) + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
        fMeth_check_sum += l2;
        return l2;
    }

    public void mainTest(String[] stringArray) {
        int n = -196;
        int n2 = 129;
        int n3 = 7425;
        int n4 = -205;
        int n5 = 41598;
        int n6 = -254;
        int[] nArray = new int[400];
        double d = 2.121841;
        long[][][] lArray = new long[400][400][400];
        FuzzerUtils.init(nArray, -57920);
        FuzzerUtils.init((Object[][])lArray, (Object)62001L);
        nArray[(Test.iFld >>> 1) % 400] = -50696;
        for (n = 12; n < 272 && !(this.fMeth(instanceCount, (byte)-65) <= (float)iFld); ++n) {
            instanceCount |= (long)n2;
            n2 = this.byFld;
            for (n3 = 4; n3 < 97; ++n3) {
                fFld += (float)d;
                instanceCount += (long)(50768 + n3 * n3);
            }
            iFld1 += iFld1;
            n4 += 7 + n * n;
            long[] lArray2 = lArray[n][n + 1];
            int n7 = n - 1;
            lArray2[n7] = lArray2[n7] + -1L;
        }
        n5 = 1;
        while (++n5 < 212) {
            iFld = n4;
            n4 = n;
            Test.iArrFld[n5 + 1][n5] = -180;
        }
        iFld += (int)fFld;
        iFld1 = n;
        switch ((n >>> 1) % 1 * 5 + 20) {
            case 23: {
                n6 = 1;
                do {
                    try {
                        iFld1 = n % n2;
                        n2 = n4 % iArrFld[n6][n6];
                        n4 = n2 / iFld1;
                    } catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    fFld += (float)n4;
                    iFld = n2;
                    instanceCount = n3;
                    Test.dArrFld[n6] = iFld1 <<= -5296;
                    Test.dArrFld[n6 + 1] = this.byFld;
                    n4 += iFld1;
                    this.iFld2 = (int)((long)this.iFld2 + ((long)(n6 * this.sFld + n) - instanceCount));
                    instanceCount = -17687L;
                } while (++n6 < 385);
                break;
            }
            default: {
                fFld = n;
            }
        }
        FuzzerUtils.out.println("i i1 i21 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i22 d3 i23 = " + n4 + "," + Double.doubleToLongBits(d) + "," + n5);
        FuzzerUtils.out.println("i24 iArr lArr1 = " + n6 + "," + FuzzerUtils.checkSum(nArray) + "," + FuzzerUtils.checkSum((Object[][])lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.bFld sFld Test.iFld1 = " + (bFld ? 1 : 0) + "," + this.sFld + "," + iFld1);
        FuzzerUtils.out.println("byFld iFld2 byArrFld = " + this.byFld + "," + this.iFld2 + "," + FuzzerUtils.checkSum(this.byArrFld));
        FuzzerUtils.out.println("Test.iArrFld Test.dArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -14408);
        FuzzerUtils.init(dArrFld, 63.11026);
        fMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}


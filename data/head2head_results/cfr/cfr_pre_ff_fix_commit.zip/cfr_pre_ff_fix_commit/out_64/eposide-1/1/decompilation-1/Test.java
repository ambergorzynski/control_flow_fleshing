/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 3381053224L;
    public static int iFld = -5;
    public static double dFld = -72.51985;
    public float fFld = 53.38f;
    public static byte byFld = (byte)127;
    public long[] lArrFld = new long[400];
    public static long[] lArrFld1 = new long[400];
    public long[][] lArrFld2 = new long[400][400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2(long l) {
        int n = 10;
        int n2 = -47933;
        int n3 = 34375;
        int n4 = -38037;
        int n5 = -6;
        int n6 = -14;
        int n7 = 12;
        int n8 = -87;
        int[][] nArray = new int[400][400];
        int n9 = -4135;
        float f = 1.527f;
        boolean bl = false;
        FuzzerUtils.init(nArray, 184);
        switch (39) {
            case 46: {
                for (n = 17; n < 358; ++n) {
                    for (n3 = n; n3 < 5; ++n3) {
                        int n10 = n + 1;
                        lArrFld1[n10] = lArrFld1[n10] + l;
                        for (n5 = 1; n5 < 1; ++n5) {
                            l += (long)(n5 * n5);
                            l += (long)(n5 | byFld);
                        }
                        block22: for (n7 = 1; 1 > n7; ++n7) {
                            n9 = (short)(n9 * 2);
                            switch (n % 7 + 35) {
                                case 35: {
                                    switch (n3 % 2 * 5 + 41) {
                                        case 45: {
                                            instanceCount -= l;
                                            iFld = (int)dFld;
                                            break;
                                        }
                                        case 51: {
                                            int n11 = n - 1;
                                            lArrFld1[n11] = lArrFld1[n11] - l;
                                            f += (float)(n7 * byFld);
                                        }
                                    }
                                    continue block22;
                                }
                                case 36: {
                                    nArray[n3 + 1][n - 1] = (int)f;
                                    continue block22;
                                }
                                case 37: {
                                    instanceCount = iFld;
                                    continue block22;
                                }
                                case 38: {
                                    if (!bl) continue block22;
                                    continue block22;
                                }
                                case 39: {
                                    l += (long)dFld;
                                    continue block22;
                                }
                                case 40: {
                                    l <<= n8;
                                    continue block22;
                                }
                                case 41: {
                                    l += (long)(n7 * n7);
                                }
                            }
                        }
                    }
                }
                break;
            }
            case 32: {
                l += (long)n4;
                break;
            }
            case 31: {
                byFld = (byte)(byFld - (byte)n5);
            }
            case 43: 
        }
        vMeth2_check_sum += l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)n9 + (long)Float.floatToIntBits(f) + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth1(double d, long l, long l2) {
        float f = -19.375f;
        int n = -243;
        int n2 = 26080;
        boolean bl = false;
        Test.vMeth2(l2);
        iFld = -11;
        f *= f;
        for (n = 18; 288 > n; n += 3) {
            n2 >>= iFld;
            f -= (float)dFld;
        }
        vMeth1_check_sum += Double.doubleToLongBits(d) + l + l2 + (long)Float.floatToIntBits(f) + (long)n + (long)n2 + (long)(bl ? 1 : 0);
    }

    public static void vMeth(int n, boolean bl, int n2) {
        int n3 = -31083;
        int n4 = 3;
        int n5 = -11;
        int n6 = -35232;
        int n7 = 238;
        int n8 = 40020;
        int n9 = -12;
        int n10 = 238;
        int n11 = -9;
        int n12 = 17272;
        for (n3 = 21; n3 < 345; ++n3) {
            int n13 = 27;
            n13 = (byte)(n13 - 1);
            n12 = (short)(n12 >> (short)n13);
            Test.vMeth1(dFld, -904160788L, instanceCount);
            n13 = (byte)(n13 >>> (byte)n);
            iFld = -4;
            instanceCount -= (long)n4;
        }
        n5 = 1;
        do {
            n12 = (short)iFld;
        } while ((n5 += 2) < 139);
        n /= n3 | 1;
        for (n6 = 314; n6 > 5; --n6) {
            for (n8 = 5; n8 > 1; n8 -= 2) {
                instanceCount *= (long)n12;
                for (n10 = 1; n10 < 3; ++n10) {
                    n *= n6;
                    Test.lArrFld1[n10] = n12;
                }
            }
        }
        vMeth_check_sum += (long)(n + (bl ? 1 : 0) + n2 + n3 + n4 + n12 + n5 + n6 + n7 + n8 + n9 + n10 + n11);
    }

    public void mainTest(String[] stringArray) {
        float f = 0.1f;
        int n = 182;
        int n2 = 9;
        int n3 = -137;
        int n4 = 45901;
        int n5 = 43;
        int n6 = -61127;
        int[] nArray = new int[400];
        int[][] nArray2 = new int[400][400];
        boolean bl = false;
        FuzzerUtils.init(nArray, 240);
        FuzzerUtils.init(nArray2, 102);
        int n7 = (iFld >>> 1) % 400;
        long l = this.lArrFld[352];
        this.lArrFld[352] = l - 1L;
        int n8 = (iFld >>> 1) % 400;
        long l2 = this.lArrFld[n8] + 1L;
        this.lArrFld[n8] = l2;
        nArray[n7] = nArray[n7] | (int)(l * (-2082932367L * (-5470L + l2)));
        int n9 = iFld = iFld--;
        double d = dFld + (double)iFld - 99.130966 * (double)(this.fFld + this.fFld);
        ++iFld;
        iFld = n9 + (int)(d / (double)(iFld | 1));
        Test.vMeth(-55220, true, iFld);
        switch ((iFld >>> 1) % 3 + 40) {
            case 40: {
                f = 1.0f;
                do {
                    try {
                        nArray[(int)(f + 1.0f)] = nArray[(int)(f + 1.0f)] % 37238;
                        iFld /= iFld;
                        iFld /= 228;
                    } catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    iFld += (int)(f * (float)instanceCount);
                    this.fFld -= 2.72f;
                    instanceCount -= instanceCount;
                    this.fFld -= (float)instanceCount;
                    n = 1;
                    do {
                        instanceCount += (long)(n * n);
                        n2 = 1;
                        while (++n2 < 4) {
                        }
                        n3 = n2;
                        dFld = iFld;
                        n3 = (int)((long)n3 + ((long)n * instanceCount + (long)n3 - (long)n));
                        n4 = 1;
                        if (n4 < 4) {
                            // empty if block
                        }
                        this.lArrFld = this.lArrFld2[n];
                        iFld = n3;
                        int n10 = n + 1;
                        nArray[n10] = nArray[n10] & n4;
                        n6 = 1;
                        do {
                            n5 = (int)((long)n5 + ((long)n6 - instanceCount));
                            nArray[(int)(f - 1.0f)] = (int)instanceCount;
                            this.fFld -= -6187.0f;
                            n5 <<= (int)instanceCount;
                        } while (++n6 < 4);
                    } while ((n += 3) < 89);
                } while ((f += 1.0f) < 283.0f);
            }
            case 41: {
                n5 |= (int)instanceCount;
                break;
            }
            case 42: {
                byFld = (byte)this.fFld;
            }
        }
        FuzzerUtils.out.println("f2 i21 i22 = " + Float.floatToIntBits(f) + "," + n + "," + n2);
        FuzzerUtils.out.println("b3 i23 i24 = " + (bl ? 1 : 0) + "," + n3 + "," + n4);
        FuzzerUtils.out.println("i25 i26 iArr = " + n5 + "," + n6 + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("iArr2 = " + FuzzerUtils.checkSum(nArray2));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("fFld Test.byFld lArrFld = " + Float.floatToIntBits(this.fFld) + "," + byFld + "," + FuzzerUtils.checkSum(this.lArrFld));
        FuzzerUtils.out.println("Test.lArrFld1 lArrFld2 = " + FuzzerUtils.checkSum(lArrFld1) + "," + FuzzerUtils.checkSum(this.lArrFld2));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld1, -4017198832530695990L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}


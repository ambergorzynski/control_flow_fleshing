/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = 983128420479108747L;
    public static volatile float fFld = -24.24f;
    public volatile short sFld = (short)21291;
    public static int[] iArrFld = new int[400];
    public static long[] lArrFld = new long[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth(int n) {
        double d = 57.109828;
        double d2 = 86.99492;
        int n2 = 60751;
        int n3 = 11;
        int n4 = -204;
        int n5 = -10;
        float f = 0.467f;
        boolean bl = false;
        int n6 = 4448;
        d = n;
        n = (int)instanceCount;
        for (n2 = 219; n2 > 9; n2 -= 3) {
            for (n4 = 1; 22 > n4; ++n4) {
                n5 += n;
                instanceCount = (long)((float)instanceCount + ((float)(n4 * n + n2) - f));
                Test.iArrFld[n2] = (int)instanceCount;
                n -= n3;
                f = n4;
            }
            n3 = n6;
            int n7 = n2;
            iArrFld[n7] = iArrFld[n7] + n5;
            d2 = 1.0;
            do {
                instanceCount -= (long)n;
            } while ((d2 += 1.0) < 22.0);
            if (!bl) continue;
        }
        long l = (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)Float.floatToIntBits(f) + (long)(bl ? 1 : 0) + (long)n6 + Double.doubleToLongBits(d2);
        iMeth_check_sum += l;
        return (int)l;
    }

    public static void vMeth1(int n, long l, int n2) {
        float f = -3.383f;
        float[] fArray = new float[400];
        int n3 = 58266;
        int n4 = 12;
        int n5 = -3;
        int n6 = -10;
        int n7 = -10850;
        int n8 = 11;
        int n9 = -8782;
        FuzzerUtils.init(fArray, -1.92f);
        l = (long)((float)Test.iMeth(n2) + f);
        iArrFld[339] = iArrFld[339] * n2;
        for (n3 = 366; n3 > 2; n3 -= 2) {
            n -= (int)instanceCount;
            n -= 34049;
        }
        for (n5 = 12; n5 < 380; ++n5) {
            for (n7 = 1; 5 > n7; ++n7) {
                boolean bl = false;
                n2 ^= n9;
                n2 = n5;
                int n10 = n7 - 1;
                iArrFld[n10] = iArrFld[n10] + 16372;
                if (n3 == 0) continue;
                vMeth1_check_sum += (long)n + l + (long)n2 + (long)Float.floatToIntBits(f) + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)n9 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
                return;
            }
            n8 = n9;
            int n11 = n5 - 1;
            lArrFld[n11] = lArrFld[n11] ^ 0xFFFFFFFFFFFF3E7BL;
        }
        vMeth1_check_sum += (long)n + l + (long)n2 + (long)Float.floatToIntBits(f) + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)n9 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public void vMeth() {
        int n = -149;
        int n2 = 35423;
        int n3 = 49222;
        boolean bl = true;
        long l = 3587399425167903519L;
        int n4 = 104;
        for (n = 10; n < 188; ++n) {
            Test.vMeth1(n, instanceCount, 171);
            if (bl) break;
            int n5 = n - 1;
            iArrFld[n5] = iArrFld[n5] << n2;
            l = 1L;
            do {
                if (bl) {
                    fFld = n2;
                    n4 = -95;
                    continue;
                }
                if (bl) {
                    instanceCount = (long)fFld;
                    n3 += (int)(l | (long)n);
                    n2 = (int)((long)n2 + (54501L + l * l));
                    n3 ^= n3;
                    continue;
                }
                n3 = (int)fFld;
                n3 *= n;
            } while (++l < 9L);
        }
        vMeth_check_sum += (long)(n + n2 + (bl ? 1 : 0)) + l + (long)n4 + (long)n3;
    }

    public void mainTest(String[] stringArray) {
        int n = 6;
        int n2 = -45155;
        int n3 = 238;
        int n4 = -109;
        int n5 = -34353;
        int n6 = 41232;
        long l = 76L;
        long l2 = -9L;
        double d = 0.111945;
        boolean bl = true;
        boolean[] blArray = new boolean[400];
        byte by = 50;
        FuzzerUtils.init(blArray, true);
        this.vMeth();
        n = 1;
        while (++n < 213) {
            for (l = 2L; l < 118L; ++l) {
                fFld += (float)(l * l);
                n3 -= n3;
                d = n2;
                n3 *= n;
                Test.iArrFld[(int)(l + 1L)] = 8;
                switch ((int)(l % 1L * 5L + 19L)) {
                    case 24: {
                        instanceCount += l * l;
                        n4 = 1;
                        do {
                            blArray[n4 + 1] = true;
                            int n7 = n + 1;
                            iArrFld[n7] = iArrFld[n7] * (n2 &= n4);
                            instanceCount += (long)(5 + n4 * n4);
                            if (!bl) continue;
                        } while (++n4 < 2);
                        n3 *= by;
                        for (n5 = 1; n5 < 2; ++n5) {
                            n3 = (int)l;
                            instanceCount += l;
                            n3 = (int)(d -= (double)fFld);
                            int n8 = n - 1;
                            lArrFld[n8] = lArrFld[n8] / (long)(n5 | 1);
                            n6 = n4;
                            int n9 = n - 1;
                            iArrFld[n9] = iArrFld[n9] + (int)instanceCount;
                            instanceCount += (long)n5 - l2;
                        }
                        break;
                    }
                }
                n2 += (int)((float)(l * (long)this.sFld + (long)n5) - fFld);
                int n10 = (int)(l + 1L);
                iArrFld[n10] = iArrFld[n10] + n5;
                n6 |= 0x54;
            }
        }
        FuzzerUtils.out.println("i16 l2 i17 = " + n + "," + l + "," + n2);
        FuzzerUtils.out.println("i18 d2 i19 = " + n3 + "," + Double.doubleToLongBits(d) + "," + n4);
        FuzzerUtils.out.println("b3 by1 i20 = " + (bl ? 1 : 0) + "," + by + "," + n5);
        FuzzerUtils.out.println("i21 l3 bArr = " + n6 + "," + l2 + "," + FuzzerUtils.checkSum(blArray));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld sFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + this.sFld);
        FuzzerUtils.out.println("Test.iArrFld Test.lArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 0);
        FuzzerUtils.init(lArrFld, 43260L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}


/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 91L;
    public int iFld = -42891;
    public static int iFld1 = 6;
    public int[][] iArrFld = new int[400][400];
    public static int[] iArrFld1 = new int[400];
    public static long sMeth_check_sum;
    public static long bMeth_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth(long l, int n) {
        int n2 = 4252;
        int n3 = -118;
        int n4 = -31770;
        int n5 = 8;
        int n6 = -173;
        int n7 = -8;
        int n8 = 24592;
        int n9 = 45;
        float f = 1.391f;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -4328577423159867848L);
        for (n2 = 20; n2 < 339; ++n2) {
            for (n4 = 1; n4 < 5; ++n4) {
                instanceCount = n9;
                n6 = 1;
                do {
                    n = n2;
                    n5 -= 51969;
                    iFld1 += (int)f;
                    int n10 = n6 + 1;
                    iArrFld1[n10] = iArrFld1[n10] - (int)f;
                    int n11 = n2;
                    lArray[n11] = lArray[n11] << n2;
                } while (++n6 < 2);
                iFld1 -= n4;
            }
            n5 += (int)l;
            instanceCount = n2;
            for (n7 = n2; n7 < 5; ++n7) {
                instanceCount -= 10L;
            }
            n >>= n3;
        }
        vMeth_check_sum += l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n9 + (long)n6 + (long)Float.floatToIntBits(f) + (long)n7 + (long)n8 + FuzzerUtils.checkSum(lArray);
    }

    public static boolean bMeth() {
        int n = -166;
        int n2 = -49218;
        int n3 = -32931;
        boolean bl = false;
        double d = 39.101127;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -3132435109L);
        for (n = 15; n < 327; ++n) {
            Test.vMeth(instanceCount, n2 += n * n);
        }
        long l = (long)(n + n2 + n3 + (bl ? 1 : 0)) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(lArray);
        bMeth_check_sum += l;
        return l % 2L > 0L;
    }

    public static short sMeth(float f) {
        double d = 0.70576;
        double d2 = -1.110895;
        int n = 3;
        int n2 = -28117;
        int n3 = 2619;
        int n4 = 14;
        int n5 = 34251;
        int n6 = -14;
        int[] nArray = new int[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, -10);
        FuzzerUtils.init(lArray, -14241L);
        int n7 = (iFld1 >>> 1) % 400;
        nArray[n7] = nArray[n7] - -iFld1-- * ++iFld1;
        int n8 = (iFld1 >>> 1) % 400;
        nArray[n8] = nArray[n8] - (int)lArray[(iFld1 >>> 1) % 400];
        nArray[0] = (int)d;
        iFld1 = -nArray[0];
        n = 1;
        while (++n < 395) {
            for (d2 = 1.0; 4.0 > d2; d2 += 3.0) {
                for (n3 = 1; n3 < 4; ++n3) {
                    instanceCount += (long)((float)nArray[(int)(d2 + 1.0)] - ((float)nArray[n3 + 1] + (float)n4 * f));
                }
                if (Test.bMeth()) continue;
                for (n5 = 1; n5 < 4; ++n5) {
                    instanceCount += (long)(n5 * n5);
                    lArray[n5] = n2;
                    instanceCount += (long)(n5 | n3);
                    n2 *= iFld1;
                    try {
                        n2 = n6 % n2;
                        n6 = n5 / iArrFld1[n5 + 1];
                        nArray[(int)(d2 + 1.0)] = n2 / n3;
                    } catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    iFld1 += n2;
                }
            }
        }
        long l = (long)Float.floatToIntBits(f) + Double.doubleToLongBits(d) + (long)n + Double.doubleToLongBits(d2) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
        sMeth_check_sum += l;
        return (short)l;
    }

    public void mainTest(String[] stringArray) {
        byte by = -68;
        double d = -1.55243;
        float f = 1.679f;
        float[] fArray = new float[400];
        float[] fArray2 = new float[400];
        int n = -206;
        int n2 = 10;
        int n3 = 3;
        int n4 = 3;
        int n5 = -82;
        int n6 = -9;
        int n7 = -11857;
        int[] nArray = new int[400];
        short s = -8832;
        short[] sArray = new short[400];
        boolean bl = false;
        long[] lArray = new long[400];
        FuzzerUtils.init(fArray, -97.616f);
        FuzzerUtils.init(sArray, (short)11488);
        FuzzerUtils.init(lArray, 865257099685413269L);
        FuzzerUtils.init(fArray2, -50.733f);
        FuzzerUtils.init(nArray, -69);
        double d2 = d;
        d = d2 - 1.0;
        instanceCount -= (long)((double)((long)by + instanceCount) + 62360.0 * d2 + (double)(this.iFld / -32039 + 175 * (this.iFld % (this.iFld | 1))));
        this.iArrFld = this.iArrFld = (this.iArrFld = (this.iArrFld = this.iArrFld));
        Test.sMeth(f);
        fArray[(this.iFld >>> 1) % 400] = 122.0f;
        for (n = 221; n > 11; n -= 3) {
            this.iFld = (int)instanceCount;
            s = (short)(s >>> (short)instanceCount);
            n2 *= 0;
            sArray[n] = (short)iFld1;
            n2 <<= this.iFld;
            d += 40.0;
            try {
                n2 /= n2;
                Test.iArrFld1[n] = iArrFld1[n] / 4714;
                n2 = this.iArrFld[n + 1][n] / this.iFld;
                continue;
            } catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
        }
        for (n3 = 5; n3 < 332; ++n3) {
            if (bl) continue;
            n2 -= n4;
            f -= (float)by;
            n5 = 1;
            do {
                int[] nArray2 = this.iArrFld[n3 - 1];
                int n8 = n3 + 1;
                nArray2[n8] = nArray2[n8] << (int)instanceCount;
                switch (n3 % 1 * 5 + 125) {
                    case 127: {
                        n4 >>= n5;
                        int n9 = n5 - 1;
                        iArrFld1[n9] = iArrFld1[n9] % 71;
                        n4 -= (int)f;
                    }
                }
                int n10 = n5 - 1;
                lArray[n10] = lArray[n10] / ((long)d | 1L);
                this.iFld += 26 + n5 * n5;
                if (bl) {
                    for (n6 = 1; n3 < n6; --n6) {
                        fArray2 = fArray;
                        n4 += n6 * n3 + n - iFld1;
                        if (!bl) continue;
                    }
                } else {
                    int n11 = n5 - 1;
                    nArray[n11] = nArray[n11] % (n4 | 1);
                }
            } while (++n5 < 77);
        }
        FuzzerUtils.out.println("by d f3 = " + by + "," + Double.doubleToLongBits(d) + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i17 i18 s = " + n + "," + n2 + "," + s);
        FuzzerUtils.out.println("i19 i20 b1 = " + n3 + "," + n4 + "," + (bl ? 1 : 0));
        FuzzerUtils.out.println("i21 i22 i23 = " + n5 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("fArr sArr lArr3 = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + "," + FuzzerUtils.checkSum(sArray) + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("fArr1 iArr1 = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray2)) + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.iFld1 = " + instanceCount + "," + this.iFld + "," + iFld1);
        FuzzerUtils.out.println("iArrFld Test.iArrFld1 = " + FuzzerUtils.checkSum(this.iArrFld) + "," + FuzzerUtils.checkSum(iArrFld1));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
        FuzzerUtils.out.println("sMeth_check_sum: " + sMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld1, 197);
        sMeth_check_sum = 0L;
        bMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}


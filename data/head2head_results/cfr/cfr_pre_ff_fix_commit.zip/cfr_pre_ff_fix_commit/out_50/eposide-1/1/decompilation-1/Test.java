/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -3067793559548521372L;
    public static double dFld = 27.5564;
    public static float fFld = -75.458f;
    public static boolean bFld = false;
    public static short sFld = (short)-18063;
    public int[] iArrFld = new int[400];
    public static long[][] lArrFld = new long[400][400];
    public float[] fArrFld = new float[400];
    public double[] dArrFld = new double[400];
    public static long vMeth_check_sum;
    public static long lMeth_check_sum;
    public static long vMeth1_check_sum;

    public void vMeth1(int n, int n2, int n3) {
        int n4 = -230;
        int n5 = 162;
        int n6 = 213;
        int n7 = -34548;
        int n8 = -11;
        int n9 = 5;
        int n10 = 25;
        int n11 = -1329;
        int n12 = 51;
        for (n4 = 223; 5 < n4; --n4) {
            n <<= n11;
            this.iArrFld[n4 + 1] = -67;
            fFld -= fFld;
        }
        for (n6 = 8; 192 > n6; ++n6) {
            ++n3;
            for (n8 = n6; n8 < 9; ++n8) {
                if (n8 != 0) {
                    vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5 + n11 + n6 + n7 + n8 + n9 + n10 + n12);
                    return;
                }
                n3 += 7042 + n8 * n8;
                n10 = 1;
                do {
                    n12 = (byte)(n12 | (byte)n2);
                    n9 *= 3532;
                    n11 = (short)(n11 >> -4);
                    this.iArrFld[n8 - 1] = n9 = n2;
                } while (++n10 < 1);
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5 + n11 + n6 + n7 + n8 + n9 + n10 + n12);
    }

    public long lMeth(double d, long l, int n) {
        long l2 = 198L;
        int n2 = 53694;
        int n3 = 20362;
        int n4 = 4;
        int n5 = 12;
        int n6 = -1236;
        this.vMeth1(n, n, n);
        for (l2 = 17L; l2 < 337L; ++l2) {
            instanceCount = n2;
            fFld += 2.04285555E9f;
            n3 = 1;
            if (n3 >= 5) continue;
        }
        long l3 = Double.doubleToLongBits(d) + l + (long)n + l2 + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6;
        lMeth_check_sum += l3;
        return l3;
    }

    public void vMeth(int n, int n2) {
        int n3 = 39504;
        int n4 = -5967;
        int n5 = 245;
        int n6 = 164;
        float f = 108.621f;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, 84.175f);
        n3 = 300;
        while (--n3 > 0) {
            f *= (float)n2;
            dFld += (double)((long)n2 + (instanceCount * (long)n3 - this.lMeth(dFld, instanceCount, n2)));
        }
        for (n4 = 2; n4 < 137; ++n4) {
            n2 = 8368;
            instanceCount -= (long)n5;
            instanceCount = n2;
            n5 *= n4;
        }
        n6 = 1;
        while (++n6 < 191) {
            int n7 = n6;
            fArray[n7] = fArray[n7] - (float)n;
            n2 = n4;
            if (bFld) {
                try {
                    n = this.iArrFld[n6] / 145;
                    n5 = this.iArrFld[n6] / n2;
                    n = n6 % 1567103587;
                } catch (ArithmeticException arithmeticException) {}
                continue;
            }
            f = sFld;
            this.iArrFld[n6] = n6;
        }
        vMeth_check_sum += (long)(n + n2 + n3 + Float.floatToIntBits(f) + n4 + n5 + n6) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public void mainTest(String[] stringArray) {
        int n = -114;
        int n2 = 39919;
        int n3 = -20009;
        int n4 = -11;
        int n5 = -64767;
        int n6 = -46956;
        int n7 = -9201;
        float f = 36.373f;
        float f2 = 0.16f;
        byte by = -74;
        short[] sArray = new short[400];
        FuzzerUtils.init(sArray, (short)-31177);
        this.vMeth(6, n);
        dFld *= (double)(--instanceCount);
        this.iArrFld[362] = -188;
        for (n2 = 17; n2 < 294; ++n2) {
            n3 = n;
            if (!bFld) continue;
            long[] lArray = lArrFld[n2 - 1];
            int n8 = n2;
            lArray[n8] = lArray[n8] - 0L;
        }
        FuzzerUtils.out.println("i22 i23 i24 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("f1 i25 i26 = " + Float.floatToIntBits(f) + "," + n4 + "," + n5);
        FuzzerUtils.out.println("f2 i27 i28 = " + Float.floatToIntBits(f2) + "," + n6 + "," + n7);
        FuzzerUtils.out.println("by1 sArr = " + by + "," + FuzzerUtils.checkSum(sArray));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.fFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.bFld Test.sFld iArrFld = " + (bFld ? 1 : 0) + "," + sFld + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("Test.lArrFld fArrFld dArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, -5262046258807420993L);
        vMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}


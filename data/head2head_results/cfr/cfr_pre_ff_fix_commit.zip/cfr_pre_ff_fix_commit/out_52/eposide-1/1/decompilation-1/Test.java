/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = 42842L;
    public float fFld = 66.108f;
    public boolean bFld = true;
    public static byte byFld = (byte)-20;
    public static double dFld = 0.127902;
    public int[] iArrFld = new int[400];
    public boolean[] bArrFld = new boolean[400];
    public static double[] dArrFld = new double[400];
    public static long fMeth_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth(int n) {
        vMeth_check_sum += (long)n;
    }

    public int iMeth(int n, int n2) {
        int n3 = 1;
        int n4 = -29557;
        int n5 = -123;
        int n6 = 51069;
        boolean bl = true;
        for (n3 = 5; n3 < 246; ++n3) {
            n4 += 12;
            Test.vMeth(n);
            if (bl) continue;
            n4 = 22;
        }
        n2 = -158;
        this.fFld *= (float)n3;
        instanceCount -= -20L;
        this.iArrFld[(n2 >>> 1) % 400] = n4;
        for (n5 = 7; n5 < 128; ++n5) {
            if (bl) continue;
        }
        n6 += n2;
        n2 -= 128950886;
        n2 = n6;
        long l = n + n2 + n3 + n4 + (bl ? 1 : 0) + n5 + n6;
        iMeth_check_sum += l;
        return (int)l;
    }

    public float fMeth(int n, int n2, int n3) {
        int n4 = -10;
        int n5 = 202;
        int n6 = -47065;
        int n7 = 5;
        int n8 = 73;
        int n9 = -18;
        int n10 = -5;
        int n11 = 6346;
        int n12 = 10;
        int n13 = -19257;
        int n14 = 86;
        short[] sArray = new short[400];
        FuzzerUtils.init(sArray, (short)-2323);
        this.fFld = -this.iMeth(9, n2);
        this.bFld = this.bFld;
        for (n4 = 4; n4 < 251; ++n4) {
            for (n6 = 1; 7 > n6; ++n6) {
                for (n8 = 1; 2 > n8; ++n8) {
                    n += n8 * n8;
                    int n15 = n4;
                    this.iArrFld[n15] = this.iArrFld[n15] >> n2;
                }
                n -= n3;
                for (n10 = n6; n10 < 2; ++n10) {
                    this.fFld += (float)(n10 * n6 + byFld - n);
                }
                int n16 = n4;
                sArray[n16] = (short)(sArray[n16] + (short)dFld);
                for (n12 = n6; 2 > n12; ++n12) {
                    dFld -= (double)n5;
                    n2 = n6;
                    instanceCount += (long)(n12 * n14 + n12 - n5);
                }
            }
        }
        long l = (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + n10 + n11 + n12 + n13 + n14) + FuzzerUtils.checkSum(sArray);
        fMeth_check_sum += l;
        return l;
    }

    public void mainTest(String[] stringArray) {
        int n = -8;
        int n2 = 25865;
        int n3 = 4;
        int n4 = 4;
        int n5 = 11;
        int n6 = -64968;
        int n7 = 10;
        int n8 = -31785;
        int n9 = 178;
        double d = -123.20643;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, -85.794f);
        int n10 = ((n &= (int)(--instanceCount)) >>> 1) % 400;
        int n11 = this.iArrFld[n10];
        this.iArrFld[n10] = n11 + 1;
        this.fMeth(-247, n -= n11, n);
        d = 1.0;
        do {
            int n12 = (int)(d - 1.0);
            this.iArrFld[n12] = this.iArrFld[n12] * (int)instanceCount;
            for (n2 = 7; n2 < 122; ++n2) {
                fArray = FuzzerUtils.float1array(400, -1.258f);
                instanceCount = n3;
            }
            for (n4 = 122; n4 > 7; n4 -= 2) {
                n3 += n4;
                instanceCount += -2L;
            }
            this.bArrFld[(int)d] = this.bFld;
            if (this.bFld) break;
            n3 %= n3 | 1;
            instanceCount += (long)d;
        } while ((d += 1.0) < 206.0);
        block12: for (n6 = 3; n6 < 308; ++n6) {
            n5 &= n5;
            switch (n6 % 5 + 105) {
                case 105: {
                    byFld = (byte)n3;
                    try {
                        n5 = 147 % n4;
                        n7 = this.iArrFld[n6 - 1] % -131;
                        this.iArrFld[n6 + 1] = n4 % this.iArrFld[n6 + 1];
                    } catch (ArithmeticException arithmeticException) {}
                    continue block12;
                }
                case 106: {
                    this.fFld -= (float)d;
                    instanceCount += (long)n5;
                    continue block12;
                }
                case 107: {
                    instanceCount <<= -27645;
                    n &= 0xFFFFFF81;
                    instanceCount >>= n6;
                    continue block12;
                }
                case 108: {
                    n += -14 + n6 * n6;
                    for (n8 = 4; n8 < 82; ++n8) {
                        this.fFld += (float)(-31509 + n8 * n8);
                        instanceCount += -7321278512215405763L + (long)(n8 * n8);
                    }
                }
                case 109: {
                    dFld = n8;
                    continue block12;
                }
                default: {
                    n = 8;
                }
            }
        }
        FuzzerUtils.out.println("i d i22 = " + n + "," + Double.doubleToLongBits(d) + "," + n2);
        FuzzerUtils.out.println("i23 i24 i25 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i26 i27 i28 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("i29 fArr = " + n9 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("Test.instanceCount fFld bFld = " + instanceCount + "," + Float.floatToIntBits(this.fFld) + "," + (this.bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.byFld Test.dFld iArrFld = " + byFld + "," + Double.doubleToLongBits(dFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("bArrFld Test.dArrFld = " + FuzzerUtils.checkSum(this.bArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(dArrFld, 65.106736);
        fMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}


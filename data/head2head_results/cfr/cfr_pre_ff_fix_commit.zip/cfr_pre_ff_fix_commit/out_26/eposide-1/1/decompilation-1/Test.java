/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -42L;
    public static float fFld = 81.723f;
    public static byte byFld = (byte)-79;
    public int iFld = 5;
    public static long[] lArrFld = new long[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2(double d) {
        double d2 = 2.11049;
        int n = 42534;
        int n2 = 112;
        int n3 = -6018;
        int n4 = 187;
        int n5 = -45149;
        int n6 = -213;
        int[] nArray = new int[400];
        boolean bl = true;
        boolean[] blArray = new boolean[400];
        float f = 0.377f;
        int n7 = -31264;
        FuzzerUtils.init(nArray, 31230);
        FuzzerUtils.init(blArray, false);
        for (int n8 : nArray) {
            for (d2 = 1.0; d2 < 4.0; d2 += 1.0) {
                n += (int)(d2 * d2);
            }
            blArray[(n >>> 1) % 400] = bl;
            for (f = 1.0f; f < 4.0f; f += 1.0f) {
                n2 ^= n8;
            }
            d -= (double)n;
            for (n3 = 1; n3 < 4; ++n3) {
                for (n5 = n3; n5 < 2; ++n5) {
                    n7 = (short)d;
                    n2 += (int)(121.102f + (float)(n5 * n5));
                    n2 = n3;
                    instanceCount = 4188460544L;
                    n7 = -12;
                    if (n8 == 0) continue;
                    vMeth2_check_sum += Double.doubleToLongBits(d) + Double.doubleToLongBits(d2) + (long)n + (long)(bl ? 1 : 0) + (long)Float.floatToIntBits(f) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(blArray);
                    return;
                }
            }
        }
        vMeth2_check_sum += Double.doubleToLongBits(d) + Double.doubleToLongBits(d2) + (long)n + (long)(bl ? 1 : 0) + (long)Float.floatToIntBits(f) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(blArray);
    }

    public static void vMeth1(int n, long l) {
        double d = 121.59527;
        double d2 = 1.115926;
        int n2 = 88;
        int n3 = 17797;
        int n4 = 120;
        int n5 = 51739;
        int n6 = 5236;
        int[][] nArray = new int[400][400];
        int n7 = -32345;
        FuzzerUtils.init(nArray, 185);
        Test.vMeth2(d);
        int n8 = (n >>> 1) % 400;
        lArrFld[n8] = lArrFld[n8] ^ (long)n;
        for (d2 = 2.0; d2 < 280.0; d2 += 1.0) {
            n2 = (int)l;
        }
        int n9 = (n2 >>> 1) % 400;
        lArrFld[n9] = lArrFld[n9] * (long)n;
        n7 = (short)(--n2);
        n2 |= n2;
        n = -13;
        for (n3 = 3; n3 < 197; ++n3) {
            for (n5 = 1; n5 < 8; ++n5) {
                n = n3;
                n6 *= 6;
                int[] nArray2 = nArray[n5];
                int n10 = n3 - 1;
                nArray2[n10] = nArray2[n10] ^ n;
            }
        }
        vMeth1_check_sum += (long)n + l + Double.doubleToLongBits(d) + Double.doubleToLongBits(d2) + (long)n2 + (long)n7 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth(int n) {
        int n2 = 53;
        int n3 = -12;
        int n4 = -30536;
        int n5 = -24;
        int n6 = 8;
        int n7 = 5;
        int[] nArray = new int[400];
        boolean bl = false;
        FuzzerUtils.init(nArray, 221);
        Test.vMeth1(n, instanceCount);
        for (n2 = 9; n2 < 358; ++n2) {
            instanceCount = 1267161461L;
            instanceCount += (long)n;
            for (n4 = 1; 5 > n4; ++n4) {
                int n8 = n2;
                nArray[n8] = nArray[n8] + n2;
                n = (int)fFld;
                n3 = (int)((long)n3 + ((long)n4 * instanceCount + instanceCount - (long)n4));
                n += n4 + byFld;
                instanceCount += (long)(n4 * n2);
                for (n6 = 1; n6 < 2; ++n6) {
                    n7 *= -19;
                    n3 = (int)((long)n3 + ((long)n6 * instanceCount + (long)byFld - (long)n2));
                    n = n2;
                    if (!bl) continue;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + (bl ? 1 : 0)) + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 17;
        int n2 = -35532;
        int n3 = 5;
        int n4 = -11;
        int n5 = -228;
        int n6 = 1;
        int n7 = -12;
        int n8 = -11732;
        int n9 = 4753;
        int n10 = 9;
        int n11 = 656;
        int n12 = -19;
        int n13 = 4562;
        int n14 = 11;
        int[] nArray = new int[400];
        boolean bl = true;
        double d = -2.127131;
        short s = -28730;
        FuzzerUtils.init(nArray, 14);
        Test.vMeth(this.iFld);
        n = 1;
        while (++n < 271 && !bl) {
        }
        n2 = 1;
        do {
            this.iFld = (int)instanceCount;
            for (n3 = 5; n3 < 122; ++n3) {
                instanceCount = (long)d;
            }
        } while (++n2 < 206);
        for (n5 = 4; n5 < 398; ++n5) {
            this.iFld >>= (int)instanceCount;
            if (bl) break;
            fFld += (float)instanceCount;
            this.iFld = (int)((long)this.iFld + ((long)(n5 * n3 + n3) - instanceCount));
            for (n7 = 64; n7 > 3; --n7) {
                for (n9 = 1; n9 < 2; ++n9) {
                    fFld -= (float)n8;
                }
                this.iFld = (int)instanceCount;
                this.iFld = n3;
                instanceCount -= -17949L;
                for (n11 = 1; n11 < 2; ++n11) {
                    nArray[n11 - 1] = n7;
                }
                n4 += 49745 + n7 * n7;
                instanceCount = n5;
            }
            n4 -= n10;
            for (n13 = 64; n13 > 3; --n13) {
                n10 = n7;
                fFld += (float)n13;
                nArray[n5 + 1] = (int)instanceCount;
            }
            instanceCount <<= s;
        }
        FuzzerUtils.out.println("i20 b2 i21 = " + n + "," + (bl ? 1 : 0) + "," + n2);
        FuzzerUtils.out.println("i22 i23 d4 = " + n3 + "," + n4 + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("i24 i25 i26 = " + n5 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("i27 i28 i29 = " + n8 + "," + n9 + "," + n10);
        FuzzerUtils.out.println("i30 i31 i32 = " + n11 + "," + n12 + "," + n13);
        FuzzerUtils.out.println("i33 s2 iArr3 = " + n14 + "," + s + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.byFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + byFld);
        FuzzerUtils.out.println("iFld Test.lArrFld = " + this.iFld + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, -120L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}


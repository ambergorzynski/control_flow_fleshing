/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 4L;
    public int iFld = 12604;
    public static volatile boolean bFld = true;
    public static volatile float fFld = 22.272f;
    public short sFld = (short)26090;
    public byte[] byArrFld = new byte[400];
    public static long[] lArrFld = new long[400];
    public static volatile double[] dArrFld = new double[400];
    public volatile short[] sArrFld = new short[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth(short s, float f) {
        int n = 97;
        long l = s + Float.floatToIntBits(f) + (n += 43017);
        iMeth_check_sum += l;
        return (int)l;
    }

    public static void vMeth1(short s) {
        int n = 167;
        int n2 = 0;
        int n3 = 9;
        int n4 = -3;
        int n5 = 13;
        int n6 = 45091;
        int n7 = 14;
        float f = 54.1004f;
        for (long l : lArrFld) {
            n = 1;
            do {
                n2 = -n7 - Short.reverseBytes((short)((long)n + l));
                float f2 = f;
                f = f2 - 1.0f;
                n2 += (int)(f2 - (float)n + (float)(instanceCount >>= Test.iMeth(s, 1.372f)));
            } while (++n < 4);
            n2 *= -96;
        }
        n3 = 1;
        while (++n3 < 268) {
            n2 += n3 | n;
            if (bFld) continue;
            n2 = n4;
            s = (short)(instanceCount += (long)f);
            for (n5 = 1; n5 < 6; ++n5) {
                n6 = 27597;
                int n8 = n5 + 1;
                dArrFld[n8] = dArrFld[n8] - 7.0;
            }
        }
        vMeth1_check_sum += (long)(s + n + n2 + n7 + Float.floatToIntBits(f) + n3 + n4 + n5 + n6);
    }

    public static void vMeth(long l, int n) {
        short s = 783;
        int n2 = -67;
        int n3 = -182;
        int n4 = 0;
        int n5 = -13;
        int n6 = -95;
        int n7 = 43342;
        int n8 = -33829;
        int n9 = 32;
        int[] nArray = new int[400];
        float f = 1.5f;
        FuzzerUtils.init(nArray, 117);
        bFld = true;
        Test.vMeth1(s);
        n2 = 4;
        if (n2 < 123) {
            f += (float)n2;
        }
        vMeth_check_sum += l + (long)n + (long)s + (long)n2 + (long)n3 + (long)Float.floatToIntBits(f) + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)n9 + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 28081;
        int n2 = -1;
        int n3 = 194;
        int n4 = -114;
        int n5 = -249;
        int n6 = -4;
        int[] nArray = new int[400];
        double d = 1.482;
        byte by = -82;
        float[] fArray = new float[400];
        FuzzerUtils.init(nArray, 42);
        FuzzerUtils.init(fArray, 2.2f);
        int n7 = (this.iFld >>> 1) % 400;
        this.byArrFld[n7] = (byte)(this.byArrFld[n7] ^ (byte)(++this.iFld * (this.iFld + -21630 - this.iFld)));
        block20: for (int n8 : nArray) {
            Test.vMeth(-4L, this.iFld);
            switch ((n8 >>> 1) % 6 + 45) {
                case 45: 
                case 46: {
                    this.iFld -= n8;
                    this.iFld = this.iFld;
                }
                case 47: {
                    this.byArrFld[4] = (byte)(this.byArrFld[4] - 11);
                    continue block20;
                }
                case 48: {
                    this.iFld = this.iFld;
                    Test.dArrFld[(this.iFld >>> 1) % 400] = this.iFld;
                    Test.lArrFld[331] = n8;
                    block21: for (n = 1; n < 63; ++n) {
                        n2 += n;
                        fArray[n] = n8;
                        nArray[n] = -11;
                        switch (n % 9 + 78) {
                            case 78: {
                                n2 = (int)instanceCount;
                                instanceCount += (long)d;
                                for (n3 = n; n3 < 2; ++n3) {
                                    instanceCount = (long)((float)instanceCount + ((float)(n3 * this.iFld) + fFld - (float)n8));
                                }
                                Test.lArrFld[n + 1] = 9873L;
                                continue block21;
                            }
                            case 79: {
                                try {
                                    n4 = 33326 % n3;
                                    n4 = n % 119;
                                    this.iFld = n % 141;
                                } catch (ArithmeticException arithmeticException) {
                                    // empty catch block
                                }
                                n8 |= 0xFFFFFFEB;
                            }
                            case 80: {
                                for (n5 = 1; n5 < 2; ++n5) {
                                    this.iFld -= n8;
                                    n8 += (int)(fFld += (float)instanceCount);
                                }
                                n8 += n;
                                n8 = this.iFld;
                                continue block21;
                            }
                            case 81: {
                                n4 >>= -8;
                                continue block21;
                            }
                            case 82: {
                                int n9 = n - 1;
                                nArray[n9] = nArray[n9] + (int)instanceCount;
                            }
                            case 83: {
                                int n10 = n;
                                nArray[n10] = nArray[n10] + n3;
                                continue block21;
                            }
                            case 84: {
                                instanceCount += (long)n * instanceCount + (long)by - (long)n8;
                                continue block21;
                            }
                            case 85: {
                                fFld -= 24055.0f;
                                continue block21;
                            }
                            case 86: {
                                n6 = this.iFld;
                                continue block21;
                            }
                            default: {
                                n8 = n6;
                            }
                        }
                    }
                }
                case 49: {
                    this.sArrFld[41] = (short)(this.sArrFld[41] + (short)instanceCount);
                    continue block20;
                }
                case 50: {
                    this.iFld -= this.sFld;
                }
                default: {
                    nArray[388] = nArray[388] - (int)fFld;
                }
            }
        }
        FuzzerUtils.out.println("i17 i18 d = " + n + "," + n2 + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("i19 i20 i21 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i22 by1 iArr = " + n6 + "," + by + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("fArr = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.bFld = " + instanceCount + "," + this.iFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.fFld sFld byArrFld = " + Float.floatToIntBits(fFld) + "," + this.sFld + "," + FuzzerUtils.checkSum(this.byArrFld));
        FuzzerUtils.out.println("Test.lArrFld Test.dArrFld sArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + FuzzerUtils.checkSum(this.sArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, -26L);
        FuzzerUtils.init(dArrFld, 56.101474);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}


/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -193L;
    public byte byFld = (byte)-118;
    public static int[] iArrFld = new int[400];
    public static long[] lArrFld = new long[400];
    public static long lMeth_check_sum;
    public static long vMeth_check_sum;
    public static long dMeth_check_sum;

    public static void vMeth(int n) {
        Test.iArrFld[(n >>> 1) % 400] = n;
        vMeth_check_sum += (long)n;
    }

    public static double dMeth(int n, long l) {
        int n2 = -191;
        int n3 = -224;
        Test.vMeth(n);
        n2 = 7;
        while (135 > n2) {
            n >>= n;
            int n4 = n2++;
            iArrFld[n4] = iArrFld[n4] + n;
        }
        long l2 = (long)n + l + (long)n2 + (long)n3;
        dMeth_check_sum += l2;
        return l2;
    }

    public static long lMeth(long l, double d) {
        int n = 0;
        int n2 = 224;
        int n3 = -45649;
        int n4 = 27374;
        int n5 = 5;
        int n6 = -136;
        int n7 = 76;
        float f = 98.695f;
        boolean bl = false;
        int n8 = 19779;
        for (n = 3; 238 > n; ++n) {
            int n9 = n + 1;
            int n10 = n;
            int n11 = iArrFld[n10] - 1;
            iArrFld[n10] = n11;
            lArrFld[n9] = lArrFld[n9] << (int)((long)(n11 * n) + ((long)(n2 + -5) - instanceCount));
            n7 = (byte)(n7 + (byte)(n * n));
            for (n3 = n; 7 > n3; ++n3) {
                f = n2 >>= (int)instanceCount;
                Test.vMeth(n4 += (int)Test.dMeth(n, instanceCount));
                for (n5 = n; n5 < 1; ++n5) {
                    f *= (float)n3;
                    if (n4 != 0) {
                        // empty if block
                    }
                    if (bl) {
                        l += (long)f;
                        n4 <<= n4;
                        l >>>= n6;
                        continue;
                    }
                    if (bl) {
                        instanceCount *= (long)n4;
                        n7 = (byte)(n7 >>> n7);
                        continue;
                    }
                    l = bl ? 1L : (long)n8;
                }
            }
        }
        long l2 = l + Double.doubleToLongBits(d) + (long)n + (long)n2 + (long)n7 + (long)n3 + (long)n4 + (long)Float.floatToIntBits(f) + (long)n5 + (long)n6 + (long)(bl ? 1 : 0) + (long)n8;
        lMeth_check_sum += l2;
        return l2;
    }

    public void mainTest(String[] stringArray) {
        int n = -46506;
        int n2 = -69;
        int n3 = -162;
        int n4 = 55;
        int n5 = 62539;
        int n6 = -4;
        int n7 = 13;
        float f = -2.373f;
        float f2 = 17.356f;
        double d = 94.101418;
        byte[] byArray = new byte[400];
        FuzzerUtils.init(byArray, (byte)58);
        for (int n8 : iArrFld) {
            n8 = (int)((long)Integer.reverseBytes(Math.abs(-45)) - Test.lMeth(-3L, -73.61892));
            byArray[((n8 >>= -31) >>> 1) % 400] = (byte)instanceCount;
        }
        lArrFld[2] = lArrFld[2] + 92L;
        for (n = 9; n < 163; ++n) {
            for (n3 = 3; n3 < 163; ++n3) {
                n4 <<= (int)instanceCount;
                n2 += n3;
            }
            for (n5 = 8; 163 > n5; ++n5) {
                n6 >>>= (int)instanceCount;
                block15: for (f = 1.0f; f < 2.0f; f += 1.0f) {
                    n4 = (int)instanceCount;
                    switch (n5 % 6 + 80) {
                        case 80: {
                            Test.lArrFld[(n5 >>> 1) % 400] = n3;
                            n2 += (int)(f * f);
                            continue block15;
                        }
                        case 81: {
                            instanceCount -= (long)n6;
                            switch (n5 % 1 + 118) {
                                case 118: {
                                    n6 = (int)instanceCount;
                                    n6 = (int)f;
                                    n7 += (int)(f * (float)n5 + (float)n2 - (float)n4);
                                }
                            }
                            int n9 = n;
                            iArrFld[n9] = iArrFld[n9] + (int)instanceCount;
                            n6 += (int)instanceCount;
                            continue block15;
                        }
                        case 82: {
                            this.byFld = (byte)(this.byFld + (byte)((long)f | (long)n6));
                        }
                        case 83: {
                            f2 += f;
                        }
                        case 84: {
                            n7 = 38931;
                            d = 15008.0;
                            continue block15;
                        }
                        case 85: {
                            n7 = (int)instanceCount;
                            n2 = n6;
                            continue block15;
                        }
                        default: {
                            f2 -= (float)d;
                        }
                    }
                }
            }
        }
        FuzzerUtils.out.println("i11 i12 i13 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i14 i15 i16 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("f1 i17 f2 = " + Float.floatToIntBits(f) + "," + n7 + "," + Float.floatToIntBits(f2));
        FuzzerUtils.out.println("d1 byArr = " + Double.doubleToLongBits(d) + "," + FuzzerUtils.checkSum(byArray));
        FuzzerUtils.out.println("Test.instanceCount byFld Test.iArrFld = " + instanceCount + "," + this.byFld + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.lArrFld = " + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -8);
        FuzzerUtils.init(lArrFld, 64419L);
        lMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        dMeth_check_sum = 0L;
    }
}


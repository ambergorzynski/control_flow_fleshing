/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 0L;
    public volatile int iFld = -14;
    public static volatile boolean bFld = false;
    public double dFld = 79.43243;
    public float fFld = 110.945f;
    public long[] lArrFld = new long[400];
    public volatile short[][] sArrFld = new short[400][400];
    public static long lMeth_check_sum = 0L;
    public static long vMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;

    public static void vMeth1() {
        int n = -235;
        int[][] nArray = new int[400][400];
        float f = 0.8f;
        FuzzerUtils.init(nArray, 248);
        instanceCount *= instanceCount;
        nArray[(n >>> 1) % 400][(n >>> 1) % 400] = 31168;
        vMeth1_check_sum += (long)(n + Float.floatToIntBits(f *= 2872.0f)) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth(int n, int n2, double d) {
        float f = 2.683f;
        long l = 3L;
        int n3 = 83;
        int n4 = 9;
        int n5 = 92;
        int n6 = 190;
        int n7 = -20568;
        int[] nArray = new int[400];
        int n8 = -2163;
        int n9 = -38;
        boolean[] blArray = new boolean[400];
        double[] dArray = new double[400];
        FuzzerUtils.init(blArray, false);
        FuzzerUtils.init(dArray, -83.109028);
        FuzzerUtils.init(nArray, 20);
        boolean bl = blArray[(n >>> 1) % 400] = -(51610.0f * (f + (float)n2)) >= (float)n;
        if (bFld) {
            Test.vMeth1();
        } else {
            if (bFld) {
                int n10 = (n2 >>> 1) % 400;
                dArray[n10] = dArray[n10] + (double)l;
                nArray[4] = nArray[4] + (int)d;
                for (n3 = 4; n3 < 212; ++n3) {
                    n4 -= n3;
                }
                vMeth_check_sum += (long)(n + n2) + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + l + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n8 + (long)n9 + (long)n7 + FuzzerUtils.checkSum(blArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + FuzzerUtils.checkSum(nArray);
                return;
            }
            n5 = 4;
            while (n5 < 356) {
                f = (float)d;
                n8 = (short)(n8 - (short)l);
                n9 = (byte)(n9 * (byte)n3);
                n2 = 156;
                n4 = n5++;
                n7 >>= n3;
            }
        }
        vMeth_check_sum += (long)(n + n2) + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + l + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n8 + (long)n9 + (long)n7 + FuzzerUtils.checkSum(blArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + FuzzerUtils.checkSum(nArray);
    }

    public static long lMeth(int n) {
        int n2 = 264;
        int n3 = -13;
        int n4 = -111;
        int n5 = 0;
        int n6 = -45591;
        int n7 = -136;
        int[] nArray = new int[400];
        float f = 0.68f;
        int n8 = 58;
        double d = 2.1149;
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(blArray, false);
        FuzzerUtils.init(nArray, -52597);
        n >>= n;
        n = n * n++;
        for (n2 = 1; n2 < 138; ++n2) {
            for (n4 = n2; 11 > n4; ++n4) {
                --n5;
                n5 = (int)((float)(-(++instanceCount) * (long)n5) + (f -= 1.0f));
                blArray[n4 + 1] = bFld;
                f += (float)n4;
                f += (float)(n4 * n2 + n5) - f;
                n += n4;
                n8 = (byte)(n8 - 1);
                n5 -= (int)((long)n8 - ((long)n5 - instanceCount--));
                nArray[n4] = 843992302;
                for (n6 = 1; 1 > n6; ++n6) {
                    n8 = (byte)(n8 + (byte)n--);
                    bFld = blArray[(n5 >>> 1) % 400];
                    Test.vMeth(n4, n6, d);
                }
            }
        }
        long l = (long)(n + n2 + n3 + n4 + n5 + Float.floatToIntBits(f) + n8 + n6 + n7) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(blArray) + FuzzerUtils.checkSum(nArray);
        lMeth_check_sum += l;
        return l;
    }

    public void mainTest(String[] stringArray) {
        int n = 258;
        int n2 = 59298;
        int n3 = -42890;
        int n4 = 41754;
        int n5 = 208;
        int n6 = -2850;
        int n7 = 0;
        int n8 = -49;
        int[] nArray = new int[400];
        double[] dArray = new double[400];
        FuzzerUtils.init(nArray, 17);
        FuzzerUtils.init(dArray, 2.30941);
        this.iFld = this.iFld;
        instanceCount *= this.lArrFld[(this.iFld >>> 1) % 400];
        this.iFld >>= this.iFld;
        this.iFld *= n;
        Test.lMeth(12);
        short[] sArray = this.sArrFld[13];
        int n9 = (this.iFld >>> 1) % 400;
        sArray[n9] = (short)(sArray[n9] >>> (short)this.iFld);
        nArray[(this.iFld >>> 1) % 400] = (int)instanceCount;
        for (n2 = 382; n2 > 12; n2 -= 2) {
            n3 += n2 + n2;
            if (bFld) break;
            int n10 = n2;
            nArray[n10] = nArray[n10] + n3;
        }
        this.iFld -= n2;
        int n11 = (n2 >>> 1) % 400;
        dArray[n11] = dArray[n11] + this.dFld;
        for (n4 = 213; n4 > 11; --n4) {
            nArray[n4] = n = (short)(n + (short)(n4 * n4));
            instanceCount += (long)n5;
            n6 = 1;
            do {
                n3 <<= n2;
                n3 = (int)((long)n3 + ((long)(n6 * n5 + n4) - (instanceCount -= (long)n4)));
                this.fFld += (float)((long)n6 ^ (long)n5);
                this.iFld += n;
                for (n7 = 1; n7 < 1; ++n7) {
                    this.iFld = (int)instanceCount;
                    if (!bFld) continue;
                    if (bFld) {
                        n = (short)instanceCount;
                        this.iFld = n2;
                        continue;
                    }
                    instanceCount += (long)this.dFld;
                }
            } while (++n6 < 124);
        }
        FuzzerUtils.out.println("s i15 i16 = " + (short)n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i17 i18 i19 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i20 i21 iArr3 = " + n7 + "," + n8 + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("dArr1 = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.bFld = " + instanceCount + "," + this.iFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("dFld fFld lArrFld = " + Double.doubleToLongBits(this.dFld) + "," + Float.floatToIntBits(this.fFld) + "," + FuzzerUtils.checkSum(this.lArrFld));
        FuzzerUtils.out.println("sArrFld = " + FuzzerUtils.checkSum(this.sArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}


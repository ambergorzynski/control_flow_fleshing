/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758).
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -26094L;
    public static short sFld = (short)14581;
    public static double dFld = 1.118493;
    public static volatile float fFld = 0.958f;
    public static int iFld = -3;
    public int iFld1 = 252;
    public byte byFld = (byte)-18;
    public static int[] iArrFld = new int[400];
    public static volatile double[] dArrFld = new double[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2(long l, long l2, int n) {
        int n2 = -3;
        int n3 = -1;
        int n4 = -6;
        int n5 = 9457;
        long l3 = -3691775292L;
        long[] lArray = new long[400];
        float f = 0.719f;
        double d = -93.76483;
        int n6 = 114;
        FuzzerUtils.init(lArray, -720L);
        for (int n7 : iArrFld) {
            Test.iArrFld[374] = (int)l2;
            n2 = 1;
            while (++n2 < 4) {
                for (l3 = 1L; l3 < 1L; ++l3) {
                    int n8 = -14;
                    l /= (long)f | 1L;
                    d -= (double)n8;
                    sFld = (short)n;
                }
                int n9 = n2;
                lArray[n9] = lArray[n9] << 1;
                for (n4 = 1; 1 > n4; ++n4) {
                    n5 *= n7;
                    l = n7;
                    d -= (double)n6;
                    f += (float)n7;
                    n3 = n;
                }
            }
        }
        vMeth2_check_sum += l + l2 + (long)n + (long)n2 + l3 + (long)n3 + (long)Float.floatToIntBits(f) + Double.doubleToLongBits(d) + (long)n4 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(lArray);
    }

    public static void vMeth1(int n, float f) {
        int n2 = 37289;
        int n3 = -4;
        int n4 = -172;
        int n5 = -7;
        int[] nArray = new int[400];
        boolean bl = false;
        int n6 = 62;
        FuzzerUtils.init(nArray, 19);
        for (n2 = 8; n2 < 164; n2 += 3) {
            n3 = (int)((float)n3 + ((float)n2 - f));
            int n7 = n2;
            nArray[n7] = nArray[n7] ^ n3;
            Test.vMeth2(instanceCount, instanceCount, -3);
            bl = true;
            block6: for (n4 = 1; n4 < 29; ++n4) {
                switch (n4 % 4 + 34) {
                    case 34: {
                        if (bl) {
                            n5 += n4;
                        } else {
                            n <<= -54;
                            n <<= n2;
                            n5 >>= (int)instanceCount;
                            dFld = instanceCount;
                        }
                        n5 += n3;
                        continue block6;
                    }
                    case 35: 
                    case 36: {
                        n3 += n6;
                        continue block6;
                    }
                    case 37: {
                        n -= n3;
                    }
                }
            }
        }
        vMeth1_check_sum += (long)(n + Float.floatToIntBits(f) + n2 + n3 + (bl ? 1 : 0) + n4 + n5 + n6) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth(long l, int n) {
        int n2 = 33301;
        int n3 = 218;
        int n4 = -11769;
        int n5 = 0;
        int[][][] nArray = new int[400][400][400];
        int[][][] nArray2 = new int[400][400][400];
        boolean bl = true;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 3660069573L);
        FuzzerUtils.init((Object[][])nArray, (Object)8);
        FuzzerUtils.init((Object[][])nArray2, (Object)521);
        n2 = 1;
        do {
            boolean bl2 = bl;
            bl = bl2;
            bl = bl2;
            if (bl2) break;
            instanceCount = instanceCount++ + instanceCount;
            l = n--;
            Test.vMeth1(n2, fFld);
            n3 = 1;
            while (++n3 < 4) {
                for (n4 = 1; 1 > n4; ++n4) {
                    n5 -= (int)instanceCount;
                    n += (int)instanceCount;
                    n <<= (int)instanceCount;
                    int n6 = n4 + 1;
                    lArray[n6] = lArray[n6] + instanceCount;
                    l = n3;
                }
            }
            nArray[n2][n2][n2 + 1] = n4;
            int[] nArray3 = nArray2[n2 + 1][n2];
            int n7 = n2++;
            nArray3[n7] = nArray3[n7] * 103;
        } while (n2 < 376);
        vMeth_check_sum += l + (long)n + (long)n2 + (long)(bl ? 1 : 0) + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum((Object[][])nArray) + FuzzerUtils.checkSum((Object[][])nArray2);
    }

    public void mainTest(String[] stringArray) {
        int n = -6;
        int n2 = -6;
        int n3 = -55858;
        int n4 = 13;
        int n5 = 64444;
        int n6 = -62932;
        int n7 = 29;
        int n8 = 40543;
        int n9 = 38042;
        boolean bl = false;
        double d = -1.44649;
        Test.vMeth(instanceCount, iFld);
        for (n = 8; n < 146; ++n) {
            int n10 = n - 1;
            iArrFld[n10] = iArrFld[n10] - n2;
            for (n3 = 2; n3 < 182; ++n3) {
                block11: for (n5 = 1; 2 > n5; ++n5) {
                    switch (n5 % 2 * 5 + 87) {
                        case 89: 
                        case 92: {
                            fFld = instanceCount;
                            break;
                        }
                        default: {
                            instanceCount += (long)n5;
                            if (bl) continue block11;
                            int n11 = n3 - 1;
                            dArrFld[n11] = dArrFld[n11] - (double)iFld;
                        }
                    }
                    if (bl) break;
                    d -= (double)n5;
                    d += (double)instanceCount;
                    this.iFld1 = this.iFld1;
                    try {
                        n6 = 88 % this.iFld1;
                        n4 = n2 % 322531754;
                        iFld = n2 % 15450;
                        continue;
                    } catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                }
                block12: for (n7 = 1; n7 < 2; ++n7) {
                    switch (n7 % 2 * 5 + 62) {
                        case 66: {
                            int n12 = n7;
                            iArrFld[n12] = iArrFld[n12] - this.byFld;
                            n6 -= 20927;
                            continue block12;
                        }
                        case 67: {
                            sFld = (short)(sFld >> (short)n2);
                            n2 = n6 += 9711 + n7 * n7;
                            continue block12;
                        }
                        default: {
                            Test.iArrFld[n3 + 1] = 33323;
                            n4 += 6912;
                            if (bl) {
                                n4 += n7 * this.iFld1 + n8 - iFld;
                                instanceCount += (long)n7;
                                continue block12;
                            }
                            if (bl) {
                                fFld += (float)((long)(n7 * n5) + instanceCount) - fFld;
                                n4 = n2;
                                continue block12;
                            }
                            n9 += -37699 + n7 * n7;
                        }
                    }
                }
            }
        }
        FuzzerUtils.out.println("i16 i17 i18 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i19 i20 i21 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("b2 d1 i22 = " + (bl ? 1 : 0) + "," + Double.doubleToLongBits(d) + "," + n7);
        FuzzerUtils.out.println("i23 i24 = " + n8 + "," + n9);
        FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.dFld = " + instanceCount + "," + sFld + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.fFld Test.iFld iFld1 = " + Float.floatToIntBits(fFld) + "," + iFld + "," + this.iFld1);
        FuzzerUtils.out.println("byFld Test.iArrFld Test.dArrFld = " + this.byFld + "," + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        } catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -6);
        FuzzerUtils.init(dArrFld, 0.19113);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}

